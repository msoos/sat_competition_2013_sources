#!/bin/sh
module load compiler/intel/12.0
cd code
make
cd ..
rm -rf binary
mkdir binary
cp code/probSATsc13 binary/probSATsc13
echo "build done"