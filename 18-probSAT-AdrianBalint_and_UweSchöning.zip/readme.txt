----------------------------------------------------------
probSAT version SC13
Authors: Adrian Balint
Ulm University - Institute of Theoretical Computer Science 
2013
----------------------------------------------------------

Usage of probSAT:
./probSAT [options] <DIMACS CNF instance> [<seed>]

probSAT options:
which function to use:
--fct <0,1> : 0 =  polynomial; 1 = exponential [default = 0]
--eps <double_value> : eps>0 (only valid when --fct 0)[default = 1.0]
which constant to use in the functions:
--cb <double_value> : constant for break [default = k dependet]

Further options:
--runs <int_value>, -r<int_value>  : maximum number of tries 
--maxflips <int_value> , -m<int_value>: number of flips per try 
--printSolution, -a : output assignment
--help, -h : output this help
----------------------------------------------------------
