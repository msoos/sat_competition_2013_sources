#!/bin/sh

rm -rf binary/sinn

cd code

export MROOT=$PWD

make -C core clean
make -C simp clean

