// Copyright (c) 2011, Jingchao Chen, Donghua University,China.  All rights reserved.

#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include "D_Constants.h"
#include "glue_Constants.h"
#include "interactSAT.h"
#include "glue_Solver.h"

void release_occCls(PPS *pps);
void free_mem(int * & ptr);
void release_free_pps (PPS * & pps);
void verify_output(int *solution);
void extend_solution(PPS *pps); 

extern double starttime;
double nowtime();
int originVars;
extern int *partSolution;
PPS *G_pps=0;
using namespace Minisat;

int MidSolver(char *CNFfile, int * & solution);

bool parity (unsigned x)
{ bool res = false; while (x) res = !res, x &= x-1; 
    return res; 
}

int load_glueclause(Solver* solver, PPS *pps)
{   
    bool ret;
    vec<Lit> lits;
    int numatom=pps->numVar;
    int *fixedvar=pps->unit;
    free_mem(pps->seen);
    int *Seen=pps->seen=(int *) calloc (solver->nVars()+1, sizeof (int));
	
    int i;
//CNF clause   
    int *pcls=pps->clause->begin();
    int *pend=pps->clause->end();
	while(pcls < pend){
         int len=*pcls;
	     int mark=len & MARKBIT;
		 len=len>>FLAGBIT;
		 int *litp=pcls+1;
                 pcls+=len;
		 if(mark==DELETED) continue;
		 if(mark==CNF_CLS){
			 lits.clear();
			 for (; litp<pcls; litp++){
		         int lit=*litp;
			 int vv=ABS(lit);
				if(fixedvar[vv]==0 || fixedvar[vv]==vv+1) {
           			        Seen[vv]=1;
					lits.push( (lit > 0) ? mkLit(lit-1) : ~mkLit(-lit-1) );	
				}
				else {
					if(fixedvar[vv]==lit) goto nextCNF;
				}
			 }
 		         ret=solver->addClause(lits); //close a clause
			 if(ret==false) return UNSAT;
		 }
nextCNF:
		 ;
	}
	for(i=1; i<=numatom; i++){
	    if(solver->assigns[i-1] != l_Undef) continue;
		if(fixedvar[i]) continue;
	    if(Seen[i]) continue;
       	fixedvar[i]=i+1;		// 0 occurrence
	}
    release_occCls(pps);
    free_mem(pps->seen);
    return _UNKNOWN;
}


vec<int> in_exMap;

int load_glueclause_Map(Solver* solver, PPS *pps,PPS *new_pps)
{   int i;
	bool ret;
    vec<Lit> lits;
	int Vn=1;
	int binclauses=0;
	int *ex_inMap=(int *) calloc (pps->numVar+1, sizeof (int));
//CNF clause
   	int *pcls=pps->clause->begin();
	int *pend=pps->clause->end();
	i=0;
	while(pcls < pend){
             int len=*pcls;
	     int mark=len & MARKBIT;
	     len=len>>FLAGBIT;
	     int *litp=pcls+1;
             pcls+=len;
	     if(mark==DELETED) continue;// bug 2011/9/25
	     if(mark==CNF_CLS){
		   lits.clear();
		   if(pcls-litp==2) binclauses++;
		   for (; litp<pcls; litp++){
		         int lit=*litp;
			 int vv=ABS(lit);
			 if(ex_inMap[vv]==0){
        			  while (Vn > solver->nVars()) solver->newVar();
                                  ex_inMap[vv]=Vn++;
                                  in_exMap.push(vv);
			 }
			vv=ex_inMap[vv]-1;
        		lits.push( (lit > 0) ? mkLit(vv) : ~mkLit(vv));	
	           }
	           ret=solver->addClause(lits); //close a clause
	           if(ret==false) return UNSAT;
             }
	 }
	 free(ex_inMap);
	 free_mem(pps->seen);
	 release_occCls(pps);
	 new_pps->numVar=Vn-1;
	 solver->binclauses=binclauses;
	 
	 printf("c binclauses=%d \n",binclauses);
         return _UNKNOWN;
}
//lit1 V lit2
void addbin(Solver* solver, int lit1, int lit2)
{  vec<Lit> lits;
   lits.clear();
  // printf("%d %d \n",lit1, lit2);
   lits.push( (lit1 > 0) ? mkLit(lit1-1) : ~mkLit(-lit1-1));	
   lits.push( (lit2 > 0) ? mkLit(lit2-1) : ~mkLit(-lit2-1));
   solver->addClause(lits);
}

void StardardAMO(Solver* solver, int sz, int *lits)
{    int j,k;
     for(j=0; j<sz-1; j++){
	  for(k=j+1; k<sz; k++)  addbin(solver, -lits[j],-lits[k]);
     }
}

void add2productAMO(Solver* solver,int & numVar,int *cls, int len)
{     int i,j,k,p,q;
      int newcls=0;
       	  
      int V[200], W[200];
      for(p=2; p<len; p++) if(p*p>=len) break;
      q=p-1;
      if(q*p<len) q=p;
      for(j=0; j<p; j++) V[j]=++numVar;
      for(j=0; j<q; j++) W[j]=++numVar;
 
      while (numVar > solver->nVars()) solver->newVar();
     
      int n=0;
      for(j=0; j<p; j++){
	   if(n>=len) break;
	   for(k=0; k<q; k++){
		 int lit=cls[n];
		 addbin(solver, -lit, V[j]);
                 addbin(solver, -lit,W[k]);
                 n++;
		 if(n>=len) break;
	   }
      }
      StardardAMO(solver,p,V);
      StardardAMO(solver,q,W);
}

int load_Edge_clause(Solver* solver, PPS *pps, int & numVar)
{       
	bool ret;
        vec<Lit> lits;
   	int *pcls=pps->clause->begin();
	int *pend=pps->clause->end();
        numVar=pps->numVar;
        while (numVar > solver->nVars()) solver->newVar();
        while(pcls < pend){
             int len=*pcls;
	     int mark=len & MARKBIT;
	     len=len>>FLAGBIT;
	     int *litp=pcls+1;
             int *cls=litp;
             pcls+=len;
	     if(mark==DELETED) continue;
	     if(mark==CNF_CLS){
		   lits.clear();
        	   for (; litp<pcls; litp++){
		        int lit=*litp;
                        lits.push( (lit > 0) ? mkLit(lit-1) : ~mkLit(-lit-1));
	           }
                   ret=solver->addClause(lits); //close a clause
	           if(ret==false) return UNSAT;
                   if(len>20){ // At most one
                          add2productAMO(solver,numVar, cls, len-1);
                   }
             }
	}
	return _UNKNOWN;
}

int final_solution(Solver * & solver, lbool ret, int * solution,vec<int> & in_ex_Map)
{
  	if(ret==l_True) {
		 int *iunit=solver->g_pps->unit;
      	         for (int i = 0; i < solver->nVars(); i++){
                 int eV=in_ex_Map[i];
		 if(solution[eV]) continue;
                 int iV=i+1;
		 if(iunit){
			 if(iunit[iV]){
                              if(iunit[iV]==iV) solution[eV]=eV;
			      if(iunit[iV]==-iV) solution[eV]=-eV;
			      continue;
			 }
		 }
		 if (solver->assigns[i] != l_Undef){
                         if(solver->assigns[i]==l_True) solution[eV]=eV;
			 else solution[eV]=-eV;
		 }
		 else solution[eV]=eV;
	 }
    }
    release_free_pps (solver->g_pps);
    delete solver;
    solver=0;
    if(ret==l_True)  return SAT;
    if(ret==l_False) return UNSAT;
    return _UNKNOWN;
}

void check(int sol[],Stack<int> *clause);
void displaySAT(Stack<int> *clause);
Solver *Gsolver=0;
//extern int EdgeMatch;

int EdgeMatch_Solver(PPS *pps)
{
    printf("c Edge Match problem\n");
   
    PPS * new_pps=(struct PPS *) calloc (1, sizeof (PPS));
    vec<Lit> dummy;
    lbool ret;
    Gsolver=new Solver();
    int rc=load_Edge_clause(Gsolver,pps,new_pps->numVar);

    printf("c new numVar=%d \n",new_pps->numVar);
    
    if(rc==UNSAT) goto ret_end;
    if (!Gsolver->simplify()) goto ret_end;

    Gsolver->g_pps=new_pps;
    Gsolver->SolvePolicy=0;
    Gsolver->FreeVarChange=0;
    Gsolver->verbosity = 1;
    Gsolver->con_limit=3000000;
    ret = Gsolver->solveLimited(dummy);
    if(ret!=l_True){
ret_end:
       delete Gsolver;
       return _UNKNOWN;
    }
   // 
    int *iunit=Gsolver->g_pps->unit;
    int *solution=pps->unit;
    for (int i = 0; i < pps->numVar; i++){
            int eV=i+1;
	    if(solution[eV]) continue;
            if(iunit){
		 if(iunit[eV]){
                      if(iunit[eV]==eV) solution[eV]=eV;
		      if(iunit[eV]==-eV) solution[eV]=-eV;
		      continue;
		 }
	    }
	    if (Gsolver->assigns[i] != l_Undef){
                if(Gsolver->assigns[i]==l_True) solution[eV]=eV;
		else solution[eV]=-eV;
	    }
	    else solution[eV]=eV;
    }
    release_free_pps (Gsolver->g_pps);
    delete Gsolver;
    return SAT;
}  

int Load_glueSolver(PPS *pps)
{ 
    printf("c Load_glueSolver \n");
  
    G_pps=pps;
    Gsolver=new Solver();
   
    Gsolver->verbosity = 1;
    Gsolver->random_var_freq = 0.1; 
   
    PPS * new_pps=(struct PPS *) calloc (1, sizeof (PPS));
	
    int rc=load_glueclause_Map(Gsolver, pps,new_pps);
	if(rc==UNSAT){
	     delete Gsolver;
  	     return UNSAT;
	}
	Gsolver->recursive=0;
 	if (!Gsolver->simplify()){
               printf("c UNSATISFIABLE by simplifying \n");
  	       return UNSAT;
	 }
  	vec<Lit> dummy;
	printf("c middle solver->nVars=%d solver->dec_vars=%d \n",Gsolver->nVars(),(int)Gsolver->dec_vars);
        Gsolver->g_pps=new_pps;

	delete pps->clause;
	pps->clause=0;
	if(pps->clausePos){
		delete pps->clausePos;
		pps->clausePos=0;
	}
	
        Gsolver->SolvePolicy=0;
        Gsolver->FreeVarChange=0;
        Gsolver->con_limit=100000;
      	lbool ret = Gsolver->solveLimited(dummy);
        if(ret==l_Undef) ret=Gsolver->interactSolve();
        return final_solution(Gsolver, ret, pps->unit, in_exMap);
}

int load_bigSAT(char *CNFfile, Solver* solver)
{
    bool ret;
    int i,lastc,nextc,lit;
    vec<Lit> lits;

    FILE *fp=fopen(CNFfile,"r");
    if(fp==NULL) {
	   printf("c Cann't open file %s \n", CNFfile);
	   exit(1);
    }
    while ((lastc = fgetc(fp)) == 'c'){
	    while ((nextc = fgetc(fp)) != EOF && nextc != '\n');
    }
    ungetc(lastc,fp);
	int numatom,numClauses;
    if (fscanf(fp,"p cnf %i %i",&numatom,&numClauses) != 2) {
	     printf("c Bad input file \n");
	     exit(1);
    }
    for(i = 0;i < numClauses;i++){
    	lits.clear();
        do {
		   if (fscanf(fp,"%i ",&lit) != 1) {
		        printf("c wrong CNF proposition \n");
		        exit(0);
		   }
	       if(lit != 0) {
         		int vv=ABS(lit);
			    while (vv > solver->nVars()) solver->newVar();
                vv--;
				lits.push( (lit > 0) ? mkLit(vv) : ~mkLit(vv));	
				if(vv>=numatom){
                      printf("c ERROR - extraneous literals\n");
	                  exit(0);
				}
			}
	  	} while(lit != 0);
		ret=solver->addClause(lits); //close a clause
		if(ret==false) return UNSAT;
	}
 	fclose(fp);
  	return _UNKNOWN;
}	

int Load_bigSolver(char *CNFfile,int * & solution)
{ 
    Solver *solver=new Solver();
   
    printf("c Load big Solver \n");
    
    solver->verbosity = 2;
    solver->random_var_freq = 0; //

    int rc=load_bigSAT(CNFfile, solver);
    if(rc==UNSAT){
	       delete solver;
               printf("s UNSATISFIABLE\n");
      	       exit(20);
	}
        solver->bigSAT=true;
        solver->SolvePolicy=4;
  	vec<Lit> dummy;
	lbool ret = solver->solveLimited(dummy);
  //  printStats(*solver);
//    printf(ret == l_True ? "s SATISFIABLE\n" : ret == l_False ? "s UNSATISFIABLE\n" : "s UNKNOWN\n");
       printf("c \nc  Running time=%f \n", nowtime()-starttime);
 	if(ret==l_True) {
         solution=(int *) calloc (solver->nVars()+1, sizeof (int));
	 	 for (int i = 1; i <= solver->nVars(); i++){
                 if (solver->assigns[i-1] != l_Undef){
                     if(solver->assigns[i-1]==l_True) solution[i]=i;
				     else solution[i]=-i;
				 }
		         else solution[i]=i;
		 }
        	 delete solver;
		 return SAT;
      	// verify_output(solution);
     	 //exit(10);
    }
     delete solver;
     if(ret==l_False) {
             printf("s UNSATISFIABLE\n");
             //return UNSAT;
	     exit(20);
    }
//    printf("s UNKNOWN\n");
    return _UNKNOWN;
   //	exit(0);
}

int load_SAT(char *CNFfile, int * & solution)
{
    int lastc,nextc;
   
    FILE *fp=fopen(CNFfile,"r");
    if(fp==NULL) {
	   printf("c Cann't open file %s \n", CNFfile);
	   exit(1);
    }
    while ((lastc = fgetc(fp)) == 'c'){
	    while ((nextc = fgetc(fp)) != EOF && nextc != '\n');
    }
    ungetc(lastc,fp);
    int numClauses;
    if (fscanf(fp,"p cnf %i %i",&originVars,&numClauses) != 2) {
	     printf("c Bad input file \n");
	     exit(1);
    }
	printf("c %d variable %d clauses \n", originVars, numClauses);
  	fclose(fp);
  
    if(numClauses>6000000 || originVars>2000000){
  		int rc=Load_bigSolver(CNFfile, solution);
		return rc;
    }
    int rc=MidSolver(CNFfile, solution);
    return rc;
} //--------------------------------------------
bool set_solver_solution(Solver * solver, int * solution,vec<int> & in_ex_Map)
{    int i,nV=solver->nVars();
     int *unit=solver->g_pps->unit;
     solver->cancelUntil(0);
  
     printf("c set_solver_solution \n");
  
     for (i = 0; i < nV; i++){
		 if (solver->assigns[i] != l_Undef) continue;
		 int v=i+1;
		 if(unit) if(unit[v]==v+1) continue; //not zero literal 
                 int eV=in_ex_Map[i];
		 if(solution[eV]==0) continue;
		 if(solution[eV]==eV+1) continue;
		 Lit p=(solution[eV]==eV)? mkLit(i) : ~mkLit(i);
		 solver->uncheckedEnqueue(p);
                 CRef confl=solver->propagate();
		 solver->simpDB_assigns=-1;
		 if (confl != CRef_Undef) return false;//UNSAT
     }
     return true;
}

void get_solver_solution(Solver * solver, int * solution, vec<int> & in_ex_Map)
{    int i,nV=solver->nVars();

     int *unit1=solver->g_pps->unit;
     solver->cancelUntil(0);
     for (i = 0; i < nV; i++){
	     if (solver->assigns[i] != l_Undef){
		   int v=i+1;
		   if(unit1) if(unit1[v]==v+1) continue; 
		   int eV=in_ex_Map[i];
		   if(solution[eV]) continue;
		   if(solver->assigns[i]==l_True) solution[eV]=eV;
		   else solution[eV]=-eV;
	      }
      }
}

int glue_cont_solve()
{  int rc;
   
   printf("c glue_cont_solve \n");
   bool ret=set_solver_solution(Gsolver, partSolution,in_exMap);
   if (!ret) {
          printf("c \ns UNSATISFIABLE\n"); 
	  exit(20);
   }
   Gsolver->recursive=-1;
   Gsolver->verbosity=2;
   int  DfreeVars=Gsolver->nFreeVars();
   //Gsolver->con_limit=100000;
 //  Gsolver->FreeVarChange=1;
   //if(Gsolver->nVars()-DfreeVars>=2 && DfreeVars<1000) {
      Gsolver->FreeVarChange=0;
      Gsolver->con_limit=300000;//vmpc_31
   //}
   lbool res=Gsolver->solve_();
   DfreeVars-=Gsolver->nFreeVars();
   if(res!=l_Undef) {
	rc=final_solution(Gsolver, res, G_pps->unit,in_exMap);
	if(rc==SAT){
		extend_solution(G_pps);
               // for(int i=1; i<=G_pps->numVar; i++){ 
               //      if(partSolution[i]==0) continue;
               //      if(partSolution[i]==G_pps->unit[i]) continue;
               //      printf("<%d  %d>",partSolution[i],G_pps->unit[i]);
               //      getchar();
               // }
                verify_output(G_pps->unit);
	        exit(10);
	 }
	if(rc==UNSAT){
             printf("c \ns UNSATISFIABLE\n"); 
	     exit(20);
         }
   }
   get_solver_solution(Gsolver, partSolution, in_exMap);
   printf("c clasp solve... \n");
   return _UNKNOWN;
} 
