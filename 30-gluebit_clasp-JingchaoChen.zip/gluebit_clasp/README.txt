gluebit_clasp -- Copyright (c) 2013, Jingchao Chen  Donghua University, China   
gluebit_clasp -- An hybird solver based on clasp for Hard-combinatorial SAT+UNSAT track. 
---------------------------------------
gluebit_clasp is distributed under the GNU Public License, see file LICENSE.txt for details.
It is written in (mostly) Standard-C++ and was successfully built and run under 
Linux (x86-32, x86-64) using gcc.

Detailed information (including a User's manual) can be found at: 
  http://potassco.sourceforge.net/

Distribution contents:
  COPYING      - GNU Public License
  README       - This file
  configure.sh - Simple script that creates Makefiles for building gluebit_clasp (library and application) 
  app/         - Source code directory of the command-line interface
  libclasp/    - Directory of the clasp (static) library (sources, documentation, unit tests)
  libprogram_opts/
               - Library for parsing command-line options (needed by app)
  glue_bit  - Source code directory of glue_bit, 
  tools/       - Some additional files

------------------------- 
For compiling : 
   ./build.sh


For running
binary/gluebit_clasp BENCHNAME

---------------------------------------  
Make-based Build & Install
--------------------------
You'll need to have the GNU Compiler Collection (GCC) version 3 or
better installed in order to build gluebit_clasp. You'll also need GNU 
make 3.80 or better.
Note: 
 In the following it is assumed that 'make' is an alias for the installed GNU make. If this
 is not the case on your system, replace 'make' with the name of the GNU make  executable (e.g. gmake)

To configure the build:
  The configure-script supports different build configurations/options.
  Type 
    ./configure.sh --help 
  to get an overview of all supported options.
  
To build gluebit_clasp:
  ./configure.sh
  cd build/release
  make
  
To install gluebit_clasp:
  make gluebit_clasp
	
  By default, 'make install' will install gluebit_clasp in '/usr/local/bin'
  You can specify an installation prefix other than '/usr/local' 
  by running the configure-script with the option '--prefix=PATH'.
  Alternatively, use option '--bindir=PATH' to directly specify the
  installation path. 

  Finally, you can always skip installation and simply copy the
  gluebit_clasp executable to a directory of your choice.
		
Usage
-----
	gluebit_clasp reads problem instances either from stdin, e.g 
	  cat problem | gluebit_clasp
	or from a given file, e.g
	  gluebit_clasp problem
	
	In addition to printing status information, gluebit_clasp also
	provides information about the computation via its exit status.
	The exit status is:
	  10: if the problem was found to be satisfiable
	  20: if the problem was proved to be unsatisfiable
	   0: if the satisfiability of problem is not known, 
	      because search was either interrupted or not started
	 127: if gluebit_clasp(clasp) ran out of memory
	Furthermore, the exit status of 1 indicates an error.


