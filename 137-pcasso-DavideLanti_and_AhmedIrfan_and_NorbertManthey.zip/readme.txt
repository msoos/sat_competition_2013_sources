pcasso version SAT Competition 2013
------------------------------------------
Authors:
------------------------------------------
code pcasso: Davide Lanti, Ahmed Irfan, Norbert Manthey - TU Dresden - norbert.manthey@tu-dresden.de
------------------------------------------

Compile & execute:
------------------------------------------
call the build.sh script 
cd binary
execute with ./cp3.sh <instance>
or execute with ./cp3-port.sh <instance>
------------------------------------------

Further Details
------------------------------------------
See SAT Competition 2013 solver description for further details!
------------------------------------------
