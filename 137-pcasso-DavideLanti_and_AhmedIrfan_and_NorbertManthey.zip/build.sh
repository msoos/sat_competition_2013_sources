#!/bin/sh
rm -rf binary
mkdir binary
cd code/pcasso; make r
cd ../../code/riss3g; make coprocessorRS
cd ../..
cp code/pcasso/pcasso binary/pcasso
cp code/riss3g/coprocessor binary/cp3
cp pcasso-port.sh pcasso.sh cp3-port.sh cp3.sh binary
