/*****************************************************************************************[lock.h]
Copyright (c) 2012,      Norbert Manthey

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/

#ifndef LOCK_H
#define LOCK_H

#include <cstdio>
#include <pthread.h>
#include <semaphore.h>

class Lock{

private:

	sem_t _lock;	// actual semaphore
	int _max;	// users for the semaphore (threads that are allowed to share the semaphore at the same time)
public:

	/** create an unlocked lock
	*
	* @param max specify number of maximal threads that have entered the semaphore
	*/
	Lock(int max = 1)
	 : _max( max )
	{
		// create semaphore with no space in it
		sem_init(&(_lock), 0, max);
	}
	
	/** release all used resources (nothing to do -> semaphore becomes invalid)
	*/
	~Lock(){
	}
	
	/** tries to lock
	* @return true, if locking was successful
	*/
	bool lock(){
		int err = sem_trywait( &_lock );
		return err == 0;
	}
	//@param transitive allow multiple locking of the same thread ?
	
	/** releases one lock again
	*
	* should only be called by the thread that is currently owns the lock
	*/
	void unlock(){
		sem_post( &_lock );
		//fprintf( stderr, "\n\nreleased lock %d\n\n" , (int)*(int*)(void*)&_lock );
	}

	/** waits until the lock is given to the calling thread
	*/	
	void wait(){
		//fprintf( stderr, "\n\nwait for lock %d\n\n" , (int)*(int*)(void*)&_lock );
		sem_wait( &_lock );
		//fprintf( stderr, "\n\nblog lock %d\n\n" , (int)*(int*)(void*)&_lock );
	}

	/** return numbers of waiters in the semaphore
	*/
	int getWaiters(){
	  int ret = 0;
	  sem_getvalue(&_lock, &ret);
	  return ret;
	}
};

#endif
