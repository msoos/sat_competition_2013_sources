#ifndef CLAUSE_H
#define CLAUSE_H

#include "mtl/Vec.h"
#include <iostream> // Davide> Debug

using namespace Minisat;

namespace davide{
  
  struct clause{
    unsigned int size;
    vec<Lit> lits;
    
    clause(){};
    // copy constructor required by push_back
    clause(const clause& c){
      size = c.size;
      c.lits.copyTo(lits);
    }
    clause& operator = (const clause& c){
      
      if( this != &c ){ // Davide> Self-copy protection
	lits.clear(true);
	c.lits.copyTo(lits);
	size = c.size;
      }
      return *this;
    }
  };

}

#endif
