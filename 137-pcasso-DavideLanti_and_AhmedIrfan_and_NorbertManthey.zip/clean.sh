#!/bin/sh
rm -rf binary
cd code/pcasso; make clean
cd ../../code/riss3g; make clean
