Compile: run ./build.sh

Usage: run the solver (in binary/) as follows

./march_br INSTANCE

With INSTANCE referring to the input formula.
