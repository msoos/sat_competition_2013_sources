cd code
make
rm *.o
cd ..
mv code/march_br binary/march_br
