./march_br $1 $2
tail=`tail -n 1 $2 | awk '{print $1}'` 
if [ $tail == 0 ]
then
  echo "o proof BDRUP" 
  cat $2
fi
