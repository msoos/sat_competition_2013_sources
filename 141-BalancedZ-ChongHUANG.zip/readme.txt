BalancedZ is complied by gcc with the following command:

gcc -O3 -static -m32 BalancedZ.c -o BalancedZ

BalancedZ should be called in the challenge using:

BalancedZ INSTANCE -seed RANDOMSEED

Copyright (C) 2013 Chong HUANG (jason_hch@hotmail.com) 

If you have any questions, please contact me or Chumin Li (chu-min.li@u-picardie.fr).

have fun

