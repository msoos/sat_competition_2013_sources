#!/bin/sh

mkdir binary

cd code

gcc -O3 -static -m32 BalancedZ.c -o BalancedZ

mv BalancedZ ../binary

