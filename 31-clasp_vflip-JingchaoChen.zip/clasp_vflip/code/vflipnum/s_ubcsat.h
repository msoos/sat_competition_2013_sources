/*

      ##  ##  #####    #####   $$$$$   $$$$   $$$$$$    
      ##  ##  ##  ##  ##      $$      $$  $$    $$      
      ##  ##  #####   ##       $$$$   $$$$$$    $$      
      ##  ##  ##  ##  ##          $$  $$  $$    $$      
       ####   #####    #####  $$$$$   $$  $$    $$      
  ======================================================
  SLS SAT Solver from The University of British Columbia
  ======================================================
  ...Developed by Dave Tompkins (davet [@] cs.ubc.ca)...
  ------------------------------------------------------
  .......consult legal.txt for legal information........
  ......consult revisions.txt for revision history......
  ------------------------------------------------------
  ... project website: http://www.satlib.org/ubcsat ....
  ------------------------------------------------------
  .....e-mail ubcsat-help [@] cs.ubc.ca for support.....
  ------------------------------------------------------

*/

#ifndef UBCSAT_H

#define UBCSAT_H

#ifdef _MSC_VER
#define _CRT_SECURE_NO_WARNINGS
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#ifdef _MSC_VER
#include "stdint.h"
#else
#include <stdint.h>
#endif //_MSC_VER

#include "s_mt19937ar.h"

#include "ubcsat-limits.h"
#include "ubcsat-types.h"

#include "ubcsat-lit.h"
#include "ubcsat-mem.h"
#include "ubcsat-time.h"
#include "ubcsat-io.h"
#include "ubcsat-internal.h"
#include "ubcsat-globals.h"
#include "ubcsat-triggers.h"

#include "s_algorithms.h"
#include "s_reports.h"

#include "s_mylocal.h"

#endif

