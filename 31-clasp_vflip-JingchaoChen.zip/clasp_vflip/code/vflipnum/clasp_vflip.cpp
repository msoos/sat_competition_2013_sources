/*
 clasp_vflip  Copyright (c) 2013, Jingchao Chen, Donghua University,China.
*/

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include "D_Constants.h"
#include <signal.h>
#include "interactSAT.h"
#include "MersenneTwister.h"

void displaySAT(Stack<int> *clause);
int originClauses;
float *size_diff;
int EdgeMatch=0;
int aux_numVar=0;
int aux_numClause=0;
int EdgeMatch_Solver(PPS *pps);
extern int eCutoff;
extern int eSeed;
extern int UnitClauseflag;

namespace ubcsat {
     int vflipnumMain(char * Filename);
}

MTRand mtrand(100);

void release_pps (PPS *pps);
void release_free_pps (PPS * & pps);
void release_occCls(PPS *pps);
void free_mem(int * & ptr);
void extend_solution(PPS *pps);

void verify_output(int *solution);
void init_weight();
void check(int sol[],Stack<int> *clause);
void readSATProblem(char *CNFfile, PPS * & pps);

/*
 * A signal handling function.
 * For handling user interuption (Ctrl+c).
 * Print out execution stats and exit.
 *
 */
void SIGINT_handler(int signum) 
{
  printf("c \n");
  printf("c \n");
  printf("c INTERRUPTED \n");
  printf("c Time used: %fs\n",get_cpu_time());
  exit(0); 
}

/*
 * A signal handling function. 
 * For handling segmentation fault.
 * 
 * Print out indicator message and exit.
 */
void SIGSEGV_handler(int signum) 
{
  printf("c \n");
  printf("c \n");
  printf("c SEGMENTATION FAULT \n");
  printf("c \ns UNKNOWN\n");
  printf("c \n");
  exit(0); 
}

//time measuring function
double nowtime() 
{
#ifdef _MSC_VER
#include <ctime>
    return (double)clock() / CLOCKS_PER_SEC;
#else
  struct rusage u;
  if (getrusage (RUSAGE_SELF, &u)) return 0;
  double res = u.ru_utime.tv_sec + 1e-6 * u.ru_utime.tv_usec;
  res += u.ru_stime.tv_sec + 1e-6 * u.ru_stime.tv_usec;
  return res;
#endif
}

char *FileName;
double starttime;
int claspmain(int argc, char *argv[]);

int iargc;
char *iargv[10];

int main(int  argc, char *argv[])
{
   signal(SIGINT,SIGINT_handler);
   signal(SIGSEGV,SIGSEGV_handler);
   srand(INIT_RANDOM_SEED);
   if (argc<2) {
       printf("c Using format: clasp_vflip CNF_file\n");
       exit(0);
//        FileName=filename;
   }
   else FileName=argv[1];
   printf("c clasp_vflip by Jingchao Chen, March 2013\n");
   printf("c input CNF file=%s \n",FileName);
   aux_numVar=0;
   mtrand.seed(10);
   PPS * pps; 

   readSATProblem(FileName, pps);
   printf("c Clause#=%d  var#=%d  ratio=%d EdgeMatch=%d\n",pps->numClause,pps->numVar,pps->numClause/pps->numVar,EdgeMatch);
   
   eSeed=123;
   if(EdgeMatch==0 && pps->numVar<50000 && pps->numClause<500000 && pps->numClause<150*pps->numVar){
   	    int trys=3;
          //if(pps->numVar<600) trys=6;
            if(pps->numVar<1000) eCutoff=20000000;
	    else eCutoff=4000000;
            for(int i=0; i<trys; i++){
	        ubcsat::vflipnumMain(FileName);
	        eSeed++;
                if(UnitClauseflag) eCutoff=3000000;
            }
     }


   release_pps (pps);
   iargc=argc;
   for(int i=0; i<argc; i++) iargv[i]=argv[i];
   int result=claspmain(argc, argv);
   if(EdgeMatch && result!=10){
         EdgeMatch=0;
         result=claspmain(iargc, iargv);
   }
   printf("c \nc  Running time=%f clasp result=%d\n", nowtime()-starttime,result); //SAT=10, UNSAT=20
   exit(result);
  
  // starttime=nowtime();
 /*
   int *solution;
   switch(result) 
   {    case SAT:
   	     verify_output(solution);
	     result=10;
	     exit(result);
        case UNSAT:
 	     printf("c \ns UNSATISFIABLE\n"); 
	     result=20;
            break;
	    default:
               printf("c \ns UNKNOWN\n");
	      result=0;
   }
   printf("c \nc Running time=%f \n", nowtime()-starttime);
   exit(result);
*/   
   return result;
}

/* 
 * Prints the current solution 
 */
void print_solution(int sol[],int numVar)
{   
    printf("v ");
   // if(numVar>100) numVar=100;
    //FILE *fp=fopen("solution.txt","w+t");
    for(int i=1; i<=numVar; i++) if(sol[i]) printf("%d ", sol[i]);
    //for(int i=1; i<=numVar; i++) if(sol[i]) fprintf(fp,"%d ", sol[i]);
    printf("\nv 0\n");
    printf("c \nc Running time=%f \n", nowtime()-starttime);
    //fprintf(fp," 0 \n");
    //fclose(fp);
}

void verify_output(int *solution)
{    PPS *s_pps;
     readSATProblem(FileName,s_pps);
     for(int i=1; i<=s_pps->numVar; i++){ 
	    if(solution[i]==0) solution[i]=i;
     }
     check(solution,s_pps->clause);
     printf("c \ns SATISFIABLE\n");
     print_solution(solution,s_pps->numVar);
     release_pps (s_pps);
}

int bigCls;

void aux_NumVar(int len)
{     int p,q;
       	  
      for(p=2; p<len; p++) if(p*p>=len) break;
      q=p-1;
      if(q*p<len) q=p;
      aux_numVar+=p+q;
      aux_numClause+=2*len+(p*(p-1))/2+(q*(q-1))/2;
}

void readSATProblem(char *CNFfile, PPS * & pps)
{
    int i,lastc,nextc,lit,size1=0,size2=0;
    int cnt1=0,cnt2=0;
    bigCls=0;
    static int reRead=0;
    FILE *fp=fopen(CNFfile,"r");
    if(fp==NULL) {
	   printf("c Cann't open file %s \n", CNFfile);
	   exit(1);
    }
    while ((lastc = fgetc(fp)) == 'c'){
	    while ((nextc = fgetc(fp)) != EOF && nextc != '\n');
    }
    ungetc(lastc,fp);
	int numatom,numClauses;
    if (fscanf(fp,"p cnf %i %i",&numatom,&numClauses) != 2) {
	     printf("c Bad input file \n");
	     exit(1);
    }

    originClauses=numClauses;
    pps=(struct PPS *) calloc (1, sizeof (PPS));
    pps->numClause=numClauses;
    pps->numVar=numatom;
    
    pps->clause=new Stack<int>; 
    Stack<int> * clsSAT=pps->clause;
    for(i = 0; i < numClauses; i++){
	    int clsbegin=clsSAT->nowpos();
	    clsSAT->push(0);
            do {
		   if (fscanf(fp,"%i ",&lit) != 1) {
		        printf("c wrong CNF proposition \n");
		        exit(0);
		   }
	           if(lit != 0) {
         		clsSAT->push(lit);
				if(ABS(lit)>numatom){
                      printf("c ERROR - incorrect problem format or extraneous characters\n");
	                  exit(0);
				}
			}

		} while(lit != 0);
                int len =clsSAT->nowpos()-clsbegin;
                (*clsSAT)[clsbegin]=(len<<FLAGBIT) | CNF_CLS;
                len--;
                if(len<16) continue;
                if(reRead==0){
                       bigCls++;
                       aux_NumVar(len);
                       if(size1==0)   { size1=len; cnt1++; continue;}
	               if(size1==len) { cnt1++; continue;}
                       if(size2==0)   { size2=len; cnt2++; continue;}
                       if(size2==len) { cnt2++; continue;}
                       reRead=1;
                }
	  }
          EdgeMatch=0;
          if(size1>20 && size1==cnt1/2 && size2>20 && size2==cnt2/2 && bigCls>20 && reRead==0){
            if(numatom>2000 && numatom<50000 && numClauses>20000 && numClauses <1000000 && numClauses <30*numatom && bigCls<1000 && numatom){
               printf("c %d size1=%d, %d size2=%d  bigCls=%d \n",cnt1, size1, cnt2, size2, bigCls);
               EdgeMatch=1;
            }
      }
      reRead=1;
      fclose(fp);
}	

void check(int sol[],Stack<int> *clause)
{
     int len,sum,i,vi;

	 int *pcls=clause->begin();
	 int *pend=clause->end();
	 i=0;
  
	 while(pcls < pend){
                 len=*pcls;
		// int mark=len & MARKBIT;
		 len=len>>FLAGBIT;
		 int *lits=pcls+1;
    	         pcls+=len;
                 sum=0; i++;
                 for (; lits<pcls; lits++){
		     vi=*lits;
       	             int xi= vi < 0 ? -vi : vi; 
                     if(sol) {
			   if(sol[xi]==vi) sum+=1;
		      }
		 }
//		 printf (" s=%d ",sum);
		 if(sum==0 && sol) {
        	      printf ("c result something wrong at i=%d !!!!! \n",i);
		      exit(0);
                      int *lits=pcls+1-len;
		      for (; lits<pcls; lits++){
		           vi=*lits;
       	                   int xi= vi < 0 ? -vi : vi; 
                           printf("%d[%d] ",vi,sol[xi]);
		       }
		       exit(0);
  	          }
   }
   printf("c verified \n");
 //  getchar();
}

void free_mem(int * & ptr)
{
	if(ptr) free(ptr);
	ptr=0;
}
void release_pps (PPS * pps)
{
	if(pps==0) return;
	if(pps->clause) {
		delete pps->clause;
		pps->clause=0;
	}
    release_occCls(pps);
	if(pps->clausePos){
		delete pps->clausePos;
		pps->clausePos=0;
	}
	free_mem(pps->unit);
	free_mem(pps->seen);
    free_mem(pps->outEquAtom);
    if(pps->n_inative) {
		free(pps->inaLit[0]);
		free(pps->inaLit);
		pps->n_inative=0;
    }
	if(pps->numXOR){
		pps->numVar=0;
		free(pps->Leq[0]);
		free(pps->Leq);
	}
    if(pps->inactiveVar){
		delete pps->inactiveVar;
		pps->inactiveVar=0;
	}
}

void release_free_pps (PPS * & pps)
{
	if(pps==0) return;
    release_pps (pps);
    free(pps);
	pps=0;
}

void release_occCls(PPS *pps) 
{
	if(pps->occCls){
		for(int i = 1; i <= pps->numVar; i++) {
	       pps->occCls[i].release();
	       pps->occCls[-i].release();
		}
	    pps->occCls-=pps->numVar;
	    free(pps->occCls);
        pps->occCls = 0;
	}
	if(pps->occBoth){
        for(int i = 1; i <= pps->numVar; i++) pps->occBoth[i].release();
	    free(pps->occBoth); 
        pps->occBoth=0;
	}
}
