#!/bin/bash

mkdir -p binary 
cd code
export MROOT=$PWD

cd simp
make rs
cp minisat_bit_static ../../binary/minisat_bit
 
