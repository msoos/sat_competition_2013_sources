#include <stdio.h>
#include <stdlib.h>

void main (int argc, char** argv) {
  int tmp, lit;
  int *data, size = 0, max = 10000000, *buffer, bsize;
  int blast = max, lsize = 0;

  FILE *input  = fopen(argv[1], "r");
  FILE *output = fopen("drup" , "w");

  data   = (int*) malloc (sizeof(int) * max);
  buffer = (int*) malloc (sizeof(int) * max);

  bsize = 0;
  do {
    tmp = fscanf (input, " %i ", &lit);
    if (tmp > 0) {
      buffer[ bsize++ ] = lit;

      if (lit == 0) {
        int i, flag;

        for (i = 0; i < bsize; i++) printf("%i ", buffer[ i ]);
        printf("\n");
        if (bsize == 1) break;
delete:
        flag = (bsize < blast);
        if (flag) {
          for (i = 0; i < bsize - 1; i++)
            if (data[ lsize + i ] != buffer[ i ]) flag = 0;
        }
        if (flag) {
          printf("d ");
          for (i = 0; i < blast; i++) printf("%i ", data[ lsize + i ]);
          printf("\n");
          size  = lsize;
          lsize--;
          blast = 1;
          while (data[ lsize - 1 ] != 0) {
            blast++;
            lsize--;
          }
          goto delete;
        }
        lsize = size;
        if (size + bsize >= max) {
          max = max * 2;
          data = (int *) realloc (data, sizeof(int) * max);
        }

        for (i = 0; i < bsize; i++) data[ size++ ] = buffer[ i ];
        blast = bsize;
        bsize = 0;
      }
    }
    else break;

  }
  while (1);

  fclose (input);
  fclose (output);
}
