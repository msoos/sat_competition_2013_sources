NB: Use this version of march_br only for k-SAT instances.
    In case the input file contains unit clauses or 
    equivalences, the proof may not be valid.

Notice that this version is optimized for performance on 
UNSATISFIABLE formulas. The default version of march_br
that does not emits proofs contains several optimizations
for SATISFIABLE formulas. Therefore, use the default 
version of march_br in case one does not expect the
input to be UNSATISFIABLE.

Compile: run ./build.sh

Usage: run the solver (in binary/) as follows

./march_br INSTANCE PROOF

With INSTANCE referring to the input formula and PROOF 
referring to the proof file in the BRUP format.

Checking: use the following script (in binary/) to verify 
the output of march_br

./check.sh INSTANCE PROOF TMPPROOF  

With INSTANCE referring to the input formula and PROOF 
referring to the proof emitted by the solver. The checker
first converts the PROOF file in BRUP format to the 
TMPPROOF file in DRUP format. The TMPPROOF format is
checked by a DRUP checker. The ./check script requires 
that the brup2drup and drup-check tools are in the same
directory.

