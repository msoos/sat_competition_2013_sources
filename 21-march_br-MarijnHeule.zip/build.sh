cd code
make
rm *.o
cd ..
mv code/march_br binary/march_br
cp tools/check.sh binary/check.sh
gcc tools/brup2drup.c -O2 -o binary/brup2drup
gcc tools/drup-check.c -O2 -o binary/drup-check
