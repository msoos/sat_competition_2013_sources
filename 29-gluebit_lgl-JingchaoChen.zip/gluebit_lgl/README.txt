gluebit_lgl -- Copyright (c) 2013, Jingchao Chen  Donghua University, China   
gluebit_lgl -- An hybird solver combining glue_bit and Lingeling 

gluebit_lgl sources are under the GNU General Public License Version 3.
See LICENSE.txt for more details.  

For compiling : 
   ./build.sh


For running 
binary/gluebit_lgl BENCHNAME

