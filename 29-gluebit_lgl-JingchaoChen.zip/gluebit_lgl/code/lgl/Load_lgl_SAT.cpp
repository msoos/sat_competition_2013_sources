/***************************************************************************************
 Copyright (c) 2013, Jingchao Chen, Donghua University,China.  All rights reserved.
---------------------------------------------------------
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/

#include "lglib.h"
#include <stdio.h>
#include <ctype.h>
#include "interactSAT.h"
#include "D_Constants.h"
#ifdef _MSC_VER
#include "glue_Vec.h"
#else
#include "glue_bit/glue_Vec.h"
#endif

void release_occCls(PPS *pps);
void free_mem(int * & ptr);
void release_free_pps (PPS * & pps);
void OutputSolution(LGL * lgl, int *unit,int *in_exMap);
int lglrem (LGL * lgl);

using namespace Minisat;
vec<int> in_exMap_l;
int *ex_inMap_l=0;
int load_lglclause_Map(LGL * lgl, PPS *pps)
{   int i;
	int Vn=1;
	int binclauses=0;
	ex_inMap_l=(int *) calloc (pps->numVar+1, sizeof (int));
//	for(Vn=1; Vn<=pps->numVar; Vn++){
  //       ex_inMap_l[Vn]=Vn;
    //     in_exMap_l.push(Vn);
   // }
        
//CNF clause   
   	 int *pcls=pps->clause->begin();
	 int *pend=pps->clause->end();
	 i=0;
	 while(pcls < pend){
         int len=*pcls;
	     int mark=len & MARKBIT;
		 len=len>>FLAGBIT;
		 int *litp=pcls+1;
         pcls+=len;
		 if(mark==DELETED) continue;
		 if(mark==CNF_CLS){
			 if(pcls-litp==2) binclauses++;
			 for (; litp<pcls; litp++){
		        int lit=*litp;
			    int vv=ABS(lit);
				if(ex_inMap_l[vv]==0){
                       ex_inMap_l[vv]=Vn++;
                       in_exMap_l.push(vv);
				}
				vv=ex_inMap_l[vv];
				lit=lit>0? vv: -vv;
				lgladd (lgl, lit);
			 }
		     lgladd (lgl, 0); //close a clause
		 }
	 }
	 free_mem(pps->seen);
	 release_occCls(pps);
	 return _UNKNOWN;
}

int assignSolution(LGL * & lgl, int res, int *solution, bool map)
{
    if (res == 10) {
		  int maxvar = lglmaxvar (lgl);
		  int i;
		  for (i = 1; i <= maxvar; i++) {//extern var 
             int lit;
		     lit = (lglderef (lgl, i) > 0) ? i : -i;
			 if(!map){
				 	if(solution[i]==0) solution[i]=lit;
			 }
			 else{
                 int eVar=in_exMap_l[i-1];
				 if(solution[eVar]==0) {
         				 if(lit<0) solution[eVar]=-eVar;
				         else solution[eVar]=eVar;
				 }
			 }
	   }
	   if(!map){
	//	    for (i = maxvar+1; i <=numatom; i++) {
      //   		 if(solution[i]==0) solution[i]=i;//x=y and x,y are unfixed,  
		//	}
	   }
       lglrelease (lgl);
	   lgl=0;
  	   return SAT;
  } 
  lglrelease (lgl);
  lgl=0;
  if (res == 20) return UNSAT;
  return _UNKNOWN;
}

LGL * lgl_solver;
void lgl_loadunit(int *unit,int numatom)
{
    for(int vv=1; vv<=numatom; vv++){
          int lit=unit[vv];
		  if(lit==0) continue; 
          if(lit==vv+1) continue; 
		  if(ex_inMap_l[vv]==0) continue;
		  int iv=ex_inMap_l[vv];
		  lit=lit>0? iv: -iv;
		  int val=lglideref(lgl_solver, lit);
	      if(val) continue;
		  int ilit=lglimport (lgl_solver, lit);
		  lglunit (lgl_solver, ilit);
	}
//	getchar();
}

int Load_lglSolver(PPS *pps, int & DfreeVars,int conf_limit)
{ 
	lgl_solver = lglinit ();

	int verbose=2;
    lglsetopt (lgl_solver, "verbose", verbose);

    load_lglclause_Map(lgl_solver, pps);

	setconf_limit(lgl_solver, conf_limit);

	int res = lglsat (lgl_solver,DfreeVars);

//out:    
	if(res==0) {
	    OutputSolution(lgl_solver, pps->unit, in_exMap_l);
		return _UNKNOWN;
	}
    return assignSolution(lgl_solver, res, pps->unit,true);
}

int lgl_cont_Solver(PPS *pps, int & DfreeVars,int conf_limit)
{
	setconf_limit(lgl_solver, conf_limit);

    lgl_loadunit(pps->unit, pps->numVar);

	int res=lgl_continue_solve(lgl_solver, DfreeVars);
	if(res==0) {
	    OutputSolution(lgl_solver, pps->unit, in_exMap_l);
		return _UNKNOWN;
	}
    return assignSolution(lgl_solver, res, pps->unit, true);
}

void delete_lgl_solver()
{
	if(lgl_solver){
		lglrelease (lgl_solver);
	    lgl_solver=0;
  	}
    if(ex_inMap_l) {
		free(ex_inMap_l);
		ex_inMap_l=0;
	}
} 	 

int lgl_freeVars()
{
	return lglrem (lgl_solver);
}

