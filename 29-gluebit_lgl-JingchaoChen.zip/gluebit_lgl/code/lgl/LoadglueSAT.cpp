/***************************************************************************************
 Copyright (c) 2013, Jingchao Chen, Donghua University,China.  All rights reserved.
---------------------------------------------------------
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/

#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include "D_Constants.h"
#include "interactSAT.h"

#ifdef _MSC_VER
#include "glue_Constants.h"
#include "glue_Solver.h"
#else
#include "glue_bit/glue_Constants.h"
#include "glue_bit/bit_Solver.h"
#endif

void release_occCls(PPS *pps);
void free_mem(int * & ptr);
void release_free_pps (PPS * & pps);
void verify_output(int *solution);

extern double starttime;
double nowtime();
using namespace Minisat;

void extend_unit_solution(Solver * solver);
int Load_lglSolver(PPS *pps, int & deltaFreeV, int conf_limit);
int lgl_cont_Solver(PPS *pps, int & DfreeVars, int conf_limit);
void delete_lgl_solver();
int MidSolver(char *CNFfile, int * & solution);

int lgl_freeVars();
int numatom,numClauses;
int lgl_load=0;
	
bool parity (unsigned x)
{ bool res = false; while (x) res = !res, x &= x-1; 
    return res; 
}

vec<int> in_exMap1;
int *ex_inMap1=0;
int load_glueclause_Map(Solver* solver, PPS *pps,PPS *new_pps,vec<int> & in_exMap, int * & ex_inMap)
{   int i;
	bool ret;
    vec<Lit> lits;
	int binclauses=0;
	int FreeVarNo=in_exMap1.size();
	int Vn=1+FreeVarNo;
//CNF clause   
   	 int *pcls=pps->clause->begin();
	 int *pend=pps->clause->end();
	 i=0;
	 while (FreeVarNo > solver->nVars()) solver->newVar();

   	 while(pcls < pend){
         int len=*pcls;
	     int mark=len & MARKBIT;
		 len=len>>FLAGBIT;
		 int *litp=pcls+1;
         pcls+=len;
		 if(mark==DELETED) continue;
		 if(mark==CNF_CLS){
			 lits.clear();
			// int disp=0;
			// if(pcls-litp<3) {disp=1;printf("\n%d: ", i++);}
			 if(pcls-litp==2) binclauses++;
			 for (; litp<pcls; litp++){
		        int lit=*litp;
			//	if(disp) printf("%d ",lit);
			    int vv=ABS(lit);
				if(ex_inMap[vv]==0){
        			   while (Vn > solver->nVars()) solver->newVar();
                       ex_inMap[vv]=Vn++;
                       in_exMap.push(vv);
				}
				vv=ex_inMap[vv]-1;
        		lits.push( (lit > 0) ? mkLit(vv) : ~mkLit(vv));	
			 }
			 ret=solver->addClause(lits); //close a clause
			 if(ret==false) return UNSAT;
		 }
	 }
	 free_mem(pps->seen);
	 release_occCls(pps);
	 new_pps->numVar=Vn-1;
     solver->binclauses=binclauses;
	 return _UNKNOWN;
}

void check(int sol[],Stack<int> *clause);
void displaySAT(Stack<int> *clause);

int final_solution(Solver * & solver, lbool ret, int * solution,vec<int> & in_exMap)
{
  	if(ret==l_True) {
		 int *iunit=solver->g_pps->unit;
      	 for (int i = 0; i < solver->nVars(); i++){
                 int eV=in_exMap[i];
		         if(solution[eV]) continue;
                 int iV=i+1;
				 if(iunit){
					 if(iunit[iV]){
                       if(iunit[iV]==iV) solution[eV]=eV;
				       if(iunit[iV]==-iV) solution[eV]=-eV;
			           if(solution[eV]) continue;
                  	 }
				 }
		         if (solver->assigns[i] != l_Undef){
                     if(solver->assigns[i]==l_True) solution[eV]=eV;
				     else solution[eV]=-eV;
				 }
				 else solution[eV]=eV;
		 }
    }
    release_free_pps (solver->g_pps);
    delete solver;
 	solver=0;
 	if(ret==l_True)  return SAT;
	if(ret==l_False) return UNSAT;
   	return _UNKNOWN;
}

int Load_glueSolver(PPS *pps, int SolvePolicy, Solver * & solver)
{ 
    solver=new Solver();
	solver->verbosity = 2;
	solver->SolvePolicy=SolvePolicy;

   	PPS * new_pps=(struct PPS *) calloc (1, sizeof (PPS));
    solver->g_pps=new_pps;
    
	int rc=load_glueclause_Map(solver, pps,new_pps, in_exMap1,ex_inMap1);
	if(rc==UNSAT) return final_solution(solver, l_False, (int *)0,in_exMap1);
    solver->assumptions.clear();
   	return _UNKNOWN;
}

int load_bigSAT(char *CNFfile, Solver* solver)
{
    bool ret;
    int i,lastc,nextc,lit;
    vec<Lit> lits;

    FILE *fp=fopen(CNFfile,"r");
    if(fp==NULL) {
	   printf("c Cann't open file %s \n", CNFfile);
	   exit(1);
    }
    while ((lastc = fgetc(fp)) == 'c'){
	    while ((nextc = fgetc(fp)) != EOF && nextc != '\n');
    }
    ungetc(lastc,fp);
    if (fscanf(fp,"p cnf %i %i",&numatom,&numClauses) != 2) {
	     printf("c Bad input file \n");
	     exit(1);
    }
//	printf("c rate=%d \n",numClauses/numatom);
   // if(numatom>1500 || numClauses/50<numatom) //vmpc
    if((numClauses<6000000 && numatom<2000000) || (numClauses<10000000 && numatom<400000)){
         fclose(fp);
         solver->bigSAT=false;
         return _UNKNOWN;
    }

    for(i = 0;i < numClauses;i++){
    	lits.clear();
        do {
		   if (fscanf(fp,"%i ",&lit) != 1) {
		        printf("c wrong CNF proposition \n");
		        exit(0);
		   }
	       if(lit != 0) {
         		int vv=ABS(lit);
			    while (vv > solver->nVars()) solver->newVar();
                vv--;
				lits.push( (lit > 0) ? mkLit(vv) : ~mkLit(vv));	
				if(vv>=numatom){
                      printf("c ERROR - extraneous literals\n");
	                  exit(0);
				}
			}
	  	} while(lit != 0);
		ret=solver->addClause(lits); //close a clause
		if(ret==false) return UNSAT;
	}
 	fclose(fp);
        solver->bigSAT=true;
  	return _UNKNOWN;
}	

int Load_bigSolver(char *CNFfile,int * & solution)
{ 
    Solver *solver=new Solver();
   
    solver->verbosity = 1;
    solver->random_var_freq = 0; //

    int rc=load_bigSAT(CNFfile, solver);
//    printf("c Running time=%f \n", nowtime()-starttime);
    if(rc==UNSAT){
	 delete solver;   
     	 return UNSAT;
    }
    if(solver->bigSAT==false){
	  delete solver;
    	  return MidSolver(CNFfile,solution);
    }
  
	printf("c big instance \n");

	solver->SolvePolicy=4;
  	vec<Lit> dummy;
	lbool ret = solver->solveLimited(dummy);

    //printStats(*solver);

//    printf("c Running time=%f \n", nowtime()-starttime);
 	if(ret==l_True) {
         solution=(int *) calloc (solver->nVars()+1, sizeof (int));
	 	 for (int i = 1; i <= solver->nVars(); i++){
                 if (solver->assigns[i-1] != l_Undef){
                     if(solver->assigns[i-1]==l_True) solution[i]=i;
				     else solution[i]=-i;
				 }
		         else solution[i]=i;
		 }
     	 delete solver;
		 return SAT;
    }
	delete solver;
	if(ret==l_False) return UNSAT;
 	return _UNKNOWN;
   //  printf("s UNKNOWN\n");
//   	exit(0);
}

bool set_solver_solution(Solver * solver, int * solution,vec<int> & in_exMap)
{    int i,nV=solver->nVars();

     int *unit=solver->g_pps->unit;
	 solver->cancelUntil(0);
   	 for (i = 0; i < nV; i++){
		  	 if (solver->assigns[i] != l_Undef) continue;
			 int v=i+1;
			 if(unit) if(unit[v]==v+1) continue; //not zero literal 
             int eV=in_exMap[i];
		     if(solution[eV]==0) continue;
		     if(solution[eV]==eV+1) continue;
			 Lit p=(solution[eV]==eV)? mkLit(i) : ~mkLit(i);
		     solver->uncheckedEnqueue(p);
             CRef confl=solver->propagate();
			 solver->simpDB_assigns=-1;
			if (confl != CRef_Undef) return false;//UNSAT
	 }
	 return true;
}

void get_solver_solution(Solver * solver, int * solution, vec<int> & in_exMap)
{    int i,nV=solver->nVars();

     //if(solver->g_pps->unit==0) solver->g_pps->unit=(int *) calloc (nV+1, sizeof (int));
     int *unit1=solver->g_pps->unit;
   	 solver->cancelUntil(0);
   	 for (i = 0; i < nV; i++){
		  	 if (solver->assigns[i] != l_Undef){
				  int v=i+1;
				  if(unit1) if(unit1[v]==v+1) continue; 
				  int eV=in_exMap[i];
			      if(solution[eV]) continue;
		          if(solver->assigns[i]==l_True) solution[eV]=eV;
				  else solution[eV]=-eV;
			 }
	 }
}

int InteractSolver( PPS *pps)
{
    printf("c interactive solving cls#=%d var#=%d \n", pps->numClause, pps->numVar);
	int i;
	bool ret;
	int kk,rc,nF0;	
	int conf_limit;
	int dsum,lglconf_limit,max;
	int crypt_restart_inc;

	lbool res;
   	Solver * solver[3];
   	int DfreeVars[6],maxave=100000;

        solver[0]=solver[1]=solver[2]=0;
  	if(numClauses>4000000 && numClauses>28*pps->numVar){//11pipe_k.cnf
           lglconf_limit=0x7fffffff;
           goto lgl_solve;
	}


	if(ex_inMap1==0) ex_inMap1=(int *) calloc (pps->numVar+1, sizeof (int));

	dsum=0;
	for(i=0; i<3; i++){
	   rc=Load_glueSolver(pps, i, solver[i]);
           if(rc==UNSAT) goto solvend;
	    
           solver[i]->con_limit=3000;
	   solver[i]->restartLimit=10;
   	     
	   ret=set_solver_solution(solver[i], pps->unit,in_exMap1);
           if (!ret) {rc=UNSAT; goto solvend;}
     	    
	   DfreeVars[i]=solver[i]->nFreeVars();
      	   res=solver[i]->solve_();
	   DfreeVars[i]-=solver[i]->nFreeVars();
      	   dsum+=DfreeVars[i];
	   if(res!=l_Undef) {
			 if(res==l_True) extend_unit_solution(solver[i]);
			 rc=final_solution(solver[i], res, pps->unit,in_exMap1);
             goto solvend;   
		 }
	     get_solver_solution(solver[i], pps->unit,in_exMap1);
		 maxave=solver[0]->maxave;
	 }
	//printf("dsum=%d ",dsum);
     nF0=solver[0]->nFreeVars();
     for(kk=0; kk<4 && dsum && nF0<10000; kk++){
	   for(i=0; i<3; i++){
         solver[i]->con_limit=80000;
		 solver[i]->restartLimit=2000;
         ret=set_solver_solution(solver[i], pps->unit,in_exMap1);
         if (!ret) {rc=UNSAT; goto solvend;}
     	 DfreeVars[i]=solver[i]->nFreeVars();
      	 res=solver[i]->solve_();
		 DfreeVars[i]-=solver[i]->nFreeVars();
      	 if(res!=l_Undef) {
			          if(res==l_True) extend_unit_solution(solver[i]);
			          rc=final_solution(solver[i], res, pps->unit,in_exMap1);
                      goto solvend;   
		  }
	      get_solver_solution(solver[i], pps->unit, in_exMap1);
	   }
	}
	lglconf_limit=2000;
	DfreeVars[3]=DfreeVars[4]=0;
lgl_solve:  	
	rc=Load_lglSolver(pps, DfreeVars[3],lglconf_limit);
    lgl_load=1;
	if(rc!=_UNKNOWN) goto solvend;
	
	delete pps->clause;
	pps->clause=0;
	if(pps->clausePos){
		delete pps->clausePos;
		pps->clausePos=0;
	}

	max=0;
    conf_limit=500;
	for(kk=0; 1; kk++){
		for(i=0; i<3; i++){
	        solver[i]->con_limit=1500;
	     	solver[i]->restartLimit=10;
   	  		solver[i]->FreeVarChange=0;
            if(DfreeVars[i]>DfreeVars[max]) max=i;
		}
		int lvars=lgl_freeVars();
		int gvar=solver[max]->nFreeVars();
    	if(maxave<200){
			if(kk<10){
				if((kk>2) && DfreeVars[max]==0 && (int)solver[2]->conflicts/2000<(int)solver[2]->starts){
		    		max=2;
			 		if(solver[0]->conflicts/2000>solver[0]->starts) max=0;
				}
				else max=0;
			//	if(DfreeVars[max]==0) max=2;
			}
		}
		else{
			if(kk<4 && DfreeVars[max]==0 && gvar<8000) max=2;
		}
		if(kk<5 && gvar<10000 || gvar<1300) max=2;    
		//printf(" max=%d maxave=%d ",max,maxave);
	    //solver[max]->FreeVarChange=1;
	
		if(conf_limit<=10000){
			if(DfreeVars[3]>DfreeVars[max]){
			   if(DfreeVars[3]/2>DfreeVars[max]) conf_limit=10000;
               else {
	             if(maxave<250)	conf_limit=1000;
				 else{
					 if(conf_limit<10000) conf_limit=3000;
				 }
			   }
			   if(conf_limit<10000 && DfreeVars[max]>0) solver[max]->FreeVarChange=1;
			}		
           else  {
		 	   if(conf_limit<10000 || DfreeVars[3]+1<DfreeVars[max]/8 || (DfreeVars[3]==0 && DfreeVars[max]==0 && lvars>gvar-gvar/10)) {
			    	solver[max]->FreeVarChange=1;
				    conf_limit=500;
			   }
			   else{
	             if(lvars<gvar-gvar/10) conf_limit=10000;
			   }
		   }
		}
	
		if(DfreeVars[2]==0 && solver[2]->conflicts/20000>solver[2]->starts) {
			max=0;
			if(kk<6){
				solver[1]->FreeVarChange=1;
			    solver[1]->con_limit=50000;
			}
			solver[2]->con_limit=0;
		}		
    
		if((maxave<100 || gvar<8000) && DfreeVars[3]<2*DfreeVars[max]+3) {
			solver[max]->FreeVarChange=1;
			conf_limit=200;
		}
	
		if(conf_limit>=10000 && kk>25 && DfreeVars[max]==0) {
			solver[max]->FreeVarChange=0;
			conf_limit=12000;
		}
		
		if(kk<100){
			if(DfreeVars[max]) {
				solver[max]->FreeVarChange=1;
            	conf_limit=500;
			}
			solver[max]->con_limit=30000;
		}
		
		if(solver[max]->conflicts<90*solver[max]->starts && maxave<1000 && maxave>100 && solver[max]->nFreeVars()<30000) max=0; //md5 sha0
		
		if(solver[max]->FreeVarChange) solver[max]->con_limit=50000;
		
        printf("c Dfreevars[%d]=%d nF=%d maxave=%d \n",max,DfreeVars[max],DfreeVars[3],maxave);
	  //  getchar();

		for(i=0; i<3; i++){
               ret=set_solver_solution(solver[i], pps->unit,in_exMap1);
               if (!ret) {rc=UNSAT; goto solvend;}
     	       if(solver[i]->con_limit==0) continue;
			   DfreeVars[i]=solver[i]->nFreeVars();
      	       res=solver[i]->solve_();
		       DfreeVars[i]-=solver[i]->nFreeVars();
      	       if(res!=l_Undef) {
			          if(res==l_True) extend_unit_solution(solver[i]);
			          rc=final_solution(solver[i], res, pps->unit,in_exMap1);
                      goto solvend;   
			   }
	           get_solver_solution(solver[i], pps->unit, in_exMap1);
		}
		rc=lgl_cont_Solver(pps, DfreeVars[3],conf_limit);
		if(rc!=_UNKNOWN) goto solvend;
	}
solvend:
	for(i=0; i<3; i++){
	    if(solver[i]){
		    release_free_pps(solver[i]->g_pps);
		    delete solver[i];
		}
	}
    if(ex_inMap1) free(ex_inMap1);
    if( lgl_load){
	delete_lgl_solver();
    }
	return rc;
}
//------------------------------------------------------------------
Solver *G_solver;
vec<int> in_exMap2;
int *ex_inMap2=0;
void new_glueSolver(int exVars)
{
	   G_solver=new Solver();
	   G_solver->binclauses=0;
       in_exMap2.clear();
       ex_inMap2=(int *) calloc (exVars+1, sizeof (int));
}

bool glue_addclause (Stack<int> & lits, int num)
{
	vec<Lit> glits;
	if(num==2) G_solver->binclauses++;
	
    int i=0;
	for(i=0; i<num; i++) {
        int lit=lits[i]; 
		int vv=ABS(lit);
		if(ex_inMap2[vv]==0){
        		 int Vn=G_solver->newVar();
                 ex_inMap2[vv]=Vn+1;
                 in_exMap2.push(vv);
		}
		vv=ex_inMap2[vv]-1;
       	glits.push( (lit > 0) ? mkLit(vv) : ~mkLit(vv));	
	}
	bool ret=G_solver->addClause(glits);
	return ret;
}

bool glue_addxorclause (Stack<int> & lits, int xorlen, int & exVar)
{
 	int xbuf[10];
	int size;

	Stack<int> sub_lits;
	for(int pos=0; pos<xorlen; pos+=size){
	     if(xorlen<=4) size=xorlen;
		 else{
			 if(pos+3>=xorlen) size=xorlen-pos;
			 else size=2;
		 }
		 int xs;
		 for(xs=0;xs<size; xs++) xbuf[xs]=lits[pos+xs];
		 if(pos)  xbuf[xs++]=exVar++;
		 if(size!=xorlen-pos) xbuf[xs++]=-exVar;
		 unsigned pow2=1<<xs;
      	 unsigned int j;
		 for(j=0; j<pow2; j++){ // XOR -> CNF
		   	   if(parity(j)) continue;
           	   unsigned bits=j;
		       sub_lits.shrink(0);
       		   for(int k=0; k<xs; k++) {
				     int lit=xbuf[k];
					 if(bits & 1) lit=-lit;
	                 sub_lits.push(lit);
					 bits=bits>>1;
        	   }
		       bool ret=glue_addclause(sub_lits, xs);
			   if(!ret) return false;
		 }
	}
	return true;
}

int glue_solve(int exVars,int * & solution)
{
	G_solver->verbosity = 1;
    G_solver->random_var_freq=0; 
    G_solver->SolvePolicy=4;
    PPS * new_pps=(struct PPS *) calloc (1, sizeof (PPS));
	new_pps->numVar=G_solver->nVars();
    G_solver->g_pps=new_pps;
   
//	printf("c glue solve... Var#=%d dec_vars=%d \n",G_solver->nVars(),(int)G_solver->dec_vars);

   	vec<Lit> dummy;
	lbool ret = G_solver->solveLimited(dummy);
    
	solution=(int *) calloc (exVars+1, sizeof (int));
	return final_solution(G_solver, ret, solution,in_exMap2);
}

