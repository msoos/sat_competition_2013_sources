#!/bin/bash
export FM=$PWD/sources/SatElite/ForMani
rm -rf gluebit_lgl_static 

cd ../../glue_bit/core
make clean 

find . -name 'depend.mak' -delete 
find . -name 'depend.mk' -delete 
