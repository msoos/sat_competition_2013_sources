#!/bin/bash
#export FM=$PWD/code/SatELite/ForMani

mkdir -p binary
cd code/lgl
make rs
cp gluebit_lgl_static ../../binary/gluebit_lgl
 
