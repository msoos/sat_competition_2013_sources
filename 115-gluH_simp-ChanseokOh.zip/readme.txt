HOW TO BUILD
------------

To build, `cd' into where `build.sh' is located.

   $ ./build.sh

This will generate and place `gluH_static' under `./binary'.



EXECUTION
---------

    $ ./gluH_static <input CNF>
