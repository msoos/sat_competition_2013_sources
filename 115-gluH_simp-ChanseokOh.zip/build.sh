#!/bin/bash

EXEDIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )

cd $EXEDIR/code/simp
make clean
rm -f $EXEDIR/binary/gluH_static

make rs
mkdir -p $EXEDIR/binary
cp -f gluH_static $EXEDIR/binary
