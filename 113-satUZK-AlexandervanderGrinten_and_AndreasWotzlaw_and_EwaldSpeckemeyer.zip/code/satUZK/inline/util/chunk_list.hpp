
template<typename Type, int PerChunk>
class chunk_list {
private:
	struct chunk {
		Type elems[PerChunk];
		chunk *next_ptr;
	};
	
	chunk *p_start, *p_head;
	int p_list_length, p_head_length;
	
public:
	class iterator {
	private:
		friend class chunk_list;
		int p_index; /* index from the start of the list */
		int p_offset; /* index from the start of the chunk */
		chunk *p_chunk;
		
		iterator(int index, int offset, chunk *the_chunk)
			: p_index(index), p_offset(offset), p_chunk(the_chunk) { }
		
	public:
		bool operator== (const iterator &other) const {
			return p_index == other.p_index;
		}
		bool operator!= (const iterator &other) const {
			return p_index != other.p_index;
		}
		Type operator* () const {
			return p_chunk->elems[p_offset];
		}
		Type &operator* () {
			return p_chunk->elems[p_offset];
		}

		void operator++ () {
			p_index++;
			p_offset++;
			if(p_offset == PerChunk) {
				p_offset = 0;
				p_chunk = p_chunk->next_ptr;
			}
		}
	};

private:
	chunk *p_alloc_chunk() {
		chunk *the_chunk = new chunk();
//		std::cout << "alloc " << the_chunk << std::endl;
		return the_chunk;
	}
	void p_free_chain(chunk *the_chunk) {
		while(the_chunk != NULL) {
			chunk *next_ptr = the_chunk->next_ptr;
//			std::cout << "delete " << the_chunk << std::endl;
			delete the_chunk;
			the_chunk = next_ptr;
		}
	}
	void p_ensure_space() {
		if(p_head_length != PerChunk)
			return;
		chunk *new_head = p_alloc_chunk();
		new_head->next_ptr = NULL;
		p_head->next_ptr = new_head;
		p_head = new_head;
		p_head_length = 0;
	}

public:
	typedef uint32_t size_type;
	
	chunk_list() : p_list_length(0), p_head_length(0) {
		p_start = p_alloc_chunk();
		p_start->next_ptr = NULL;
		p_head = p_start;
	}
	chunk_list(chunk_list &&other) : p_start(other.p_start),
			p_head(other.p_head),
			p_list_length(other.p_list_length),
			p_head_length(other.p_head_length) {
		other.p_start = NULL;
		other.p_head = NULL;
		other.p_list_length = 0;
		other.p_head_length = 0;
	}
	~chunk_list() {
		p_free_chain(p_start);
		p_start = NULL;
		p_head = NULL;
	}
	
	iterator begin() {
		return iterator(0, 0, p_start);
	}
	iterator end() {
		return iterator(p_list_length, p_head_length, p_head);
	}
	size_type size() {
		return p_list_length;
	}

	void push_back(Type elem) {
		p_ensure_space();
		p_head->elems[p_head_length] = elem;
		p_head_length++;
		p_list_length++;
	}
	void erase(iterator &it) {
		if(it == end()) {
			cut_before(it);
			return;
		}
		
		iterator last = it;
		while(true) {
			iterator next = last;
			++next;
			if(next == end())
				break;
			++last;
		}
		
		*it = *last;
		cut_before(last);
	}
	
	void cut_before(iterator &it) {
		if(it == end())
			return;
		p_head = it.p_chunk;
		p_head_length = it.p_offset;
		p_list_length = it.p_index;
		p_free_chain(it.p_chunk->next_ptr);
		it.p_chunk->next_ptr = NULL;
	}
	void clear() {
		p_head_length = 0;
		p_list_length = 0;
		p_free_chain(p_head->next_ptr);
		p_head->next_ptr = NULL;
	}
};

