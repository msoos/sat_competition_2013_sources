
namespace util {

template<class RandomAccessIterator, class UniformRandomNumberGenerator>
void shuffle(RandomAccessIterator first, RandomAccessIterator last, 
		UniformRandomNumberGenerator &&generator) {
	typedef typename std::uniform_int_distribution<unsigned int> distribution_type;
	
	unsigned int count = last - first;
	if(count == 0)
		return;
	for(unsigned int i = count - 1; i > 0; --i) {
		distribution_type distrib(0, i);
		std::swap(first[i], first[distrib(generator)]);
	}
}

};

