
template<typename Hooks>
void fle2_visit(Hooks &hooks,
		typename Hooks::literal_type literal,
		unsigned int &next_preorder,
		unsigned int &next_postorder,
		std::vector<unsigned int> &preorder,
		std::vector<unsigned int> &postorder,
		std::vector<typename Hooks::literal_type> &stack) {
	SYS_ASSERT(SYS_ASRT_GENERAL, preorder[literal] == 0);
	preorder[literal] = next_preorder++;
	stack.push_back(literal);

	if(hooks.lit_true(literal))
		return;
	if(hooks.lit_false(literal))
		return;

	auto inverse = hooks.lit_inverse(literal);
	if(preorder[inverse] != 0 && postorder[inverse] == 0) {
		/* the inverse is a parent of this node in the dfs tree
			i.e. it is a failed literal */
		if(hooks.lit_false(literal)) {
			SYS_CRITICAL("FLE2 conflict\n");
		}else if(!hooks.lit_true(literal)) {
			hooks.push_assign(literal, Hooks::antecedent_type::make_decision());
			hooks.stat.simp.fle2_literals++;
			hooks.propagate();
			if(hooks.at_conflict())
				SYS_CRITICAL("FLE2 conflict\n");
		}
	}

	for(auto i = hooks.big_begin(literal);
			i != hooks.big_end(literal); ++i) {
		auto dest = (*i).literal;
		if(preorder[dest] != 0)
			continue;
		fle2_visit(hooks, dest, next_preorder, next_postorder,
				preorder, postorder, stack);
	}

	postorder[literal] = next_postorder++;
}

template<typename Hooks>
void fle2_check(Hooks &hooks,
		typename Hooks::literal_type literal,
		std::vector<unsigned int> &preorder,
		std::vector<unsigned int> &postorder,
		std::vector<bool> &discarded,
		std::vector<typename Hooks::literal_type> &stack) {
	unsigned int next_preorder = 1;
	unsigned int next_postorder = 1;
	
	fle2_visit(hooks, literal, next_preorder, next_postorder,
			preorder, postorder, stack);

	auto root_inverse = hooks.lit_inverse(literal);
	bool root_failed = (preorder[root_inverse] != 0);

	for(auto i = stack.begin(); i != stack.end(); ++i) {
		auto inverse = hooks.lit_inverse(*i);
		if(!root_failed) {
			discarded[*i] = true;
		}else if(preorder[inverse] == 0) {
			discarded[*i] = true;
		}else if(preorder[*i] > preorder[inverse]
				|| postorder[*i] > postorder[inverse]) {
			discarded[*i] = true;
		}
	}
	for(auto i = stack.begin(); i != stack.end(); ++i) {
		preorder[*i] = 0;
		postorder[*i] = 0;
	}
	stack.clear();
}

template<typename Hooks, typename RndEngine>
void fle2_eliminate_random(Hooks &hooks, RndEngine &rnd_engine,
		unsigned int num_runs) {
	std::vector<unsigned int> preorder;
	std::vector<unsigned int> postorder;
	std::vector<bool> discarded;
	std::vector<typename Hooks::literal_type> stack;

	unsigned int lit_count = hooks.p_var_config.count() * 2;
	preorder.resize(lit_count, 0);
	postorder.resize(lit_count, 0);
	discarded.resize(lit_count, false);

	std::uniform_int<typename Hooks::variable_type> distrib
			(0, hooks.p_var_config.count());

	unsigned int skipped = 0;
	for(unsigned int i = 0; i < num_runs; ++i) {
		typename Hooks::variable_type var = distrib(rnd_engine);
		
		auto zero_lit = hooks.zero_literal(var);
		if(!discarded[zero_lit]) {
			fle2_check(hooks, zero_lit, preorder, postorder, discarded, stack);
		}else skipped++;
		
		auto one_lit = hooks.one_literal(var);
		if(!discarded[one_lit]) {
			fle2_check(hooks, one_lit, preorder, postorder, discarded, stack);
		}else skipped++;
	}
	std::cout << "Skipped: " << skipped << std::endl;
	
	hooks.eliminate_facts();
	hooks.delete_queue_process();
	hooks.install_queue_process();
}

template<typename Hooks>
void fle2_eliminate_all(Hooks &hooks) {
	std::vector<unsigned int> preorder;
	std::vector<unsigned int> postorder;
	std::vector<bool> discarded;
	std::vector<typename Hooks::literal_type> stack;

	unsigned int lit_count = hooks.p_var_config.count() * 2;
	preorder.resize(lit_count, 0);
	postorder.resize(lit_count, 0);
	discarded.resize(lit_count, false);

	unsigned int skipped = 0;
	for(typename Hooks::variable_type var = 0;
			var < hooks.p_var_config.count(); ++var) {
		auto zero_lit = hooks.zero_literal(var);
		if(!discarded[zero_lit]) {
			fle2_check(hooks, zero_lit, preorder, postorder, discarded, stack);
		}else skipped++;
		
		auto one_lit = hooks.one_literal(var);
		if(!discarded[one_lit]) {
			fle2_check(hooks, one_lit, preorder, postorder, discarded, stack);
		}else skipped++;
	}
	std::cout << "Skipped: " << skipped << std::endl;
	
	hooks.eliminate_facts();
	hooks.delete_queue_process();
	hooks.install_queue_process();
}

