
namespace problem {
namespace sat {
namespace first_uip {

struct lit_info {
	static const uint8_t TOUCHED = 1;
	static const uint8_t MARKED = 2;
	static const uint8_t MIN_CHECKED = 16;
	static const uint8_t MIN_IMPLIED = 32;
	static const uint8_t LIT_IN_CUT = 64;
	static const uint8_t LIT_IN_MIN = 128;
	uint8_t flags;

	bool is_touched() {
		return (flags & TOUCHED) != 0;
	}
	void set_touched() {
		flags |= TOUCHED;
	}
};

template<typename Variable, typename Literal>
struct config_struct {
	typedef Variable variable_type;
	typedef Literal literal_type;
	typedef lit_info varinfo_type;

	typedef uint64_t levelsig_type;
	
	static levelsig_type levelsig_make(uint64_t level) {
		return (1 << (level % (sizeof(levelsig_type) * 8)));
	}

	typedef std::vector<literal_type> var_vector;
	typedef typename var_vector::iterator var_iterator;
	
	typedef std::vector<literal_type> lit_vector;
	typedef typename lit_vector::iterator lit_iterator;

	std::vector<varinfo_type> var_array;
	
	var_vector touched;
	/* all literals that are part of the original clause */
	var_vector cut_clause;
	/* literals that are part of the minimized clause */
	lit_vector min_clause;
	/* literals that were visited at the current decision level */
	var_vector curlevel_vars;

	levelsig_type levelsig;

	unsigned int min_length;

	config_struct() : levelsig(0), min_length(0) { }

	typename var_vector::size_type cut_size() {
		return cut_clause.size();
	}
	var_iterator begin_cut() {
		return cut_clause.begin();
	}
	var_iterator end_cut() {
		return cut_clause.end();
	}

	typename lit_vector::size_type min_size() {
		return min_clause.size();
	}
	literal_type min_get(typename lit_vector::size_type index) {
		return min_clause[index];
	}
	lit_iterator begin_min() {
		return min_clause.begin();
	}
	lit_iterator end_min() {
		return min_clause.end();
	}

	var_iterator begin_curlevel() { return curlevel_vars.begin(); }
	var_iterator end_curlevel() { return curlevel_vars.end(); }
};

template<typename Config, typename Hooks>
void initialize(Config &config, Hooks &hooks,
		typename Hooks::variable_type num_vars) {
	config.var_array.resize(num_vars);
	for(typename Hooks::variable_type i = 0; i < num_vars; i++)
		config.var_array[i].flags = 0;
}

template<typename Config, typename Hooks>
void reset(Config &config, Hooks &hooks) {
	for(auto it = config.touched.begin(); it != config.touched.end(); ++it)
		config.var_array[*it].flags = 0;
	config.touched.clear();
	config.cut_clause.clear();
	config.min_clause.clear();
	config.curlevel_vars.clear();
	config.levelsig = 0;
	config.min_length = 0;
}

template<typename Config, typename Hooks>
__attribute__((always_inline)) inline void visit_variable(Config &config, Hooks &hooks,
		typename Hooks::variable_type cause_var,
		typename Hooks::order_type &link_counter) {
	typename Config::varinfo_type &cause_info = config.var_array[cause_var];
	if((cause_info.flags & Config::varinfo_type::MARKED) != 0)
		return;
	if(hooks.var_declevel(cause_var) == 1)
		return;

	/* mark cause literals; increment activity */
	config.touched.push_back(cause_var);
	cause_info.flags |= Config::varinfo_type::TOUCHED;
	cause_info.flags |= Config::varinfo_type::MARKED;
	hooks.on_var_activity(cause_var);

	if(hooks.var_declevel(cause_var) < hooks.cur_declevel()) {
		/* add decision variables to the clause */
		cause_info.flags |= Config::varinfo_type::LIT_IN_CUT;
		cause_info.flags |= Config::varinfo_type::LIT_IN_MIN;
		config.min_length++;
		config.levelsig |= Config::levelsig_make(hooks.var_declevel(cause_var));
		config.cut_clause.push_back(cause_var);
	}else{
		config.curlevel_vars.push_back(cause_var);
		link_counter++;
	}
}

template<typename Config, typename Hooks>
__attribute__((always_inline)) inline void visit_antecedent(Config &config, Hooks &hooks,
		typename Hooks::variable_type var,
		typename Hooks::order_type &link_counter) {
	auto antecedent = hooks.var_antecedent(var);
	hooks.on_antecedent_activity(antecedent);
	for(auto i = hooks.causes_begin(var); i != hooks.causes_end(var); ++i)
		visit_variable(config, hooks, hooks.lit_getvar(*i), link_counter);
}

template<typename Config, typename Hooks>
__attribute__((always_inline)) inline void cut(Config &config, Hooks &hooks,
		typename Hooks::conflict_iterator begin,
		typename Hooks::conflict_iterator end) {
	typedef typename Hooks::literal_type literal_type;
	
	/* reserve space for the first uip */
	SYS_ASSERT(SYS_ASRT_GENERAL, config.cut_clause.size() == 0);
	config.cut_clause.push_back((literal_type)Hooks::ILLEGAL_LIT);

	/* visit the causes of both the unit assignment
			and the inverse unit assignment */
	typename Hooks::order_type link_counter = 0;
	for(auto i = begin; i != end; ++i) {
		SYS_ASSERT(SYS_ASRT_GENERAL, hooks.lit_true(*i));
		auto var = hooks.lit_getvar(*i);
		visit_variable(config, hooks, var, link_counter);
	}
	
	typename Hooks::order_type order = hooks.cur_order();
	while(true) {
		SYS_ASSERT(SYS_ASRT_GENERAL, order > 0);
		order--;

		typename Hooks::literal_type literal = hooks.order_get(order);
		typename Hooks::variable_type var = hooks.lit_getvar(literal);
		typename Config::varinfo_type &var_info = config.var_array[var];
		SYS_ASSERT(SYS_ASRT_GENERAL, hooks.var_declevel(var) == hooks.cur_declevel());
	
		if((var_info.flags & Config::varinfo_type::MARKED) == 0)
			continue;
		
		link_counter--;
		if(link_counter == 0) {
			/* add the first-uip to the clause */
			if(!var_info.is_touched()) {
				config.touched.push_back(var);
				var_info.set_touched();
			}
			var_info.flags |= Config::varinfo_type::LIT_IN_CUT;
			var_info.flags |= Config::varinfo_type::LIT_IN_MIN;
			config.min_length++;
			config.levelsig |= Config::levelsig_make(hooks.cur_declevel());
			config.cut_clause[0] = var;
			break;
		}else{
			visit_antecedent(config, hooks, var, link_counter);
		}
	}
}

/* checks whether a given literal is implied by the conflict clause */
template<typename Config, typename Hooks>
__attribute__((always_inline)) inline bool min_lit_implied(Config &config, Hooks &hooks,
		typename Hooks::literal_type literal) {
	typename Hooks::variable_type var = hooks.lit_getvar(literal);
	typename Hooks::declevel_type declevel = hooks.var_declevel(var);
	if((config.levelsig & Config::levelsig_make(declevel)) == 0
			&& declevel != 1)
		return false;

	/* literals that are part of the clause are obviously
			implied by the clause */
	typename Config::varinfo_type &var_info = config.var_array[var];
	if((var_info.flags & Config::varinfo_type::LIT_IN_CUT) != 0) {
		/* the conflict clause will only contain literals that
			are currently false */			
		if(hooks.lit_true(literal))
			return true;
		return false;
	}
	
	/* ignore variables at decision level 1 */
	if(hooks.var_declevel(var) == 1)
		return true;

	/* decision variables of that are not in the clause
			are obviously not implied by the clause */
	typename Hooks::antecedent_type antecedent = hooks.var_antecedent(var);
	if(antecedent.is_decision())
		return false;
	
	/* cache implication information */
	if((var_info.flags & Config::varinfo_type::MIN_CHECKED) != 0)
		return (var_info.flags & Config::varinfo_type::MIN_IMPLIED) != 0;

	/* otherwise a literal is implied if all its causes are implied */
	if(min_antecedent_implied(config, hooks, antecedent)) {
		if(!var_info.is_touched()) {
			config.touched.push_back(var);
			var_info.set_touched();
		}
		var_info.flags |= Config::varinfo_type::MIN_CHECKED;
		var_info.flags |= Config::varinfo_type::MIN_IMPLIED;
		return true;
	}else{
		if(!var_info.is_touched()) {
			config.touched.push_back(var);
			var_info.set_touched();
		}
		var_info.flags |= Config::varinfo_type::MIN_CHECKED;
		return false;
	}
}

/* checks whether all causes are implied by the conflict clause */
template<typename Config, typename Hooks>
bool min_antecedent_implied(Config &config, Hooks &hooks,
		typename Hooks::antecedent_type antecedent) {
	for(auto i = hooks.causes_begin(antecedent);
			i != hooks.causes_end(antecedent); ++i) {
		if(!min_lit_implied(config, hooks, *i))
			return false;
	}
	return true;
}

template<typename Config, typename Hooks>
__attribute__((always_inline)) inline void minimize(Config &config, Hooks &hooks) {
	minimize_recursive(config, hooks);
	
	if(hooks.opts.learn.minimize_glucose
			&& config.min_length < 30) {
		hooks.lbd_init();
		for(auto it = config.begin_cut(); it != config.end_cut(); ++it) {
			typename Config::varinfo_type &var_info = config.var_array[*it];
			if((var_info.flags & Config::varinfo_type::LIT_IN_MIN) == 0)
				continue;
			hooks.lbd_insert(hooks.var_declevel(*it));
		}
		for(auto it = config.begin_cut(); it != config.end_cut(); ++it) {
			typename Config::varinfo_type &var_info = config.var_array[*it];
			if((var_info.flags & Config::varinfo_type::LIT_IN_MIN) == 0)
				continue;
			hooks.lbd_cleanup(hooks.var_declevel(*it));
		}
		
		if(hooks.lbd_result() <= 6) {
			typename Hooks::variable_type uip_var = config.cut_clause[0];
			typename Hooks::literal_type uip_lit = hooks.lit_true(hooks.one_literal(uip_var))
					? hooks.one_literal(uip_var) : hooks.zero_literal(uip_var);
			minimize_big(config, hooks, uip_lit);
		}
	}
}

template<typename Config, typename Hooks>
void minimize_recursive(Config &config, Hooks &hooks) {
	for(auto it = config.begin_cut(); it != config.end_cut(); ++it) {
		/* ignore literals whose antecedent is implied
				by the conflict clause */
		typename Hooks::antecedent_type antecedent = hooks.var_antecedent(*it);
		if(antecedent.is_decision())
			continue;
		if(!min_antecedent_implied(config, hooks, antecedent))
			continue;
		
		typename Config::varinfo_type &var_info = config.var_array[*it];
		var_info.flags &= ~Config::varinfo_type::LIT_IN_MIN;
		config.min_length--;
	}
}

/* the inverse of the given literal must be part of the conflict clause! */
template<typename Config, typename Hooks>
void minimize_big(Config &config, Hooks &hooks,
		typename Hooks::literal_type literal) {
	for(auto i = hooks.big_begin(literal);
			i != hooks.big_end(literal); ++i) {
		auto dest_lit = (*i).literal;
		auto dest_var = hooks.lit_getvar(dest_lit);
		typename Config::varinfo_type &dest_info = config.var_array[dest_var];
		if((dest_info.flags & Config::varinfo_type::LIT_IN_CUT) == 0)
			continue;
		if((dest_info.flags & Config::varinfo_type::LIT_IN_MIN) == 0)
			continue;
		dest_info.flags &= ~Config::varinfo_type::LIT_IN_MIN;
		config.min_length--;
	}
}

template<typename Config, typename Hooks>
__attribute__((always_inline)) inline void build(Config &config, Hooks &hooks) {
	SYS_ASSERT(SYS_ASRT_GENERAL, config.cut_clause.size() > 0);
	
	typename Hooks::variable_type uip_var = config.cut_clause[0];
	typename Config::varinfo_type &uip_info = config.var_array[uip_var];
	SYS_ASSERT(SYS_ASRT_GENERAL, (uip_info.flags & Config::varinfo_type::LIT_IN_CUT) != 0);
	SYS_ASSERT(SYS_ASRT_GENERAL, (uip_info.flags & Config::varinfo_type::LIT_IN_MIN) != 0);
	SYS_ASSERT(SYS_ASRT_GENERAL, hooks.var_declevel(uip_var) == hooks.cur_declevel());
	
	/* find the second watched literal */
	typename Hooks::variable_type watch = Hooks::ILLEGAL_VAR;
	for(auto it = config.begin_cut() + 1; it != config.end_cut(); ++it) {
		typename Hooks::variable_type var = *it;
		typename Config::varinfo_type &info = config.var_array[var];
		SYS_ASSERT(SYS_ASRT_GENERAL, hooks.var_declevel(var) != hooks.cur_declevel());
		if((info.flags & Config::varinfo_type::LIT_IN_MIN) == 0)
			continue;
		
		SYS_ASSERT(SYS_ASRT_GENERAL, (info.flags & Config::varinfo_type::LIT_IN_CUT) != 0);
		if(watch == Hooks::ILLEGAL_VAR || hooks.var_declevel(var)
				> hooks.var_declevel(watch))
			watch = var;
	}
	
	/* build an array containing all literals of the minimized clause
		where the 0th element is the uip and the
		1st element is from the second decision level */
	SYS_ASSERT(SYS_ASRT_GENERAL, config.min_clause.size() == 0);
	config.min_clause.push_back(hooks.lit_true(hooks.one_literal(uip_var))
			? hooks.zero_literal(uip_var) : hooks.one_literal(uip_var));
	if(watch != Hooks::ILLEGAL_VAR)
		config.min_clause.push_back(hooks.lit_true(hooks.one_literal(watch))
				? hooks.zero_literal(watch) : hooks.one_literal(watch));
	for(auto it = config.begin_cut() + 1; it != config.end_cut(); ++it) {
		typename Hooks::variable_type var = *it;
		typename Config::varinfo_type &info = config.var_array[var];
		if((info.flags & Config::varinfo_type::LIT_IN_MIN) == 0)
			continue;
		if(var == watch)
			continue;
		config.min_clause.push_back(hooks.lit_true(hooks.one_literal(var))
				? hooks.zero_literal(var) : hooks.one_literal(var));
	}
}

}}}; /* namespace problem::sat::first_uip */

