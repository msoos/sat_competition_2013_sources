
template<typename Hooks>
void unhiding_stamp(Hooks &hooks,
		typename Hooks::literal_type literal,
		typename Hooks::literal_type this_root,
		unsigned int depth,
		unsigned int &next_timestamp,
		std::vector<unsigned int> &observed,
		std::vector<unsigned int> &preorder,
		std::vector<unsigned int> &postorder,
		std::vector<typename Hooks::literal_type> &root,
		std::vector<typename Hooks::literal_type> &parent,
		std::vector<typename Hooks::literal_type> &stack,
		unsigned int &stat_equiv, unsigned int &stat_failed,
		unsigned int &stat_transitive,
		unsigned int &stat_num_lits, unsigned int &stat_depth_sum) {
	SYS_ASSERT(SYS_ASRT_GENERAL, !hooks.p_var_config.get_varflag_deleted(hooks.lit_getvar(literal)));
	SYS_ASSERT(SYS_ASRT_GENERAL, preorder[literal] == 0);
	next_timestamp++;
	preorder[literal] = next_timestamp;
	observed[literal] = next_timestamp;
	root[literal] = this_root;
	stack.push_back(literal);

	bool scc_root = true;
	for(auto i = hooks.big_begin(literal);
			i != hooks.big_end(literal); ++i) {
		/* skip transitive edges */
		if((*i).flags == 1)
			continue;

		auto dest = (*i).literal;
		auto inverse = hooks.lit_inverse(dest);

		/* check if we found a transitive edge */
		if(preorder[literal] < observed[dest]) {
			/* mark the edges (and reverse edge) as transitive */
			auto rev_lit = hooks.lit_inverse(dest);
			auto rev_dest = hooks.lit_inverse(literal);
			auto rev_it = hooks.big_find(rev_lit, rev_dest);
			SYS_ASSERT(SYS_ASRT_GENERAL, rev_it != hooks.big_end(rev_lit));
			SYS_ASSERT(SYS_ASRT_GENERAL, (*rev_it).flags == 0);
			(*i).flags = 1;
			(*rev_it).flags = 1;
			hooks.p_var_config.set_litflag_big_removed(literal);
			hooks.p_var_config.set_litflag_big_removed(rev_lit);
				
			hooks.stat.simp.unhide_transitive++;
			stat_transitive++;
			continue;
		}

		/* if a literal and its inverse are both observed
			from the same root all common ancestors
			of the literal are failed */
		if(preorder[this_root] <= observed[inverse]) {
			/* find the last common ancestor */
			typename Hooks::literal_type failed = literal;
			while(preorder[failed] > observed[inverse])
				failed = parent[failed];
			hooks.fact_queue_push(hooks.lit_inverse(failed));
			hooks.stat.simp.unhide_failed++;
			stat_failed++;

			if(preorder[inverse] != 0 && postorder[inverse] == 0)
				continue;
		}
		
		if(preorder[dest] == 0) {
			parent[dest] = literal;
			unhiding_stamp(hooks, dest, this_root, depth + 1, next_timestamp,
					observed, preorder, postorder, root, parent, stack,
					stat_equiv, stat_failed, stat_transitive,
					stat_num_lits, stat_depth_sum);
		}
		
		/* check if we found a backward edge */
		if(postorder[dest] == 0 && preorder[dest] < preorder[literal]) {
			preorder[literal] = preorder[dest];
			scc_root = false;
		}
		observed[dest] = next_timestamp;
	}

	/* there were no backward edges, this literal is the head
		of a strongly connected component */
	if(scc_root) {
		next_timestamp++;
		typename Hooks::literal_type equivalent;
		do {
			equivalent = stack.back();
			stack.pop_back();
			preorder[equivalent] = preorder[literal];
			postorder[equivalent] = next_timestamp;
			
			/* TODO: make sure this substitution is legal */
			auto root1 = hooks.p_var_config.equiv_root(literal);
			auto root2 = hooks.p_var_config.equiv_root(equivalent);
			if(root1 != root2) {
				hooks.p_var_config.equiv_union(equivalent, literal);
				hooks.p_var_config.equiv_union(hooks.lit_inverse(equivalent),
						hooks.lit_inverse(literal));
				hooks.stat.simp.scc_variables++;
				stat_equiv++;
			}
			stat_num_lits++;
			stat_depth_sum += depth;
		} while(equivalent != literal);
	}
}

template<typename Hooks>
void unhiding_hle(Hooks &hooks,
		typename Hooks::clause_type clause,
		std::vector<unsigned int> &discovery,
		std::vector<unsigned int> &finish,
		std::vector<typename Hooks::literal_type> &s_plus,
		std::vector<typename Hooks::literal_type> &s_minus,
		unsigned int &stat_hle_lits) {
	unsigned int num_marked = 0;
	
	unsigned int finished = 0;
	for(auto i = s_plus.rbegin(); i != s_plus.rend(); ++i) {
		if(hooks.p_var_config.get_litflag_marked(*i))
			continue;
		if(finished == 0) {
			finished = finish[*i];
		}else if(finish[*i] > finished) {
			hooks.p_var_config.set_litflag_marked(*i);
			num_marked++;
		}else finished = finish[*i];
	}

	finished = 0;
	for(auto i = s_minus.begin(); i != s_minus.end(); ++i) {
		typename Hooks::literal_type inv = hooks.lit_inverse(*i);
		if(hooks.p_var_config.get_litflag_marked(inv))
			continue;
		if(finished == 0) {
			finished = finish[*i];
		}else if(finish[*i] < finished) {
			hooks.p_var_config.set_litflag_marked(inv);
			num_marked++;
		}else finished = finish[*i];
	}

	if(num_marked == 0)
		return;

	std::vector<typename Hooks::literal_type> new_lits;
	for(auto i = hooks.clause_begin(clause);
			i != hooks.clause_end(clause); ++i) {
		bool marked = hooks.p_var_config.get_litflag_marked(*i);
		hooks.p_var_config.clear_litflag_marked(*i);
		if(marked)
			continue;
		new_lits.push_back(*i);
	}

	if(new_lits.size() == 1) {
		hooks.fact_queue.push_back(new_lits.front());
	}else if(new_lits.size() == 2) {
		hooks.binary_create(new_lits.front(), new_lits.back());
	}else{
		auto new_clause = hooks.clause_alloc(new_lits.size(),
				new_lits.begin(), new_lits.end());
		if(hooks.clause_head(clause)->get_essential())
			hooks.clause_head(new_clause)->set_essential(true);
		hooks.clause_set_lbd(new_clause, hooks.clause_get_lbd(clause));
		hooks.clause_set_activity(new_clause, hooks.clause_activity(clause));
		hooks.install_queue_push(new_clause);
	}
	hooks.stat.simp.unhide_hle += num_marked;
	stat_hle_lits += num_marked;
	hooks.clause_delete(clause);
}

template<typename Hooks>
bool unhiding_hte(Hooks &hooks,
		typename Hooks::clause_type clause,
		std::vector<unsigned int> &discovery,
		std::vector<unsigned int> &finish,
		std::vector<typename Hooks::literal_type> &s_plus,
		std::vector<typename Hooks::literal_type> &s_minus) {
	auto l_pos = s_plus.begin();
	auto l_neg = s_minus.begin();
	while(true) {
		if(discovery[*l_neg] > discovery[*l_pos]) {
			l_pos++;
			if(l_pos == s_plus.end())
				return false;
		}else if(finish[*l_neg] < finish[*l_pos]
				|| hooks.clause_length(clause) == 2) {
			l_neg++;
			if(l_neg == s_minus.end())
				return false;
		}else return true;
	}
}

template<typename Hooks>
class unhiding_lt {
public:
	unhiding_lt(std::vector<unsigned int> &preorder)
			: p_preorder(preorder) { }

	bool operator() (typename Hooks::literal_type literal1,
			typename Hooks::literal_type literal2) {
		return p_preorder[literal1] < p_preorder[literal2];
	}
private:
	std::vector<unsigned int> &p_preorder;
};

template<typename Hooks>
void unhiding_eliminate_all(Hooks &hooks,
		bool perform_hte,
		unsigned int &stat_equiv,
		unsigned int &stat_failed, unsigned int &stat_transitive,
		unsigned int &stat_hle_lits, unsigned int &stat_hte_clauses,
		float &stat_avg_depth) {
	std::vector<unsigned int> observed;
	std::vector<unsigned int> preorder;
	std::vector<unsigned int> postorder;
	std::vector<typename Hooks::literal_type> root;
	std::vector<typename Hooks::literal_type> parent;
	std::vector<typename Hooks::literal_type> stack;

	unsigned int lit_count = hooks.p_var_config.count() * 2;
	observed.resize(lit_count, 0);
	preorder.resize(lit_count, 0);
	postorder.resize(lit_count, 0);
	root.resize(lit_count, (typename Hooks::literal_type)Hooks::ILLEGAL_LIT);
	parent.resize(lit_count, (typename Hooks::literal_type)Hooks::ILLEGAL_LIT);

	unsigned int next_timestamp = 1;

	std::vector<typename Hooks::literal_type> var_queue;
	for(typename Hooks::variable_type var = 0;
			var < hooks.p_var_config.count(); ++var) {
		if(hooks.p_var_config.get_varflag_deleted(var))
			continue;
		var_queue.push_back(var);
	}
	util::shuffle(var_queue.begin(), var_queue.end(),
			hooks.rnd_engine);

	unsigned int stat_num_lits = 0;
	unsigned int stat_depth_sum = 0;

	for(auto i = var_queue.begin(); i != var_queue.end(); ++i) {
		auto zero_lit = hooks.zero_literal(*i);
		auto one_lit = hooks.one_literal(*i);
		if(preorder[zero_lit] == 0)
			unhiding_stamp(hooks, zero_lit, zero_lit, 0, next_timestamp,
					observed, preorder, postorder, root, parent, stack,
					stat_equiv, stat_failed, stat_transitive,
					stat_num_lits, stat_depth_sum);
		if(preorder[one_lit] == 0)
			unhiding_stamp(hooks, one_lit, one_lit, 0, next_timestamp,
					observed, preorder, postorder, root, parent, stack,
					stat_equiv, stat_failed, stat_transitive,
					stat_num_lits, stat_depth_sum);
	}
	stat_avg_depth = (float)stat_depth_sum / stat_num_lits;
//FIXME:	std::cout << "c   [UNHIDE] average depth: " << stat_avg_depth << std::endl;

	for(auto i = var_queue.begin(); i != var_queue.end(); ++i) {
		auto zero_lit = hooks.zero_literal(*i);
		auto one_lit = hooks.one_literal(*i);
		hooks.big_compact_single(zero_lit);
		hooks.big_compact_single(one_lit);
	}

	/* substitute equivalent literals */
	equiv_replace_all(hooks);
	if(hooks.is_unsatisfiable())
		return;

	/*FIXME:if(stat_avg_depth > 10.0f) {*/
		unhiding_lt<Hooks> comparator(preorder);
		std::vector<typename Hooks::literal_type> s_plus;
		std::vector<typename Hooks::literal_type> s_minus;
		
		std::vector<typename Hooks::clause_type> queue;
		for(auto i = hooks.clauses_begin(); i != hooks.clauses_end(); ++i) {
			if(!hooks.clause_present(*i))
				continue;
			queue.push_back(*i);
		}
		for(auto i = queue.begin(); i != queue.end(); ++i) {
			s_plus.clear();
			s_minus.clear();
			for(auto j = hooks.clause_begin(*i); j != hooks.clause_end(*i); ++j) {
				s_plus.push_back(*j);
				s_minus.push_back(hooks.lit_inverse(*j));
			}
			std::sort(s_plus.begin(), s_plus.end(), comparator);
			std::sort(s_minus.begin(), s_minus.end(), comparator);
			
			if(perform_hte && unhiding_hte(hooks, *i, preorder, postorder, s_plus, s_minus)) {
				hooks.clause_delete(*i);
				hooks.stat.simp.unhide_hte++;
				stat_hte_clauses++;
			}else unhiding_hle(hooks, *i, preorder, postorder,
					s_plus, s_minus, stat_hle_lits);
		}
	//}
	
	hooks.install_queue_process();
	if(hooks.fact_queue_length() > 0) {
		hooks.fact_queue_process2();
		if(hooks.is_unsatisfiable())
			return;
		hooks.eliminate_facts();
		hooks.install_queue_process();
	}
	hooks.check_garbage();
}

template<typename Hooks, typename Heuristics>
void unhiding_heuristic(Hooks &hooks,
		bool perform_hte,
		Heuristics &heuristics,
		unsigned int &total_runs,
		util::performance::counter &total_elapsed) {
	while(true) {
		auto time_start = util::performance::current();
		unsigned int new_equiv = 0;
		unsigned int new_failed = 0;
		unsigned int new_transitive = 0;
		unsigned int new_hle_lits = 0;
		unsigned int new_hte_clauses = 0;
		float new_avg_depth = 0;

		unhiding_eliminate_all(hooks, perform_hte, new_equiv, new_failed,
				new_transitive, new_hle_lits, new_hte_clauses, new_avg_depth);
		auto last_elapsed = util::performance::elapsed(time_start);
		heuristics.run_stats(new_equiv, new_failed, new_hle_lits, last_elapsed);

		total_elapsed += last_elapsed;
		total_runs++;
		
		if(hooks.is_unsatisfiable())
			return;

		if(!heuristics.another_run(total_runs, new_equiv, new_failed, new_hle_lits,
				last_elapsed, total_elapsed))
			return;
	}
}

