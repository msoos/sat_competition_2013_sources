
/* checks whether the given literal blocks the given clause.
		the given literal must be in the clause. */
template<typename Hooks>
bool bce_blocks(Hooks &hooks, typename Hooks::clause_type clause,
		typename Hooks::literal_type literal) {
	if(hooks.lit_false(literal))
		return false;/*FIXME: what does this check do? */

	/* check for 2-cnf resolvents */
	for(auto i = hooks.big_begin(literal);
			i != hooks.big_end(literal); ++i) {
		auto to_check = hooks.lit_inverse((*i).literal);
		if(!hooks.clause_contains(clause, to_check))
			return false;
	}

	typename Hooks::literal_type inverse = hooks.lit_inverse(literal);
	for(auto i = hooks.occur_begin(inverse);
			i != hooks.occur_end(inverse); ++i) {
		if(!hooks.clause_present(clause))
			continue;
		if(!hooks.resolvent_trivial(clause, *i, hooks.lit_getvar(literal)))
			return false;
	}
	return true;
}

/* checks whether the given clause is a blocked clause */
template<typename Hooks>
bool bce_blocked(Hooks &hooks, typename Hooks::clause_type clause,
		typename Hooks::literal_type &blocking) {
	for(auto i = hooks.clause_begin(clause);
			i != hooks.clause_end(clause); ++i)
		if(bce_blocks(hooks, clause, *i)) {
			blocking = *i;
			return true;
		}
	return false;
}

template<typename Hooks>
bool bce_eliminate_single(Hooks &hooks,
		typename Hooks::clause_type clause) {
	typename Hooks::literal_type blocking = Hooks::ILLEGAL_LIT;
	if(!bce_blocked(hooks, clause, blocking))
		return false;
		
	problem::sat::extmodel::push_blocked_clause(hooks, hooks.extmodel_config,
			hooks.extmodel_alloc, clause, blocking);
	hooks.clause_delete(clause);
	hooks.stat_blocked_clauses++;
	return true;
}

/* performs blocked clause elimination */
template<typename Hooks>
void bce_eliminate(Hooks &hooks) {
	SYS_ASSERT(SYS_ASRT_GENERAL, hooks.install_queue_length() == 0);

	std::vector<typename Hooks::clause_type> queue;
	for(auto i = hooks.clauses_begin(); i != hooks.clauses_end(); ++i) {
		if(!hooks.clause_present(*i))
			continue;
		if(hooks.clause_length(*i) == 2)
			continue;
		queue.push_back(*i);
	}
	for(auto i = queue.begin(); i != queue.end(); ++i) {
		typename Hooks::literal_type blocking = Hooks::ILLEGAL_LIT;
		if(!bce_blocked(hooks, *i, blocking))
			continue;
		
		problem::sat::extmodel::push_blocked_clause(hooks,
				hooks.extmodel_config, hooks.extmodel_alloc, *i, blocking);
		hooks.clause_delete(*i);
		hooks.stat_blocked_clauses++;
	}
}

