
template<typename Hooks>
class brm_variable_order {
public:
	brm_variable_order(Hooks &hooks) : p_hooks(hooks) { }

	bool operator() (typename Hooks::variable_type var1,
			typename Hooks::variable_type var2) {
		if(p_hooks.var_activity(var1) > p_hooks.var_activity(var2))
			return true;
		return false;
	}

private:
	Hooks &p_hooks;
};

template<typename Hooks>
void brm_probe(Hooks &hooks,
		std::vector<typename Hooks::literal_type> &probe_path,
		std::vector<typename Hooks::literal_type> &implication_stack,
		std::vector<unsigned int> &decision_stack,
		unsigned int &stat_failed, unsigned int &stat_equivalent,
		unsigned int &stat_independent) {
	SYS_ASSERT(SYS_ASRT_GENERAL, hooks.cur_declevel() == 1);
//	std::cout << "Branch-Merge" << std::endl;
	/* assign the probe path */
	for(auto i = probe_path.begin(); i != probe_path.end(); ++i) {
		/* note: this decision level can be empty but it is required
				for the algorithm! */
		hooks.push_declevel();
		
		if(hooks.lit_false(*i)) {
			/* we found a failed literal FIXME */
			hooks.backjump(1);
			hooks.stat.simp.brm_failed++;
			stat_failed++;
			implication_stack.clear();
			decision_stack.clear();
			return;
		}else if(hooks.lit_true(*i)) {
			/* FIXME: equivalent literal */
		}else{
			hooks.push_assign(*i, Hooks::antecedent_type::make_decision());
			hooks.propagate();
		
			/* check for failed literals */
			if(hooks.at_conflict()) {
				while(hooks.at_conflict()) { /*TODO: don't abort the whole branch */
					if(hooks.is_unsatisfiable())
						return;
					hooks.resolve();
					hooks.propagate();
				}
				hooks.backjump(1);
				hooks.stat.simp.brm_failed++;
				stat_failed++;
				implication_stack.clear();
				decision_stack.clear();
				return;
			}
		}

		/* record all implications of the assignment */
		auto curlevel = hooks.cur_declevel();
		unsigned int count = 0;
		for(auto order = hooks.p_prop_config.assign_first(curlevel);
				order != hooks.p_prop_config.assign_last(curlevel); ++order) {
			auto literal = hooks.p_prop_config.get_assign(order);
			if(literal == *i)
				continue;
			auto var = hooks.lit_getvar(literal);
			SYS_ASSERT(SYS_ASRT_GENERAL, hooks.var_antecedent(var)
					!= Hooks::antecedent_type::make_decision());
			implication_stack.push_back(literal);
			count++;
//			std::cout << "    Pushing: " << literal << ", index: " << (i - probe_path.begin())
//					<< ", declevel: " << curlevel << std::endl;
		}
		decision_stack.push_back(count);
	}
	hooks.backjump(1);
	
	/* assign the inverse path */
	for(auto i = probe_path.rbegin(); i != probe_path.rend(); ++i) {
		/* note: this decision level can be empty but it is required
				for the algorithm! */
		hooks.push_declevel();
		
		auto inverse = hooks.lit_inverse(*i);
		if(hooks.lit_false(inverse)) {
			/* we found a failed literal FIXME */
			hooks.backjump(1);
			hooks.stat.simp.brm_failed++;
			stat_failed++;
			implication_stack.clear();
			decision_stack.clear();
			return;
		}else if(hooks.lit_true(inverse)) {
			/* FIXME: equivalent literal */
		}else{
			hooks.push_assign(inverse, Hooks::antecedent_type::make_decision());
			hooks.propagate();
			
			/* check for failed literals */
			if(hooks.at_conflict()) {
				while(hooks.at_conflict()) { /*TODO: don't abort the whole branch */
					if(hooks.is_unsatisfiable())
						return;
					hooks.resolve();
					hooks.propagate();
				}
				hooks.backjump(1);
				hooks.stat.simp.brm_failed++;
				stat_failed++;
				implication_stack.clear();
				decision_stack.clear();
				return;
			}
		}
	}

	bool substitute = false;

//	std::cout << "    cur declevel: " << hooks.cur_declevel() << std::endl;
	/* detect equivalent and independent literals */
	auto k = implication_stack.begin();
	for(unsigned int i = 0; i != decision_stack.size(); ++i) {
		for(unsigned int j = 0; j < decision_stack[i]; ++j, ++k) {
			SYS_ASSERT(SYS_ASRT_GENERAL, k != implication_stack.end());
			auto var = hooks.lit_getvar(*k);
			if(!hooks.var_assigned(var))
				continue;

			SYS_ASSERT(SYS_ASRT_GENERAL, hooks.var_declevel(var) > 1);
			unsigned int iidx = hooks.cur_declevel() - hooks.var_declevel(var);
//			std::cout << "    Testing: " << *k << ", index: " << iidx;
//			std::cout << ", declevel: " << hooks.var_declevel(var) << std::endl;
//			std::cout << "declevel(var): " << hooks.var_declevel(var)
//					<< ", declevel(probe[iidx]): " << hooks.var_declevel(hooks.lit_getvar(probe_path[iidx])) << std::endl;
			SYS_ASSERT(SYS_ASRT_GENERAL, hooks.var_declevel(var)
					== hooks.var_declevel(hooks.lit_getvar(probe_path[iidx])));

			if(i <= iidx && hooks.lit_true(*k)) {
				/* the literal is implied by the branch-merge rule */
				hooks.fact_queue_push(*k);
				hooks.stat.simp.brm_independent++;
				stat_independent++;
			}else if(i <= iidx && hooks.lit_false(*k)) {
				for(unsigned int l = i; l <= iidx; ++l) {
					auto lit = probe_path[l];
					SYS_ASSERT(SYS_ASRT_GENERAL, hooks.var_declevel(hooks.lit_getvar(lit)) > 1);
					auto root1 = hooks.p_var_config.equiv_root(lit);
					auto root2 = hooks.p_var_config.equiv_root(*k);
					if(root1 == root2)
						continue;
					hooks.p_var_config.equiv_union(lit, *k);
					hooks.p_var_config.equiv_union(hooks.lit_inverse(lit),
							hooks.lit_inverse(*k));
					hooks.stat.simp.brm_equivalent++;
					stat_equivalent++;
					substitute = true;
				}
			}
		}
	}
	SYS_ASSERT(SYS_ASRT_GENERAL, k == implication_stack.end());
	hooks.backjump(1);
	
	if(substitute) {
		equiv_replace_all(hooks);
		if(hooks.is_unsatisfiable())
			return;
	}
	hooks.fact_queue_process();
	if(hooks.is_unsatisfiable())
		return;
	implication_stack.clear();
	decision_stack.clear();
}

template<typename Hooks>
void brm_find_path(Hooks &hooks,
		typename Hooks::literal_type leaf_literal,
		std::vector<bool> &discard,
		std::vector<typename Hooks::literal_type> &probe_path) {
	auto leaf_inverse = hooks.lit_inverse(leaf_literal);
	auto leaf_var = hooks.lit_getvar(leaf_literal);

	SYS_ASSERT(SYS_ASRT_GENERAL, !discard[leaf_var]);
	probe_path.push_back(leaf_literal);
	discard[leaf_var] = true;
	
	for(auto i = hooks.big_begin(leaf_inverse);
			i != hooks.big_end(leaf_inverse); ++i) {
		auto literal = (*i).literal;
		auto var = hooks.lit_getvar(literal);
		auto inverse = hooks.lit_inverse(literal);

		SYS_ASSERT(SYS_ASRT_GENERAL, !hooks.lit_false(literal));
		if(hooks.var_assigned(var))
			continue;
		if(discard[var])
			continue;
		if(std::find(probe_path.begin(), probe_path.end(),
				inverse) != probe_path.end())
			continue;
		brm_find_path(hooks, inverse, discard, probe_path);
		return;
	}
}

/*template<typename Hooks>
void brm_eliminate_active(Hooks &hooks, unsigned int num_runs,
		unsigned int &stat_failed, unsigned int &stat_equivalent,
		unsigned int &stat_independent) {
	hooks.big_compact_fast();
	hooks.watch_compact_fast();

	std::vector<typename Hooks::literal_type> implications;
	
	std::vector<typename Hooks::variable_type> queue;
	for(typename Hooks::variable_type i = 0; i < hooks.p_var_config.count(); i++)
		queue.push_back(i);
	brm_variable_order<Hooks> order(hooks);
	std::sort(queue.begin(), queue.end(), order);

	unsigned int k = 0;
	for(auto i = queue.begin(); i != queue.end(); ++i) {
		if(hooks.var_assigned(*i))
			continue;
		if(hooks.p_var_config.get_varflag_deleted(*i))
			continue;
		brm_probe(hooks, *i, implications, stat_failed,
				stat_equivalent, stat_independent);
		k++;
		if(k > num_runs)
			break;
	}
	hooks.eliminate_facts();
	hooks.install_queue_process();
	hooks.check_garbage();
}*/

/*template<typename Hooks>
void brm_eliminate_all(Hooks &hooks,
		unsigned int &stat_failed, unsigned int &stat_equivalent,
		unsigned int &stat_independent) {
	hooks.big_compact_fast();
	hooks.watch_compact_fast();

	std::vector<typename Hooks::literal_type> implications;
	for(typename Hooks::variable_type i = 0; i < hooks.p_var_config.count(); i++) {
		if(hooks.var_assigned(i))
			continue;
		if(hooks.p_var_config.get_varflag_deleted(i))
			continue;
		brm_probe(hooks, i, implications, stat_failed,
				stat_equivalent, stat_independent);
	}
	hooks.eliminate_facts();
	hooks.install_queue_process();
	hooks.check_garbage();
}*/

template<typename Hooks>
void brm_eliminate_random(Hooks &hooks, unsigned int num_runs,
		unsigned int &stat_failed, unsigned int &stat_equivalent,
		unsigned int &stat_independent) {
	std::uniform_int_distribution<typename Hooks::variable_type> distrib
			(0, hooks.p_var_config.count() - 1);

	hooks.big_compact_fast();
	hooks.watch_compact_fast();

	std::vector<bool> discard;
	std::vector<typename Hooks::literal_type> probe_path;
	std::vector<typename Hooks::literal_type> implication_stack;
	std::vector<unsigned int> declevel_stack;
	
	discard.resize(hooks.p_var_config.count(), false);

	for(unsigned int i = 0; i < num_runs; i++) {
		typename Hooks::variable_type var = distrib(hooks.rnd_engine);
		if(hooks.var_assigned(var))
			continue;
		if(discard[var])
			continue;
		if(hooks.p_var_config.get_varflag_deleted(i))
			continue;
		brm_find_path(hooks, hooks.zero_literal(var), discard, probe_path);
		brm_probe(hooks, probe_path, implication_stack, declevel_stack,
				stat_failed, stat_equivalent, stat_independent);
		probe_path.clear();
	
		if(hooks.is_unsatisfiable())
			return;
	}
	hooks.eliminate_facts();
	hooks.install_queue_process();
	hooks.check_garbage();
}

template<typename Hooks, typename Heuristics>
void brm_eliminate_heuristic(Hooks &hooks, Heuristics &heuristics,
		util::performance::counter &total_elapsed) {
	std::uniform_int_distribution<typename Hooks::variable_type> distrib
			(0, hooks.p_var_config.count() - 1);

	hooks.watch_compact_fast();

	std::vector<bool> discard;
	std::vector<typename Hooks::literal_type> probe_path;
	std::vector<typename Hooks::literal_type> implication_stack;
	std::vector<unsigned int> declevel_stack;
	
	discard.resize(hooks.p_var_config.count(), false);

	while(true) {
		unsigned int run_failed = 0;
		unsigned int run_equivalent = 0;
		unsigned int run_independent = 0;
	
		auto run_start = util::performance::current();
		for(unsigned int i = 0; i < 100; i++) {
			typename Hooks::variable_type var = distrib(hooks.rnd_engine);
			if(hooks.var_assigned(var))
				continue;
			if(discard[var])
				continue;
			if(hooks.p_var_config.get_varflag_deleted(i))
				continue;
			brm_find_path(hooks, hooks.zero_literal(var), discard, probe_path);
			brm_probe(hooks, probe_path, implication_stack, declevel_stack,
					run_failed, run_equivalent, run_independent);
			probe_path.clear();
	
			if(hooks.is_unsatisfiable())
				return;
		}
		auto run_elapsed = util::performance::elapsed(run_start);
		heuristics.run_stats(run_equivalent, run_failed + run_independent,
				run_elapsed);

		total_elapsed += run_elapsed;

		if(!heuristics.another_run(run_equivalent,
				run_failed + run_independent, run_elapsed, total_elapsed))
			break;
	}
	hooks.eliminate_facts();
	hooks.install_queue_process();
	hooks.check_garbage();
}

template<typename Hooks>
class brm_activity_order {
public:
	brm_activity_order(Hooks &hooks) : p_hooks(hooks) { }

	bool operator() (typename Hooks::variable_type var1,
			typename Hooks::variable_type var2) {
		return p_hooks.var_activity(var1) > p_hooks.var_activity(var2);
	}
private:
	Hooks &p_hooks;
};

struct brm_run_stats_struct {
	uint32_t failed;
	uint32_t equivalent;
	uint32_t independent;
	util::performance::counter elapsed;
	
	brm_run_stats_struct() : failed(0), equivalent(0), independent(0),
		elapsed(0) { }
};

template<typename Hooks>
void brm_eliminate_active(Hooks &hooks, unsigned int num_checks,
		brm_run_stats_struct &run_stats) {
	hooks.watch_compact_fast();

	std::vector<bool> discard;
	std::vector<typename Hooks::literal_type> probe_path;
	std::vector<typename Hooks::literal_type> implication_stack;
	std::vector<unsigned int> declevel_stack;
	
	discard.resize(hooks.p_var_config.count(), false);

	std::vector<typename Hooks::variable_type> queue;
	for(typename Hooks::variable_type var = 0;
			var < hooks.p_var_config.count(); ++var) {
		if(hooks.p_var_config.get_varflag_deleted(var))
			continue;
		queue.push_back(var);
	}
	brm_activity_order<Hooks> order(hooks);
	std::sort(queue.begin(), queue.end(), order);

	auto run_start = util::performance::current();
	for(unsigned int i = 0; i < num_checks; i++) {
		if(i >= queue.size());
			break;
		auto var = queue[i];
		if(hooks.var_assigned(var))
			continue;
		if(discard[var])
			continue;
//FIXME:		std::cout << "activity: " << hooks.var_activity(var) << std::endl;
		brm_find_path(hooks, hooks.zero_literal(var), discard, probe_path);
		brm_probe(hooks, probe_path, implication_stack, declevel_stack,
				run_stats.failed, run_stats.equivalent, run_stats.independent);
		probe_path.clear();
		
		if(hooks.is_unsatisfiable())
			return;
	}
	run_stats.elapsed = util::performance::elapsed(run_start);
	
	hooks.eliminate_facts();
	hooks.install_queue_process();
	hooks.check_garbage();
}
