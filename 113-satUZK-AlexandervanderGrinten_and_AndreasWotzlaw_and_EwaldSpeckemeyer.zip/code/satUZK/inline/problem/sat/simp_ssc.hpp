
template<typename Hooks>
void ssc_visit(Hooks &hooks,
		typename Hooks::literal_type literal,
		unsigned int &next_preorder,
		std::vector<unsigned int> &preorder,
		std::vector<typename Hooks::literal_type> &roots,
		std::vector<typename Hooks::literal_type> &stack) {
	SYS_ASSERT(SYS_ASRT_GENERAL, preorder[literal] == 0);
	preorder[literal] = next_preorder++;
	roots[literal] = literal;
	stack.push_back(literal);
	hooks.p_var_config.set_litflag_ssc(literal);

	for(auto i = hooks.big_begin(literal);
			i != hooks.big_end(literal); ++i) {
		typename Hooks::literal_type dest = (*i).literal;
		
		/* if we see an edge with a destination that is not on the stack
			but has a preorder number then it is in a different scc
			since the scc containing it has already been found */
		if(preorder[dest] == 0) {
			ssc_visit(hooks, dest, next_preorder, preorder, roots, stack);
			
			/* we have seen all backward paths starting at the
				destination of the edge.
				roots[dest] cannot change after this point. */ 
			typename Hooks::literal_type cur_root = roots[literal];
			typename Hooks::literal_type dest_root = roots[dest];
			if(preorder[dest_root] < preorder[cur_root])
				roots[literal] = dest_root;
		}else if(hooks.p_var_config.get_litflag_ssc(dest)) {
			/* the current edge is a backward edge */
			typename Hooks::literal_type cur_root = roots[literal];
			if(preorder[dest] < preorder[cur_root])
				roots[literal] = dest;
		}
	}

	if(roots[literal] == literal) {
		/* this literal is the root of a ssc */
		typename Hooks::literal_type child;
		do {
			child = stack.back();
			roots[child] = literal;
			hooks.p_var_config.clear_litflag_ssc(child);
			stack.pop_back();
		} while(child != literal);
	}
}

template<typename Hooks>
std::vector<typename Hooks::literal_type> ssc_decompose(Hooks &hooks) {
	std::vector<unsigned int> preorder;
	std::vector<typename Hooks::literal_type> roots;
	std::vector<typename Hooks::literal_type> stack;

	/* initialize the preorder of all literal to zero.
		preorder zero means that the literal has not been visited yet. */
	for(typename Hooks::variable_type var = 0;
			var < hooks.p_var_config.count(); ++var) {
		preorder.push_back(0);
		preorder.push_back(0);
		roots.push_back((typename Hooks::literal_type)Hooks::ILLEGAL_LIT);
		roots.push_back((typename Hooks::literal_type)Hooks::ILLEGAL_LIT);
	}

	/* visit all literals */
	unsigned int next_preorder = 1;
	for(typename Hooks::variable_type var = 0;
			var < hooks.p_var_config.count(); ++var) {
		auto lit1 = hooks.zero_literal(var);
		auto lit2 = hooks.one_literal(var);
		if(preorder[lit1] == 0)
			ssc_visit(hooks, lit1, next_preorder, preorder, roots, stack);
		SYS_ASSERT(SYS_ASRT_GENERAL, stack.size() == 0);
		if(preorder[lit2] == 0)
			ssc_visit(hooks, lit2, next_preorder, preorder, roots, stack);
		SYS_ASSERT(SYS_ASRT_GENERAL, stack.size() == 0);
	}
	return roots;
}

template<typename Hooks>
typename Hooks::literal_type scc_getsubst(Hooks &hooks,
		typename Hooks::literal_type literal,
		std::vector<typename Hooks::literal_type> &scc_roots) {
	/* there are two possibilties for the equivalence class of a variable */
	auto var = hooks.lit_getvar(literal);
	auto one_scc = scc_roots[hooks.one_literal(var)];
	auto one_scc2 = hooks.lit_inverse(scc_roots[hooks.zero_literal(var)]);
	/* we have to make a choice that is consistent across all variables
		so we always choose the representative with smaller index */
	auto choice = one_scc < one_scc2 ? one_scc : one_scc2;
	return hooks.lit_is_one(literal) ? choice : hooks.lit_inverse(choice);
}

template<typename Hooks>
void ssc_substitute(Hooks &hooks,
		typename Hooks::clause_type clause,
		std::vector<typename Hooks::literal_type> &ssc_roots) {
	std::vector<typename Hooks::literal_type> new_literals;
	for(auto j = hooks.clause_begin(clause);
			j != hooks.clause_end(clause); ++j) {
		auto scc = scc_getsubst(hooks, *j, ssc_roots);
		auto inverse = hooks.lit_inverse(scc);
		
		/* TODO: unfortunately this has quadratic runtime */
		if(std::find(new_literals.begin(), new_literals.end(), scc)
				!= new_literals.end())
			continue;
		if(std::find(new_literals.begin(), new_literals.end(), inverse)
				!= new_literals.end()) {
			hooks.delete_queue_push(clause);
			return;
		}
		new_literals.push_back(scc);
	}

	if(new_literals.size() == 1) {
		hooks.fact_queue_push(new_literals.front());
	}else{
		auto new_clause = hooks.clause_alloc(new_literals.size(),
				new_literals.begin(), new_literals.end());
		if(hooks.clause_head(clause)->get_essential())
			hooks.clause_head(new_clause)->set_essential(true);
		hooks.install_queue_push(new_clause);
	}
	hooks.delete_queue_push(clause);
}

template<typename Hooks>
void ssc_eliminate(Hooks &hooks) {
	auto scc_roots = ssc_decompose(hooks);

	/* check whether the binary implication graph is conflicting */
	for(typename Hooks::variable_type var = 0;
			var < hooks.p_var_config.count(); ++var) {
		auto zero_lit = hooks.zero_literal(var);
		auto one_lit = hooks.one_literal(var);
		
		auto zero_scc = scc_roots[zero_lit];
		auto one_scc = scc_roots[one_lit];
		auto zero_subst = scc_getsubst(hooks, zero_lit, scc_roots);
		auto one_subst = scc_getsubst(hooks, one_lit, scc_roots);
		
		SYS_ASSERT(SYS_ASRT_GENERAL, one_scc != zero_scc);
		SYS_ASSERT(SYS_ASRT_GENERAL, zero_scc
				== scc_roots[hooks.lit_inverse(one_scc)]);
		SYS_ASSERT(SYS_ASRT_GENERAL, one_scc
				== scc_roots[hooks.lit_inverse(zero_scc)]);
		SYS_ASSERT(SYS_ASRT_GENERAL, zero_scc
				== scc_roots[hooks.lit_inverse(one_subst)]);
		SYS_ASSERT(SYS_ASRT_GENERAL, one_scc
				== scc_roots[hooks.lit_inverse(zero_subst)]);		

		if(zero_lit != zero_subst) {
			problem::sat::extmodel::push_equivalent(hooks,
					hooks.extmodel_config, hooks.extmodel_alloc,
					var, zero_subst);
			hooks.stat.simp.scc_variables++;
		}
	}

	/* build a new clause for each old one */
	std::vector<typename Hooks::clause_type> queue;
	for(auto i = hooks.clauses_begin(); i != hooks.clauses_end(); ++i)
		queue.push_back(*i);
	for(auto i = queue.begin(); i != queue.end(); ++i)
		ssc_substitute(hooks, *i, scc_roots);

	hooks.install_queue_process();
	hooks.delete_queue_process();
	if(hooks.fact_queue_length() != 0) {
		hooks.fact_queue_process();
		hooks.eliminate_facts();
		hooks.install_queue_process();
		hooks.delete_queue_process();
	}
	hooks.check_garbage();
}

