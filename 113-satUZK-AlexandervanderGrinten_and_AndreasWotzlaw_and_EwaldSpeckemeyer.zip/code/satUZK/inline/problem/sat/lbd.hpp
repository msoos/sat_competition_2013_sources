
namespace problem {
namespace sat {
namespace lbd {

template<typename Hooks, int Limit>
int of_clause(Hooks &hooks, typename Hooks::clause_type clause) {
	hooks.lbd_init();
	for(auto i = hooks.clause_begin(clause);
			i != hooks.clause_end(clause); ++i) {
		auto var = hooks.lit_getvar(*i);
		hooks.lbd_insert(hooks.var_declevel(var));
	}
	for(auto i = hooks.clause_begin(clause);
			i != hooks.clause_end(clause); ++i) {
		auto var = hooks.lit_getvar(*i);
		hooks.lbd_cleanup(hooks.var_declevel(var));
	}
	return hooks.lbd_result();
}

}}};

