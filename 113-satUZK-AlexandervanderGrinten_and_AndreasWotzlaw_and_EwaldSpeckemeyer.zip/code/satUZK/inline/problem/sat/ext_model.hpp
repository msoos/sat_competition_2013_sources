
namespace problem {
namespace sat {
namespace extmodel {

enum tag_type {
	fact,
	equivalent,
	distributed,
	blocked_clause
};

struct desc_type {
	tag_type tag;
	uint32_t base_offset;
};

struct config_struct {
	typedef std::vector<desc_type> vector_type;
	typedef vector_type::reverse_iterator reverse_iterator;

	vector_type desc_vector;	

	void push(tag_type tag, uint32_t base_offset) {
		desc_type description;
		description.tag = tag;
		description.base_offset = base_offset;
		desc_vector.push_back(description);
	}

	reverse_iterator rbegin() { return desc_vector.rbegin(); }
	reverse_iterator rend() { return desc_vector.rend(); }
};

class stack_allocator {
public:
	typedef unsigned int size_type;

	stack_allocator() : p_pointer(NULL), p_offset(0), p_capacity(0) { }
	~stack_allocator() {
		operator delete(p_pointer);
	}
	
	size_type allocate(size_type length) {
		if(p_pointer == NULL || p_capacity < p_offset + length) {
			size_type new_capacity = 1.5f * (p_offset + length);
			void *new_pointer = operator new(new_capacity);
			if(p_pointer != NULL)
				std::memcpy(new_pointer, p_pointer, p_capacity);
			operator delete(p_pointer);
			p_pointer = new_pointer;
			p_capacity = new_capacity;
		}
		size_type offset = p_offset;
		p_offset += length;
		return offset;
	}
	void align(size_type alignment) {
		size_type over = p_offset % alignment;
		if(over != 0)
			p_offset += (alignment - over);
	}

	template<typename T>
	T *access(size_type offset) {
		auto pointer = reinterpret_cast<uintptr_t>(p_pointer);
		return reinterpret_cast<T*>	(pointer + offset);
	}

	size_type get_offset() {
		return p_offset;
	}

private:
	void *p_pointer;
	size_type p_offset;
	size_type p_capacity;
};

template<typename Allocator>
class stack_writer {
public:
	typedef unsigned int size_type;

	stack_writer(Allocator &alloc) : p_allocator(alloc) {
		p_base_offset = p_allocator.get_offset();
	}
	
	size_type base_offset() {
		return p_base_offset;
	}
	
	template<typename T>
	void write(T object) {
		p_allocator.align(__alignof__(T));
		size_type offset = p_allocator.allocate(sizeof(T));
		*p_allocator.template access<T>(offset) = object;
	}
	
private:
	Allocator &p_allocator;
	size_type p_base_offset;
};

template<typename Allocator>
class stack_reader {
public:
	typedef unsigned int size_type;
	
	stack_reader(Allocator &alloc, size_type base_offset)
			: p_allocator(alloc), p_offset(base_offset) { }

	template<typename T>
	T read() {
		size_type alignment = __alignof__(T);
		size_type over = p_offset % alignment;
		if(over != 0)
			p_offset += (alignment - over);
		T *pointer = p_allocator.template access<T>(p_offset);
		p_offset += sizeof(T);
		return *pointer;
	}
private:
	Allocator &p_allocator;
	size_type p_offset;
};

template<typename Hooks, typename Config, typename Allocator>
void push_fact(Hooks &hooks, Config &config, Allocator &allocator,
		typename Hooks::literal_type fact) {
	stack_writer<Allocator> writer(allocator);
	writer.template write<uint32_t>(fact);
	config.push(tag_type::fact, writer.base_offset());
}

template<typename Hooks, typename Config, typename Allocator>
void push_equivalent(Hooks &hooks, Config &config, Allocator &allocator,
		typename Hooks::variable_type variable,
		typename Hooks::literal_type zero_equivalent) {
	stack_writer<Allocator> writer(allocator);
	writer.template write<uint32_t>(variable);
	writer.template write<uint32_t>(zero_equivalent);
	config.push(tag_type::equivalent, writer.base_offset());
}

template<typename Hooks, typename Config, typename Allocator>
void push_distributed(Hooks &hooks, Config &config, Allocator &allocator,
		typename Hooks::variable_type variable) {
	auto literal = hooks.zero_literal(variable);
	auto literal1 = hooks.one_literal(variable);
	
	stack_writer<Allocator> writer(allocator);
	writer.template write<uint32_t>(variable);
//	writer.template write<uint32_t>(hooks.occur_size(literal));

	uint32_t count = 0;
	for(auto j = hooks.occur_begin(literal);
			j != hooks.occur_end(literal); ++j) {
		if(!hooks.clause_present(*j))
			continue;
		count++;
	}
	for(auto j = hooks.big_begin(literal1);
			j != hooks.big_end(literal1); ++j) {
		count++;
	}
	writer.template write<uint32_t>(count);

	for(auto j = hooks.occur_begin(literal);
			j != hooks.occur_end(literal); ++j) {
		if(!hooks.clause_present(*j))
			continue;
		writer.template write<uint32_t>(hooks.clause_length(*j));
		for(auto i = hooks.clause_begin(*j);
				i != hooks.clause_end(*j); ++i) {
			writer.template write<uint32_t>(*i);
		}
	}
	for(auto j = hooks.big_begin(literal1);
			j != hooks.big_end(literal1); ++j) {
		writer.template write<uint32_t>(2);
		writer.template write<uint32_t>(literal);
		writer.template write<uint32_t>((*j).literal);
	}
	config.push(tag_type::distributed, writer.base_offset());
}

template<typename Hooks, typename Config, typename Allocator>
void push_blocked_clause(Hooks &hooks, Config &config, Allocator &allocator,
		typename Hooks::clause_type clause,
		typename Hooks::literal_type blocking) {
	stack_writer<Allocator> writer(allocator);
	writer.template write<uint32_t>(blocking);
	writer.template write<uint32_t>(hooks.clause_length(clause));
	for(auto i = hooks.clause_begin(clause);
			i != hooks.clause_end(clause); ++i) {
		writer.template write<uint32_t>(*i);
	}
	config.push(tag_type::blocked_clause, writer.base_offset());
}

template<typename Hooks, typename Allocator>
bool check_stored_clause(Hooks &hooks,
		stack_reader<Allocator> &reader) {
	//std::cout << "Checking clause" << std::endl;
	bool satisfied = false;
	uint32_t length = reader.template read<uint32_t>();
	for(uint32_t i = 0; i < length; ++i) {
		typename Hooks::literal_type lit = reader.template read<uint32_t>();
	//	std::cout << "Checking literal " << lit << std::endl;
		if(hooks.model_get_literal(lit))
			satisfied = true;
	}
	return satisfied;
}

template<typename Hooks, typename Config, typename Allocator>
void extend_equivalent(Hooks &hooks, Config &config, Allocator &allocator,
		uint32_t base_offset) {
	stack_reader<Allocator> reader(allocator, base_offset);
	
	typename Hooks::variable_type var = reader.template read<uint32_t>();
	typename Hooks::literal_type zero_equivalent = reader.template read<uint32_t>();

	if(hooks.model_get_literal(zero_equivalent)) {
		hooks.model_set_variable(var, false);
	}else hooks.model_set_variable(var, true);
}

template<typename Hooks, typename Config, typename Allocator>
void extend_distributed(Hooks &hooks, Config &config, Allocator &allocator,
		uint32_t base_offset) {
	stack_reader<Allocator> reader(allocator, base_offset);

	/* try to set the variable to one first */
	typename Hooks::variable_type var = reader.template read<uint32_t>();
	hooks.model_set_variable(var, true);

	uint32_t count = reader.template read<uint32_t>();
	for(uint32_t i = 0; i < count; ++i) {
		if(check_stored_clause(hooks, reader))
			continue;
		/* didn't satisfy the formula, so the variable must be one */
		hooks.model_set_variable(var, false);
		return;
	}
}

template<typename Hooks, typename Config, typename Allocator>
void extend_blocked_clause(Hooks &hooks, Config &config, Allocator &allocator,
		uint32_t base_offset) {
	stack_reader<Allocator> reader(allocator, base_offset);

	typename Hooks::literal_type blocking = reader.template read<uint32_t>();

	/* check the current model first */
	if(check_stored_clause(hooks, reader))
		return;
	/* didn't satisfy the clause so the blocking literal must be set */
	hooks.model_set_literal(blocking);
}

template<typename Hooks, typename Config, typename Allocator>
void build_model(Hooks &hooks, Config &config, Allocator &allocator) {
	/* set all model assignments to the current assignment */
	for(typename Hooks::variable_type var = 0; var < hooks.p_var_config.count(); ++var) {
		if(!hooks.var_assigned(var))  {
			/*TODO: memorize unassigned variables */
			hooks.model_set_variable(var, false);
		}else hooks.model_set_variable(var, hooks.var_one(var));
	}

	for(auto i = config.rbegin(); i != config.rend(); ++i) {
		stack_reader<Allocator> reader(allocator, (*i).base_offset);
		if((*i).tag == tag_type::fact) {
			typename Hooks::literal_type literal = reader.template read<uint32_t>();
			hooks.model_set_literal(literal);
		}else if((*i).tag == tag_type::equivalent) {
			extend_equivalent(hooks, config, allocator, (*i).base_offset);
		}else if((*i).tag == tag_type::distributed) {
			extend_distributed(hooks, config, allocator, (*i).base_offset);
		}else if((*i).tag == tag_type::blocked_clause) {
			extend_blocked_clause(hooks, config, allocator, (*i).base_offset);
		}else SYS_CRITICAL("Illegal tag\n");
	}
}

}}};

