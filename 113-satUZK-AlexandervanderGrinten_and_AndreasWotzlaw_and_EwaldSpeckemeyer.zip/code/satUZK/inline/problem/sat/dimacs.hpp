
namespace problem {
namespace sat {
namespace dimacs {

template<typename Hooks>
class reader {
public:
	typedef long literal_type;

	reader(std::istream &istream, Hooks &handler)
			: p_istream(istream), p_handler(handler) { }

	void read() {
		p_state = STATE_NONE;
		while(!p_istream.fail())
			p_read_line();
		SYS_ASSERT(SYS_ASRT_GENERAL, p_istream.eof());
		SYS_ASSERT(SYS_ASRT_GENERAL, p_state == STATE_NONE);
	}

private:
	enum state_type {
		STATE_NONE,
		STATE_PROBLEM_AFTER_P,
		STATE_PROBLEM_AFTER_TYPE,
		STATE_PROBLEM_AFTER_VARS,
		STATE_CLAUSE
	};

	void p_read_line() {
//		std::cout << "Reading line.." << std::endl;
//		std::cout << "  In state: " << p_state << std::endl;

		/* read a line from the file */
		const int buffer_size = 16 * 1024;
		char buffer[buffer_size];
		p_istream.getline(buffer, buffer_size);
		if(p_istream.fail())
			return;
		
//		std::cout << "  Line: " << buffer << std::endl;
		
		p_process_line(buffer);
	}

	void p_process_line(char *buffer) {
		char *strtok_state = NULL;
		char *token = NULL;

		/* get the first token from the read line */
		const char *delimiters = " ";
		token = strtok_r(buffer, delimiters, &strtok_state);
		
		/* it's a comment */
		if(token != NULL && strcmp(token, "c") == 0)
			return;

		while(token != NULL) {
			p_process_token(token);
			token = strtok_r(NULL, delimiters, &strtok_state);
		}
		p_process_endline();
	}

	void p_process_token(char *token) {
		//printf("Token: '%s'\n", token);
		if(p_state == STATE_NONE) {
			if(strcmp(token, "p") == 0) {
				p_state = STATE_PROBLEM_AFTER_P;
			}else if(strlen(token) != 0) {
				p_state = STATE_CLAUSE;
			}
		}else if(p_state == STATE_PROBLEM_AFTER_P) {
			p_state = STATE_PROBLEM_AFTER_TYPE;
		}else if(p_state == STATE_PROBLEM_AFTER_TYPE) {
			literal_type var_count = atoi(token);
			printf("c #variables: %ld\n", var_count);
			p_state = STATE_PROBLEM_AFTER_VARS;
		}else if(p_state == STATE_PROBLEM_AFTER_VARS) {
			literal_type clause_count = atoi(token);
			printf("c #clauses: %ld\n", clause_count);
			p_state = STATE_NONE;
		}

		if(p_state == STATE_CLAUSE) {
			literal_type literal = atoi(token);
			if(literal != 0) {
				p_clause.push_back(literal);
			}else{
		/*		printf("Read clause:");
				for(int i = 0; i < p_clause.size(); i++)
					printf(" %d", p_clause[i]);
				printf("\n");*/
				p_handler.read_clause(p_clause);
				p_clause.clear();
				p_state = STATE_NONE;
			}
		}
	}
	
	void p_process_endline() {
		SYS_ASSERT(SYS_ASRT_GENERAL, p_state != STATE_PROBLEM_AFTER_P);
		SYS_ASSERT(SYS_ASRT_GENERAL, p_state != STATE_PROBLEM_AFTER_TYPE);
		SYS_ASSERT(SYS_ASRT_GENERAL, p_state != STATE_PROBLEM_AFTER_VARS);
	}
	
	/* stream we are reading from */
	std::istream &p_istream;

	/* handler that receives all the read clauses */
	Hooks &p_handler;

	/* state we are currently in */
	state_type p_state;

	/* clause we are currently reading */
	std::vector<literal_type> p_clause;
};

}}}; /* namespace problem::sat::dimacs */

