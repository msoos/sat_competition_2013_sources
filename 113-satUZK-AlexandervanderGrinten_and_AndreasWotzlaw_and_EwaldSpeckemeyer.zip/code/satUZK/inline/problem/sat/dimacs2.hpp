
typedef long number_type;
typedef std::string word_type;

enum token_type {
	none,
	word,
	number
};
enum process_type {
	ignore,
	consume,
	finish,
	finish_newline,
	end_of_stream
};

static const char eof_char = 0x04;

struct mmap_stream {
	void *pointer;
	uintptr_t offset;
	uintptr_t length;
};

struct base_reader {
	/* last/current token we were reading */
	token_type current_token;
	/* last/current number we were reading */
	long current_number;
	bool current_negative;
	/* last/current string we were reading */
	std::string current_word;
	
	/* must be called before reading each token */
	void clear_token() {
		current_number = 0;
		current_negative = false;
		current_word.clear();
		current_token = token_type::none;
	}

	long get_number() {
		if(current_negative)
			return -current_number;
		return current_number;
	}

	process_type skip_line(mmap_stream &stream) {
		process_type result;
		do {
			if(stream.offset == stream.length) {
				if(skip_line_char(eof_char) != end_of_stream)
					SYS_CRITICAL("Unexpected end of stream\n");
				return end_of_stream;
			}
			char *pointer = (char*)stream.pointer + stream.offset;
			result = skip_line_char(*pointer);
			stream.offset++;
		}while(result != process_type::finish && result != process_type::finish_newline);
		return result;
	}
	process_type skip_line(std::istream &istream) {
		if(istream.fail())
			SYS_CRITICAL("Stream is in illegal state\n");
		process_type result;
		do {
			int character = istream.get();
			if(istream.eof()) {
				if(skip_line_char(eof_char) != end_of_stream)
					SYS_CRITICAL("Unexpected end of stream\n");
				return end_of_stream;
			}
			if(istream.fail())
				SYS_CRITICAL("Could not read from stream\n");
			result = skip_line_char(character);
		}while(result != process_type::finish && result != process_type::finish_newline);
		return result;
	}

	process_type read_token(mmap_stream &stream) {
		process_type result;
		do {
			if(stream.offset == stream.length) {
				if(read_token_char(eof_char) != end_of_stream)
					SYS_CRITICAL("Unexpected end of stream\n");
				return end_of_stream;
			}
			char *pointer = (char*)stream.pointer + stream.offset;
			result = read_token_char(*pointer);
			stream.offset++;
		}while(result != process_type::finish && result != process_type::finish_newline);
		return result;
	}
	process_type read_token(std::istream &istream) {
		if(istream.fail())
			SYS_CRITICAL("Stream is in illegal state\n");
		process_type result;
		do {
			int character = istream.get();
			if(istream.eof()) {
				if(read_token_char(eof_char) != end_of_stream)
					SYS_CRITICAL("Unexpected end of stream\n");
				return end_of_stream;
			}
			if(istream.fail())
				SYS_CRITICAL("Could not read from stream\n");
			result = read_token_char(character);
		}while(result != process_type::finish && result != process_type::finish_newline);
		return result;
	}
	
	process_type skip_line_char(char character) {
		if(character == '\n' || character == '\r') {
			return process_type::finish_newline;
		}else if(character == eof_char) {
			return process_type::end_of_stream;
		}else return process_type::ignore;
	}
	
	process_type read_token_char(char character) {
		 if(character == eof_char) {
			return process_type::end_of_stream;
		}else if(current_token == token_type::number) {
			/* process following characters of number */
			if(character == ' ' || character == '\t') {
				return process_type::finish;
			}else if(character == '\n' || character == '\r') {
				return process_type::finish_newline;
			}else if(character >= '0' && character <= '9') {
				current_number *= 10;
				current_number += digit(character);
				return process_type::consume;
			}else{
				SYS_CRITICAL("Illegal character in number\n");
			}
		}else if(current_token == token_type::word) {
			/* process following characters of word */
			if(character == ' ' || character == '\t') {
				return process_type::finish;
			}else if(character == '\n' || character == '\r') {
				return process_type::finish_newline;
			}else if((character >= 'a' && character <= 'z')
					|| (character >= 'A' && character <= 'Z')
					|| (character >= '0' && character <= '9')) {
				current_word.push_back(character);
				return process_type::consume;
			}else{
				SYS_CRITICAL("Illegal character in word\n");
			}
		}else if(current_token == token_type::none) {
			if(character == ' ' || character == '\t'
					|| character == '\n' || character == '\r') {
				return process_type::ignore;
			}else if(character >= '0' && character <= '9') {
				/* proces the first character of a positive number */
				current_token = token_type::number;
				current_number = digit(character);
				return process_type::consume;
			}else if(character == '-') {
				/* proces the first character of a negative number */
				current_negative = true;
				current_token = token_type::number;
				return process_type::consume;
			}else if((character >= 'a' && character <= 'z')
					|| (character >= 'A' && character <= 'Z')) {
				/* process the first character of a word */
				current_token = token_type::word;
				current_word = character;
				return process_type::consume;
			}else SYS_CRITICAL("Illegal character %d in file\n", character);
		}else SYS_CRITICAL("Illegal token\n");
	}

	int digit(char character) {
		return (int)(character - '0');
	}
	
};

template<typename Hooks, typename Stream>
class cnf_reader_struct {
public:
	cnf_reader_struct(Hooks &hooks) : p_hooks(hooks) { }

	void read(Stream &istream) {
		std::vector<long> clause;

		process_type result;
		while(true) {
			p_state.clear_token();
			result = p_state.read_token(istream);
			if(result == process_type::end_of_stream)
				break;

			if(p_state.current_token == token_type::word
					&& p_state.current_word == "c") {
				/* skip comment lines */
				if(result != process_type::finish_newline)
					p_state.skip_line(istream);
			}else if(p_state.current_token == token_type::word
					&& p_state.current_word == "p") {
				/* read the format definition */
				p_state.clear_token();
				result = p_state.read_token(istream);
				if(result == process_type::end_of_stream)
					SYS_CRITICAL("Unexpected end-of-stream\n");
				if(p_state.current_token != token_type::word)
					SYS_CRITICAL("Unexpected token\n");

				/* read the number of variables */
				p_state.clear_token();
				result = p_state.read_token(istream);
				if(result == process_type::end_of_stream)
					SYS_CRITICAL("Unexpected end-of-stream\n");
				if(p_state.current_token != token_type::number)
					SYS_CRITICAL("Unexpected token\n");
				long num_vars = p_state.get_number();
				
				/* read the number of clauses */
				p_state.clear_token();
				result = p_state.read_token(istream);
				if(result == process_type::end_of_stream)
					SYS_CRITICAL("Unexpected end-of-stream\n");
				if(p_state.current_token != token_type::number)
					SYS_CRITICAL("Unexpected token\n");
				long num_clauses = p_state.get_number();
				
				p_hooks.on_problem(num_vars, num_clauses);
			}else if(p_state.current_token == token_type::number) {
				/* read clauses */
				clause.clear();
				
				while(p_state.get_number() != 0) {
					clause.push_back(p_state.get_number());
				
					p_state.clear_token();
					result = p_state.read_token(istream);
					if(result == process_type::end_of_stream)
						SYS_CRITICAL("Unexpected end-of-stream\n");
					if(p_state.current_token != token_type::number)
						SYS_CRITICAL("Unexpected token\n");
				}
				
				p_hooks.on_clause(clause);
			}else SYS_CRITICAL("Illegal token\n");
		}
	}
	
private:
	Hooks &p_hooks;
	base_reader p_state;
};

template<typename Hooks, typename Stream>
class cert_reader_struct {
public:
	cert_reader_struct(Hooks &hooks) : p_hooks(hooks) { }

	void read(Stream &istream) {
		std::vector<long> clause;

		process_type result;
		while(true) {
			p_state.clear_token();
			result = p_state.read_token(istream);
			if(result == process_type::end_of_stream)
				break;

			if(p_state.current_token == token_type::word
					&& p_state.current_word == "c") {
				/* skip comment lines */
				p_state.skip_line(istream);
			}else if(p_state.current_token == token_type::word
					&& p_state.current_word == "s") {
				p_state.clear_token();
				result = p_state.read_token(istream);
				if(result == process_type::end_of_stream)
					SYS_CRITICAL("Unexpected end-of-stream\n");
				if(p_state.current_token != token_type::word)
					SYS_CRITICAL("Unexpected token\n");

				if(p_state.current_word == "SATISFIABLE") {
					p_hooks.on_output(10);
				}else if(p_state.current_word == "UNSATISFIABLE") {
					p_hooks.on_output(20);
				}else p_hooks.on_output(0);
			}else if(p_state.current_token == token_type::word
					&& p_state.current_word == "v") {
				/* read the satisfying assignment */
				do {
					p_state.clear_token();
					result = p_state.read_token(istream);
					if(result == process_type::end_of_stream)
						SYS_CRITICAL("Unexpected end-of-stream\n");
					if(p_state.current_token != token_type::number)
						SYS_CRITICAL("Unexpected token\n");
					
					if(p_state.get_number() != 0)
						p_hooks.on_assignment(p_state.get_number());
				} while(p_state.get_number() != 0);
			}else SYS_CRITICAL("Illegal token\n");
		}
	}
	
private:
	Hooks &p_hooks;
	base_reader p_state;
};

