
namespace problem {
namespace sat {
namespace packed_clause {

template<typename Literal, typename LitIndex,
	typename Activity>
struct head_struct {
	static const uint32_t QUEUED_FOR_INSTALL = 8;
	static const uint32_t QUEUED_FOR_DELETE = 16;
	static const uint32_t IMPROVED = 32;
	static const uint32_t CHECKED_DIST = 64;
	static const uint32_t CREATED_VECD = 128;
	static const uint32_t CHECKED_SSUB = 256;
	
	/* bit 0: clause is installed i.e. in watch lists */
	static const uint32_t FLAG_INSTALLED_SHIFT = 0;
	/* bit 1: marked for deletion */
	static const uint32_t FLAG_DELETE_SHIFT = 1;
	/* bit 2: marked essential i.e. must not be deleted */
	static const uint32_t FLAG_ESSENTIAL_SHIFT = 2;

	/* flags defined above */
	uint32_t flags;
	/* number of literals of the clause */
	LitIndex num_literals;
	Literal literals[0];

	void construct(LitIndex new_num_literals) {
		flags = 0;
		num_literals = new_num_literals;
	}

	bool get_delete() {
		return (flags & (1 << FLAG_DELETE_SHIFT)) != 0;
	}
	void set_delete(bool value) {
		flags &= ~(1 << FLAG_DELETE_SHIFT);
		flags |= (value ? 1 : 0) << FLAG_DELETE_SHIFT;
	}
	
	bool get_installed() {
		return (flags & (1 << FLAG_INSTALLED_SHIFT)) != 0;
	}
	void set_installed(bool value) {
		flags &= ~(1 << FLAG_INSTALLED_SHIFT);
		flags |= (value ? 1 : 0) << FLAG_INSTALLED_SHIFT;
	}
	
	bool get_essential() {
		return (flags & (1 << FLAG_ESSENTIAL_SHIFT)) != 0;
	}
	void set_essential(bool value) {
		flags &= ~(1 << FLAG_ESSENTIAL_SHIFT);
		flags |= (value ? 1 : 0) << FLAG_ESSENTIAL_SHIFT;
	}

	bool get_improved() { return (flags & IMPROVED) != 0; }
	void set_improved() { flags |= IMPROVED; }
	void clear_improved() { flags &= ~IMPROVED; }

	/* allows access to the clause body */
	void *access(int offset) {
		return (void*)((uintptr_t)this + sizeof
				(head_struct<Literal, LitIndex, Activity>) + offset);
	}

	/* allows access to literals */
	Literal *literal(LitIndex index) {
		Literal *litptr = (Literal*)access(index * sizeof(Literal));
		return litptr;
	}
};

struct tail_struct {
	double activity;
	uint64_t signature;
	uint16_t lbd;
};

template<typename Literal, typename LitIndex,
	typename Activity, typename ClauseIndex>
class config_type {
public:
	typedef Literal literal_type;
	typedef LitIndex litindex_type;
	typedef Activity activity_type;
	typedef ClauseIndex index_type;
	
	typedef head_struct<Literal, LitIndex, Activity> head_type;
	typedef tail_struct tail_type;

	typedef std::vector<ClauseIndex> index_vector;
	typedef typename index_vector::iterator index_iterator;
	typedef typename index_vector::size_type size_type;

	typedef config_type<Literal, LitIndex, Activity, ClauseIndex> this_type;

	config_type() : clauses_bytes(0), present_clauses(0), deleted_clauses(0),
			p_present_literals(0) { }

	index_iterator begin() {
		return p_indices.begin();
	}
	index_iterator end() {
		return p_indices.end();
	}

	void push_back(index_type index) {
		p_indices.push_back(index);
	}

	size_type num_clauses() {
		return p_indices.size();
	}
	size_type get_clauses_bytes() {
		return clauses_bytes;
	}
	uint64_t present_literals() {
		return p_present_literals;
	}

	litindex_type adjust_len(litindex_type length) {
		if(length % 2 == 1)
			return length + 1;
		return length;
	}
	index_type calc_bytes(litindex_type length) {
		return sizeof(head_type)
				+ adjust_len(length) * sizeof(literal_type)
				+ sizeof(tail_type);
	}
	template<typename ClauseAlloc>
	head_type *get_head(ClauseAlloc &alloc, index_type index) {
		return (head_type*)alloc[index];
	}
	template<typename ClauseAlloc>
	tail_type *get_tail(ClauseAlloc &alloc, index_type index) {
		auto headptr = get_head(alloc, index);
		auto adj_length = adjust_len(headptr->num_literals);
		return (tail_type*)headptr->access(adj_length * sizeof(literal_type));
	}

	template<typename ClauseAlloc>
	void set_delete(ClauseAlloc &alloc, index_type clause) {
		get_head(alloc, clause)->set_delete(true);
		present_clauses--;
		deleted_clauses++;
		p_present_literals += get_head(alloc, clause)->num_literals;
	}
	template<typename ClauseAlloc>
	bool get_delete(ClauseAlloc &alloc, index_type clause) {
		return get_head(alloc, clause)->get_delete();
	}

	template<typename ClauseAlloc>
	void prun_deleted(ClauseAlloc &alloc) {
		auto j = p_indices.begin();
		for(auto i = p_indices.begin(); i != p_indices.end(); ++i) {
			head_type *headptr = get_head(alloc, *i);
			if(headptr->get_delete()) {
				clauses_bytes -= calc_bytes(headptr->num_literals);
				continue;
			}
			*j = *i;
			j++;
		}
		p_indices.resize(j - p_indices.begin());
		deleted_clauses = 0;
	}

	unsigned int clauses_bytes;

	index_vector p_indices;
	unsigned int present_clauses;
	unsigned int deleted_clauses;
	uint64_t p_present_literals;
};

template<typename Config, typename ClauseAlloc>
typename Config::head_type *get_head(ClauseAlloc &alloc,
		typename Config::index_type index) {
	return (typename Config::head_type*)alloc[index];
}

template<typename Config, typename ClauseAlloc>
typename Config::index_type new_clause(Config &config,
		ClauseAlloc &cl_alloc, typename Config::litindex_type length) {
	/* allocate memory for the clause */
	typename ClauseAlloc::index_type bytelen = config.calc_bytes(length);
	typename ClauseAlloc::index_type index = cl_alloc.alloc(bytelen);

	/* we have to setup the head before we can use get_tail()! */
	auto head = config.get_head(cl_alloc, index);
	head->construct(length);

	auto tail = config.get_tail(cl_alloc, index);
	tail->lbd = 0;
	tail->activity = 0.0f;
	tail->signature = 0;

	config.push_back(index);
	config.clauses_bytes += bytelen;
	config.present_clauses++;
	config.p_present_literals += length;
	return index;
}

template<typename Config, typename ClauseAlloc,
		typename Callback>
void relocate(Config &from_config, ClauseAlloc &from_alloc,
		Config &to_config, ClauseAlloc &to_alloc, Callback &callback) {
	typename Config::index_iterator write_ptr = from_config.begin();
	for(typename Config::index_iterator it = from_config.begin();
			it != from_config.end(); ++it) {
		typename Config::index_type from_index = *it;
		typename Config::head_type *from_head = get_head<Config, ClauseAlloc>
				(from_alloc, from_index);
		if(from_head->get_delete())
			continue;
		
		/* allocate the new clause */
		typename Config::index_type to_index = new_clause
				(to_config, to_alloc, from_head->num_literals);
		auto from_tail = from_config.get_tail(from_alloc, from_index);
		typename Config::head_type *to_head = get_head<Config, ClauseAlloc>
				(to_alloc, to_index);
		auto to_tail = from_config.get_tail(to_alloc, to_index);
		
		/* copy all flags, literals, etc. */
		for(typename Config::litindex_type i = 0;
				i < from_head->num_literals; i++) {
			typename Config::literal_type literal = *from_head->literal(i);
			*to_head->literal(i) = literal;
		}
		to_head->flags = from_head->flags;
		to_tail->lbd = from_tail->lbd;
		to_tail->activity = from_tail->activity;
		to_tail->signature = from_tail->signature;

		callback.on_move(from_alloc, to_alloc, from_index, to_index);
	}
	from_config.deleted_clauses = 0;
}

template<typename Config, typename Allocator>
class iterator_struct {
public:
	iterator_struct(Allocator &allocator, typename Config::index_type clause,
			typename Config::litindex_type index) {
		p_index = get_head<Config, Allocator>(allocator, clause)->literal(index);
	}

	void operator++ () {
		p_index++;
	}
	bool operator== (const iterator_struct<Config, Allocator> &other) const {
		return p_index == other.p_index;
	}
	bool operator!= (const iterator_struct<Config, Allocator> &other) const {
		return p_index != other.p_index;
	}
	typename Config::literal_type &operator* () {
		return *p_index;
	}
	
private:
	typename Config::literal_type *p_index;
};

/*template<typename Config, typename Allocator>
class iterator_struct {
public:
	iterator_struct(Allocator &allocator, typename Config::index_type clause,
			typename Config::litindex_type index)
			: p_allocator(allocator), p_clause(clause), p_index(index) { }

	void operator++ () {
		p_index++;
	}
	bool operator== (const iterator_struct<Config, Allocator> &other) const {
		return p_index == other.p_index;
	}
	bool operator!= (const iterator_struct<Config, Allocator> &other) const {
		return p_index != other.p_index;
	}
	typename Config::literal_type &operator* () {
		typename Config::head_type *head = get_head
				<Config, Allocator>(p_allocator, p_clause);
		return *head->literal(p_index);
	}
	
private:
	Allocator &p_allocator;
	typename Config::index_type p_clause;
	typename Config::litindex_type p_index;
};*/

}}}; /* namespace problem::sat::packed_clause */

