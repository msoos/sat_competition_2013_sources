
#include <cstdint>

#include <string>
#include <vector>
#include <set>

#include <iostream>
#include <fstream>

#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>

#include "../../inline/sys/debug.hpp"
#include "../../inline/problem/sat/dimacs2.hpp"

class config_struct {
public:
	int exit_code;
	int unsat_clauses;

	config_struct() : exit_code(-1), unsat_clauses(0) { }

	void put_assign(long literal) {
		if(is_assigned(-literal))
			std::cout << "Illegal assignment!" << std::endl;
		p_assigned.insert(literal);
	}
	bool is_assigned(long literal) {
		return (p_assigned.find(literal) != p_assigned.end());
	}
private:
	std::set<long> p_assigned;
};

class cnf_hooks_struct {
public:
	cnf_hooks_struct(config_struct &config) : p_config(config) { }

	void on_problem(long num_variables, long num_clauses) {

	}

	void on_clause(std::vector<long> &clause) {
//		std::cout << "Clause: Length: " << clause.size() << std::endl;
		for(auto i = clause.begin(); i != clause.end(); ++i) {
//			std::cout << "   " << *i << std::endl;
			if(p_config.is_assigned(*i)) {
//				std::cout << "   Assigned" << std::endl;
				return;
			}
		}
		p_config.unsat_clauses++;
	}

private:
	config_struct &p_config;
};

class cert_hooks_struct {
public:
	cert_hooks_struct(config_struct &config) : p_config(config) { }

	void on_output(int exit_code) {
		p_config.exit_code = exit_code;
	}
	void on_assignment(long literal) {
		p_config.put_assign(literal);
	}

private:
	config_struct &p_config;
};

int main(int argc, char **argv) {
	SYS_ASSERT(SYS_ASRT_GENERAL, argc == 3);

	const char *cnf_filename = argv[1];
	const char *cert_filename = argv[2];

	config_struct config;
	cert_hooks_struct cert_hooks(config);
	cnf_hooks_struct cnf_hooks(config);

	cert_reader_struct<cert_hooks_struct, std::fstream> cert_reader(cert_hooks);
	cnf_reader_struct<cnf_hooks_struct, std::fstream> cnf_reader(cnf_hooks);
	
	std::fstream cert_stream(cert_filename);
	std::fstream cnf_stream(cnf_filename);

	cert_reader.read(cert_stream);
	cnf_reader.read(cnf_stream);
	
	cert_stream.close();
	cnf_stream.close();
	
	if(config.exit_code != 10) {
		std::cout << "Nothing to check" << std::endl;
		return 0;
	}else if(config.unsat_clauses == 0) {
		std::cout << "Checked: Okay" << std::endl;
		return 0;
	}else if(config.unsat_clauses != 0) {
		std::cout << "Checked: Error!" << std::endl;
		return 1;
	}
}

