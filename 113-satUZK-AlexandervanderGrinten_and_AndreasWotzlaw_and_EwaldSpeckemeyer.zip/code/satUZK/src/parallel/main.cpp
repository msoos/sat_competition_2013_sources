
#include <algorithm>
#include <vector>
#include <map>
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <random>
#include <cstring>
#include "../../inline/sys/debug.hpp"
#include "../../inline/util/performance.hpp"
#include "../../inline/util/shuffle.hpp"
#include "../../inline/util/memory/bulk_alloc.hpp"
#include "../../inline/util/heaps/binary.hpp"
#include "../../inline/util/vectors/simple.hpp"
#include "../../inline/problem/sat/vars.hpp"
#include "../../inline/problem/sat/packed_clause.hpp"
#include "../../inline/problem/sat/prop.hpp"
#include "../../inline/problem/sat/first_uip.hpp"
#include "../../inline/problem/sat/lbd.hpp"
#include "../../inline/problem/sat/ext_model.hpp"
#include "../../inline/problem/sat/simp_vecd.hpp"
#include "../../inline/problem/sat/simp_bce.hpp"
#include "../../inline/problem/sat/simp_brm.hpp"
#include "../../inline/problem/sat/simp_ssub.hpp"
#include "../../inline/problem/sat/simp_ssc.hpp"
#include "../../inline/problem/sat/simp_fle2.hpp"
#include "../../inline/problem/sat/simp_hla.hpp"
#include "../../inline/problem/sat/simp_hle.hpp"
#include "../../inline/problem/sat/simp_dist.hpp"
#include "../../inline/problem/sat/simp_unhiding.hpp"
//#include "../../inline/problem/sat/dimacs.hpp"
#include "../../inline/problem/sat/dimacs2.hpp"
#include "../../inline/prog/sat_core/config.hpp"

#ifdef FEATURE_GOOGLE_PROFILE
#include <google/profiler.h>
#endif

typedef uint32_t literal_type;
typedef uint32_t variable_type;
typedef uint32_t litindex_type;
typedef uint32_t clause_type;
typedef uint32_t order_type;
typedef double activity_type;
typedef uint32_t declevel_type;

typedef prog::sat_core::config_struct<literal_type, litindex_type, clause_type,
		order_type, activity_type, declevel_type> config_type;

template<typename Config>
class read_hooks_struct2 {
private:
	typedef std::map<long, typename Config::variable_type> map_type;
public:
	read_hooks_struct2(Config &config) : p_config(config) { }

	void on_clause(std::vector<long> &in_clause) {
		/* remove duplicates and check for tautologies */
		auto k = in_clause.begin();
		for(auto i = in_clause.begin(); i != in_clause.end(); ++i) {
			bool duplicate = false;
			for(auto j = i + 1; j != in_clause.end(); ++j) {
				if(*j == *i) {
					duplicate = true;
				}else if(*j == -*i) {
					return;
				}
			}
			if(duplicate)
				continue;
			*k = *i;
			k++;
		}
		in_clause.resize(k - in_clause.begin());
		
		/* transform input variable ids to internal variable ids */
		std::vector<typename Config::literal_type> out_clause;
		for(auto it = in_clause.begin(); it != in_clause.end(); ++it) {
			long in_literal = *it;
			long in_variable = in_literal < 0 ? -in_literal : in_literal;
			
			/* map input variables to internal variables */
			typename map_type::iterator mapped = p_variable_map.lower_bound(in_variable);
			if((*mapped).first != in_variable) {
				auto var = p_config.var_alloc();
				mapped = p_variable_map.insert(mapped,
						typename map_type::value_type(in_variable, var));
			}
						
			typename Config::literal_type literal = in_literal < 0
					? p_config.zero_literal((*mapped).second)
					: p_config.one_literal((*mapped).second);
			out_clause.push_back(literal);
		}
		
		/* permutate the input clause */
		if(p_config.opts.general.permutate_input)
			util::shuffle(out_clause.begin(), out_clause.end(),
					p_config.rnd_engine);
		
		if(out_clause.size() == 1) {
			typename Config::literal_type literal = out_clause[0];
			SYS_ASSERT(SYS_ASRT_GENERAL, !p_config.lit_false(literal));
			if(!p_config.lit_true(literal))
				p_config.push_assign(out_clause[0],
						Config::antecedent_type::make_decision());
		}else{
			SYS_ASSERT(SYS_ASRT_GENERAL, out_clause.size() > 1);
			typename Config::clause_type clause = p_config.clause_alloc(out_clause.size(),
					out_clause.begin(), out_clause.end());
			p_config.clause_head(clause)->set_essential(true);
//			std::cout << "Reading clause: " << p_config.print_clause(clause) << std::endl;
		}
	}
	
	map_type p_variable_map;
	Config &p_config;
};

struct thread_config_struct {
	std::string instance_file;
	config_type config;
	pthread_t pthread;
};

void *thread_main(void *config_pointer) {
	thread_config_struct &thread_config
			= *(thread_config_struct*)config_pointer;

	config_type &config = thread_config.config;

	/* read the cnf file */
	std::ifstream stream(thread_config.instance_file);
	
	read_hooks_struct2<config_type> read_hooks(config);
	cnf_reader_struct<decltype(read_hooks), std::ifstream> reader(read_hooks);
	reader.read(stream);

	std::cout << "c parse time: " << sysGetCpuTime() << " ms" << std::endl;

	config.initialize();
	
	/* run the solver */
	solve_state result =  solve_step(config);
	if(result == SOLVE_SOLUTION) {
		std::cout << "s SATISFIABLE" << std::endl;
	}else if(result == SOLVE_FINISHED) {
		std::cout << "s UNSATISFIABLE" << std::endl;
	}else std::cout << "s UNKNOWN" << std::endl;
	
	return NULL;
}

int main(int argc, char **argv) {
	SYS_ASSERT(SYS_ASRT_GENERAL, argc == 2);
	
	std::mt19937 master_engine;
	
	std::vector<thread_config_struct*> threads;
	for(int i = 0; i < 4; ++i) {
		thread_config_struct *trd_config = new thread_config_struct;
		trd_config->instance_file = std::string(argv[1]);

		/* set the solver's configuration */	
		trd_config->config.cfg_seed(master_engine());
		trd_config->config.opts.general.permutate_input = true;
	
		if(pthread_create(&trd_config->pthread, NULL,
				thread_main, trd_config) != 0)
			SYS_CRITICAL("Could not create new pthread\n");
		threads.push_back(trd_config);
	}

	for(auto i = threads.begin(); i != threads.end(); ++i) {
		if(pthread_join((**i).pthread, NULL) != 0)
			SYS_CRITICAL("Could not pthread\n");
	}
}

