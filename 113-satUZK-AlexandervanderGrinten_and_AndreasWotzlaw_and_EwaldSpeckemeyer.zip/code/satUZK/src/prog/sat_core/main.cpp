
#include <unistd.h>
#include <algorithm>
#include <vector>
#include <map>
#include <queue>
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <random>
#include <stdexcept>
#include <cstring>
#include <csignal>
#include "../../../inline/sys/debug.hpp"
#include "../../../inline/util/performance.hpp"
#include "../../../inline/util/shuffle.hpp"
#include "../../../inline/util/memory/bulk_alloc.hpp"
#include "../../../inline/util/heaps/binary.hpp"
#include "../../../inline/util/chunk_list.hpp"
#include "../../../inline/util/vectors/simple.hpp"
#include "../../../inline/problem/sat/vars.hpp"
#include "../../../inline/problem/sat/packed_clause.hpp"
#include "../../../inline/problem/sat/prop.hpp"
#include "../../../inline/problem/sat/lbd.hpp"
#include "../../../inline/problem/sat/first_uip.hpp"
#include "../../../inline/problem/sat/ext_model.hpp"
#include "../../../inline/problem/sat/search.hpp"
#include "../../../inline/problem/sat/simp_equiv.hpp"
#include "../../../inline/problem/sat/simp_vecd.hpp"
#include "../../../inline/problem/sat/simp_bce.hpp"
#include "../../../inline/problem/sat/simp_brm.hpp"
#include "../../../inline/problem/sat/simp_ssub.hpp"
#include "../../../inline/problem/sat/simp_dist.hpp"
#include "../../../inline/problem/sat/simp_unhiding.hpp"
#include "../../../inline/problem/sat/lookahead.hpp"
#include "../../../inline/problem/sat/dimacs2.hpp"
#include "../../../inline/problem/sat/utils.hpp"
#include "../../../inline/problem/sat/misc_structs.hpp"
#include "../../../inline/prog/sat_core/preproc.hpp"
#include "../../../inline/prog/sat_core/inproc.hpp"
#include "../../../inline/prog/sat_core/config.hpp"

#ifdef FEATURE_GOOGLE_PROFILE
#include <google/profiler.h>
#endif

typedef uint32_t literal_type;
typedef uint32_t variable_type;
typedef uint32_t litindex_type;
typedef uint32_t clause_type;
typedef uint32_t order_type;
typedef double activity_type;
typedef uint32_t declevel_type;

struct basedefs {
	typedef uint32_t literal_type;
	typedef uint32_t variable_type;
	typedef uint32_t litindex_type;
	typedef uint32_t clause_type;
	typedef uint32_t order_type;
	typedef double activity_type;
	typedef uint32_t declevel_type;
};

typedef prog::sat_core::config_struct<basedefs> config_type;

template<typename Config>
class read_hooks_struct2 {
public:
	read_hooks_struct2(Config &config) : p_config(config) { }
	
	void on_problem(long num_vars, long num_clauses) {
		p_config.var_reserve(num_vars);
		for(long i = 0; i < num_vars; ++i)	
			p_config.var_alloc();
		p_var_count = num_vars;
		std::cout << "c var memory: " << sys_peak_memory() << " kb" << std::endl;
//		exit(0);
	}

	void on_clause(std::vector<long> &in_clause) {
		/* remove duplicates and check for tautologies */
		auto k = in_clause.begin();
		for(auto i = in_clause.begin(); i != in_clause.end(); ++i) {
			bool duplicate = false;
			for(auto j = i + 1; j != in_clause.end(); ++j) {
				if(*j == *i) {
					duplicate = true;
				}else if(*j == -*i) {
					return;
				}
			}
			if(duplicate)
				continue;
			*k = *i;
			k++;
		}
		in_clause.resize(k - in_clause.begin());
		
		/* transform input variable ids to internal variable ids */
		std::vector<typename Config::literal_type> out_clause;
		for(auto it = in_clause.begin(); it != in_clause.end(); ++it) {
			long in_literal = *it;
			long in_variable = in_literal < 0 ? -in_literal : in_literal;
			
			typename Config::variable_type map_variable
					= in_variable - 1;
			SYS_ASSERT(SYS_ASRT_GENERAL, map_variable < p_config.p_var_config.count());
			typename Config::literal_type map_literal = in_literal < 0
					? p_config.zero_literal(map_variable)
					: p_config.one_literal(map_variable);
			out_clause.push_back(map_literal);
		}
		
		/* permutate the input clause */
		if(p_config.opts.general.permutate_input)
			util::shuffle(out_clause.begin(), out_clause.end(),
					p_config.rnd_engine);
		
		if(out_clause.size() == 1) {
			typename Config::literal_type literal = out_clause[0];
			SYS_ASSERT(SYS_ASRT_GENERAL, !p_config.lit_false(literal));
			if(!p_config.lit_true(literal))
				p_config.push_assign(out_clause[0],
						Config::antecedent_type::make_decision());
		}else{
			SYS_ASSERT(SYS_ASRT_GENERAL, out_clause.size() > 1);
			p_config.clause_input(out_clause.size(),
					out_clause.begin(), out_clause.end());
		}
	}

	long num_variables() {
		return p_var_count;
	}
	typename Config::variable_type map_variable(long in_variable) {
		return in_variable - 1;
	}

	long p_var_count;

	Config &p_config;
};

config_type *the_config = new config_type;

void on_interrupt(int sig) {
	std::cout << "c signal: ";
	switch(sig) {
	case SIGINT: std::cout << "SIGINT"; break;
	case SIGXCPU: std::cout << "SIGXCPU"; break;
	default: std::cout << sig;
	}
	std::cout << std::endl;
	the_config->state.general.stop_solve = true;
}

int main(int argc, char **argv) {
	config_type &config = *the_config;

	if(signal(SIGINT, on_interrupt) == SIG_ERR
			|| signal(SIGXCPU, on_interrupt) == SIG_ERR)
		throw std::runtime_error("Could not install signal handler");

	/* parse the parameters given to the solver */
	std::vector<std::string> args;
	for(int i = 1; i < argc; ++i)
		args.push_back(std::string(argv[i]));

	bool show_model = false;

	std::string instance;
	std::string model_file;
	for(auto i = args.begin(); i != args.end(); /* no increment here */) {
		if(*i == "-v") {
			config.opts.general.verbose = 3;
			++i;
		}else if(*i == "-budget") {
			++i;
			if(i == args.end()) {
				std::cout << "Expected argument for -budget" << std::endl;
				return 0;
			}
			config.opts.general.budget = std::atoi((*i).c_str())
					* 1000LL * 1000LL * 1000LL;
			++i;
		}else if(*i == "-timeout") {
			++i;
			if(i == args.end()) {
				std::cout << "Expected argument for -timeout" << std::endl;
				return 0;
			}
			config.opts.general.budget = std::atoi((*i).c_str())
					* 1000LL * 1000LL * 1000LL;
			config.opts.general.timeout = std::atoi((*i).c_str())
					* 1000LL * 1000LL * 1000LL;
			++i;
		}else if(*i == "-seed") {
			++i;
			if(i == args.end()) {
				std::cout << "Expected argument for -seed" << std::endl;
				return 0;
			}
			config.cfg_seed(std::atoi((*i).c_str()));
			++i;
		}else if(*i == "-permutate-input") {
			config.opts.general.permutate_input = true;
			++i;
		}else if(*i == "-preproc-iterative") {
			config.opts.preproc.model = config_type::preproc_model_iterative;
			++i;
		}else if(*i == "-preproc-adaptive") {
			config.opts.preproc.model = config_type::preproc_model_adaptive;
			++i;
		}else if(*i == "-preproc-iterations") {
			++i;
			if(i == args.end()) {
				std::cout << "Expected argument for -preproc-iterations" << std::endl;
				return 0;
			}
			config.opts.preproc.iterations = std::atoi((*i).c_str());
			++i;
		}else if(*i == "-preproc-model1") {
			config.opts.preproc.model = config_type::preproc_model_adaptive;
			config.opts.preproc.with_vecd = true;
			config.opts.preproc.with_bce = false;
			config.opts.preproc.with_selfsub = false;
			config.opts.preproc.with_unhiding = false;
			config.opts.preproc.with_brm = false;
			++i;
		}else if(*i == "-preproc-model2") {
			config.opts.preproc.model = config_type::preproc_model_adaptive;
			config.opts.preproc.with_vecd = false;
			config.opts.preproc.with_bce = false;
			config.opts.preproc.with_selfsub = true;
			config.opts.preproc.with_unhiding = false;
			config.opts.preproc.with_brm = false;
			++i;
		}else if(*i == "-preproc-model3") {
			config.opts.preproc.model = config_type::preproc_model_adaptive;
			config.opts.preproc.with_vecd = true;
			config.opts.preproc.with_bce = false;
			config.opts.preproc.with_selfsub = true;
			config.opts.preproc.with_unhiding = false;
			config.opts.preproc.with_brm = false;
			++i;
		}else if(*i == "-preproc-model4") {
			config.opts.preproc.model = config_type::preproc_model_adaptive;
			config.opts.preproc.with_vecd = false;
			config.opts.preproc.with_bce = true;
			config.opts.preproc.with_selfsub = false;
			config.opts.preproc.with_unhiding = false;
			config.opts.preproc.with_brm = false;
			++i;
		}else if(*i == "-preproc-model5") {
			config.opts.preproc.model = config_type::preproc_model_adaptive;
			config.opts.preproc.with_vecd = true;
			config.opts.preproc.with_bce = true;
			config.opts.preproc.with_selfsub = true;
			config.opts.preproc.with_unhiding = false;
			config.opts.preproc.with_brm = false;
			++i;
		}else if(*i == "-preproc-model6") {
			config.opts.preproc.model = config_type::preproc_model_adaptive;
			config.opts.preproc.with_vecd = false;
			config.opts.preproc.with_bce = false;
			config.opts.preproc.with_selfsub = false;
			config.opts.preproc.with_unhiding = true;
			config.opts.preproc.with_brm = false;
			++i;
		}else if(*i == "-preproc-model7") {
			config.opts.preproc.model = config_type::preproc_model_adaptive;
			config.opts.preproc.with_vecd = true;
			config.opts.preproc.with_bce = true;
			config.opts.preproc.with_selfsub = true;
			config.opts.preproc.with_unhiding = true;
			config.opts.preproc.with_brm = false;
			++i;
		}else if(*i == "-preproc-model8") {
			config.opts.preproc.model = config_type::preproc_model_adaptive;
			config.opts.preproc.with_vecd = true;
			config.opts.preproc.with_bce = true;
			config.opts.preproc.with_selfsub = false;
			config.opts.preproc.with_unhiding = true;
			config.opts.preproc.with_brm = false;
			++i;
		}else if(*i == "-inproc-adaptive") {
			config.opts.inproc.model = config_type::inproc_model_adaptive;
			++i;
		}else if(*i == "-inproc-model1") {
			config.opts.inproc.model = config_type::inproc_model_adaptive;
			config.opts.inproc.with_dist = false;
			config.opts.inproc.with_unhiding = true;
			config.opts.inproc.with_brm = false;
			++i;
		}else if(*i == "-inproc-model2") {
			config.opts.inproc.model = config_type::inproc_model_adaptive;
			config.opts.inproc.with_dist = true;
			config.opts.inproc.with_unhiding = false;
			config.opts.inproc.with_brm = false;
			++i;
		}else if(*i == "-inproc-model3") {
			config.opts.inproc.model = config_type::inproc_model_adaptive;
			config.opts.inproc.with_dist = true;
			config.opts.inproc.with_unhiding = true;
			config.opts.inproc.with_brm = false;
			++i;
		}else if(*i == "-inproc-model4") {
			config.opts.inproc.model = config_type::inproc_model_adaptive;
			config.opts.inproc.with_dist = false;
			config.opts.inproc.with_unhiding = false;
			config.opts.inproc.with_brm = true;
			++i;
		}else if(*i == "-learn-bump-glue-twice") {
			config.opts.learn.bump_glue_twice = true;
			++i;
		}else if(*i == "-learn-minimize-glucose") {
			config.opts.learn.minimize_glucose = true;
			++i;
		}else if(*i == "-clause-red-agile") {
			config.opts.clause_red.model = config_type::clause_red_model_agile;
			++i;
		}else if(*i == "-restart-glucose") {
			config.opts.restart.strategy = config_type::restart_strategy::glucose;
			++i;
		}else if(*i == "-show-model") {
			show_model = true;
			++i;
		}else if(*i == "-save-model") {
			++i;
			if(i == args.end()) {
				std::cout << "Expected argument for -save_model" << std::endl;
				return 0;
			}
			model_file = *i;
			++i;
		}else if((*i).at(0) == '-') {
			std::cout << "Illegal command line parameter '" << (*i) << "'" << std::endl;
			return 0;
		}else{
			/* the last parameter is always the instance name */
			instance = *i;
			++i;
			if(i != args.end()) {
				std::cout << "Unexpected parameter '" << *i
						<< "' after instance name" << std::endl;
				return 0;
			}
		}
	}

	std::cout << "c sizeof(assign_type): " << sizeof(config_type::var_config_type::assign_type) << std::endl;
//	std::cout << "c sizeof(watchlist_entry): " << sizeof(config_type::var_config_type::watchlist_entry) << std::endl;
//	std::cout << "c sizeof(clause_head_type): " << sizeof(config_type::clause_head_type) << std::endl;

	SYS_ASSERT(SYS_ASRT_GENERAL, instance.length() > 0);
	std::ifstream stream(instance);

#ifdef FEATURE_GOOGLE_PROFILE
	char profile[256];
	sprintf(profile, "%d.profile", getpid());
	printf("Writing profile %s\n", profile);
	ProfilerStart(profile);
#endif

	read_hooks_struct2<config_type> read_hooks(config);
	cnf_reader_struct<decltype(read_hooks), std::ifstream> reader(read_hooks);
	reader.read(stream);
	config.input_finish();

	std::cout << "c parse time: " << sysGetCpuTime() << " ms" << std::endl;
	std::cout << "c parse memory: " << sys_peak_memory() << " kb" << std::endl;

	config.initialize();

	solve_state result =  solve_step(config);

	if(model_file.length() > 0) {
		std::fstream model_stream(model_file,
				std::fstream::out | std::fstream::trunc);
		if(result == SOLVE_SOLUTION) {
			model_stream << "SAT\n";
			
			problem::sat::extmodel::build_model(config,
					config.extmodel_config, config.extmodel_alloc);
			
			for(long i = 1; i <= read_hooks.num_variables(); ++i) {
				auto map_variable = read_hooks.map_variable(i);
				if(i != 1)
					model_stream << " ";
				/* TODO: don't include non-assigned variables? */
				if(config.model_get_literal(config.one_literal(map_variable))) {
					model_stream << i;
				}else model_stream << -i;
			}
			model_stream << " 0\n";
		}else if(result == SOLVE_FINISHED) {
			model_stream << "UNSAT\n";
		}else model_stream << "INDET\n";
		model_stream.close();
	}else{
		if(result == SOLVE_SOLUTION) {
			std::cout << "s SATISFIABLE" << std::endl;

			problem::sat::extmodel::build_model(config,
					config.extmodel_config, config.extmodel_alloc);		
			
			if(show_model) {
				std::cout << "v";
				for(long i = 1; i <= read_hooks.num_variables(); ++i) {
					auto map_variable = read_hooks.map_variable(i);
					/* TODO: don't include non-assigned variables? */
					if(config.model_get_literal(config.one_literal(map_variable))) {
						std::cout << " " << i;
					}else std::cout << " " << -i;
				}
				std::cout << " 0" << std::endl;
			}
		}else if(result == SOLVE_FINISHED) {
			std::cout << "s UNSATISFIABLE" << std::endl;
		}else std::cout << "s UNKNOWN" << std::endl;
	}

#ifdef FEATURE_GOOGLE_PROFILE
	ProfilerStop();	
#endif

	unsigned int secs = sysGetCpuTime() / 1000;

	std::cout << "c ------ statistics: general ------" << std::endl;
	std::cout << "c cpu time: " << secs << " secs" << std::endl;
	std::cout << "c peak memory: " << sys_peak_memory() << " kb" << std::endl;
	std::cout << "c    [      ] clause reallocations: " << config.stat.general.clause_reallocs
		<< ", collections: " << config.stat.general.clause_collects << std::endl;

	std::cout << "c ------ search ------" << std::endl;
	std::cout << "c    #conflicts: " << config.conflict_num << std::endl;
	if(secs != 0)
		std::cout << "c    conflicts/secs: " << (config.conflict_num / secs) << std::endl;
	std::cout << "c    propagations: " << config.stat_propagations << std::endl;
	if(secs != 0)
		std::cout << "c    propagations/secs: " << (config.stat_propagations / secs) << std::endl;
	std::cout << "c    #deleted clauses: " << config.del_clause_number << std::endl;
	std::cout << "c    #restarts: " << config.restart_num << std::endl;
	std::cout << "c    #learned units: " << config.learned_units << ", binary: " << config.learned_binary << std::endl;
	std::cout << "c    #minimized literals: " << config.stat_minimized_lits
			<< " of " << config.stat_learned_lits << ", " << (100.0f - config.stat_minimized_lits * 100.0f
			/ config.stat_learned_lits) << "% redundant" << std::endl;
	std::cout << "c    #facts removed: clauses: " << config.stat.search.fact_elim_clauses
			<< ", literals: " << config.stat.search.fact_elim_literals
			<< ", runs: " << config.stat.search.fact_elim_runs << std::endl;
	std::cout << "c    #learnts limit: " << config.state.clause_red.geom_size_limit << std::endl;
	
	std::cout << "c ------ simplification ------" << std::endl;
	std::cout << "c    [VECD  ]  vars eliminated: " << config.stat_vecd_elim << std::endl;
	std::cout << "c    [VECD  ]  facts discovered: " << config.stat.simp.vecd_facts << std::endl;
	std::cout << "c    [SCC   ]  vars eliminated: " << config.stat.simp.scc_variables << std::endl;
	std::cout << "c    [BRM   ]  failed literals: " << config.stat.simp.brm_failed << std::endl;
	std::cout << "c    [BRM   ]  equivalent literals: " << config.stat.simp.brm_equivalent << std::endl;
	std::cout << "c    [BRM   ]  independent literals: " << config.stat.simp.brm_independent << std::endl;
	std::cout << "c    [SUB   ]  clauses removed: " << config.stat.simp.subsumed_clauses << std::endl;
	std::cout << "c    [SSUB  ]  shortcut checks: " << config.stat.simp.selfsub_shortcuts
		<< ", subsumption: " << config.stat.simp.selfsub_subchecks
		<< ", resolution: " << config.stat.simp.selfsub_reschecks << std::endl;
	std::cout << "c    [SSUB  ]  clauses shortened: " << config.stat.simp.selfsub_clauses << std::endl;
	std::cout << "c    [SSUB  ]  facts discovered: " << config.stat.simp.selfsub_facts << std::endl;
	std::cout << "c    [BCE   ]  blocked clauses: " << config.stat_blocked_clauses << std::endl;
	std::cout << "c    [DIST  ]  checks: " << config.stat.simp.dist_checks << std::endl;
	std::cout << "c    [DIST  ]  conflicts: " << config.stat.simp.dist_conflicts
			<< ", lits removed " << config.stat.simp.dist_conflicts_removed << std::endl;
	std::cout << "c    [DIST  ]  asserts: " << config.stat.simp.dist_asserts
			<< ", lits removed: " << config.stat.simp.dist_asserts_removed << std::endl;
	std::cout << "c    [DIST  ]  ssubs: " << config.stat.simp.dist_ssubs
			<< ", lits removed: " << config.stat.simp.dist_ssubs_removed << std::endl;
	std::cout << "c    [UNHIDE]  transitive edges: " << config.stat.simp.unhide_transitive << std::endl;
	std::cout << "c    [UNHIDE]  failed literals: " << config.stat.simp.unhide_failed << std::endl;
	std::cout << "c    [UNHIDE]  hidden literals: " << config.stat.simp.unhide_hle << std::endl;
	std::cout << "c    [UNHIDE]  hidden tautologies: " << config.stat.simp.unhide_hte << std::endl;
	
	std::cout << "c    [SAVED ]  space used for saved infos: "
			<< (config.extmodel_alloc.get_offset() / 1024) << " kb" << std::endl;

	std::cout << "c ------ time ------" << std::endl;
	std::cout << "c    [      ]  inprocessing: "
			<< (config.perf.inproc_time / (1000 * 1000)) << " ms" << std::endl;
	std::cout << "c    [      ]  preprocessing: "
			<< (config.perf.preproc_time / (1000 * 1000)) << " ms" << std::endl;
	std::cout << "c    [SEARCH]  fact elimination: "
			<< (config.perf.fact_elim_time / (1000 * 1000)) << " ms" << std::endl;

	delete the_config;

	if(result == SOLVE_SOLUTION) {
		return 10;
	}else if(result == SOLVE_FINISHED) {
		return 20;
	}
	return 0;
}

