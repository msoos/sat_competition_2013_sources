#!/bin/bash

if [ -d binary ]; then
	rm -r binary/
fi

# NOTE: uncomment if you have GCC 4.7
cd code/satUZK
make static
if [ $? -ne 0 ]; then
	echo "Could not build satUZK"
	exit 1
fi
cd ../..

cd code/satUZK_wrapper
make
if [ $? -ne 0 ]; then
	echo "Could not build satUZK_wrapper"
	exit 1
fi
cd ../..

mkdir binary
cp code/satUZK/satUZK binary/
cp code/satUZK_wrapper/satUZK_wrapper binary/
cp code/blobs/SatELite_release binary/

