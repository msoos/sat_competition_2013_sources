
----------------------------
satUZK + SatELite
----------------------------
	Version: satUZK 48
	Authors: Alexander van der Grinten, Andreas Wotzlaw
		Ewald Speckenmeyer
	University of Cologne

----------------------------
How to build
----------------------------
	The solver can be built using gcc 4.8.
	
	SatELite was compiled from the latest version available
	from http://minisat.se/SatELite.html.

	build.sh builds a wrapper that calls our solver and
	SatELite from source and copies all required binary files
	to /binary.

----------------------------
How to use
----------------------------
	satUZK_wrapper accepts the following arguments:
	/binary/satUZK_wrapper TEMPDIR solver INSTANCE <solver arguments>

	For the SAT Competition 2013 we do not pass any
	command line arguments to our solver.

