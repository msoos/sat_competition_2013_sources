/*
 * Stat.h
 *
 *  Created on: 2012/07/06
 *      Author: nabesima
 */

#ifndef STAT_H_
#define STAT_H_

#include "core/Solver.h"

namespace Minisat {

extern void printStats(Solver& solver);

}

#endif /* STAT_H_ */
