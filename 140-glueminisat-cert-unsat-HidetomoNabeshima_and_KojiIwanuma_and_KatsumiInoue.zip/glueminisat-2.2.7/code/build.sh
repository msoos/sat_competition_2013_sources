#!/bin/sh

export MROOT=$PWD

make -C simp r
cp simp/glueminisat-simp_release ./glueminisat-simp



 
