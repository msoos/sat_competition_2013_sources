These are the sources of the SAT solver Lingeling.  To compile issue
'./configure && make'.  This will build the library 'liblgl.o', the
sequential solver 'lingeling' and its parallel version 'plingeling'.

You might want to use './configure --competition' to enforce compilation
options as used for the SAT competition.  If you use this option, before you
compile, you need to copy a typical CNF benchmark to './profile.cnf.gz'.

The file VERSION contains the current version number.
The file NEWS lists history and latest changes.

These sources are under the GNU General Public License Version 3.
See COPYING for more details.  In essence you are only allowed to
distribute a modified version of Lingeling or a program that uses
Lingeling if you make the sources of your modifications respectively
the program that uses Linegeling under the GPL as well.

Lingeling is copyright by Armin Biere, Johannes Kepler University, Linz,
Austria.  If you need another License please contact Armin Biere
<biere@jku.at>.

Mon Feb 28 23:23:24 CET 2011
