HOW TO BUILD
------------

To build, `cd' into where `build.sh' is located.

   $ ./build.sh

This will generate two executables, `SatELite_release' and `gluH_static',
and place them under `./binary'.



EXECUTION
---------
To run, `cd' into `binary', and execute the `gluH.sh' script.

    $ cd binary
    $ ./gluH.sh <input CNF> [<temp dir>]
