#!/bin/bash

EXEDIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )

$EXEDIR/clean.sh

export FM=$EXEDIR/code/SatELite/ForMani

cd $EXEDIR/code/SatELite
make r
cp SatELite_release $EXEDIR/binary

cd $EXEDIR/code/gluH/core
make rs
cp gluH_static $EXEDIR/binary
