#!/bin/bash

EXEDIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )

export FM=$EXEDIR/code/SatELite/ForMani

rm -rf $EXEDIR/binary/gluH_static $EXEDIR/binary/gluH_debug
rm -rf $EXEDIR/binary/SatELite_release

cd $EXEDIR/code/SatELite
make clean

cd $EXEDIR/code/gluH/core
make clean

find . -name 'depend.mak' -delete
