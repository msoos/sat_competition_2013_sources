#!/bin/bash

EXEDIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )

export FM=$EXEDIR/code/SatELite/ForMani

cd $EXEDIR/code/SatELite
make r
cp SatELite_release $EXEDIR/binary

cd $EXEDIR/code/gluH/core
make d
cp gluH_debug $EXEDIR/binary
