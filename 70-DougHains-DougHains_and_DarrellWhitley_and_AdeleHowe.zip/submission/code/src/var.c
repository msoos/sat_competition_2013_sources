#include <stdio.h>
#include <stdlib.h>
#include "varvectors.h"
#include "varwalsh.h"
#include "var.h"
#include "varclause.h"

/*--- Helper Functions ---*/
 
//returns 1 if heap[i] < heap[j]
inline int mmless(Mediator* m, int i, int j)
{
   return (m->data[m->heap[i]] < m->data[m->heap[j]]);
}
 
//swaps items i&j in heap, maintains indexes
int mmexchange(Mediator* m, int i, int j)
{
   int t = m->heap[i];
   m->heap[i]=m->heap[j];
   m->heap[j]=t;
   m->pos[m->heap[i]]=i;
   m->pos[m->heap[j]]=j;
   return 1;
}
 
//swaps items i&j if i<j;  returns true if swapped
inline int mmCmpExch(Mediator* m, int i, int j)
{
   return (mmless(m,i,j) && mmexchange(m,i,j));
}
 
//maintains minheap property for all items below i.
void minSortDown(Mediator* m, int i)
{
   for (i*=2; i <= m->minCt; i*=2)
   {  if (i < m->minCt && mmless(m, i+1, i)) { ++i; }
      if (!mmCmpExch(m,i,i/2)) { break; }
   }
}
 
//maintains maxheap property for all items below i. (negative indexes)
void maxSortDown(Mediator* m, int i)
{
   for (i*=2; i >= -m->maxCt; i*=2)
   {  if (i > -m->maxCt && mmless(m, i, i-1)) { --i; }
      if (!mmCmpExch(m,i/2,i)) { break; }
   }
}
 
//maintains minheap property for all items above i, including median
//returns true if median changed
inline int minSortUp(Mediator* m, int i)
{
   while (i>0 && mmCmpExch(m,i,i/2)) i/=2;
   return (i==0);
}
 
//maintains maxheap property for all items above i, including median
//returns true if median changed
inline int maxSortUp(Mediator* m, int i)
{
   while (i<0 && mmCmpExch(m,i/2,i))  i/=2;
   return (i==0);
}
 
/*--- Public Interface ---*/
 
 
//creates new Mediator: to calculate `nItems` running median. 
//mallocs single block of memory, caller must free.
Mediator* MediatorNew(int nItems)
{
   int size = sizeof(Mediator)+nItems*(sizeof(Item)+sizeof(int)*2);
   Mediator* m=  malloc(size);
   m->data= (Item*)(m+1);
   m->pos = (int*) (m->data+nItems);
   m->heap = m->pos+nItems + (nItems/2); //points to middle of storage.
   m->N=nItems;
   m->minCt = m->maxCt = m->idx = 0;
   while (nItems--)  //set up initial heap fill pattern: median,max,min,max,...
   {  m->pos[nItems]= ((nItems+1)/2) * ((nItems&1)?-1:1);
      m->heap[m->pos[nItems]]=nItems;
   }
   return m;
}
 
 
//Inserts item, maintains median in O(lg nItems)
void MediatorInsert(Mediator* m, Item v)
{
   int p = m->pos[m->idx];
   Item old = m->data[m->idx];
   m->data[m->idx]=v;
   m->idx = (m->idx+1) % m->N;
   if (p>0)         //new item is in minHeap
   {  if (m->minCt < (m->N-1)/2)  { m->minCt++; }
      else if (v>old) { minSortDown(m,p); return; }
      if (minSortUp(m,p) && mmCmpExch(m,0,-1)) { maxSortDown(m,-1); }
   }
   else if (p<0)   //new item is in maxheap
   {  if (m->maxCt < m->N/2) { m->maxCt++; }
      else if (v<old) { maxSortDown(m,p); return; }
      if (maxSortUp(m,p) && m->minCt && mmCmpExch(m,1,0)) { minSortDown(m,1); }
   }
   else //new item is at median
   {  if (m->maxCt && maxSortUp(m,-1)) { maxSortDown(m,-1); }
      if (m->minCt && minSortUp(m, 1)) { minSortDown(m, 1); }
   }
}
 
//returns median item (or average of 2 when item count is even)
Item MediatorMedian(Mediator* m)
{
   Item v= m->data[m->heap[0]];
   if (m->minCt<m->maxCt) { v=(v+m->data[m->heap[-1]])/2; }
   return v;
}
 
 


int add_clause(var **sol, varclause *instance, int i, int p) {
	(*sol)[p].num_clauses++;
	if(!((*sol)[p].clauses = realloc((*sol)[p].clauses, sizeof(clause*) * (*sol)[p].num_clauses))) {
		fprintf(stderr,"Failed allocatation of memory for variable %d on clause %d\n",p,(*sol)[p].num_clauses);
		return -1;
	}
	(*sol)[p].clauses[(*sol)[p].num_clauses-1] = &instance[i];
	return 0;
}

int add_w_cof(var *sol, int v, int w_id) {
	sol[v].num_w_cofs++;
	if(!(sol[v].w_cofs = realloc(sol[v].w_cofs, sizeof(int) * sol[v].num_w_cofs))) {
		fprintf(stderr,"Failed allocating memory for %d w_cofs in variable\n",sol[v].num_w_cofs);
		return -1;
	}
	sol[v].w_cofs[sol[v].num_w_cofs-1] = w_id;
	return 0;
}


int build_solution(var **sol, varclause *instance, int n, int m) {
	int i, j;

	*sol = malloc(sizeof(var) * n);

	for(i = 0; i < n; i++) {
		(*sol)[i].idx = i;
		(*sol)[i].value = (drand48() > .5)?1:0;
		(*sol)[i].num_clauses = 0;
		(*sol)[i].clauses = NULL;
		(*sol)[i].num_w_cofs = 0;
		(*sol)[i].w_cofs = NULL;
		(*sol)[i].next = NULL;
		(*sol)[i].prev = NULL;
		(*sol)[i].in_buf = 0;
		(*sol)[i].last_flipped = 0;
		(*sol)[i].last_hp = 0;
		(*sol)[i].breaks = 0;
		(*sol)[i].makes = 0;
		(*sol)[i].fixed = 0;
		(*sol)[i].total_cl = 0;
		(*sol)[i].firstorder = 0;
	}
	for(i = 0; i < m; i++) {
		for(j = 0; j < instance[i].numvars; j++) {
			if(add_clause(sol, instance, i, instance[i].vars[j]) == -1) 
				return -1;
			(*sol)[instance[i].vars[j]].total_cl = (*sol)[instance[i].vars[j]].total_cl + instance[i].numvars;
			(*sol)[instance[i].vars[j]].firstorder += (instance[i].signs[j]==1?1:-1);
		}
	}

	for(i = 0; i < n; i++) {
		(*sol)[i].m = MediatorNew((*sol)[i].num_clauses);
	}

	for(i = 0; i < m; i++) {
		for(j = 0; j < instance[i].numvars; j++) {
			MediatorInsert((*sol)[instance[i].vars[j]].m,instance[i].numvars);
		}
	}

	return 0;
}

void flip_bit(var *sol, varw_vec *w_prime, vector_ptr v, int bit) {
	sol[bit].value = sol[bit].value ^ 1;
	sol[bit].last_flipped = v->iter;
	v->last_flipped = bit;
}


int evaluate_solution_with_v(var *sol, struct Vectors *v, varclause *instance, int m) {
	int eval = 0;
	int clause_true;
	int i,j;

	v->numunsat = 0;

	for(i = 0; i < m; i++) {
		clause_true = 0;
		v->unsat[i] = 0;
		v->whereunsat[i] = -1;
		for(j = 0; j < instance[i].numvars; j++) {
			if((sol[instance[i].vars[j]].value && (instance[i].signs[j] > 0)) ||
				(!sol[instance[i].vars[j]].value && (instance[i].signs[j] < 0))) {
				clause_true = 1;
			}
		}
		if(!clause_true) {
			v->unsat[v->numunsat] = i;
			v->whereunsat[i] = v->numunsat++;
		}
		eval += clause_true;
	}

	return eval;
}

int evaluate_solution(var *sol, varclause *instance, int m) {
	int eval = 0;
	int clause_true;
	int i,j;

	for(i = 0; i < m; i++) {
		clause_true = 0;
		for(j = 0; j < instance[i].numvars; j++) {
			if((sol[instance[i].vars[j]].value && (instance[i].signs[j] > 0)) ||
				(!sol[instance[i].vars[j]].value && (instance[i].signs[j] < 0))) {
				clause_true = 1;
			}
		}
		eval += clause_true;
	}

	return eval;
}

void random_init(struct Walsh_list *wl, struct VarW_vec *w_prime, var *sol, int n, varclause *instance, int m) {
	int i;
	for(i = 0; i < n; i++) {
		sol[i].value = (drand48() < .5 ? 1 : 0);
	}
}


void hyperplane_init(struct Walsh_list *wl, struct VarW_vec *w_prime, var *sol, int n, varclause *instance, int m) {
	int i,j,k;
	double *zeros;
	double *ones; 

	zeros = malloc(sizeof(double) * n);
	ones = malloc(sizeof(double) * n);
	w_prime->hyperplane_bias = malloc(sizeof(double) * n);

	for(i = 0; i < n; i++) {
		zeros[i] = ones[i] = 0;
	}

	for(i = 0; i < m; i++) {
		varhyperplane *hp = &(instance[i].hp[0]);
		int best_fit = hp->fitness;
		for(j = 1; j < instance[i].numhp; j++) {
			if(instance[i].hp[j].fitness > best_fit) {
				hp = &(instance[i].hp[j]);
				best_fit = instance[i].hp[j].fitness;
			}
		}
		for(k = 0; k < instance[i].numvars; k++) {
			if(hp->value[k] == 0) {
				zeros[hp->vars[k]] += hp->fitness;
			} else {
				ones[hp->vars[k]] += hp->fitness;
			}
		}
	}


	for(i = 0; i < n; i++) {
		int total = zeros[i] + ones[i];
		if(total == 0) {
			sol[i].value = (drand48() < 0.5) ? 0 : 1;
			w_prime->hyperplane_bias[i] = 0.5;
		} else {
			sol[i].value = (drand48() < (zeros[i]/total)) ? 0 : 1;
			w_prime->hyperplane_bias[i] = zeros[i]/total;
		}
		/*
		if(w_prime->hyperplane_bias[i] <= 0.01) {
			w_prime->hyperplane_bias[i] = 0.01;
		}
		if(w_prime->hyperplane_bias[i] >= 0.99) {
			w_prime->hyperplane_bias[i] = 0.99;
		}
		*/

	}
}

void hyperplane_init_withfixed(struct Walsh_list *wl, struct VarW_vec *w_prime, var *sol, int n, varclause *instance, int m) {
	int i;

	for(i = 0; i < n; i++) {
		sol[i].value = (drand48() < (w_prime->hyperplane_bias[i]) ? 0 : 1);
		if(w_prime->hyperplane_bias[i] < .1 || w_prime->hyperplane_bias[i] > .9) {
			if(drand48() < w_prime->p) {
				sol[i].fixed = 1;
			} else {
				sol[i].fixed = 0;
			}
		}
	}
}

void hyperplane_reinit(struct Walsh_list *wl, struct VarW_vec *w_prime, var *sol, int n, varclause *instance, int m) {
	int i;

	for(i = 0; i < n; i++) {
		if(drand48() > .5) {
			sol[i].value = (drand48() < (w_prime->hyperplane_bias[i])) ? 0 : 1;
		}
	}


}

/* Let anyone with a positive value vote */
void hyperplane_bias_v3(struct Walsh_list *wl, struct W_vec *w_prime, var *sol, int n, clause *instance, int m) {
	int i,j,k;
	double *zeros;
	double *ones; 

	zeros = malloc(sizeof(double) * n);
	ones = malloc(sizeof(double) * n);
	w_prime->hyperplane_bias = malloc(sizeof(double) * n);

	for(i = 0; i < n; i++) {
		zeros[i] = ones[i] = 0;
	}

	for(i = 0; i < m; i++) {
		for(j = 0; j < 8; j++) {
			hyperplane *hp = &(instance[i].hp[j]);
			if(hp->fitness > 0) {
				for(k = 0; k < 3; k++) {
					if(hp->value[k] == 0) {
						zeros[hp->vars[k]] += hp->fitness;
					} else {
						ones[hp->vars[k]] += hp->fitness;
					}
				}
			}
		}
	}

	for(i = 0; i < n; i++) {
		int total = zeros[i] + ones[i];
		sol[i].value = (drand48() < (zeros[i]/total)) ? 0 : 1;
		w_prime->hyperplane_bias[i] = zeros[i]/total;
	}
}



void hyperplane_bias_v2(struct Walsh_list *wl, struct W_vec *w_prime, var *sol, int n, clause *instance, int m) {
	int i,j,k;
	double *zeros;
	double *ones; 

	zeros = malloc(sizeof(double) * n);
	ones = malloc(sizeof(double) * n);
	w_prime->hyperplane_bias = malloc(sizeof(double) * n);

	for(i = 0; i < n; i++) {
		zeros[i] = ones[i] = 0;
	}

	for(i = 0; i < m; i++) {
		hyperplane *hp = &(instance[i].hp[0]);
		int best_fit = hp->fitness;
		for(j = 1; j < 8; j++) {
			if(instance[i].hp[j].fitness > best_fit) {
				hp = &(instance[i].hp[j]);
				best_fit = instance[i].hp[j].fitness;
			}
		}
		for(k = 0; k < 3; k++) {
			if(hp->value[k] == 0) {
				zeros[hp->vars[k]] += hp->fitness;
			} else {
				ones[hp->vars[k]] += hp->fitness;
			}
		}
	}

	for(i = 0; i < n; i++) {
		int total = zeros[i] + ones[i];
		sol[i].value = (drand48() < (zeros[i]/total)) ? 0 : 1;
		w_prime->hyperplane_bias[i] = zeros[i]/total;
	}
}


void hyperplane_bias(struct Walsh_list *wl, struct W_vec *w_prime, var *sol, int n, clause *instance, int m) {
	int i,j,k;
	double *zeros;
	double *ones; 

	zeros = malloc(sizeof(double) * n);
	ones = malloc(sizeof(double) * n);

	for(i = 0; i < n; i++) {
		zeros[i] = ones[i] = 0;
	}

	for(i = 0; i < m; i++) {
		for(j = 0; j < 8; j++) {
			hyperplane *hp;
			hp = &(instance[i].hp[j]);
			for(k = 0; k < 3; k++) {
				if(hp->value[k] == 0) {
					zeros[hp->vars[k]] += hp->fitness;
				} else {
					ones[hp->vars[k]] += hp->fitness;
				}
			}

		}
	}

	for(i = 0; i < n; i++) {
		int total = zeros[i] + ones[i];
		sol[i].value = (drand48() < (zeros[i]/total)) ? 0 : 1;
	}
}



void walsh_bias(struct Walsh_list *wl, struct W_vec *w_prime, var *sol, int n, clause *instance, int m) {
	int i, j;
	int walsh_sum;
	int min_sum, max_sum;

	min_sum = 0;
	max_sum = 0;

	for(i = 0; i < n; i++) {
		walsh_sum = 0;
		for(j = 0; j < sol[i].num_w_cofs; j++) {
			if(w_prime->wb[sol[i].w_cofs[j]].order == 1) {
				walsh_sum += w_prime->wb[sol[i].w_cofs[j]].value;
			}
		}
		if(walsh_sum < min_sum) {
			min_sum = walsh_sum;
		} 
		if(walsh_sum > max_sum) {
			max_sum = walsh_sum;
		}
	}

	for(i = 0; i < n; i++) {
		walsh_sum = 0;
		for(j = 0; j < sol[i].num_w_cofs; j++) {
			if(w_prime->wb[sol[i].w_cofs[j]].order == 1) {
				walsh_sum += w_prime->wb[sol[i].w_cofs[j]].value;
			}
		}
		if(walsh_sum == 0) {
			sol[i].value = ((drand48() > .5) ? 1 : 0);
			sol[i].p[0] = .5;
			sol[i].p[1] = .5;
		} else if(walsh_sum < 0) {
			sol[i].value = ((drand48() > .5 - ((double) walsh_sum / min_sum / 2.0)) ? 1 : 0);
			sol[i].p[0] = ((double) walsh_sum / min_sum);
			sol[i].p[1] = 1 - ((double) walsh_sum / min_sum);
		} else {
			sol[i].value = ((drand48() > .5 + ((double) walsh_sum / max_sum / 2.0)) ? 1 : 0);
			sol[i].p[0] = 1 - ((double) walsh_sum / max_sum);
			sol[i].p[1] = ((double) walsh_sum / max_sum);
		}
	}
}



