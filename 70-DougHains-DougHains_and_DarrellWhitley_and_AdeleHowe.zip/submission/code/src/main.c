#include <stdio.h>
#include <stdlib.h>
#include <float.h>
#include <unistd.h>
#include <math.h>
#include <time.h>
#include <sys/times.h>
#include <string.h>
#include <limits.h>
#include "varclause.h"
#include "varwalsh.h"
#include "varvectors.h"
#include "varascent.h"

int parse_instance(char *filename);
void parse_parameters(int argc,char *argv[]);

int parseLine(char* line){
	int i = strlen(line);
	while (*line < '0' || *line > '9') line++;
	line[i-3] = '\0';
	i = atoi(line);
	return i;
}

int getValue(){ //Note: this value is in KB!
	FILE* file = fopen("/proc/self/status", "r");
	int result = -1;
	char line[128];
	while (fgets(line, 128, file) != NULL){
		if (strncmp(line, "VmSize:", 7) == 0){
			result = parseLine(line);
			break;
		}
	}
	fclose(file);
	return result;
}

int NUMBITS = 4;
/* INIT ROUTINES */
enum init_types {RANDOMINIT,HYPERPLANEINIT};
int init_type = RANDOMINIT;
static void (*initRoutines[])(walsh_list*, varw_vec*, var*, int, varclause*, int) =
{random_init, hyperplane_init};
/* CLAUSE PICKS */
enum clause_picks {RCLAUSE,AGE};
int clause_pick = RCLAUSE; /* Default clause pick */
static varclause* (*clausePicks[])(vector_ptr, varclause*, int, var*, varw_vec*) = 
{varrandom_clause_pick, aged_clause_pick};
/* GREEDY PICKS */
enum greedy_picks {NEXT,NEXT_HPTABU,GSAT,NULLG};
int greedy_pick = NEXT; /* Default greedy pick */
static int (*greedyPicks[])(vector_ptr) = 
{vars_next_greedy_pick,
	s_next_greedy_pick_hp_tabu,
	vars_gsat_greedy_pick,
	null_greedy_pick
};
/* VAR PICKS */
enum var_picks {RVAR,HPVAR,HPVAR2,HPVAR3,HPVAR4,HPVAR5,HPVAR6,HPVAR7,HPVAR8,HPVAR9,HPVAR10,HPVAR11,HPVAR12,BREAKPROB,NOVELTY,BREAKS};
int var_pick =  RVAR; /* Default var pick */
static int (*varPicks[])(vector_ptr, varclause*, int, var*, varw_vec*) =
{varrandom_var_pick,
	var_hyperplane_var_pick,
	var_hyperplane_var_pick_f2,
	var_hyperplane_var_pick_f3,
	var_hyperplane_var_pick_f4,
	var_hyperplane_var_pick_f5,
	var_hyperplane_var_pick_f6,
	var_hyperplane_var_pick_f7,
	var_hyperplane_var_pick_f8,
	var_hyperplane_var_pick_f9,
	var_hyperplane_var_pick_f10,
	var_hyperplane_var_pick_f11,
	var_hyperplane_var_pick_f12,
	varbreakprob_var_pick,
	novelty_var_pick,
	breaks_var_pick
};
/* UPDATES*/
enum update_types {UPDATE,UPDATE_UNSAT};
int update_type = UPDATE_UNSAT;
static int (*updates[])(vector_ptr, varw_vec*, var*, int) =
{varupdate_vectors,
	varupdate_vectors_unsat
};

varclause *instance_tmp;
varclause *instance = NULL; /* Instance */
varclause *instance_reduced = NULL; /* Instance */
int n = 0; /* Number of atoms */
int m = 0; /* Number of clauses */
int m_reduced = 0; /* Number of clauses */
double avg_fitness = 0;
int max_wcofs = 0;
int max_flip = 100000;
int max_restarts = 1;/* Number of restarts */
double max_time = 10000000;
int seed = 0; /* RNG seed */

int no_restarts = 0;
int reinit = 0;

int int_cmp(const void *a, const void *b) { 
	var *ia = (var *) a;
	var *ib = (var *) b;
	
	return (ib->num_clauses - ia->num_clauses);
} 
 
int idx_cmp(const void *a, const void *b) { 
	var *ia = (var *) a;
	var *ib = (var *) b;
	
	return (ib->idx - ia->idx);
} 
 
int median_cmp(const void *a, const void *b) { 
	var *ia = (var *) a;
	var *ib = (var *) b;
	return ((MediatorMedian(ia->m) - MediatorMedian(ib->m))>0?1:0);
} 
 
int len_cmp(const void *a, const void *b) { 
	var *ia = (var *) a;
	var *ib = (var *) b;
	return (abs(ib->firstorder) - abs(ia->firstorder)>0?1:0);
} 
 


int main(int argc, char *argv[]) {
	int i, j, k;
	double sum, best_eval;
	int best_sol;
	double initial;
	double after_break;
	double walsh_time;
	struct tms prog_tms;
	long ticks_per_second = sysconf(_SC_CLK_TCK);
	int flips;
	int walsh_flips;
	int flips_since_best;
	int iter_best;
	int best_flip, init_eval; 
	int total_flips = 0;
	int cur_restart = 0;
	int m_tmp;
	int best;
	int best_idx;
	int *best_vars;
	int cur = 1;
	double s_time, c_time;
	double walksat_time;
	double last_walksat_time;
	varw_vec w_p;
	var *sol = NULL;
	var **sols = NULL;
	var *sol_reduced = NULL;
	var *sol_tmp;
	varclause **instances = NULL; /* Instances */
	vectors v;
	vectors *vs;
	walsh_list *wl;
	int *vars;
	int *values;
	int *flip_order;
	int ms[16];
	int max_vc;
	char outfile[10000];
	double percent;
	FILE *outfp;

	parse_parameters(argc, argv);

	if(argc > 2) {
		NUMBITS = atoi(argv[2]);
	}
	srand48(seed);
	m_tmp = m;

	times(&prog_tms);
	s_time = ((double)(((long)prog_tms.tms_utime))) /
		((double) ticks_per_second);

	vars = malloc(sizeof(int) * NUMBITS);
	values = malloc(sizeof(int) * NUMBITS);
	best_vars = malloc(sizeof(int) * NUMBITS);
	sols = malloc(sizeof(var*) * 16);
	vs = malloc(sizeof(vectors) * 16);
	flip_order = malloc(sizeof(int) * n);

	build_solution(&(sol), instance, n, m);
	if(build_solution(&sol_reduced, instance_reduced, n, m_reduced) == -1) {
		fprintf(stderr,"Error building solution\n");
		exit(1);
	}
	percent = .1;
	qsort(sol, n, sizeof(var), int_cmp);
/*	qsort(sol,(int) n*.1,sizeof(var),len_cmp); */
	

/*	qsort(sol, n*percent, sizeof(var), median_cmp); */

/*	qsort(sol, NUMBITS, sizeof(var), idx_cmp); */
	w_p.wb = malloc(sizeof(varw_cof) * max_wcofs);
	w_p.num_w_cofs = 0;
	compute_walsh(&w_p, sol_reduced, instance_reduced, m_reduced);
	
	compute_varhyperplanes(instance_reduced, &w_p, m_reduced, n, NUMBITS, sol, sol_reduced, best_vars);

	for(i = 0; i < NUMBITS; i++) {
		vars[i] = sol[i].idx;
	}

	instances = malloc(sizeof(varclause*) * 16);

	/* Initialize solutions */
	i=0;
	for(j = 0; j < NUMBITS; j++) {
		values[j] = best_vars[j];
	}
	ms[i] = reduce_instance(instance, &(instances[i]), sol, vars, values, n, m, NUMBITS);
	sprintf(outfile,"%s.%d",argv[1],(i+1));
	outfp = fopen(outfile,"w");
	fprintf(outfp, "p cnf %d %d\n",n,ms[i]+NUMBITS);
	fflush(stdout);
	for(j = 0; j < ms[i]; j++) {
		for(k = 0; k < instances[i][j].numvars; k++) {
			fprintf(outfp,"%d ",(instances[i][j].vars[k]+1) * instances[i][j].signs[k]);
		}
		fprintf(outfp,"0\n");
	}
	for(j = 0; j < NUMBITS; j++) {
		fprintf(outfp,"%d 0\n",(vars[j]+1) * (values[j]?1:-1));
	}

	/*
	fclose(outfp);
	sprintf(outfile,"%s.map",argv[1],(i+1));
	outfp = fopen(outfile,"w");
	fflush(stdout);
	for(j = 0; j < NUMBITS; j++) {
		fprintf(outfp,"%d\n",(vars[j]+1) * (values[j]?1:-1));
	}
	fclose(outfp);
	*/


	exit(1);
	/* Initialize score vectors */
	for(i = 0; i < 16; i++) {
		vs[i].numbuffers=3;
		varbuild_vectors_unsat(&(vs[i]),instances[i],sols[i],n,ms[i]);
		vs[i].m = ms[i];
		if(vs[i].eval > best_eval) {
			best_eval = vs[i].eval;
			best_sol = i;
		}
	}


	c_time = ((double)(((long)prog_tms.tms_utime))) /
		((double) ticks_per_second);
	v.cb = 2.17;
	while(cur_restart < max_restarts) {
		cur = 0;
		/*		while( (total_flips < max_flip) && ((c_time - s_time) < max_time) ) {    */
		while( ((c_time - s_time) < max_time) ) {  
			vs[cur].iter = 1;
			flips = 0;
			flips_since_best = 0;
			while(flips < 10*n) {
				flips += varlocal_search(&(vs[cur]), instances[cur], ms[cur], sols[cur], &w_p, 
						greedyPicks[greedy_pick],
						clausePicks[clause_pick], 
						varPicks[var_pick], 
						updates[update_type]);   
				vs[cur].iter++;
				times(&prog_tms);
				c_time = ((double)(((long)prog_tms.tms_utime))) /
					((double) ticks_per_second);
				if((c_time - s_time) > max_time) {
					break;
				}
				if((ms[cur] - vs[cur].eval) < (ms[best_sol]-best_eval)) {
					best_eval = vs[cur].eval; 
					best_sol = cur;
					best_flip = flips;
				} 				
				if(vs[cur].eval == ms[cur] || vs[cur].numunsat==0) {
					best_eval = vs[cur].eval; 
					best_sol = cur;
					best_flip = flips;
					break;
				}
			}
			total_flips += flips;
			if(vs[cur].eval == ms[cur] || vs[cur].numunsat==0) {
				break;
			}
			if(c_time - s_time > max_time) {
				break;
			}
			cur++;
			if(cur==16) {
				cur = 0;
			}
		}
		times(&prog_tms);
		c_time = ((double)(((long)prog_tms.tms_utime))) /
			((double) ticks_per_second);
		printf("%f %d %f\n",
				c_time-s_time, 
				total_flips,
				(float)ms[best_sol] - best_eval
			  );

		for(k = 0; k < 4; k++) {
			sols[best_sol][sol[k].idx].value=CHECK_BIT(best_sol,k);
		}

		for(i = 0; i < n; i++) {
			fprintf(stderr,"%d ",i*(sol[best_sol].value?1:-1));
		}
		fprintf(stderr,"\n");

		cur_restart++;
		last_walksat_time = walksat_time;
		free_vectors(&v);
	}
	}

	int parse_instance(char *filename) {
		FILE *fp;
		int vars[5000], signs[5000], lit, i, idx;
		char *input = NULL;
		char tmp_a[80];
		char tmp_b[80];
		char lastc, nextc;
		int reduced_i = 0;
		size_t b_size = 1;

		if(!(fp = fopen(filename, "r"))) {
			fprintf(stderr,"Could not open %s\n",filename);
			return -1;
		}

		while ((lastc = getc(fp)) == 'c') {
			while ((nextc = getc(fp)) != EOF && nextc != '\n');
		}
		ungetc(lastc,fp);
		if (fscanf(fp,"p cnf %i %i",&n,&m) != 2) {
			fprintf(stderr,"Bad input file\n");
			exit(-1);
		}

		m_reduced = 0;
		instance = malloc(sizeof(varclause) * m);
		instance_reduced = malloc(sizeof(varclause) * m);

		for(i = 0;i < m;i++) {
			idx = 0;
			do {
				if (fscanf(fp,"%i ",&lit) != 1) {
					fprintf(stderr, "Bad input file\n");
					exit(-1);
				}
				if(lit != 0) {
					vars[idx] = abs(lit)-1;
					signs[idx++] = (lit < 0 ? -1 : 1);
				}
			}
			while(lit != 0);
			if(idx > 6) {
				init_varclause_nowf(&instance[i], idx, vars, signs); 
				instance[i].id = i;
			} else {
				init_varclause(&instance_reduced[reduced_i], idx, vars, signs); 
				instance_reduced[reduced_i].id = reduced_i;
				instance_reduced[reduced_i].orig_numvars = idx;
				reduced_i++;
				m_reduced++;
				init_varclause_nowf(&instance[i], idx, vars, signs); 
				instance[i].id = i;
				max_wcofs += pow(2,idx);
			}
		}
		fclose(fp);
	}


	void parse_parameters(int argc,char *argv[])
	{
		int i;
		int printhelp = 1;

		for (i=1;i < argc; i++) {
			printhelp = 0;
			if (argv[i][0] != '-'){
				if(parse_instance(argv[i]) == -1) {
					fprintf(stderr,"Error parsing instance\n");
					exit(1);
				}
				++i;
			}
			else if (strcmp(argv[i],"-seed") == 0)
				seed = atoi(argv[++i]);
			else if (strcmp(argv[i],"-cutoff") == 0)
				max_flip = atoi(argv[++i]);
			else if (strcmp(argv[i],"-timeout") == 0)
				max_time = atof(argv[++i]);
			else if (strcmp(argv[i],"-norestarts") == 0)
				no_restarts = 1;
			else if (strcmp(argv[i],"-hyperplaneinit") == 0)
				init_type = HYPERPLANEINIT;
			else if (strcmp(argv[i],"-hpvar") == 0)
				var_pick = HPVAR;
			else if (strcmp(argv[i],"-age") == 0)
				clause_pick = AGE;
			else if (strcmp(argv[i],"-hpvar2") == 0)
				var_pick = HPVAR2;
			else if (strcmp(argv[i],"-hpvar3") == 0)
				var_pick = HPVAR3;
			else if (strcmp(argv[i],"-hpvar4") == 0)
				var_pick = HPVAR4;
			else if (strcmp(argv[i],"-hpvar5") == 0)
				var_pick = HPVAR5;
			else if (strcmp(argv[i],"-hpvar6") == 0)
				var_pick = HPVAR6;
			else if (strcmp(argv[i],"-hpvar7") == 0)
				var_pick = HPVAR7;
			else if (strcmp(argv[i],"-hpvar8") == 0)
				var_pick = HPVAR8;
			else if (strcmp(argv[i],"-hpvar9") == 0)
				var_pick = HPVAR9;
			else if (strcmp(argv[i],"-hpvar10") == 0)
				var_pick = HPVAR10;
			else if (strcmp(argv[i],"-hpvar11") == 0)
				var_pick = HPVAR11;
			else if (strcmp(argv[i],"-hpvar12") == 0)
				var_pick = HPVAR12;
			else if (strcmp(argv[i],"-novelty") == 0)
				var_pick = NOVELTY;
			else if (strcmp(argv[i],"-breaks") == 0)
				var_pick = BREAKS;
			else if (strcmp(argv[i],"-next_hptabu") == 0)
				greedy_pick = NEXT_HPTABU;
			else if (strcmp(argv[i],"-gsat") == 0)
				greedy_pick = GSAT;
			else if (strcmp(argv[i],"-nullg") == 0)
				greedy_pick = NULLG;
			else if (strcmp(argv[i],"-reinit") == 0)
				reinit = 1;
			else {
				printhelp = 1;
				break;
			}
		}
		if(printhelp) {
			fprintf(stderr, "VARWALSHSAT v0.01\n\n");
			fprintf(stderr, "General parameters:\n");
			fprintf(stderr, "  filename = CNF file\n");
			fprintf(stderr, "  -seed N\n");
			fprintf(stderr, "  -cutoff N\n");
			fprintf(stderr, "  -timeout N\n");
			fprintf(stderr, "  -norestarts\n");
			fprintf(stderr, "Initialization method:\n");
			fprintf(stderr, "  -hyperplaneinit\n");
			fprintf(stderr, "Clause pick:\n");
			fprintf(stderr, "  -age clause age biases pick\n");
			fprintf(stderr, "Variable pick:\n");
			fprintf(stderr, "  -hpvar (absolute hyperplane pick)\n");
			fprintf(stderr, "  -hpvar2 (shifted min hyperplane pick)\n");
			fprintf(stderr, "  -hpvar3 (shifted max hyperplane pick)\n");
			fprintf(stderr, "  -hpvar4 (shifted min with age hyperplane pick)\n");
			fprintf(stderr, "  -hpvar5 (shifted max with frequency of appearance\n");
			fprintf(stderr, "  -hpvar6 (shifted max with age hyperplane pick)\n");
			fprintf(stderr, "  -hpvar7 (shifted min with frequency of appearance\n");
			fprintf(stderr, "  -hpvar8 (shifted min with age hyperplane pick)\n");
			fprintf(stderr, "  -hpvar9 (hyperplane bias)\n");
			fprintf(stderr, "  -hpvar10 (z-vector)\n");
			fprintf(stderr, "  -hpvar11 (reverse hyperplane bias)\n");
			fprintf(stderr, "  -hpvar12 (reverse z-vector)\n");
			fprintf(stderr, "  -novelty\n");
			fprintf(stderr, "  -breaks (ala Balint)\n");
			fprintf(stderr, "Greedy pick:\n");
			fprintf(stderr, "  -next_hptabu (hyperplane tabu)\n");
			fprintf(stderr, "  -gsat (GSAT like)\n");
			fprintf(stderr, "  -nullg (no greedy pick)\n");

			exit(-1);
		}
	}
