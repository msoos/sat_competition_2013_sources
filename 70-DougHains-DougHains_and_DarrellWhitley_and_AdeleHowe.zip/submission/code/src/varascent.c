#include "varascent.h"
#include "varvectors.h"
#include <stdlib.h>
#include <stdio.h>
#include <float.h>
#include <limits.h>
#include <math.h>

#define FINDBUF(a,b) (a > 0 ? 2 : a < 0 ? 0 : 1)

int varrandom_var_pick(vector_ptr v_ptr, varclause *c, int m, var *sol, varw_vec *w_prime) {
	return (c->vars[lrand48() % c->numvars]);
}

int breaks_var_pick(vector_ptr v_ptr, varclause *c, int m, var *sol, varw_vec *w_prime) {
	int i;
	int bit;
	double p, run, tot;
	double *f;

	tot = 0;
	f = malloc(sizeof(double) * c->numvars);
	for(i = 0; i < c->numvars; i++) {
		f[i] = pow(.001 + sol[c->vars[i]].breaks,-v_ptr->cb);
		tot += f[i];
	}
	run = 0;
	bit = c->vars[0];
	p = drand48();
	for(i = 0; i < c->numvars; i++) {
		run += f[i];
		if(p < ((float)run/tot)) {
			bit = c->vars[i];
			break;
		}
	}
	free(f);

	return bit;
}



int novelty_var_pick(vector_ptr v_ptr, varclause *c, int m, var *sol, varw_vec *w_prime) {
	int iYoungestVar;
	int iVar, iScore, iBestScore, iSecondBestScore;
	int iBestVar, iSecondBestVar;
	int iFlipCandidate;
	int j;

	iYoungestVar = c->vars[0];
	iBestVar = c->vars[0];
	iSecondBestVar = c->vars[0];
	iBestScore = v_ptr->s[iBestVar];
	iSecondBestScore = v_ptr->s[iBestVar];
	iSecondBestScore = v_ptr->m;
	for (j=1;j<c->numvars;j++) {
		iVar = c->vars[j];
		iScore = v_ptr->s[iVar];
		if (sol[iVar].last_flipped > sol[iYoungestVar].last_flipped) {
			iYoungestVar = iVar;
		}
		if ((iScore > iBestScore) || ((iScore == iBestScore) && 
					(sol[iVar].last_flipped < sol[iBestVar].last_flipped))) {
			iSecondBestVar = iBestVar;
			iBestVar = iVar;
			iSecondBestScore = iBestScore;
			iBestScore = iScore;
		} else if ((iScore > iSecondBestScore) || ((iScore == iSecondBestScore) 
					&& (sol[iVar].last_flipped < sol[iSecondBestVar].last_flipped))) {
			iSecondBestVar = iVar;
			iSecondBestScore = iScore;
		}
	}

	iFlipCandidate = iBestVar;
	if (iFlipCandidate != iYoungestVar) {
		return iFlipCandidate;
	}
	if (drand48() < .5) {
		iFlipCandidate = iSecondBestVar;
	}

	return iFlipCandidate;
}



int varbreakprob_var_pick(vector_ptr v_ptr, varclause *c, int m, var *sol, varw_vec *w_prime) {
	int i;
	int bit;
	double *probs,total_probs,running_probs;
	double r;

	probs = malloc(sizeof(double) * c->numvars);
	total_probs = 0;
	for(i = 0; i < c->numvars; i++) {
		probs[i] = pow((.001 + sol[c->vars[i]].breaks),-2.2);
		total_probs += probs[i];
	}

	r = drand48();
	running_probs = 0.0;

	for(i = 0; i < c->numvars; i++) {
		running_probs += probs[i];
		if(r < (running_probs/total_probs)) {
			bit = c->vars[i];
			break;
		}
	}

	return bit;
}

varclause *aged_clause_pick(vector_ptr v, varclause *instance, int m, var *sol, varw_vec *w_prime) {
	varclause *c;
	int *unsat;
	int idx = 0;
	int i,j;
	int clause_true;
	double run,tot = 0;
	double p;
	
	for(i = 0; i < v->numunsat; i++) {
		tot += v->iter-instance[v->unsat[i]].time_unsat;
	}

	run = 0;
	p = drand48();
	for(i = 0; i < v->numunsat; i++) {
		run += v->iter-instance[v->unsat[i]].time_unsat;
		if(p < run/(float)tot) {
			c = &instance[v->unsat[i]];
			break;
		}
	}

	return c;
}

varclause *varrandom_clause_pick(vector_ptr v, varclause *instance, int m, var *sol, varw_vec *w_prime) {
	varclause *c;
	int *unsat;
	int idx = 0;
	int i,j;
	int clause_true;
	c = &instance[v->unsat[lrand48() % v->numunsat]];

	return c;
}

int var_hyperplane_var_pick_f5(vector_ptr v_ptr, varclause *c, int m, var *sol, varw_vec *w_prime) { /* Does nothing yet */
	int i, j, k, flipped;
	double rnd = drand48();
	double cur_fitness = 0;
	varhyperplane *hp;
	double *hp_fitness;
	int *hp_var;
	int hp_flag;
	int hp_idx = 0;
	int bit;
	double total_fitness = 0.0;
	double hp_max = DBL_MIN;
	double r, p;

	hp_var = malloc(sizeof(int) * c->numvars);
	hp_fitness = malloc(sizeof(double) * c->numhp);

	for(i = 0; i < c->numhp; i++) {
		hp = &c->hp[i];
		for(j = 0; j < c->numvars; j++) {
			if(sol[hp->vars[j]].value != hp->value[j]) {
				hp_flag = 1;
				for(k = 0; k < c->numvars; k++) {
					if(j != k) {
						if(sol[hp->vars[k]].value != hp->value[k]) {
							hp_flag = 0;
							break;
						}
					}
				}
				if(hp_flag) {
					hp_fitness[hp_idx] = hp->fitness;
					if(hp_fitness[hp_idx] > hp_max) {
						hp_max = hp_fitness[hp_idx];
					}
					hp_var[hp_idx++] = hp->vars[j];
				}
			}
		}
	}

	for(i = 0; i < c->numvars; i++) {
		hp_fitness[i] = fabs(hp_fitness[i] - hp_max - 0.1) * (sol[i].num_clauses/v_ptr->max_clauses);
		total_fitness += hp_fitness[i];
	}

	if(total_fitness < 0.001) { 
		bit = (c->vars[lrand48() % c->numvars]);
	} 

	r = drand48();
	p = hp_fitness[0]/total_fitness;
	if(r <= p) {
		bit = hp_var[0];
	} else {
		for(i = 1; i < c->numvars; i++) {
			p+= hp_fitness[i]/total_fitness;
			if(r <= p) {
				bit = hp_var[i];
				break;
			}
		}
	}
	free(hp_var);
	free(hp_fitness);
	return bit;
}



int var_hyperplane_var_pick_f3(vector_ptr v_ptr, varclause *c, int m, var *sol, varw_vec *w_prime) {
	int i, j, k, flipped;
	double rnd = drand48();
	double cur_fitness = 0;
	varhyperplane *hp;
	double *hp_fitness;
	int *hp_var;
	int hp_flag;
	int hp_idx = 0;
	int bit;
	double total_fitness = 0.0;
	double hp_max = DBL_MIN;
	double r, p;

	hp_var = malloc(sizeof(int) * c->numvars);
	hp_fitness = malloc(sizeof(double) * c->numhp);

	for(i = 0; i < c->numhp; i++) {
		hp = &c->hp[i];
		for(j = 0; j < c->numvars; j++) {
			if(sol[hp->vars[j]].value != hp->value[j]) {
				hp_flag = 1;
				for(k = 0; k < c->numvars; k++) {
					if(j != k) {
						if(sol[hp->vars[k]].value != hp->value[k]) {
							hp_flag = 0;
							break;
						}
					}
				}
				if(hp_flag) {
					hp_fitness[hp_idx] = hp->fitness;
					if(hp_fitness[hp_idx] > hp_max) {
						hp_max = hp_fitness[hp_idx];
					}
					hp_var[hp_idx++] = hp->vars[j];
				}
			}
		}
	}

	for(i = 0; i < c->numvars; i++) {
		hp_fitness[i] = fabs(hp_fitness[i] - hp_max - 0.1);
		total_fitness += hp_fitness[i];
	}

	if(total_fitness < 0.001) { 
		bit = (c->vars[lrand48() % c->numvars]);
	} 

	r = drand48();
	p = hp_fitness[0]/total_fitness;
	if(r <= p) {
		bit = hp_var[0];
	} else {
		for(i = 1; i < c->numvars; i++) {
			p+= hp_fitness[i]/total_fitness;
			if(r <= p) {
				bit = hp_var[i];
				break;
			}
		}
	}
	free(hp_var);
	free(hp_fitness);
	return bit;
}

int var_hyperplane_var_pick_f4(vector_ptr v_ptr, varclause *c, int m, var *sol, varw_vec *w_prime) {
	int i, j, k, flipped;
	double rnd = drand48();
	double cur_fitness = 0;
	varhyperplane *hp;
	double *hp_fitness;
	int *hp_var;
	int hp_flag;
	int hp_idx = 0;
	int bit;
	double total_fitness = 0.0;
	double hp_min = DBL_MAX;
	double r, p;

	hp_var = malloc(sizeof(int) * c->numvars);
	hp_fitness = malloc(sizeof(double) * c->numhp);

	for(i = 0; i < c->numhp; i++) {
		hp = &c->hp[i];
		for(j = 0; j < c->numvars; j++) {
			if(sol[hp->vars[j]].value != hp->value[j]) {
				hp_flag = 1;
				for(k = 0; k < c->numvars; k++) {
					if(j != k) {
						if(sol[hp->vars[k]].value != hp->value[k]) {
							hp_flag = 0;
							break;
						}
					}
				}
				if(hp_flag) {
					hp_fitness[hp_idx] = hp->fitness;
					if(hp_fitness[hp_idx] < hp_min) {
						hp_min = hp_fitness[hp_idx];
					}
					hp_var[hp_idx++] = hp->vars[j];
				}
			}
		}
	}
/*
	printf("\n%d:",v_ptr->iter);
	for(i = 0; i < c->numvars; i++) {
		printf("%d ",v_ptr->last_hp_flip[hp_var[i]]);
	}
	printf("\n");
	for(i = 0; i < c->numvars; i++) {
		printf("%f ",(float)v_ptr->last_hp_flip[hp_var[i]]/v_ptr->iter);
	}
	printf("\n");
	for(i = 0; i < c->numvars; i++) {
		printf("%f ",hp_fitness[i]);
	}
	printf("\n");
	*/

	for(i = 0; i < c->numvars; i++) {
		hp_fitness[i] = (hp_fitness[i] + fabs(hp_min) + 0.1)/((float)v_ptr->last_hp_flip[hp_var[i]]/v_ptr->iter);
		total_fitness += hp_fitness[i];
	}

	if(total_fitness < 0.001) { 
		bit = (c->vars[lrand48() % c->numvars]);
	} 

	r = drand48();
	p = hp_fitness[0]/total_fitness;
	if(r <= p) {
		bit = hp_var[0];
	} else {
		for(i = 1; i < c->numvars; i++) {
			p+= hp_fitness[i]/total_fitness;
			if(r <= p) {
				bit = hp_var[i];
				break;
			}
		}
	}
	free(hp_var);
	free(hp_fitness);
	return bit;
}


int var_hyperplane_var_pick_f6(vector_ptr v_ptr, varclause *c, int m, var *sol, varw_vec *w_prime) {
	int i, j, k, flipped;
	double rnd = drand48();
	double cur_fitness = 0;
	varhyperplane *hp;
	double *hp_fitness;
	int *hp_var;
	int hp_flag;
	int hp_idx = 0;
	int bit;
	double total_fitness = 0.0;
	double hp_max = DBL_MIN;
	double r, p;

	hp_var = malloc(sizeof(int) * c->numvars);
	hp_fitness = malloc(sizeof(double) * c->numhp);

	for(i = 0; i < c->numhp; i++) {
		hp = &c->hp[i];
		for(j = 0; j < c->numvars; j++) {
			if(sol[hp->vars[j]].value != hp->value[j]) {
				hp_flag = 1;
				for(k = 0; k < c->numvars; k++) {
					if(j != k) {
						if(sol[hp->vars[k]].value != hp->value[k]) {
							hp_flag = 0;
							break;
						}
					}
				}
				if(hp_flag) {
					hp_fitness[hp_idx] = hp->fitness;
					if(hp_fitness[hp_idx] > hp_max) {
						hp_max = hp_fitness[hp_idx];
					}
					hp_var[hp_idx++] = hp->vars[j];
				}
			}
		}
	}

	for(i = 0; i < c->numvars; i++) {
		hp_fitness[i] = fabs(hp_fitness[i] - hp_max - 0.1)/((float)v_ptr->last_hp_flip[hp_var[i]]/v_ptr->iter);
		total_fitness += hp_fitness[i];
	}

	if(total_fitness < 0.001) { 
		bit = (c->vars[lrand48() % c->numvars]);
	} 

	r = drand48();
	p = hp_fitness[0]/total_fitness;
	if(r <= p) {
		bit = hp_var[0];
	} else {
		for(i = 1; i < c->numvars; i++) {
			p+= hp_fitness[i]/total_fitness;
			if(r <= p) {
				bit = hp_var[i];
				break;
			}
		}
	}
	free(hp_var);
	free(hp_fitness);
	return bit;
}

int var_hyperplane_var_pick_f8(vector_ptr v_ptr, varclause *c, int m, var *sol, varw_vec *w_prime) {
	int i, j, k, flipped;
	double rnd = drand48();
	double cur_fitness = 0;
	varhyperplane *hp;
	double *hp_fitness;
	int *hp_var;
	int hp_flag;
	int hp_idx = 0;
	int bit;
	double total_fitness = 0.0;
	double hp_min = DBL_MAX;
	double r, p;

	hp_var = malloc(sizeof(int) * c->numvars);
	hp_fitness = malloc(sizeof(double) * c->numhp);

	for(i = 0; i < c->numhp; i++) {
		hp = &c->hp[i];
		for(j = 0; j < c->numvars; j++) {
			if(sol[hp->vars[j]].value != hp->value[j]) {
				hp_flag = 1;
				for(k = 0; k < c->numvars; k++) {
					if(j != k) {
						if(sol[hp->vars[k]].value != hp->value[k]) {
							hp_flag = 0;
							break;
						}
					}
				}
				if(hp_flag) {
					hp_fitness[hp_idx] = hp->fitness;
					if(hp_fitness[hp_idx] < hp_min) {
						hp_min = hp_fitness[hp_idx];
					}
					hp_var[hp_idx++] = hp->vars[j];
				}
			}
		}
	}

	for(i = 0; i < c->numvars; i++) {
		hp_fitness[i] = (hp_fitness[i] +  fabs(hp_min) + 0.1) /((float)v_ptr->last_hp_flip[hp_var[i]]/v_ptr->iter);
		total_fitness += hp_fitness[i];
	}

	if(total_fitness < 0.001) { 
		bit = (c->vars[lrand48() % c->numvars]); 
	} 

	r = drand48();
	p = hp_fitness[0]/total_fitness;
	if(r <= p) {
		bit = hp_var[0];
	} else {
		for(i = 1; i < c->numvars; i++) {
			p+= hp_fitness[i]/total_fitness;
			if(r <= p) {
				bit = hp_var[i];
				break;
			}
		}
	}
	free(hp_var);
	free(hp_fitness);
	return bit;
}


int var_hyperplane_var_pick_f11(vector_ptr v_ptr, varclause *c, int m, var *sol, varw_vec *w_prime) {
	int i, j, k, flipped;
	double rnd = drand48();
	double cur_fitness = 0;
	varhyperplane *hp;
	double *hp_fitness;
	int *hp_var;
	int hp_flag;
	int hp_idx = 0;
	int bit;
	double total_fitness = 0.0;
	double hp_min = DBL_MAX;
	double r, p;

	hp_var = malloc(sizeof(int) * c->numvars);
	hp_fitness = malloc(sizeof(double) * c->numhp);

	for(i = 0; i < c->numvars; i++) {
		hp_var[i] = c->vars[i];
		if(sol[hp_var[i]].value == 1) {
			hp_fitness[i] = ((1 - w_prime->hyperplane_bias[c->vars[i]])  > 0 ? 1 - w_prime->hyperplane_bias[c->vars[i]] : 0) + .01;
		} else {
			hp_fitness[i] = w_prime->hyperplane_bias[c->vars[i]] + .01;
		}
		total_fitness += hp_fitness[i];
	}

	if(total_fitness < 0.001) { 
		bit = (c->vars[lrand48() % c->numvars]); 
	} 

	r = drand48();
	p = hp_fitness[0]/total_fitness;
	if(r <= p) {
		bit = hp_var[0];
	} else {
		for(i = 1; i < c->numvars; i++) {
			p+= hp_fitness[i]/total_fitness;
			if(r <= p) {
				bit = hp_var[i];
				break;
			}
		}
	}
	free(hp_var);
	free(hp_fitness);
	return bit;
}

int var_hyperplane_var_pick_f9(vector_ptr v_ptr, varclause *c, int m, var *sol, varw_vec *w_prime) {
	int i, j, k, flipped;
	double rnd = drand48();
	double cur_fitness = 0;
	varhyperplane *hp;
	double *hp_fitness;
	int *hp_var;
	int hp_flag;
	int hp_idx = 0;
	int bit;
	double total_fitness = 0.0;
	double hp_min = DBL_MAX;
	double r, p;

	hp_var = malloc(sizeof(int) * c->numvars);
	hp_fitness = malloc(sizeof(double) * c->numhp);

	for(i = 0; i < c->numvars; i++) {
		hp_var[i] = c->vars[i];
		if(sol[hp_var[i]].value == 0) {
			hp_fitness[i] = ((1 - w_prime->hyperplane_bias[c->vars[i]])  > 0 ? 1 - w_prime->hyperplane_bias[c->vars[i]] : 0) + .01;
		} else {
			hp_fitness[i] = w_prime->hyperplane_bias[c->vars[i]] + 0.01;
		}
		total_fitness += hp_fitness[i];
	}

	if(total_fitness < 0.001) { 
		bit = (c->vars[lrand48() % c->numvars]); 
	} 

	r = drand48();
	p = hp_fitness[0]/total_fitness;
	if(r <= p) {
		bit = hp_var[0];
	} else {
		for(i = 1; i < c->numvars; i++) {
			p+= hp_fitness[i]/total_fitness;
			if(r <= p) {
				bit = hp_var[i];
				break;
			}
		}
	}
	free(hp_var);
	free(hp_fitness);
	return bit;
}

int var_hyperplane_var_pick_f10(vector_ptr v_ptr, varclause *c, int m, var *sol, varw_vec *w_prime) {
	int i, j, k, flipped;
	double rnd = drand48();
	double cur_fitness = 0;
	varhyperplane *hp;
	double *hp_fitness;
	int *hp_var;
	int hp_flag;
	int hp_idx = 0;
	int bit;
	double total_fitness = 0.0;
	double hp_max = DBL_MIN;
	double r, p;

	hp_var = malloc(sizeof(int) * c->numvars);
	hp_fitness = malloc(sizeof(double) * c->numhp);

	for(i = 0; i < c->numvars; i++) {
		hp_var[i] = c->vars[i];
		hp_fitness[i] = v_ptr->z[c->vars[i]];
		if(hp_fitness[i] > hp_max) {
			hp_max = hp_fitness[i];
		}
	}

	for(i = 0; i < c->numvars; i++) {
		hp_fitness[i] =  fabs(hp_fitness[i] - hp_max) + 0.01;
		total_fitness += hp_fitness[i];
	}

	if(total_fitness < 0.001) { 
		bit = (c->vars[lrand48() % c->numvars]); 
	} 

	r = drand48();
	p = hp_fitness[0]/total_fitness;
	if(r <= p) {
		bit = hp_var[0];
	} else {
		for(i = 1; i < c->numvars; i++) {
			p+= hp_fitness[i]/total_fitness;
			if(r <= p) {
				bit = hp_var[i];
				break;
			}
		}
	}
	free(hp_var);
	free(hp_fitness);
	return bit;
}


int var_hyperplane_var_pick_f12(vector_ptr v_ptr, varclause *c, int m, var *sol, varw_vec *w_prime) {
	int i, j, k, flipped;
	double rnd = drand48();
	double cur_fitness = 0;
	varhyperplane *hp;
	double *hp_fitness;
	int *hp_var;
	int hp_flag;
	int hp_idx = 0;
	int bit;
	double total_fitness = 0.0;
	double hp_min = DBL_MAX;
	double r, p;

	hp_var = malloc(sizeof(int) * c->numvars);
	hp_fitness = malloc(sizeof(double) * c->numhp);

	for(i = 0; i < c->numvars; i++) {
		hp_var[i] = c->vars[i];
		hp_fitness[i] = v_ptr->z[c->vars[i]];
		if(hp_fitness[i] < hp_min) {
			hp_min = hp_fitness[i];
		}
	}

	for(i = 0; i < c->numvars; i++) {
		hp_fitness[i] =  hp_fitness[i] + fabs(hp_min) + 0.01;
		total_fitness += hp_fitness[i];
	}

	if(total_fitness < 0.001) { 
		bit = (c->vars[lrand48() % c->numvars]); 
	} 

	r = drand48();
	p = hp_fitness[0]/total_fitness;
	if(r <= p) {
		bit = hp_var[0];
	} else {
		for(i = 1; i < c->numvars; i++) {
			p+= hp_fitness[i]/total_fitness;
			if(r <= p) {
				bit = hp_var[i];
				break;
			}
		}
	}
	free(hp_var);
	free(hp_fitness);
	return bit;
}



int var_hyperplane_var_pick_f7(vector_ptr v_ptr, varclause *c, int m, var *sol, varw_vec *w_prime) {
	int i, j, k, flipped;
	double rnd = drand48();
	double cur_fitness = 0;
	varhyperplane *hp;
	double *hp_fitness;
	int *hp_var;
	int hp_flag;
	int hp_idx = 0;
	int bit;
	double total_fitness = 0.0;
	double hp_min = DBL_MAX;
	double r, p;

	hp_var = malloc(sizeof(int) * c->numvars);
	hp_fitness = malloc(sizeof(double) * c->numhp);

	for(i = 0; i < c->numhp; i++) {
		hp = &c->hp[i];
		for(j = 0; j < c->numvars; j++) {
			if(sol[hp->vars[j]].value != hp->value[j]) {
				hp_flag = 1;
				for(k = 0; k < c->numvars; k++) {
					if(j != k) {
						if(sol[hp->vars[k]].value != hp->value[k]) {
							hp_flag = 0;
							break;
						}
					}
				}
				if(hp_flag) {
					hp_fitness[hp_idx] = hp->fitness;
					if(hp_fitness[hp_idx] < hp_min) {
						hp_min = hp_fitness[hp_idx];
					}
					hp_var[hp_idx++] = hp->vars[j];
				}
			}
		}
	}

	for(i = 0; i < c->numvars; i++) {
		hp_fitness[i] = (hp_fitness[i] +  fabs(hp_min) + 0.1)  * (sol[i].num_clauses/v_ptr->max_clauses);
		total_fitness += hp_fitness[i];
	}

	if(total_fitness < 0.001) { 
		bit = (c->vars[lrand48() % c->numvars]); 
	} 

	r = drand48();
	p = hp_fitness[0]/total_fitness;
	if(r <= p) {
		bit = hp_var[0];
	} else {
		for(i = 1; i < c->numvars; i++) {
			p+= hp_fitness[i]/total_fitness;
			if(r <= p) {
				bit = hp_var[i];
				break;
			}
		}
	}
	free(hp_var);
	free(hp_fitness);
	return bit;
}



int var_hyperplane_var_pick_f2(vector_ptr v_ptr, varclause *c, int m, var *sol, varw_vec *w_prime) {
	int i, j, k, flipped;
	double rnd = drand48();
	double cur_fitness = 0;
	varhyperplane *hp;
	double *hp_fitness;
	int *hp_var;
	int hp_flag;
	int hp_idx = 0;
	int bit;
	double total_fitness = 0.0;
	double hp_min = DBL_MAX;
	double r, p;

	hp_var = malloc(sizeof(int) * c->numvars);
	hp_fitness = malloc(sizeof(double) * c->numhp);

	for(i = 0; i < c->numhp; i++) {
		hp = &c->hp[i];
		for(j = 0; j < c->numvars; j++) {
			if(sol[hp->vars[j]].value != hp->value[j]) {
				hp_flag = 1;
				for(k = 0; k < c->numvars; k++) {
					if(j != k) {
						if(sol[hp->vars[k]].value != hp->value[k]) {
							hp_flag = 0;
							break;
						}
					}
				}
				if(hp_flag) {
					hp_fitness[hp_idx] = hp->fitness;
					if(hp_fitness[hp_idx] < hp_min) {
						hp_min = hp_fitness[hp_idx];
					}
					hp_var[hp_idx++] = hp->vars[j];
				}
			}
		}
	}

	/*
	printf("\n");
	for(i = 0; i < c->numvars; i++) {
		printf("%f ",hp_fitness[i]);
	}
	printf("\n");
*/
	for(i = 0; i < c->numvars; i++) {
		hp_fitness[i] += fabs(hp_min) + 0.1;
		total_fitness += hp_fitness[i];
	}
	/*

	for(i = 0; i < c->numvars; i++) {
		printf("%f ",hp_fitness[i]/total_fitness);
	}
	printf("\n");
	*/


	if(total_fitness < 0.001) { 
		bit = (c->vars[lrand48() % c->numvars]);
	} 

	r = drand48();
	p = hp_fitness[0]/total_fitness;
	if(r <= p) {
		bit = hp_var[0];
	} else {
		for(i = 1; i < c->numvars; i++) {
			p+= hp_fitness[i]/total_fitness;
			if(r <= p) {
				bit = hp_var[i];
				break;
			}
		}
	}
	free(hp_var);
	free(hp_fitness);
	return bit;
}

int var_hyperplane_var_pick(vector_ptr v_ptr, varclause *c, int m, var *sol, varw_vec *w_prime) {
	int i, j, k, flipped;
	double rnd = drand48();
	double cur_fitness = 0;
	varhyperplane *hp;
	double *hp_fitness;
	int *hp_var;
	int hp_flag;
	int hp_idx = 0;
	int bit;
	double total_fitness = 0.0;
	double r, p;

	hp_var = malloc(sizeof(int) * c->numvars);
	hp_fitness = malloc(sizeof(double) * c->numhp);
/*
	printf("\n%3d %3d %3d\n",c->vars[0],
			c->vars[1],
			c->vars[2]);
	printf("%d%d%d\n",sol[c->vars[0]].value,
							sol[c->vars[1]].value,
							sol[c->vars[2]].value);
							*/
	for(i = 0; i < c->numhp; i++) {
		hp = &c->hp[i];
		for(j = 0; j < c->numvars; j++) {
			if(sol[hp->vars[j]].value != hp->value[j]) {
				hp_flag = 1;
				for(k = 0; k < c->numvars; k++) {
					if(j != k) {
						if(sol[hp->vars[k]].value != hp->value[k]) {
							hp_flag = 0;
							break;
						}
					}
				}
				if(hp_flag) {
					/*hp_fitness[hp_idx] = pow(.1 + fabs(hp->fitness),2.3); */
					hp_fitness[hp_idx] = fabs(hp->fitness);
					total_fitness += hp_fitness[hp_idx];
					hp_var[hp_idx++] = hp->vars[j];
					/*
					if(hp->fitness <= 0) {
						hp_fitness[hp_idx] = .5;
						hp_var[hp_idx++] =  hp->vars[j];
						total_fitness += .5;
					} else { 
						hp_fitness[hp_idx] = hp->fitness;
						hp_var[hp_idx++] =  hp->vars[j];
						total_fitness += hp->fitness;
					}
					*/
				}
			}
		}
	}

	
	if(total_fitness < 0.001) { 
		bit = (c->vars[lrand48() % c->numvars]);
	} 

	r = drand48();
	p = hp_fitness[0]/total_fitness;
	if(r <= p) {
		bit = hp_var[0];
	} else {
		for(i = 1; i < c->numvars; i++) {
			p+= hp_fitness[i]/total_fitness;
			if(r <= p) {
				bit = hp_var[i];
				break;
			}
		}
	}
	free(hp_var);
	free(hp_fitness);
	return bit;
}


int s_next_greedy_pick_hp_tabu(vector_ptr v_ptr) {
	int bit, i;

	if(v_ptr->numimp <= 0) {
		bit= -1;
	} else {
		bit = (v_ptr->imp[lrand48() % v_ptr->numimp]);
		if(v_ptr->hp_flip_cnt - v_ptr->last_hp_flip[bit] <= v_ptr->taboo_limit) {
			for(i = 0; i < v_ptr->numimp; i++) {
				bit = (v_ptr->imp[i]);
				if(v_ptr->hp_flip_cnt - v_ptr->last_hp_flip[bit] <= v_ptr->taboo_limit) {
					break;
				}
			}
			if(i == v_ptr->numimp) {
				bit = -1;
			}
		}
	}
	return bit;

	return -1;
}

int null_greedy_pick(vector_ptr v_ptr) {
	return -1;
}

int vars_gsat_greedy_pick(vector_ptr v_ptr) {
	if(v_ptr->anumimp[2] > 0) {
		return(v_ptr->aimp[2][lrand48() % v_ptr->anumimp[2]]);
	} else if(v_ptr->anumimp[1] > 0) {
		return(v_ptr->aimp[1][lrand48() % v_ptr->anumimp[1]]); 
	} else {
		return(v_ptr->aimp[0][lrand48() % v_ptr->anumimp[0]]); 
	}
}

int vars_next_greedy_pick(vector_ptr v_ptr) {
	if(v_ptr->anumimp[2] > 0) {
		return(v_ptr->aimp[2][lrand48() % v_ptr->anumimp[2]]);
	} else if(v_ptr->anumimp[1] > 0) {
		return -1;
		/* 	return(v_ptr->aimp[1][lrand48() % v_ptr->anumimp[1]]); */
	} else {
		return -1;
		/* 	return(v_ptr->aimp[0][lrand48() % v_ptr->anumimp[0]]); */
	}
}


int varlocal_search(vector_ptr v, varclause *i, int m, var *sol, varw_vec *w_prime, 
		greedyPick gp, varclausePick cp, varPick vp, updateType update) {
	int bit;
	varclause *c;


	bit = gp(v);
	if(bit == -1 || bit == v->last_flipped) {
		c = cp(v, i, m , sol, w_prime);
		bit = vp(v, c, m, sol, w_prime);
	} 
	if(bit != -1 && !sol[bit].fixed) {
		/*
		printf("flipping bit = %d\n",bit);
		printf("v->s[%d] = %f\n",bit,v->s[bit]);
		printf("eval = %f\n",(float)v->m - evaluate_solution(sol, i, v->m));
		printf("v->eval = %f\n",(float) v->m - v->eval);
		*/
		flip_bit(sol, w_prime, v, bit);
		update(v, w_prime, sol, bit);
		return 1;
		/*
		printf("eval = %f\n",(float)v->m - evaluate_solution(sol, i, v->m));
		printf("v->eval = %f\n\n",(float)v->m - v->eval);
		*/
	} else {
		return 0;
	}
}

void varlocal_search_simple(vector_ptr v, varclause *i, int m, var *sol, varw_vec *w_prime, 
		greedyPick gp, varclausePick cp, varPick vp, updateType update) {
	int bit;
	varclause *c;

	bit = v->last_flipped;
	while(bit == v->last_flipped) {
		c = cp(v, i, m , sol, w_prime);
		bit = vp(v, c, m, sol, w_prime);
	}
 
	if(bit != -1) {
		flip_bit(sol, w_prime, v, bit);
		update(v, w_prime, sol, bit);
	} 
}
