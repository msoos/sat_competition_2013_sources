#include <stdio.h>
#include <limits.h>
#include <stdlib.h>
#include "varvectors.h"
#include <math.h>

#define FINDBUF(a,b) (a > 0 ? 2 : a < 0 ? 0 : 1)

int varbuild_vectors_unsat(vector_ptr v, varclause *instance, var *sol, int n, int m) {
	int i, j;
	int clause_true;

	v->n = n;
	v->m = m;
	v->max_clauses = INT_MIN;
	v->last_flipped = -1;
	v->hp_flip_cnt = 0;
	v->taboo_limit = 0;
	v->numunsat = 0;

	v->unsat = malloc(sizeof(int) *m);
	v->whereunsat = malloc(sizeof(int) *m);
	v->schanges = malloc(sizeof(int) * n);
	v->oldbuffer = malloc(sizeof(int) * n);
	v->whereschanges = malloc(sizeof(int) * n);
	v->numschanges = 0;

	v->random_moves = 1;
	v->new_best = -1;
	
	v->aimp = malloc(sizeof(int*) * (v->numbuffers+3));
	v->anumimp = malloc(sizeof(int) * (v->numbuffers+3));
	v->mwhereimp = malloc(sizeof(int) * n);
	v->s = malloc(sizeof(double) * n);
	for(i = 0; i < (v->numbuffers+3); i++) {
		v->aimp[i] = malloc(sizeof(int) * n);	
		v->anumimp[i] = 0;
	}

	if((v->sol = malloc(sizeof(int) * n)) == NULL ||
		(v->last_hp_flip = malloc(sizeof(int) * n)) == NULL)
	{
		fprintf(stderr,"Error allocating %d ints for s vector\n",n);
		return -1;
	}	

	for(i = 0; i < n; i++) {
		v->last_hp_flip[i] = 1;
		if(sol[i].num_clauses > v->max_clauses) {
			v->max_clauses = sol[i].num_clauses;
		}
		sol[i].makes = 0;
		sol[i].breaks = 0;
		v->s[i] = 0.0;
		v->whereschanges[i] = -1;
	}
	for(i = 0; i < m; i++) {
		v->whereunsat[i] = -1;
		v->unsat[v->numunsat] = -1;
	}

	for(i = 0; i < m; i++) {
		clause_true = 0;
		for(j = 0; j < instance[i].numvars; j++) {
			if((sol[instance[i].vars[j]].value && (instance[i].signs[j] > 0)) ||
					(!sol[instance[i].vars[j]].value && (instance[i].signs[j] < 0))) {
				clause_true++;
				instance[i].numsat++;
			}
		}
		if(clause_true == 1) {
			for(j = 0; j < instance[i].numvars; j++) {
				if((sol[instance[i].vars[j]].value && (instance[i].signs[j] > 0)) ||
						(!sol[instance[i].vars[j]].value && (instance[i].signs[j] < 0))) {
					sol[instance[i].vars[j]].breaks++;
				}
			}
		} else if(clause_true == 0) {
			v->unsat[v->numunsat] = i;
			v->whereunsat[i] = v->numunsat++;
			instance[i].time_unsat = 1;
			for(j = 0; j < instance[i].numvars; j++) {
				sol[instance[i].vars[j]].makes++;
			}
		} 
	}

	v->eval = (float) v->m - v->numunsat;

	for(i = 0; i < n; i++) {
		v->s[i] = sol[i].makes - sol[i].breaks;
		int buf = FINDBUF(v->s[i],v->numbuffers);
		v->mwhereimp[i] = v->anumimp[buf];
		v->aimp[buf][v->anumimp[buf]++] = i;
		v->sol[i] = sol[i].value;
	}

	return 0;
}

int varupdate_vectors_unsat(vector_ptr v, varw_vec *w_prime, var *sol, int bit) {
	int i, j;
	int newbit_flag;
	double best_val = 0;

	v->whereschanges[bit] = v->numschanges;
	v->schanges[v->numschanges++] =  bit;
	v->oldbuffer[bit] = FINDBUF((v->s[bit]),v->numbuffers);

	/* update clauses */
	for(i = 0; i < sol[bit].num_clauses; i++) {
		varclause *vc = sol[bit].clauses[i];
		newbit_flag = 0;
		if(v->whereunsat[vc->id] >= 0) {
			v->unsat[v->whereunsat[vc->id]] = v->unsat[--v->numunsat];
			v->whereunsat[v->unsat[v->whereunsat[vc->id]]] = v->whereunsat[vc->id];
			v->whereunsat[vc->id] = -1;
			sol[bit].breaks++;
			v->s[bit]--;
			for(j = 0; j < vc->numvars; j++) {
				int newbit = vc->vars[j];
				sol[newbit].makes--;
				if(v->whereschanges[newbit] == -1) {
					v->oldbuffer[newbit] = FINDBUF((v->s[newbit]),v->numbuffers);
				}
				v->s[newbit]--;
				if(v->whereschanges[newbit] == -1) {
					v->whereschanges[newbit] = v->numschanges;
					v->schanges[v->numschanges++] = newbit;
				}
			}
			vc->numsat++;
		} else {
			int sat = 0;
			for(j = 0; j < vc->numvars; j++) {
				int newbit = vc->vars[j];
				if((sol[newbit].value && (vc->signs[j] > 0)) ||
						(!sol[newbit].value && (vc->signs[j] < 0))) {
					if(newbit==bit) {
						newbit_flag = 1;
					}
					sat++;
				}
			}

			if(sat == 1) {
				for(j = 0; j < vc->numvars; j++) {
					int newbit = vc->vars[j];
					if((sol[newbit].value && (vc->signs[j] > 0)) ||
							(!sol[newbit].value && (vc->signs[j] < 0))) {
						sol[newbit].breaks++;
						if(v->whereschanges[newbit] == -1) {
							v->oldbuffer[newbit] = FINDBUF((v->s[newbit]),v->numbuffers);
						}
						v->s[newbit]--;
						if(v->whereschanges[newbit] == -1) {
							v->whereschanges[newbit] = v->numschanges;
							v->schanges[v->numschanges++] = newbit;
						}

						break;
					}
				}
			} else if(sat == 2 && newbit_flag) {
				for(j = 0; j < vc->numvars; j++) {
					int newbit = vc->vars[j];
					if((sol[newbit].value && (vc->signs[j] > 0)) ||
							(!sol[newbit].value && (vc->signs[j] < 0))) {
						if(newbit != bit) {
							sol[newbit].breaks--;
							fflush(stdout);
							if(v->whereschanges[newbit] == -1) {
								v->oldbuffer[newbit] = FINDBUF((v->s[newbit]),v->numbuffers);
							}
							v->s[newbit]++;
							if(v->whereschanges[newbit] == -1) {
								v->whereschanges[newbit] = v->numschanges;
								v->schanges[v->numschanges++] = newbit;
							}
							break;
						}
					}
				}
			} else if(!sat) {
				sol[bit].breaks--;
				v->s[bit]++;
				v->unsat[v->numunsat] = vc->id;
				v->whereunsat[vc->id] = v->numunsat++;
				vc->time_unsat = v->iter;
				for(j = 0; j < vc->numvars; j++) {
					int newbit = vc->vars[j];
					sol[newbit].makes++;
					if(v->whereschanges[newbit] == -1) {
						v->oldbuffer[newbit] = FINDBUF((v->s[newbit]),v->numbuffers);
					}
					v->s[newbit]++;
					if(v->whereschanges[newbit] == -1) {
						v->whereschanges[newbit] = v->numschanges;
						v->schanges[v->numschanges++] = newbit;
					}

				}
			}
		}
	}

	for(i = 0; i < v->numschanges; i++) {
		int cbit = v->schanges[i]; 
		int buf = FINDBUF(v->s[cbit],v->numbuffers);
		int oldbuf = v->oldbuffer[cbit];
		if(oldbuf != buf) {
			/*
			printf("cbit = %d\n, buf = %d\n oldbuf = %d\n",cbit,buf,oldbuf);
			fflush(stdout);
			printf("v->mwhereimp[cbit] = %d\n",v->mwhereimp[cbit]);
			fflush(stdout);
			printf("writing to index = %d\n",v->aimp[oldbuf][v->mwhereimp[cbit]]);
			*/
			/* remove from old list */
			v->aimp[oldbuf][v->mwhereimp[cbit]] = 
				v->aimp[oldbuf][--(v->anumimp[oldbuf])];
			v->mwhereimp[v->aimp[oldbuf][v->mwhereimp[cbit]]] =
				v->mwhereimp[cbit];
			/* put in new list */
			v->mwhereimp[cbit] = v->anumimp[buf];
			v->aimp[buf][v->anumimp[buf]++] = cbit;
		}
		v->whereschanges[cbit] = -1;
	}
	v->numschanges = 0;

	v->eval = (float) v->m-v->numunsat;
	return 0;
}



int varupdate_vectors(vector_ptr v, varw_vec *w_prime, var *sol, int bit) {
	int i, j;
	double best_val = 0;
	varw_cof *w;

	v->new_best = -1;
	v->eval -= 2 * v->s[bit];
	v->s[bit] = -v->s[bit];
	v->z[bit] = -v->z[bit];

	v->whereschanges[bit] = v->numschanges;
	v->schanges[v->numschanges++] =  bit;
	v->oldbuffer[bit] = FINDBUF(2*(-v->s[bit]),v->numbuffers);

	v->last_hp_flip[bit] = v->iter;

	for(i = 0; i < sol[bit].num_w_cofs; i++) {
		w = &(w_prime->wb[sol[bit].w_cofs[i]]);
		for(j = 0; j < w->order; j++) {
			if(w->vars[j] != bit && w->vars[j] >= 0) { 
				if(v->whereschanges[w->vars[j]] == -1) {
					v->oldbuffer[w->vars[j]] = FINDBUF(2*(v->s[w->vars[j]]),v->numbuffers);
				}
				v->s[w->vars[j]] = v->s[w->vars[j]] - (2 * w->value * w->sign); 
				v->z[w->vars[j]] = v->z[w->vars[j]] - (2 * w->order * w->value * w->sign); 
				if(v->whereschanges[w->vars[j]] == -1) {
					v->whereschanges[w->vars[j]] = v->numschanges;
					v->schanges[v->numschanges++] =  w->vars[j];
				}
			}
		}
		w->sign = -w->sign;
	} 

	for(i = 0; i < v->numschanges; i++) {
		int cbit = v->schanges[i]; 
		int buf = FINDBUF(2*v->s[cbit],v->numbuffers);
		int oldbuf = v->oldbuffer[cbit];
		/* remove from old list */
		v->aimp[oldbuf][v->mwhereimp[cbit]] = 
			v->aimp[oldbuf][--(v->anumimp[oldbuf])];
		v->mwhereimp[v->aimp[oldbuf][v->mwhereimp[cbit]]] =
			v->mwhereimp[cbit];
		/* put in new list */
		v->mwhereimp[cbit] = v->anumimp[buf];
		v->aimp[buf][v->anumimp[buf]++] = cbit;
		v->whereschanges[cbit] = -1;

	}
	v->numschanges = 0;

	/* update clauses */
	for(i = 0; i < sol[bit].num_clauses; i++) {
		varclause *vc = sol[bit].clauses[i];
		if(v->whereunsat[vc->id] >= 0) {
			v->unsat[v->whereunsat[vc->id]] = v->unsat[--v->numunsat];
			v->whereunsat[v->unsat[v->whereunsat[vc->id]]] = v->whereunsat[vc->id];
			v->whereunsat[vc->id] = -1;
		} else {
			int sat = 0;
			for(j = 0; j < vc->numvars; j++) {
				int newbit = vc->vars[j];
				if((sol[newbit].value && (vc->signs[j] > 0)) ||
						(!sol[newbit].value && (vc->signs[j] < 0))) {
					sat = 1;
				}
			}
			if(!sat) {
				v->unsat[v->numunsat] = vc->id;
				v->whereunsat[vc->id] = v->numunsat++;
			}	
		}
	}

	return 0;
}


int free_vectors(vector_ptr v) {

	/*
	   free(v->s); 
	   free(v->z);
	   free(v->sol); 
	   free(v->restricted);
	   free(v->unsat);
	   free(v->whereunsat);
	   free(v->last_hp_flip);
	   free(v->imp);
	   free(v->whereimp);
	   */

	return 0;
}
