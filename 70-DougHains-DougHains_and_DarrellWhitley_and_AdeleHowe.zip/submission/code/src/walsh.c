#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include "walsh.h"
#include "vectors.h"

int o3_pat[2][4][3] =  { { {0, 0, 0}, {0, 1, 1}, {1, 0, 1}, {1, 1, 0}},
					 { {0, 0, 1}, {0, 1, 0}, {1, 0, 0}, {1, 1, 1}} };
int o2_pat[2][2][2] =  { { {0, 0}, {1, 1} },
					     { {0, 1}, {1, 0} } };
int o1_pat[2][1][1] = { { {0} },
					    { {1} } };

int walsh_sign(var *sol, w_cof *w) {
	int bc = 0;
	int i;

	for(i = 0; i < 3; i++) {
		if(w->vars[i] > -1) {
			if(sol[w->vars[i]].value > 0) {
				bc++;
			}
		}
	}

	if(bc % 2 == 0) {
		return 1;
	} else {
		return -1; 
	}
}

int walsh_sign_int(int *sol, w_cof *w) {
	int bc = 0;
	int i;

	for(i = 0; i < 3; i++) {
		if(w->vars[i] > -1) {
			if(sol[w->vars[i]] > 0) {
				bc++;
			}
		}
	}
	if(bc % 2 == 0) {
		return 1;
	} else {
		return -1; 
	}
}


int compute_hyperplanes(clause *instance, int m, int n) {
	int i, j, k;
	int *vars;
	int hp_fitness;

	vars = malloc(sizeof(int) * n);

	for(i = 0; i < m; i++) {
		for(j = 0; j < 8; j++) {
			hp_fitness = 0;
			if(j == 0) {
				vars[instance[i].vars[0]] = 0;
				vars[instance[i].vars[1]] = 0;
				vars[instance[i].vars[2]] = 0;
			} else if(j == 1) {
				vars[instance[i].vars[0]] = 1;
				vars[instance[i].vars[1]] = 0;
				vars[instance[i].vars[2]] = 0;
			} else if(j == 2) {
				vars[instance[i].vars[0]] = 0;
				vars[instance[i].vars[1]] = 1;
				vars[instance[i].vars[2]] = 0;
			} else if(j == 3) {
				vars[instance[i].vars[0]] = 1;
				vars[instance[i].vars[1]] = 1;
				vars[instance[i].vars[2]] = 0;
			} else if(j == 4) {
				vars[instance[i].vars[0]] = 0;
				vars[instance[i].vars[1]] = 0;
				vars[instance[i].vars[2]] = 1;
			} else if(j == 5) {
				vars[instance[i].vars[0]] = 1;
				vars[instance[i].vars[1]] = 0;
				vars[instance[i].vars[2]] = 1;
			} else if(j == 6) {
				vars[instance[i].vars[0]] = 0;
				vars[instance[i].vars[1]] = 1;
				vars[instance[i].vars[2]] = 1;
			} else if(j == 7) {
				vars[instance[i].vars[0]] = 1;
				vars[instance[i].vars[1]] = 1;
				vars[instance[i].vars[2]] = 1;
			}
			hp_fitness += walsh_sign_int(vars, instance[i].order_3) * instance[i].order_3->value;
			for(k = 0; k < 3; k++) {
				hp_fitness += walsh_sign_int(vars, instance[i].order_2[k]) * instance[i].order_2[k]->value;
				hp_fitness += walsh_sign_int(vars, instance[i].order_1[k]) * instance[i].order_1[k]->value;
			}
			instance[i].hp[j].value[0] = 	vars[instance[i].vars[0]];
			instance[i].hp[j].value[1] = 	vars[instance[i].vars[1]];
			instance[i].hp[j].value[2] = 	vars[instance[i].vars[2]];
			instance[i].hp[j].fitness = hp_fitness;
			instance[i].hp[j].vars[0] = instance[i].vars[0];
			instance[i].hp[j].vars[1] = instance[i].vars[1];
			instance[i].hp[j].vars[2] = instance[i].vars[2];
			if(hp_fitness > 0) {
				instance[i].total_hp_fitness += hp_fitness;
			}
		}
	}

	free(vars);
}

void compute_walsh_signs(var *sol, w_vec *w_prime) {
	int i;

	for(i = 0; i < w_prime->num_w_cofs; i++) {
		w_prime->wb[i].sign = walsh_sign(sol, &w_prime->wb[i]);
	}	
}


int check_w_cof(var *sol, w_vec *w_prime, int *vars) {
	int i, j, found;
	w_cof *check;

	if(sol[vars[0]].num_w_cofs == 0) {
		return -1;
	} else {
		for(i = 0; i < sol[vars[0]].num_w_cofs; i++) {
			check = &w_prime->wb[sol[vars[0]].w_cofs[i]];
			found = 1;
			for(j = 0; j < 3; j++) {
				if(vars[j] != check->vars[j]) {
					found = 0;
				}
			}
			if(found) {
				return check->id;
			}
		}
	}
	return -1;
}


int sum_w_cof(w_cof *w, clause *instance, int *vars) {
	int bc = 0;
	int i, j;

	for(i = 0; i < 3; i++) {
		if(vars[i] > -1) {
			j = 0;
			while(instance->vars[j] != vars[i]) {
				j++;
				if(j >= 3) {
					fprintf(stderr,"Out of bounds error in sum_w_cof\n");

				}
			}
			if(instance->signs[j] < 0) {
				bc++;
			}
		}
	}
	if(bc % 2 == 0) {
		w->value -= 1; 
	} else {
		w->value += 1;
	}

	if(w->order == 1) {
		instance->order_1[instance->order_1_idx++] = w;
	}
	if(w->order == 2) {
		instance->order_2[instance->order_2_idx++] = w;
	}
	if(w->order == 3) {
		instance->order_3 = w; 
		if(w->clause == NULL) {
			w->num_clause = 1;
			w->clause = malloc(sizeof(clause*) * 1);
		} else {
			w->num_clause++;
			w->clause = realloc(w->clause, sizeof(clause*) * w->num_clause);
		}
		w->clause[w->num_clause-1] = instance;
	} 

	return w->value;
}



int new_w_cof(w_vec *w_prime, clause *instance, var *sol, int *vars) {
	int i;
	int order = 0;

	w_prime->num_w_cofs++;
	w_prime->wb[w_prime->num_w_cofs - 1].value = 0;
	w_prime->wb[w_prime->num_w_cofs - 1].next = NULL;
	w_prime->wb[w_prime->num_w_cofs - 1].prev = NULL;
	w_prime->wb[w_prime->num_w_cofs - 1].id = w_prime->num_w_cofs - 1;
	w_prime->wb[w_prime->num_w_cofs - 1].visited = 0;
	w_prime->wb[w_prime->num_w_cofs - 1].num_clause = 0;
	w_prime->wb[w_prime->num_w_cofs - 1].clause = NULL;

	for(i = 0; i < 3; i++) {
		w_prime->wb[w_prime->num_w_cofs - 1].vars[i] = vars[i];
		if(vars[i] > -1) {
			order++;
			if(add_w_cof(sol, vars[i], w_prime->num_w_cofs-1) == -1) {
				fprintf(stderr,"Failed adding w_cof %d to variable %d\n",w_prime->num_w_cofs - 1, vars[i]);
				return -1;
			}
		}
	}

	w_prime->wb[w_prime->num_w_cofs - 1].order = order;
	sum_w_cof(&(w_prime->wb[w_prime->num_w_cofs - 1]), instance, vars);

	return 0;
}


int evaluate_solution_walsh(w_vec *w_prime, int m) {
	int i;
	int eval = 0;

	for(i = 0; i < w_prime->num_w_cofs; i++) {
		eval += w_prime->wb[i].value * w_prime->wb[i].sign;
	}

	return (eval + 7*m);
}

int process_vars_restricted(vector_ptr v_ptr, w_vec *w_prime, var *sol, clause *instance, int *vars) {
	int w_id;


	if(v_ptr->restricted[vars[0]] &&
			v_ptr->restricted[vars[1]] &&
			v_ptr->restricted[vars[2]]) {
		return 0;
	}

	if((w_id = check_w_cof(sol, w_prime, vars)) == -1) {
		if(new_w_cof(w_prime, instance, sol, vars) == -1) {
			fprintf(stderr, "Failed adding new w_cof\n");
			return -1;
		} else {
			return 1;
		}
	} else {
		return abs(sum_w_cof(&(w_prime->wb[w_id]), instance, vars));
	}
}




int process_vars(w_vec *w_prime, var *sol, clause *instance, int *vars) {
	int w_id;
	if((w_id = check_w_cof(sol, w_prime, vars)) == -1) {
		if(new_w_cof(w_prime, instance, sol, vars) == -1) {
			fprintf(stderr, "Failed adding new w_cof\n");
			return -1;
		} else {
			return 1;
		}
	} else {
		return abs(sum_w_cof(&(w_prime->wb[w_id]), instance, vars));
	}
}


int build_wb_restricted(w_vec *w_prime, vector_ptr v_ptr, var *sol, clause *instance, int m) {
	int i;
	int vars[3];

	w_prime->wb = malloc(sizeof(w_cof) * m * 8);
	w_prime->num_w_cofs = 0;

	for(i = 0; i < m; i++) {
		vars[0] = instance[i].vars[0];
		vars[1] = -1; 
		vars[2] = -1;
		if(process_vars_restricted(v_ptr,w_prime, sol, &instance[i], vars) == -1) {
			fprintf(stderr,"Error processing vars(%d,%d,%d) on clause %d\n",vars[0],vars[1],vars[2],i);
			return -1;
		}
		vars[0] = instance[i].vars[1];
		vars[1] = -1; 
		vars[2] = -1;
		if(process_vars_restricted(v_ptr,w_prime, sol, &instance[i], vars) == -1) {
			fprintf(stderr,"Error processing vars(%d,%d,%d) on clause %d\n",vars[0],vars[1],vars[2],i);
			return -1;
		}
		vars[0] = instance[i].vars[2];
		vars[1] = -1; 
		vars[2] = -1;
		if(process_vars_restricted(v_ptr,w_prime, sol, &instance[i], vars) == -1) {
			fprintf(stderr,"Error processing vars(%d,%d,%d) on clause %d\n",vars[0],vars[1],vars[2],i);
			return -1;
		}

		/* 011 */
		vars[0] = instance[i].vars[0];
		vars[1] = instance[i].vars[1];
		vars[2] = -1;
		if(process_vars_restricted(v_ptr,w_prime, sol, &instance[i], vars) == -1) {
			fprintf(stderr,"Error processing vars(%d,%d,%d) on clause %d\n",vars[0],vars[1],vars[2],i);
			return -1;
		}
		/* 101 */
		vars[0] = instance[i].vars[0];
		vars[1] = instance[i].vars[2];
		vars[2] = -1;
		if(process_vars_restricted(v_ptr,w_prime, sol, &instance[i], vars) == -1) {
			fprintf(stderr,"Error processing vars(%d,%d,%d) on clause %d\n",vars[0],vars[1],vars[2],i);
			return -1;
		}

		/* 110 */
		vars[0] = instance[i].vars[1];
		vars[1] = instance[i].vars[2];
		vars[2] = -1;
		if(process_vars_restricted(v_ptr,w_prime, sol, &instance[i], vars) == -1) {
			fprintf(stderr,"Error processing vars(%d,%d,%d) on clause %d\n",vars[0],vars[1],vars[2],i);
			return -1;
		}

		/* 111 */
		vars[0] = instance[i].vars[0];
		vars[1] = instance[i].vars[1];
		vars[2] = instance[i].vars[2];
		if(process_vars_restricted(v_ptr,w_prime, sol, &instance[i], vars) == -1) {
			fprintf(stderr,"Error processing vars(%d,%d,%d) on clause %d\n",vars[0],vars[1],vars[2],i);
			return -1;
		}

	}
	return 0;
}

void copy_wb(w_vec *w_prime, w_vec *w_star, int m) {
	int i;

	w_star->wb = malloc(sizeof(w_cof) * m * 8);
	w_star->num_w_cofs = w_prime->num_w_cofs;

	for(i = 0; i < w_prime->num_w_cofs; i++) {
		w_star->wb[i].id = w_prime->wb[i].id; 
		w_star->wb[i].value = w_prime->wb[i].value;
		w_star->wb[i].order = w_prime->wb[i].order;
		w_star->wb[i].sign = w_prime->wb[i].sign;
		w_star->wb[i].vars[0] = w_prime->wb[i].vars[0];
		w_star->wb[i].vars[1] = w_prime->wb[i].vars[1];
		w_star->wb[i].vars[2] = w_prime->wb[i].vars[2];
		w_star->wb[i].num_clause = w_prime->wb[i].num_clause;
		w_star->wb[i].clause = w_prime->wb[i].clause;
	}

}

int build_wb_var(w_vec *w_prime, var *sol, clause *instance, int m) {
	int i;
	int vars[3];

	w_prime->wb = malloc(sizeof(w_cof) * m * 8);
	w_prime->num_w_cofs = 0;

	for(i = 0; i < m; i++) {
		vars[0] = instance[i].vars[0];
		vars[1] = -1; 
		vars[2] = -1;
		if(process_vars(w_prime, sol, &instance[i], vars) == -1) {
			fprintf(stderr,"Error processing vars(%d,%d,%d) on clause %d\n",vars[0],vars[1],vars[2],i);
			return -1;
		}
		vars[0] = instance[i].vars[1];
		vars[1] = -1; 
		vars[2] = -1;
		if(process_vars(w_prime, sol, &instance[i], vars) == -1) {
			fprintf(stderr,"Error processing vars(%d,%d,%d) on clause %d\n",vars[0],vars[1],vars[2],i);
			return -1;
		}
		vars[0] = instance[i].vars[2];
		vars[1] = -1; 
		vars[2] = -1;
		if(process_vars(w_prime, sol, &instance[i], vars) == -1) {
			fprintf(stderr,"Error processing vars(%d,%d,%d) on clause %d\n",vars[0],vars[1],vars[2],i);
			return -1;
		}

		/* 011 */
		vars[0] = instance[i].vars[0];
		vars[1] = instance[i].vars[1];
		vars[2] = -1;
		if(process_vars(w_prime, sol, &instance[i], vars) == -1) {
			fprintf(stderr,"Error processing vars(%d,%d,%d) on clause %d\n",vars[0],vars[1],vars[2],i);
			return -1;
		}
		/* 101 */
		vars[0] = instance[i].vars[0];
		vars[1] = instance[i].vars[2];
		vars[2] = -1;
		if(process_vars(w_prime, sol, &instance[i], vars) == -1) {
			fprintf(stderr,"Error processing vars(%d,%d,%d) on clause %d\n",vars[0],vars[1],vars[2],i);
			return -1;
		}

		/* 110 */
		vars[0] = instance[i].vars[1];
		vars[1] = instance[i].vars[2];
		vars[2] = -1;
		if(process_vars(w_prime, sol, &instance[i], vars) == -1) {
			fprintf(stderr,"Error processing vars(%d,%d,%d) on clause %d\n",vars[0],vars[1],vars[2],i);
			return -1;
		}

		/* 111 */
		vars[0] = instance[i].vars[0];
		vars[1] = instance[i].vars[1];
		vars[2] = instance[i].vars[2];
		if(process_vars(w_prime, sol, &instance[i], vars) == -1) {
			fprintf(stderr,"Error processing vars(%d,%d,%d) on clause %d\n",vars[0],vars[1],vars[2],i);
			return -1;
		}

	}
	return 0;
}




int build_wb(w_vec *w_prime, var *sol, clause *instance, int m) {
	int i;
	int vars[3];

	w_prime->wb = malloc(sizeof(w_cof) * m * 8);
	w_prime->num_w_cofs = 0;

	for(i = 0; i < m; i++) {
		vars[0] = instance[i].vars[0];
		vars[1] = -1; 
		vars[2] = -1;
		if(process_vars(w_prime, sol, &instance[i], vars) == -1) {
			fprintf(stderr,"Error processing vars(%d,%d,%d) on clause %d\n",vars[0],vars[1],vars[2],i);
			return -1;
		}
		vars[0] = instance[i].vars[1];
		vars[1] = -1; 
		vars[2] = -1;
		if(process_vars(w_prime, sol, &instance[i], vars) == -1) {
			fprintf(stderr,"Error processing vars(%d,%d,%d) on clause %d\n",vars[0],vars[1],vars[2],i);
			return -1;
		}
		vars[0] = instance[i].vars[2];
		vars[1] = -1; 
		vars[2] = -1;
		if(process_vars(w_prime, sol, &instance[i], vars) == -1) {
			fprintf(stderr,"Error processing vars(%d,%d,%d) on clause %d\n",vars[0],vars[1],vars[2],i);
			return -1;
		}

		/* 011 */
		vars[0] = instance[i].vars[0];
		vars[1] = instance[i].vars[1];
		vars[2] = -1;
		if(process_vars(w_prime, sol, &instance[i], vars) == -1) {
			fprintf(stderr,"Error processing vars(%d,%d,%d) on clause %d\n",vars[0],vars[1],vars[2],i);
			return -1;
		}
		/* 101 */
		vars[0] = instance[i].vars[0];
		vars[1] = instance[i].vars[2];
		vars[2] = -1;
		if(process_vars(w_prime, sol, &instance[i], vars) == -1) {
			fprintf(stderr,"Error processing vars(%d,%d,%d) on clause %d\n",vars[0],vars[1],vars[2],i);
			return -1;
		}

		/* 110 */
		vars[0] = instance[i].vars[1];
		vars[1] = instance[i].vars[2];
		vars[2] = -1;
		if(process_vars(w_prime, sol, &instance[i], vars) == -1) {
			fprintf(stderr,"Error processing vars(%d,%d,%d) on clause %d\n",vars[0],vars[1],vars[2],i);
			return -1;
		}

		/* 111 */
		vars[0] = instance[i].vars[0];
		vars[1] = instance[i].vars[1];
		vars[2] = instance[i].vars[2];
		if(process_vars(w_prime, sol, &instance[i], vars) == -1) {
			fprintf(stderr,"Error processing vars(%d,%d,%d) on clause %d\n",vars[0],vars[1],vars[2],i);
			return -1;
		}

	}
	return 0;
}


int weight_w_prime(w_vec *w_prime, int n) {
	int i;

	for(i = 0; i < w_prime->num_w_cofs; i++) {
		w_cof *w = &w_prime->wb[i]; 
		w->value = (w->order - 2 * n) * w->value;
	}

}


int add_walsh_list(walsh_list *wl, w_cof *w) {

	walsh_node *wn;

	wn = wl->head;
	while(wn != NULL) {
		if(wn->w->id == w->id) {
			return -1;
		}
		wn = wn->next;
	}

	wn = malloc(sizeof(walsh_node));

	wn->next = NULL;
	wn->prev = NULL;
	wn->w = w;

	if(wl->head == NULL) {
		wl->head = wn;
		wl->tail = wn;
	} else {
		wn->prev = wl->tail;
		wl->tail->next = wn;
		wl->tail = wn;
		wn->next = NULL;
	}

	wl->length++;

	return 0;
}



void build_walsh_list(walsh_list *wl, var *sol, w_vec *w_prime) {
	int i, j, k, l1, l2;

	for(i = 0; i < w_prime->num_w_cofs; i++) {
		w_cof *w = &w_prime->wb[i]; 
		for(j = 0; j < 3; j++) {
			int v = w->vars[j];
			if(v >= 0) {
				for(k = 0; k < sol[v].num_w_cofs; k++) {
					w_cof *w2 = &w_prime->wb[sol[v].w_cofs[k]];
					if(abs(w->order - w2->order) == 1) {
						int num_common = 0;
						l1 = l2 = 0;
						while(l1 < 3 && l2 < 3) {
							if(w->vars[l1] == w2->vars[l2]) {
								num_common++;
								l1++;
								l2++;
							} else if(w->vars[l1] > w2->vars[l2]) {
								l2++;
							} else {
								l1++;
							}
						}
						if((w2->order == 3 && num_common >= 2) ||
								(w->order == 3 && num_common >=2) ||
								w2->order == 1 || 
								w->order == 1) {
								add_walsh_list(&wl[i], w2);
						}
					}
				}
			}
		}
	}
}



int walk_walsh_graph(walsh_list *wl, w_vec *w_prime, int n, int **sols, int not_fixed, int start_idx) {
	int *w_idx;
	int cur_idx = 0;
	int best_idx;
	int i, j;
	int best, fix, sign;
	int conflict;
	w_cof *w;
	walsh_node *wn;

	w_idx = malloc(sizeof(int) * w_prime->num_w_cofs);

	cur_idx = 0;
	w_idx[cur_idx++] = start_idx;

	while(not_fixed > 0) {
		best = -1;
		best_idx = -1;
		while(best_idx == -1) {
			wn = wl[w_idx[cur_idx-1]].head;
			while(wn != NULL) {
				if(abs(wn->w->value) > best && !wn->w->visited) {
					best_idx = wn->w->id;
					best= abs(wn->w->value);
				}
				wn = wn->next;
			}
			if(best_idx == -1) {
				cur_idx--;
				if(cur_idx == 0) {
					break;
				}
			} 
		}
		if(cur_idx == 0) {
			break;
		}

		w_idx[cur_idx++] = best_idx;
		w = &w_prime->wb[w_idx[cur_idx-1]];
		w->visited = 1;
/*		printf("selected %d (%d, %d, %d), order %d value %d\n",w->id, w->vars[0], w->vars[1], w->vars[2], w->order, w->value); */

		fix = 0;
		conflict = 1;
		if(w->value < 0) { sign = 0;  } 
		else if (w->value > 0) { sign = 1; }  
		else { sign = -1; conflict = 0;}
		if(sign != -1) {
			if(w->order==1) {
				for(i = 0; i < 4; i++) {
						if(sols[i][w->vars[0]] == -1) {
							sols[i][w->vars[0]] = o1_pat[sign][0][0];
							sols[i][n] = 1;
							fix = 1;
						} else if(sols[i][w->vars[0]] == o1_pat[sign][0][0]) {
							conflict = 0;
						}
					}
				if(fix) {not_fixed--;}
			} else if(w->order == 2) {
				for(i = 0; i < 4; i++) {
						if(sols[i][w->vars[0]] == -1) {
							for(j = 0; j < 2; j++) {
								if(sols[i][w->vars[1]] == o2_pat[sign][j][1]) {
									sols[i][w->vars[0]] = o2_pat[sign][j][0];
									fix = 1;
									sols[i][n]=1;
								}
							}
						} else if(sols[i][w->vars[1]] == -1) {
							for(j = 0; j < 2; j++) {
								if(sols[i][w->vars[0]] == o2_pat[sign][j][0]) {
									sols[i][w->vars[1]] = o2_pat[sign][j][1];
									fix = 1;
									sols[i][n]=1;
								}
							}
						} else { 
							for(j = 0; j < 2; j++) {
								if((sols[i][w->vars[0]] == o2_pat[sign][j][0] &&
											sols[i][w->vars[1]] == o2_pat[sign][j][1])) {
									sols[i][n]=1;
									conflict = 0;
								}
							}
						} 
					}
				if(fix) {
					not_fixed--;
				}
			} else if(w->order == 3) {
				for(i = 0; i < 4; i++) {
						if(sols[i][w->vars[0]] == -1) {
							for(j = 0; j < 4; j++) {
								if((sols[i][w->vars[1]] == o3_pat[sign][j][1]) &&
										(sols[i][w->vars[2]] == o3_pat[sign][j][2])) {
									sols[i][w->vars[0]] = o3_pat[sign][j][0];
									fix = 1;
									sols[i][n]=1;
								}
							}
						} else if(sols[i][w->vars[1]] == -1) {
							for(j = 0; j < 4; j++) {
								if((sols[i][w->vars[0]] == o3_pat[sign][j][0]) &&
										(sols[i][w->vars[2]] == o3_pat[sign][j][2])) {
									sols[i][w->vars[1]] = o3_pat[sign][j][1];
									fix = 1;
									sols[i][n]=1;
								}
							}
						} else if(sols[i][w->vars[2]] == -1) {
							for(j = 0; j < 4; j++) {
								if((sols[i][w->vars[0]] == o3_pat[sign][j][0]) &&
										(sols[i][w->vars[1]] == o3_pat[sign][j][1])) {
									sols[i][w->vars[2]] = o3_pat[sign][j][2];
									fix = 1;
									sols[i][n]=1;
								}
							}
						} else {
							for(j = 0; j < 4; j++) {
								if((sols[i][w->vars[0]] == o3_pat[sign][j][0]) &&
										(sols[i][w->vars[1]] == o3_pat[sign][j][1]) &&
										(sols[i][w->vars[2]] == o3_pat[sign][j][2]))  {

									sols[i][n]=1;
									conflict = 0;
								}
							}
						}
					}
				if(fix) {
					not_fixed--;
				}
			}
		}
		/*
	printf("not_fixed = %d\n",not_fixed);
	for(i = 0; i < n; i++) {
		printf("%4d",i);
	}printf("   v\n");

	for(i = 0; i < n+1; i++) {
		printf("%4d",sols[0][i]);
	}printf("\n");
	for(i = 0; i < n+1; i++) {
		printf("%4d",sols[1][i]);
	}printf("\n");
	for(i = 0; i < n+1; i++) {
		printf("%4d",sols[2][i]);
	}printf("\n");
	for(i = 0; i < n+1; i++) {
		printf("%4d",sols[3][i]);
	}printf("\n");
	*/


		if(!fix && conflict) {
			cur_idx--;
			if(cur_idx == 0) {
				break;
			}
		}

	}

	free(w_idx);
	return not_fixed;
}



void walsh_tree(walsh_list *wl, w_vec *w_prime, var *sol, int n, clause *instance, int m) {
	int i, j,  best, best_idx;
	int sign; /* 0 for negative, 1 for positive */
	int *sols[4];
	int *fixed;
	int not_fixed = n;
	int *w_idx;
	int cur_idx = 0;
	w_cof *w;

	for(i = 0; i < 4; i++) {
		sols[i] = malloc(sizeof(int) * (n+1));
	}
	fixed = malloc(sizeof(int) * n);
	w_idx = malloc(sizeof(int) * w_prime->num_w_cofs);

	for(i = 0; i < n+1; i++) {
		if(i < n) {
			fixed[i] = -1;
			sols[0][i] = -1;
			sols[1][i] = -1;
			sols[2][i] = -1;
			sols[3][i] = -1;
		} else {
			sols[0][i] = 1;
			sols[1][i] = 1;
			sols[2][i] = 1;
			sols[3][i] = 1;
		}
	}

	best = INT_MIN;

	for(i = 0; i < w_prime->num_w_cofs; i++) {
		if(abs(w_prime->wb[i].value) > best && !(w_prime->wb[i].visited)) {
			best_idx = i;
			best = abs(w_prime->wb[i].value);
		}
	}

	best_idx = lrand48() % w_prime->num_w_cofs;
	while(w_prime->wb[best_idx].value == 0) {
		best_idx = lrand48() % w_prime->num_w_cofs;
	}

	w = &w_prime->wb[best_idx];
	w->visited = 1;
/*	printf("selected order %d %d\n",w->order, w->value); */
	if(w->value < 0) sign = 0; else sign = 1;
	if(w->order==1) {
		for(i = 0; i < 4; i++) {
			sols[i][w->vars[0]] = o1_pat[sign][0][0];
		}
		not_fixed--;
	} else if(w->order == 2) {
		for(i = 0; i < 2; i++) {
			for(j = 0; j < 2;j++) {
				sols[i][w->vars[j]] = o2_pat[sign][i][j];
				sols[i+2][w->vars[j]] = o2_pat[sign][i][j];
			}
		}
		not_fixed-=2;
	} else if(w->order == 3) {
		for(i = 0; i < 4; i++) {
			for(j = 0; j < 3;j++) {
				sols[i][w->vars[j]] = o3_pat[sign][i][j];
			}
		}
		not_fixed-=3;
	}
	/*
	printf("not_fixed = %d\n",not_fixed);
	for(i = 0; i < n; i++) {
		printf("%4d",i);
	}printf("   v\n");

	for(i = 0; i < n+1; i++) {
		printf("%4d",sols[0][i]);
	}printf("\n");
	for(i = 0; i < n+1; i++) {
		printf("%4d",sols[1][i]);
	}printf("\n");
	for(i = 0; i < n+1; i++) {
		printf("%4d",sols[2][i]);
	}printf("\n");
	for(i = 0; i < n+1; i++) {
		printf("%4d",sols[3][i]);
	}printf("\n");
*/
	cur_idx = 0;
	w_idx[cur_idx++] = best_idx;
	not_fixed = walk_walsh_graph(wl, w_prime, n, sols, not_fixed, best_idx);

	while(not_fixed > 0) {
		best = INT_MIN;

		for(i = 0; i < w_prime->num_w_cofs; i++) {
			if(abs(w_prime->wb[i].value) > best && !(w_prime->wb[i].visited)) {
				int proceed = 0;
				if(w_prime->wb[i].order==1) {
					if(sols[0][w_prime->wb[i].vars[0]] == -1) {
						proceed = 1;
					}
				} else if(w_prime->wb[i].order==2) {
					if((sols[0][w_prime->wb[i].vars[0]] == -1) && (sols[0][w_prime->wb[i].vars[1]] == -1)) {
						proceed = 1;
					}
				} else if(w_prime->wb[i].order==3) {
					if((sols[0][w_prime->wb[i].vars[0]] == -1) && (sols[0][w_prime->wb[i].vars[1]] == -1) && (sols[0][w_prime->wb[i].vars[2]] == -1)) {
						proceed = 1;
					}
				}
				if(proceed) {
					best_idx = i;
					best = abs(w_prime->wb[i].value);
				}
			}
		}

		w = &w_prime->wb[best_idx];
		w->visited = 1;
		/*printf("nf = %d id = %d order= %d value = %d visited = %d (%d, %d, %d)\n",not_fixed, best_idx, w->order, w->value, w->visited, w->vars[0], w->vars[1], w->vars[2]); */
		if(w->value < 0) sign = 0; else sign = 1;

		if(w->order==1) {
			for(i = 0; i < 4; i++) {
				sols[i][w->vars[0]] = o1_pat[sign][0][0];
			}
			not_fixed--;
		} else if(w->order == 2) {
			for(i = 0; i < 2; i++) {
				for(j = 0; j < 2;j++) {
					sols[i][w->vars[j]] = o2_pat[sign][i][j];
					sols[i+2][w->vars[j]] = o2_pat[sign][i][j];
				}
			}
			not_fixed-=2;
		} else if(w->order == 3) {
			for(i = 0; i < 4; i++) {
				for(j = 0; j < 3;j++) {
					sols[i][w->vars[j]] = o3_pat[sign][i][j];
				}
			}
			not_fixed-=3;
		}


		not_fixed = walk_walsh_graph(wl, w_prime, n, sols, not_fixed, best_idx);
	}
/*
		for(j = 0; j < 4; j++) {
			int sum = 0;
			for(i = 0; i < n;i++) {
				if(sols[j][i] == -1) {
					sum++;
				}
			}
		}


	printf("%d - %d\n",evaluate_solution(sol, instance, m),m); */
	for(i = 0; i < 4; i++) {
		for(j = 0; j < n; j++) {
			sol[j].value = sols[i][j];
		}
		/*
		printf("%d - %d (%d)\n",evaluate_solution(sol, instance, m),m,sols[i][n]);
		*/
	}

	free(w_idx);
	for(i = 0; i < 4; i++) {
		free(sols[i]);
	}
	free(fixed);
}



