#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>
#include "varclause.h"
#include "varwalsh.h"
#include "var.h"


int int_cmp_pure (const void *a, const void *b)
{
	const int *ia = (const int *)a; // casting pointer types 
	const int *ib = (const int *)b;
	return *ib  - *ia;
}



int reduce_instance(varclause* instance, varclause **newinstance, var *sol, int *vari, int *value, int n, int m, int NUMBITS) {
	int i,j, k;
	int new_m = 0;
	int idx, nv, bit, bitval, clause_true;
	int new_n = n - 4;
	int vars[5000], signs[5000];
	int *unsat;

	unsat = malloc(sizeof(int) * m);

	for(i = 0; i < m; i++) {
		unsat[i] = 0;
	}

	/* Find sat clauses */
	for(i = 0; i < NUMBITS; i++) {
		bit = vari[i];
		bitval = value[i];
		for(j = 0; j < sol[i].num_clauses; j++) {
			varclause *vc = sol[i].clauses[j];
			clause_true = 0;
			for(k = 0; k < vc->numvars; k++) {
				if(vc->vars[k] == bit) {
					if((bitval && (vc->signs[k] > 0)) ||
							(!bitval && (vc->signs[k] < 0))) {
						clause_true = 1;
						break;
					}
				}
			}
			if(clause_true) {
				unsat[vc->id] = 1;
			} 		
		}
	}

	/* Count number of unsat clauses */
	new_m = 0;
	for(i = 0; i < m; i++) {
		if(!unsat[i]) {
			new_m++;
		}
	}

	/* Allocate new instance */
	(*newinstance) = malloc(sizeof(varclause) * new_m);

	/* Form new instance */
	new_m = 0;
	idx = 0;
	for(i = 0; i < m; i++) {
		if(!unsat[i]) {
			int fixed_bits = 0;
			nv = 0;
			for(j = 0; j < instance[i].numvars; j++) {
				int bit_flag = 1;
				for(k = 0; k < NUMBITS; k++) {
					if(instance[i].vars[j] == vari[k]) {
						bit_flag = 0;
					}
				}
				if(bit_flag) {	
					vars[nv] = instance[i].vars[j];
					signs[nv] = instance[i].signs[j];
					nv++;
				} else {
					fixed_bits++;
				}
			}
			if(fixed_bits == instance[i].numvars) {
				printf("c Contradiction in bit setting\n");
				exit(30);
			}


			if(nv > 0) {
				init_varclause_nowf(&((*newinstance)[idx]), nv, vars, signs); 
				(*newinstance)[idx].id = idx;
				idx++;
				new_m++;
			} 		
		}
	}
	free(unsat);
	return new_m;
}


int varwalsh_sign(var *sol, varw_cof *w) {
	int bc = 0;
	int i;

	for(i = 0; i < w->order; i++) {
		if(w->vars[i] > -1) {
			if(sol[w->vars[i]].value > 0) {
				bc++;
			}
		}
	}

	if(bc % 2 == 0) {
		return 1;
	} else {
		return -1; 
	}
}

int varwalsh_sign_int(int *sol, varw_cof *w) {
	int bc = 0;
	int i;

	for(i = 0; i < w->order; i++) {
		if(w->vars[i] > -1) {
			if(sol[w->vars[i]] > 0) {
				bc++;
			}
		}
	}

	if(bc % 2 == 0) {
		return 1;
	} else {
		return -1; 
	}
}

void compute_varwalsh_signs(var *sol, varw_vec *w_prime) {
	int i;

	for(i = 0; i < w_prime->num_w_cofs; i++) {
		w_prime->wb[i].sign = varwalsh_sign(sol, &w_prime->wb[i]);
	}	
}

void compute_varhyperplanes(varclause *instance, varw_vec *w_prime, int m, int n, int max, var *sol, var *reduced_sol, int *best_vars) {
	int i, j, k, l;
	int nv, idx;
	int *vars;
	double hp_fitness;
	int *vars_fake;
	int *signs_fake;
	int order;
	int *bits;
	int w_id;
	double *zeros;
	double *ones; 
	int *map;

	map = malloc(sizeof(int) * n);
	for(i = 0; i < max; i++) {
		map[sol[i].idx] = i;
	}

	varclause *fakeinstance;

	fakeinstance = malloc(sizeof(varclause) * 1);
	vars = malloc(sizeof(int) * n);

	vars_fake = malloc(sizeof(int) * max);
	signs_fake = malloc(sizeof(int) * max);

	idx = 0;
	i=0;
		nv=0;
		for(j = 0; j < max; j++) {
			vars_fake[nv] = sol[j].idx;
			signs_fake[nv] = 1;
			nv++;
		}
		init_varclause(&fakeinstance[idx], nv, vars_fake, signs_fake); 
		fakeinstance[idx].id = idx;
		bits = malloc(sizeof(int) * fakeinstance[idx].numvars);
		for(j = 1; j < pow(2,fakeinstance[idx].numvars); j++) {
			order = 0;
			for(k = 0; k < fakeinstance[idx].numvars; k++) {
				if(CHECK_BIT(j,k)) {
					bits[order] = fakeinstance[idx].vars[k];
					order++;
				}
			}
			for(k = order; k < fakeinstance[idx].numvars; k++) {
				bits[k] = -1;
			}
			w_id = check_varwcof(reduced_sol, w_prime, bits, order);
			if(w_id != -1) {
				fakeinstance[idx].w_cofs[fakeinstance[idx].cur_wcof++] = &(w_prime->wb[w_id]);
			}
		}
		free(bits);
		idx++;

	/*
	for(i = 0; i < (pow(2,4)-1); i++) {
		for(j = 0; j < fakeinstance[i].numvars; j++) {
			printf("%d ",fakeinstance[i].vars[j]);
		}
		printf("\n");
	}
	*/

	double best_hp = -DBL_MAX;

	i=0;
		if(fakeinstance[i].numvars == max) {
			for(j = 0; j < pow(2,fakeinstance[i].numvars); j++) {
				hp_fitness = 0;

				/* Set bits for hyperplane */
				for(k = 0; k < fakeinstance[i].numvars; k++) {
					if(CHECK_BIT(j,k)) {
						vars[fakeinstance[i].vars[k]] = 1;
					} else {
						vars[fakeinstance[i].vars[k]] = 0;
					}
				}

				/* Compute average hyperplane fitness */
				for(k = 0; k < fakeinstance[i].cur_wcof; k++) {
					hp_fitness += varwalsh_sign_int(vars, fakeinstance[i].w_cofs[k]) * (fakeinstance[i].w_cofs[k])->value;
				}

				if(hp_fitness > best_hp) {
					best_hp = hp_fitness;
					for(k=0;k<max;k++) {
						best_vars[k] = vars[fakeinstance[i].vars[k]];
					}
				}


				/* Record values in hyperplane */
				for(k = 0; k < fakeinstance[i].numvars; k++) {
					fakeinstance[i].hp[j].value[k] = vars[fakeinstance[i].vars[k]];
					fakeinstance[i].hp[j].vars[k] = fakeinstance[i].vars[k];
				}
				fakeinstance[i].hp[j].fitness = hp_fitness;
				if(hp_fitness > 0) {
					fakeinstance[i].total_hp_fitness += hp_fitness;
				}
			}
		}

		/*
		   if(w_prime->hyperplane_bias[i] <= 0.01) {
		   w_prime->hyperplane_bias[i] = 0.01;
		   }
		   if(w_prime->hyperplane_bias[i] >= 0.99) {
		   w_prime->hyperplane_bias[i] = 0.99;
		   }
		   */


	free(vars);
}

int is_sat(var *sol, varclause *instance, int i) {
	int j;
	for(j = 0; j < instance[i].numvars; j++) {
		if((sol[instance[i].vars[j]].value && (instance[i].signs[j] > 0)) ||
				(!sol[instance[i].vars[j]].value && (instance[i].signs[j] < 0))) {
			return 1;
		}
	}
	return 0;
}

void init_varclause_nowf(varclause *c, int numvars, int *vars, int *signs) {
	int i,j, tmp;
	c->numvars = numvars;
	c->cur_wcof=0;
	c->total_hp_fitness=0;
	c->vars = malloc(sizeof(int) * numvars);
	c->signs = malloc(sizeof(int) * numvars);
	c->numsat = 0;
	for(i = 0; i < (numvars - 1); i++) {
		for(j = 0; j < (numvars - i - 1); j++) {
			if(vars[j] < vars[j+1]) {
				tmp = vars[j];
				vars[j] = vars[j+1];
				vars[j+1] = tmp;
				tmp = signs[j];
				signs[j] = signs[j+1];
				signs[j+1] = tmp;
			}

		}
	}


	for(i = 0; i < numvars; i++) {
		c->vars[i] = vars[i];
		c->signs[i] = signs[i];
	}

} 

void init_varclause(varclause *c, int numvars, int *vars, int *signs) {
	int i,j, tmp;
	c->numvars = numvars;
	c->w_cofs = malloc(sizeof(varw_cof*) * pow(2,numvars));
	c->cur_wcof=0;
	c->total_hp_fitness=0;
	c->vars = malloc(sizeof(int) * numvars);
	c->signs = malloc(sizeof(int) * numvars);
	c->numsat = 0;
	for(i = 0; i < (numvars - 1); i++) {
		for(j = 0; j < (numvars - i - 1); j++) {
			if(vars[j] < vars[j+1]) {
				tmp = vars[j];
				vars[j] = vars[j+1];
				vars[j+1] = tmp;
				tmp = signs[j];
				signs[j] = signs[j+1];
				signs[j+1] = tmp;
			}

		}
	}


	for(i = 0; i < numvars; i++) {
		c->vars[i] = vars[i];
		c->signs[i] = signs[i];
	}

	c->numhp = pow(2,numvars);
	c->hp = malloc(sizeof(varhyperplane) * c->numhp);
	for(i = 0; i < c->numhp; i++) {
		c->hp[i].vars = malloc(sizeof(int) * numvars);
		c->hp[i].value = malloc(sizeof(int) * numvars);
		c->hp[i].fitness = 0;
	}
} 

void free_varclause(varclause *instance, int m) {
	int i,j;
	varclause *c;
	for(j = 0; j < m; j++) {
		c = &instance[j];
		for(i = 0; i < c->numhp;i++) {
			free(c->hp[i].vars);
			free(c->hp[i].value);
		}
		free(c->hp);
		free(c->vars);
		free(c->signs);
	}
	free(instance);
}

double sum_varwcof(varw_cof *w, varclause *instance, int *vars, int order) {
	int bc = 0;
	int i, j;

	for(i = 0; i < order; i++) {
		if(vars[i] > -1) {
			j = 0;
			while(instance->vars[j] != vars[i]) {
				j++;
				if(j >= instance->numvars) {
					fprintf(stderr,"Out of bounds error in sum_w_cof\n");
					exit(-1);
				}
			}
			if(instance->signs[j] < 0) {
				bc++;
			}
		}
	}

	if(bc % 2 == 0) {
		w->value -= 1/(pow(2,instance->orig_numvars)); 
	} else {
		w->value += 1/(pow(2,instance->orig_numvars)); 
	}

	instance->w_cofs[instance->cur_wcof++] = w;
	return w->value;
}


int new_varwcof(varw_vec *w_prime, varclause *instance, var *sol, int *vars, int order) {
	int i;

	w_prime->num_w_cofs++;
	w_prime->wb[w_prime->num_w_cofs - 1].value = 0;
	w_prime->wb[w_prime->num_w_cofs - 1].next = NULL;
	w_prime->wb[w_prime->num_w_cofs - 1].prev = NULL;
	w_prime->wb[w_prime->num_w_cofs - 1].id = w_prime->num_w_cofs - 1;
	w_prime->wb[w_prime->num_w_cofs - 1].visited = 0;
	w_prime->wb[w_prime->num_w_cofs - 1].num_clause = 0;
	w_prime->wb[w_prime->num_w_cofs - 1].clause = NULL;
	w_prime->wb[w_prime->num_w_cofs - 1].order = order;


	w_prime->wb[w_prime->num_w_cofs - 1].vars = malloc(sizeof(int) * order);

	for(i = 0; i < order; i++) {
		w_prime->wb[w_prime->num_w_cofs - 1].vars[i] = vars[i];
		if(vars[i] > -1) {
			if(add_w_cof(sol, vars[i], w_prime->num_w_cofs-1) == -1) {
				fprintf(stderr,"Failed adding w_cof %d to variable %d\n",w_prime->num_w_cofs - 1, vars[i]);
				return -1;
			}
		}
	}

	sum_varwcof(&(w_prime->wb[w_prime->num_w_cofs - 1]), instance, vars, order);

	return 0;
}

int check_varwcof(var *sol, varw_vec *w_prime, int *vars, int order) {
	int i, j, found;
	varw_cof *check;

	if(sol[vars[0]].num_w_cofs == 0) {
		return -1;
	} else {
		for(i = 0; i < sol[vars[0]].num_w_cofs; i++) {
			check = &w_prime->wb[sol[vars[0]].w_cofs[i]];
			found = 1;
			if(check->order == order) {
				for(j = 0; j < check->order; j++) {
					if(vars[j] != check->vars[j]) {
						found = 0;
					}
				}
			} else {
				found = 0;
			}
			if(found) {
				return check->id;
			}
		}
	}
	return -1;
}

double process_varw(varw_vec *w_prime, var *sol, varclause *instance, int *vars, int order) {
	int w_id;
	if((w_id = check_varwcof(sol, w_prime, vars, order)) == -1) {
		if(new_varwcof(w_prime, instance, sol, vars, order) == -1) {
			fprintf(stderr, "Failed adding new w_cof\n");
			return -1;
		} else {
			return 1;
		}
	} else {
		return abs(sum_varwcof(&(w_prime->wb[w_id]), instance, vars,order));
	}
}


void compute_walsh(varw_vec *w_prime, var *sol, varclause *instance, int m) {
	int i,j,k,l;
	int order;
	int *bits;

	for(i = 0; i < m; i++) {
		bits = malloc(sizeof(int) * instance[i].numvars);
		for(j = 1; j < pow(2,instance[i].numvars); j++) {
			order = 0;
			for(k = 0; k < instance[i].numvars; k++) {
				if(CHECK_BIT(j,k)) {
					bits[order] = instance[i].vars[k];
					order++;
				}
			}
			for(k = order; k < instance[i].numvars; k++) {
				bits[k] = -1;
			}
			process_varw(w_prime, sol, &instance[i], bits, order);
		}
		free(bits);
	}
}

varclause* simplify(char *bits, varclause *instance, int m) {
	int new_m, i, j;
	int sat;

	for(i = 0; i < m; i++) {
		sat = 0;
		for(j = 0; j < instance[i].numvars;j++) {
			if(bits[instance[i].vars[j]] > 0) {
				if((bits[instance[i].vars[j]] && instance[i].signs[j] > 0) || 
						(!bits[instance[i].vars[j]] && instance[i].signs[j] < 0))  {
					sat = 1;
				}
			}
		}
		if(!sat) {
			new_m++;
		}
	}
}
