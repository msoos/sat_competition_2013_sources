#ifndef _VARVECTORS_H_
#define _VARVECTORS_H_

#include "vectors.h"
#include "varwalsh.h"

int varbuild_vectors(vector_ptr v, varclause *instance, varw_vec *w_prime, var *sol, int n, int m);
int varupdate_vectors(vector_ptr v, varw_vec *w_prime, var *sol, int bit);
int varbuild_vectors_unsat(vector_ptr v, varclause *instance, var *sol, int n, int m);
int varupdate_vectors_unsat(vector_ptr v, varw_vec *w_prime, var *sol, int bit);
#endif
