#ifndef _VARCLAUSE_H_
#define _VARCLAUSE_H_

#define CHECK_BIT(var,pos) ((var) & (1<<(pos)))

struct VarW_vec;
struct Var;
struct W_cof;

typedef struct VarHyperplane {
	int *vars;
	int *value;
	float fitness;
} varhyperplane;

typedef struct VarClause {
	int id;
	int numvars;
	int orig_numvars;
	int *vars;
	int *signs;
	int numhp;
	int numsat;
	int cur_wcof;
	int time_unsat;
	float total_hp_fitness;
	struct VarW_cof **w_cofs;
	varhyperplane *hp;
} varclause;

void init_varclause_nowf(varclause *c, int numvars, int *vars, int *signs);
void init_varclause(varclause *c, int numvars, int *vars, int *signs);
int reduce_instance(varclause* instance, varclause **newinstance, struct Var *sol, int *var, int *value, int n, int m, int nb);
void compute_varwalsh_signs(struct Var *sol, struct VarW_vec *w_prime);
void compute_varhyperplanes(varclause *instance, struct VarW_vec *w_prime, int m, int n, int max, struct Var *sol, struct Var *rsol, int *best_vars);
int is_sat(struct Var *sol, varclause *instance, int i);
void free_varclause(varclause *instance, int m);

#endif
