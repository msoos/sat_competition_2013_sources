#ifndef _VAR_H_
#define _VAR_H_

#include "clause.h"
#include "varclause.h"

struct W_vec;
struct VarW_vec;
struct Walsh_list;
struct Vectors;
 
typedef int Item;
typedef struct Mediator_t
{
   Item* data;  //circular queue of values
   int*  pos;   //index into `heap` for each value
   int*  heap;  //max/median/min heap holding indexes into `data`.
   int   N;     //allocated size.
   int   idx;   //position in circular queue
   int   minCt; //count of items in min heap
   int   maxCt; //count of items in max heap
} Mediator;
 

typedef struct Var {
	int idx;
	int value;
	int num_clauses;
	struct VarClause **clauses;
	int num_w_cofs;
	int *w_cofs;
	int last_flipped;
	struct Var *next;
	struct Var *prev;
	int in_buf;
	double p[2];
	int last_hp;
	int breaks;
	int makes;
	int fixed;
	double total_cl;
	int firstorder;
	Mediator *m;
} var;

Item MediatorMedian(Mediator* m);
int add_w_cof(var *sol, int v, int w_id);
int build_solution(var **sol, varclause *instance, int n, int m);
void varflip_bit(var *sol, struct W_vec *w_prime, struct Vectors *v, int bit);
int evaluate_solution_with_v(var *sol, struct Vectors *v, varclause *instance, int m);
int evaluate_solution(var *sol, varclause *instance, int m);
void walsh_bias(struct Walsh_list *wl, struct W_vec *w_prime, var *sol, int n, clause *instance, int m);
void hyperplane_bias_v3(struct Walsh_list *wl, struct W_vec *w_prime, var *sol, int n, clause *instance, int m);
void hyperplane_bias_v2(struct Walsh_list *wl, struct W_vec *w_prime, var *sol, int n, clause *instance, int m);
void hyperplane_bias(struct Walsh_list *wl, struct W_vec *w_prime, var *sol, int n, clause *instance, int m);
void random_init(struct Walsh_list *wl, struct VarW_vec *w_prime, var *sol, int n, varclause *instance, int m);
void hyperplane_init(struct Walsh_list *wl, struct VarW_vec *w_prime, var *sol, int n, varclause *instance, int m);
int add_clause(var **sol, varclause *instance, int i, int p);

#endif
