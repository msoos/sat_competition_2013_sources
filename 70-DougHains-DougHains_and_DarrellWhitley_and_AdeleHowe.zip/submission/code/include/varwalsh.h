#ifndef _VARWALSH_H_
#define _VARWALSH_H_

#include "varclause.h"
#include "var.h"


typedef struct VarW_cof {
	int id;
	double value;
	int order;
	int sign;
	int *vars;
	int visited;
	struct W_cof *prev;
	struct W_cof *next;
	int num_clause;
	varclause **clause;
} varw_cof;


typedef struct VarW_vec {
	int num_w_cofs;
	varw_cof *wb;
	double *hyperplane_bias;
	double p;
} varw_vec;


#endif
