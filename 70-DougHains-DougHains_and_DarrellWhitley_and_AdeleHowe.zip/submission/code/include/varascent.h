#ifndef _ASCENT_H_
#define _ASCENT_H_

#include "varvectors.h"
#include "varclause.h"
#include "var.h"

typedef int (*greedyPick)(vector_ptr);
typedef varclause* (*varclausePick)(vector_ptr, varclause*, int, var*, varw_vec*);
typedef int (*varPick)(vector_ptr, varclause*, int, var*, varw_vec*);
typedef int (*updateType)(vector_ptr, varw_vec*, var*, int);


int novelty_var_pick(vector_ptr v_ptr, varclause *c, int m, var *sol, varw_vec *w_prime);
int varlocal_search(vector_ptr v, varclause *i, int m, var *sol, varw_vec *w_prime, 
		greedyPick gp, varclausePick cp, varPick vp, updateType update);
	
/* GREEDY PICKS */
int vars_next_greedy_pick(vector_ptr v_ptr);
int s_next_greedy_pick_hp_tabu(vector_ptr v_ptr);
int vars_gsat_greedy_pick(vector_ptr v_ptr);
int null_greedy_pick(vector_ptr v_ptr);

/* CLAUSE PICKS */
varclause *varrandom_clause_pick(vector_ptr v, varclause *varinstance, int m, var *sol, varw_vec *w_prime);
varclause *aged_clause_pick(vector_ptr v, varclause *instance, int m, var *sol, varw_vec *w_prime);
/* VAR PICKS */
int breaks_var_pick(vector_ptr v_ptr, varclause *c, int m, var *sol, varw_vec *w_prime);
int varrandom_var_pick(vector_ptr v_ptr, varclause *c, int m, var *sol, varw_vec *w_prime);
int var_hyperplane_var_pick(vector_ptr v_ptr, varclause *c, int m, var *sol, varw_vec *w_prime);
int var_hyperplane_var_pick_f2(vector_ptr v_ptr, varclause *c, int m, var *sol, varw_vec *w_prime);
int var_hyperplane_var_pick_f3(vector_ptr v_ptr, varclause *c, int m, var *sol, varw_vec *w_prime);
int var_hyperplane_var_pick_f4(vector_ptr v_ptr, varclause *c, int m, var *sol, varw_vec *w_prime);
int var_hyperplane_var_pick_f5(vector_ptr v_ptr, varclause *c, int m, var *sol, varw_vec *w_prime);
int var_hyperplane_var_pick_f6(vector_ptr v_ptr, varclause *c, int m, var *sol, varw_vec *w_prime);
int var_hyperplane_var_pick_f7(vector_ptr v_ptr, varclause *c, int m, var *sol, varw_vec *w_prime);
int var_hyperplane_var_pick_f8(vector_ptr v_ptr, varclause *c, int m, var *sol, varw_vec *w_prime);
int var_hyperplane_var_pick_f9(vector_ptr v_ptr, varclause *c, int m, var *sol, varw_vec *w_prime);
int var_hyperplane_var_pick_f10(vector_ptr v_ptr, varclause *c, int m, var *sol, varw_vec *w_prime);
int var_hyperplane_var_pick_f11(vector_ptr v_ptr, varclause *c, int m, var *sol, varw_vec *w_prime);
int var_hyperplane_var_pick_f12(vector_ptr v_ptr, varclause *c, int m, var *sol, varw_vec *w_prime);
int varbreakprob_var_pick(vector_ptr v_ptr, varclause *c, int m, var *sol, varw_vec *w_prime);

#endif
