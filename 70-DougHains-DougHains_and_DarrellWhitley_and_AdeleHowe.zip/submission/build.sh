#!/bin/bash

cd code
make
cd ..
cp code/best_hyperplane binary
cp minisat_static binary
cp SatELite_release binary 
cp hyperplane_minisat.sh binary
