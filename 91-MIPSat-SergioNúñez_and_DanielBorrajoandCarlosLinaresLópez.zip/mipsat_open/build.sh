#!/bin/sh

cd "$(dirname "$0")"
ROOT=$PWD

# mkdir
cd $ROOT
rm -rf $ROOT/binary
mkdir binary

if [ $? -eq 0 ]; then

	# Compile
	cd $ROOT/code
	./build
	
	if [ $? -eq 0 ]; then

		# Copy solver to binary folder
		cp -rf $ROOT/code/* $ROOT/binary

		if [ $? -eq 0 ]; then
			rm -rf $ROOT/binary/build
			echo "\nSolver ready to the SAT Competition 2013"
		else
			echo "\nError moving binary files"
		fi
	fi

else 
	echo "\nError creating binary folder"
fi
