#ifndef _BASE_HEADER
#define _BASE_HEADER

#include <vector>
#include <set>
#include <map>
#include <algorithm>
#include <fstream>

#include "Allocator.h"

using namespace std;

typedef enum Value
{
	V_TRUE=0,
	V_FALSE=1,
	V_UNASSIGNED=2
}Value;

typedef enum Phase
{
	P_POSITIVE=0,
	P_NEGATIVE=1
}Phase;

typedef unsigned int ClausePtr;
//typedef size_t ClausePtr;

typedef unsigned int Variable;

class Literal
{
private:
	unsigned int _literal;

public:
	static const Literal UNDEF;

	Literal(int id, Phase phase)
		: _literal((id<<1)+phase)
	{
		assert(id!=0);
	}

	Literal()
	    : _literal(0)
	{
	}

	Literal& operator=(const Literal& right)
	{
		_literal=right._literal;
		return *this;
	}

	bool operator==(const Literal& right) const
	{
		return _literal==right._literal;
	}

	bool operator!=(const Literal& right) const
	{
		return _literal!=right._literal;
	}

	Literal operator-() const
	{
		Literal lit(*this);
		lit._literal^=1;
		return lit;
	}

	bool operator<(const Literal& right) const
	{
		return _literal<right._literal;
	}

	bool operator>(const Literal& right) const
	{
		return _literal>right._literal;
	}

	Variable var() const
	{
		return _literal>>1;
	}

	Phase phase() const
	{
		return (Phase)(_literal&1);
	}

	Value implied_value() const    // variable's value implied by true literal
	{
		return (Value)((_literal&1)^V_TRUE);
	}

	unsigned int toInt() const
	{
		return _literal;
	}

	friend ofstream& operator<<(ofstream& out, const Literal& literal);
	friend ostream& operator<<(ostream& out, const Literal& literal);
};

class ClausePool;

class Clause
{
	friend class ClausePool;

private:
	static const unsigned int FLAG_LEARNT=1u;
	static const unsigned int FLAG_DELETED=(1u<<1);
	static const unsigned int FLAG_TOUCHED=(1u<<2);

	size_t _size;
	unsigned int _flag;
	unsigned int _glue;
	union{
		unsigned long signature;
		double activity;
	} _extra;
	Literal _literals[0];

	static unsigned long compute_signature(Literal* begin, Literal* end)
	{
		unsigned long signature=0ul;
		for(Literal* itr=begin; itr!=end; itr++){
			signature |= (1ul<<(itr->var()%sizeof(unsigned long)));
		}
		return signature;
	}

	Clause(const vector<Literal>& literals, bool is_learnt=false)
		: _size(literals.size()), _flag(0), _glue(0)
	{
		for(size_t i=0; i<_size; i++){
			_literals[i]=literals[i];
		}

		touch();

		if(is_learnt){
			_flag |= FLAG_LEARNT;
			_extra.activity=0;
		}
		else{
			_extra.signature=compute_signature(begin(), end());
		}
	}

public:
	typedef Literal* iterator;

	const Literal& operator[](size_t index) const
	{
		assert(index>=0 && index<_size);
		return _literals[index];
	}

	Literal& operator[](size_t index)
	{
		assert(index>=0 && index<_size);
		return _literals[index];
	}

	size_t size() const
	{
		return _size;
	}

	bool is_learnt() const
	{
		return (_flag & FLAG_LEARNT) != 0;
	}

	unsigned int& glue()
	{
		return _glue;
	}

	unsigned long signature()
	{
		assert(!is_learnt());
		return _extra.signature;
	}

	double& activity()
	{
		assert(is_learnt());
		return _extra.activity;
	}

	iterator begin()
	{
		return &_literals[0];
	}

	iterator end()
	{
		return &_literals[_size];
	}

	 void set_deleted()
	 {
		 _flag |= FLAG_DELETED;
	 }

	 bool is_deleted()
	 {
		 return (_flag & FLAG_DELETED) != 0;
	 }

	 void touch()
	 {
		 _flag |= FLAG_TOUCHED;
	 }

	 void untouch()
	 {
		 _flag &= ~FLAG_TOUCHED;
	 }

	 bool is_touched()
	 {
		 return (_flag & FLAG_TOUCHED) != 0;
	 }

	 void strengthen(Literal lit)
	 {
		 assert(!is_learnt());
		 for(size_t i=0; i<_size; i++){
			 if(_literals[i]==lit){
				 _literals[i]=_literals[--_size];
				 _extra.signature=compute_signature(begin(), end());
				 return;
			 }
		 }
		 assert(false);
	 }
};

class ClausePool
{
private:
//	typedef unsigned char UnitType;
	typedef int UnitType;

	static Allocator<UnitType> _allocator;

	// Calculate the number of UnitType used to store the clause
	static inline size_t calculate_clause_size(size_t literal_size)
	{
		return (sizeof(Clause)+sizeof(Literal)*literal_size)/sizeof(UnitType);
	}

	ClausePool();

public:
	static const ClausePtr CLS_NULL=Allocator<UnitType>::MEM_NULL;
	
	static ClausePtr create(const vector<Literal>& literals, bool is_learnt);
	static void free(ClausePtr ptr);

	static Clause& get(ClausePtr ptr)
	{
		return *(reinterpret_cast<Clause*>(&_allocator[ptr]));
	}
//	ClausePtr get_address(const Clause& clause);

	static void reallocate(vector<ClausePtr>& clauses, vector<ClausePtr>& learnt_clauses);

	static double wasted_ratio();

	static size_t memory_usage();

	static void dump(ostream& out);
};

#endif
