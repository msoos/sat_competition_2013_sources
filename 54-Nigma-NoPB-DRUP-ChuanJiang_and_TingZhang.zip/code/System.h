#ifndef _SYSTEM_HEADER
#define _SYSTEM_HEADER

class System
{
private:
	System();

public:
	static double get_cpu_time();

	// Wall Time = CPU Time + I/O Time + Communication Channel Delay (e.g. if data are scattered on multiple machines)
	static double get_wall_time();

	static double get_memory_usage();

	static double get_max_memory_usage();
};

#endif
