#ifndef _LITERALVECTOR_HEADER
#define _LITERALVECTOR_HEADER

#include <vector>

#include "Base.h"

using namespace std;

//
// LiteralVector takes Literal as index
//
template<typename T>
class LiteralVector
{
private:
	vector<vector<T> > _data;

	// {+1, -1, +2, -2, ...}
	static inline unsigned int indexof(Literal literal)
	{
		return literal.toInt()-2;
	}

public:
	LiteralVector()
	{
	}

	void set_variable_size(int var_size)
	{
		_data.clear();
		_data.assign(var_size*2, vector<T>());
	}

	vector<T>& operator [](Literal lit)
	{
		return _data[indexof(lit)];
	}

	void clear()
	{
		for(typename vector<vector<T> >::iterator itr=_data.begin(); itr!=_data.end(); itr++){
			itr->clear();
		}
	}

	void deallocate(Literal literal)
	{
		vector<T> temp;
		_data[indexof(literal)].swap(temp);
	}

	void deallocate_all()
	{
		vector<vector<T> > temp;
		_data.swap(temp);
	}
};

#endif
