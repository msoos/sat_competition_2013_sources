#include <cassert>
#include <signal.h>

#include "ExitStatus.h"
#include "OptionParser.h"
#include "DimacsParser.h"
#include "Solver.h"
#include "System.h"

using namespace std;

const int VALUE_PER_LINE=10;

void signal_handler(int signum)
{
	cout<<"s UNKNOWN"<<endl;
	switch(signum){
	case SIGINT:
		cout<<"c Interrupted"<<endl;
		break;
	case SIGTERM:
		cout<<"c Terminated"<<endl;
		break;
	case SIGXCPU:
		cout<<"c Timeout"<<endl;
		break;
	case SIGSEGV:
		cout<<"c Segmentation fault"<<endl;
		break;
	default:
		break;
	}
	exit(EX_TIMEOUT);
}

void register_signal_handler()
{
	signal(SIGINT, signal_handler);
	signal(SIGTERM, signal_handler);
	signal(SIGXCPU, signal_handler);
	signal(SIGSEGV, signal_handler);
}

int main(int argc, char* argv[])
{
	assert(argc>=2);

	register_signal_handler();

	SolverConfig config;
	OptionParser option_parser;
	int index=option_parser.parse(argc, argv);
	option_parser.configure(config);
	const char* file=argv[index];

	DimacsParser parser;
	Solver solver(config);

#ifdef __GNUC__
	cout<<"c Compiled by GCC "<<__VERSION__<<endl;
#endif

	try{
		parser.parse_cnf(solver, file);
		solver.solve();
	}
	catch(OutOfMemoryException&){
		cout<<"s UNKNOWN"<<endl;
		cout<<"c Out Of Memory (OutOfMemoryException)"<<endl;
		exit(EX_OUT_OF_MEMORY);
	}
	catch(bad_alloc&){
		cout<<"s UNKNOWN"<<endl;
		cout<<"c Out Of Memory (bad_alloc)"<<endl;
		exit(EX_OUT_OF_MEMORY);
	}
	catch(...){
		cout<<"s UNKNOWN"<<endl;
		cout<<"c Unknown error"<<endl;
		exit(EX_OUT_OF_MEMORY);
	}

	exit(EX_SUCCESS);
}
