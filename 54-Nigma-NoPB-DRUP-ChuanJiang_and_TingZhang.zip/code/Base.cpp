#include <iostream>
#include <cassert>
#include <algorithm>

#include "Base.h"

using namespace std;

const Literal Literal::UNDEF;

ofstream& operator<<(ofstream& out, const Literal& literal)
{
	out<<(literal.phase()==P_POSITIVE ? "" : "-")<<literal.var();
	return out;
}

ostream& operator<<(ostream& out, const Literal& literal)
{
	out<<(literal.phase()==P_POSITIVE ? "" : "-")<<literal.var();
	return out;
}

Allocator<ClausePool::UnitType> ClausePool::_allocator;

ClausePool::ClausePool()
{
}

ClausePtr ClausePool::create(const vector<Literal>& literals, bool is_learnt)
{
	ClausePtr ptr=static_cast<ClausePtr>(_allocator.create(calculate_clause_size(literals.size())));
	new (&_allocator[ptr]) Clause(literals, is_learnt);
	return ptr;
}

void ClausePool::free(ClausePtr ptr)
{
	Clause& clause=get(ptr);
	if(!clause.is_deleted()){
		clause.set_deleted();
		_allocator.free(ptr, calculate_clause_size(clause.size()));
	}
}

//ClausePtr ClauseFactory::get_address(const Clause& clause)
//{
//	return reinterpret_cast<UnitType*>(const_cast<Clause*>(&clause))-&_allocator[0];
//}

void ClausePool::reallocate(vector<ClausePtr>& clauses, vector<ClausePtr>& learnt_clauses)
{
//	map<ClausePtr, ClausePtr> table;

	//va_list argp;
	//va_start(argp, num);

//	Allocator<UnitType> temp(_allocator.capacity()-_allocator.wasted());
//	//for(int i=0; i<num; i++){
//		//vector<ClausePtr>* old_clauses=va_arg(argp, vector<ClausePtr>*);
//		for(vector<ClausePtr>::iterator itr=clauses.begin(); itr!=clauses.end(); itr++){
//			Clause& clause=get(*itr);
//			ClausePtr new_clause_ptr=
//				static_cast<ClausePtr>(temp.allocate(reinterpret_cast<UnitType*>(&clause), calculate_clause_size(clause.size())));
//			table[*itr]=new_clause_ptr;
//			*itr=new_clause_ptr;
//		}
//
//		for(vector<ClausePtr>::iterator itr=learnt_clauses.begin(); itr!=learnt_clauses.end(); itr++){
//			Clause& clause=get(*itr);
//			ClausePtr new_clause_ptr=
//				static_cast<ClausePtr>(temp.allocate(reinterpret_cast<UnitType*>(&clause), calculate_clause_size(clause.size())));
//			table[*itr]=new_clause_ptr;
//			*itr=new_clause_ptr;
//		}
//	//}
//
//	//va_end(argp);
//	temp.move(_allocator);

	// Must guarantee that the clauses in vector are orderd by address ascending
	std::sort(learnt_clauses.begin(), learnt_clauses.end());

	_allocator.begin_shrinking();

	for(vector<ClausePtr>::iterator itr=clauses.begin(); itr!=clauses.end(); itr++){
		Clause& clause=get(*itr);
		ClausePtr new_clause_ptr=
				_allocator.shrink(*itr, calculate_clause_size(clause.size()));
		*itr=new_clause_ptr;
	}

	for(vector<ClausePtr>::iterator itr=learnt_clauses.begin(); itr!=learnt_clauses.end(); itr++){
		Clause& clause=get(*itr);
		ClausePtr new_clause_ptr=
				_allocator.shrink(*itr, calculate_clause_size(clause.size()));
		*itr=new_clause_ptr;
	}

	_allocator.end_shrinking();

//	return table;
}

double ClausePool::wasted_ratio()
{
	return (double)_allocator.wasted()/_allocator.size();
}

size_t ClausePool::memory_usage()
{
	return _allocator.capacity()*sizeof(UnitType);
}

void ClausePool::dump(ostream& out)
{
	_allocator.dump(out);
}
