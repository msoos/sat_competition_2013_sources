#ifndef _RESTARTSEQUENCE_HEADER
#define _RESTARTSEQUENCE_HEADER

#include <cmath>

class RestartSequence
{
private:
	int _mode;
	size_t _current;

	union {
		struct{
			size_t bound;
			double growth_factor;
		} normal;
		struct{
			size_t unit;
			size_t time;
		} luby;
		struct{
			size_t init_bound;
			size_t inner_bound;
			size_t outer_bound;
			double growth_factor;
		} nested;
	} _config;

	void next_normal()
	{
		_current=_config.normal.bound;
		_config.normal.bound*=_config.normal.growth_factor;
	}

	void next_luby()
	{
		size_t size=1;
		size_t seq=0;
		size_t time=_config.luby.time;

		while(size<time+1){
			seq++;
			size=size*2+1;
		}

		while(size-1!=time){
			size=(size-1)>>1;
			seq--;
			time%=size;
		}

		_config.luby.time++;

		_current+=_config.luby.unit*pow((double)2, seq);
	}

	void next_nested()
	{
		_config.nested.inner_bound*=_config.nested.growth_factor;

		if(_config.nested.inner_bound>_config.nested.outer_bound){
			_config.nested.outer_bound*=_config.nested.growth_factor;
			_config.nested.inner_bound=_config.nested.init_bound;
		}

		_current=_config.nested.inner_bound;
	}

public:
	static const int NORMAL=0;
	static const int LUBY=1;
	static const int NESTED=2;

	RestartSequence() : _mode(NORMAL), _current(0)
	{
		_config.normal.bound=100;
		_config.normal.growth_factor=1.1;
	}

	void init(int mode, int init_bound, double growth_factor=1.1, int outer_value=200)
	{
		_mode=mode;
		switch(_mode){
		case NORMAL:
			_config.normal.bound=init_bound;
			_config.normal.growth_factor=growth_factor;
			break;
		case LUBY:
			_config.luby.unit=init_bound;
			_config.luby.time=0;
			break;
		case NESTED:
			_config.nested.init_bound=init_bound;
			_config.nested.inner_bound=init_bound;
			_config.nested.growth_factor=growth_factor;
			_config.nested.outer_bound=outer_value;
			break;
		default:
			break;
		}
	}

	void next()
	{
		switch(_mode){
		case NORMAL:
			next_normal();
			break;
		case LUBY:
			next_luby();
			break;
		case NESTED:
			next_nested();
			break;
		default:
			break;
		}
	}

	size_t current()
	{
		return _current;
	}
};


#endif
