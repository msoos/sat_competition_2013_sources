#ifndef _SOLVERCONFIG_HEADER
#define _SOLVERCONFIG_HEADER

#include "RestartSequence.h"

typedef struct SolverConfig
{
	struct Preprocessing
	{
		int timeout;
	} preprocessing;

	struct PartialBacktracking
	{
		bool enabled;
		unsigned int ignore_distance;
	} partial_backtracking;

	struct BinaryClause
	{
		bool enabled;
	} binary_clause;

	struct Restart
	{
		int mode;
		int init_bound;
		double growth_factor;
		int outer_value;    // Used for nested restart
		bool reuse_trail;
	} restart;

	struct ClauseDeletion
	{
		double delete_factor;
		int first_learnt_upper_bound;
		double first_learnt_factor;
		double growth_factor;
	} clause_deletion;

	struct VarActivity
	{
		double upper_bound;
		double rescale_factor;
		double decay_factor;
	} var_activity;

	struct ClauseActivity
	{
		double upper_bound;
		double rescale_factor;
		double decay_factor;
	} clause_activity;

	struct GarbageCollect
	{
		double garbage_ratio;
	} garbage_collect;

	struct StatusOutput
	{
		bool enabled;
		int first_conflict_upper_bound;
		double conflict_growth_factor;
	} status_output;

	struct AssignmentOutput
	{
		bool enabled;
	} assignment_output;

	struct DRUPOutput
	{
		bool enabled;
		const char* dir;
	} drup_output;

	SolverConfig()
	{
		preprocessing.timeout=0;

		partial_backtracking.enabled=false;
		partial_backtracking.ignore_distance=10;

		binary_clause.enabled=true;

		restart.mode=RestartSequence::LUBY;
		restart.init_bound=100;
		restart.growth_factor=1.1;
		restart.outer_value=200;
		restart.reuse_trail=false;

		clause_deletion.delete_factor=0.5;
		clause_deletion.first_learnt_upper_bound=4000;
		clause_deletion.first_learnt_factor=-1.0/3;
		clause_deletion.growth_factor=1.5;

		var_activity.upper_bound=1e100;
		var_activity.rescale_factor=1e-100;
		var_activity.decay_factor=0.95;

		clause_activity.upper_bound=1e20;
		clause_activity.rescale_factor=1e-20;
		clause_activity.decay_factor=0.999;

		garbage_collect.garbage_ratio=0.2;

		status_output.enabled=false;
		status_output.first_conflict_upper_bound=100;
		status_output.conflict_growth_factor=2.5;

		assignment_output.enabled=false;

		drup_output.enabled=false;
		drup_output.dir="/tmp";
	}
}SolverConfig;

#endif
