#include <cstring>
#include <iomanip>
#include <cassert>

#include "OptionParser.h"

OptionParser::OptionParser()
	: _opt_preprocessing_timeout("preprocessing-timeout", "stop preprocessing if exceeding [TIMEOUT] seconds (but not immediately).", "TIMEOUT", 0),
	  _opt_partial_backtracking("partial-backtracking", "enable partial backtracking."),
	  _opt_reuse_trail("reuse-trail", "enable partial restart to ReusedTrail level."),
	  _opt_garbage_ratio("garbage-ratio", "trigger garbage collection if the garbage ratio is greater than [RATIO].", "RATIO", 0.2),
	  _opt_verbose("verbose", "display the status information."),
	  _opt_display_assignments_if_sat("display-assignments-if-sat", "display the assignments if the formula is satisfiable."),
	  _opt_output_drup_if_unsat("output-drup-if-unsat", "output the delete reverse unit propagation (DRUP) if the formula is unsatisfiable."),
	  _opt_output_drup_dir("output-drup-dir", "output the delete reverse unit propagation (DRUP) to the file [DIR]/DRUP.", "DIR", "/tmp"),
	  _opt_help("help", "display this help and exit.")
{
	_options.push_back(&_opt_preprocessing_timeout);
	_options.push_back(&_opt_partial_backtracking);
	_options.push_back(&_opt_reuse_trail);
	_options.push_back(&_opt_garbage_ratio);
	_options.push_back(&_opt_verbose);
	_options.push_back(&_opt_display_assignments_if_sat);
	_options.push_back(&_opt_output_drup_if_unsat);
	_options.push_back(&_opt_output_drup_dir);
	// Do not put opt_help in _options
	// _options.push_back(&_opt_help);
}

//
// Reorder the arguments and put the unlabeled arguments after the labeled ones.
// Return the index of the first unlabeled argument.
//
int OptionParser::parse(int argc, char** argv)
{
	size_t i=1, j=1;
	bool valid=false;
	vector<char*> unlabeled_arguments;

	while(i<argc){
		valid=false;
		if(argv[i][0]=='-' && argv[i][1]=='-'){
			// Option
			for(vector<Option*>::iterator itr=_options.begin(), end=_options.end(); itr!=end; itr++){
				Option& option=**itr;
				// --help
				if(std::strcmp(_opt_help.name(), &argv[i][2])==0){
					output_usage_and_exit(cout);
				}
				else if(std::strcmp(option.name(), &argv[i][2])==0){
					valid=true;
					if(option.has_argument()){
						argv[j++]=argv[i++];
						if(i>=argc){
							output_require_argument_and_exit(cout, argv[i-1]);
						}
					}
					option.parse(argv[i]);
					break;
				}
			}
			if(!valid){
				output_invalid_option_and_exit(cout, argv[i]);
			}
			argv[j++]=argv[i++];
		}
		else{
			// Unlabeled argument
			unlabeled_arguments.push_back(argv[i++]);
		}
	}

	assert(argc==j+unlabeled_arguments.size());

	int first_index=j;
	for(vector<char*>::iterator itr=unlabeled_arguments.begin(), end=unlabeled_arguments.end(); itr!=end; itr++){
		argv[j++]=*itr;
	}

	return first_index;
}


void OptionParser::output_usage_and_exit(ostream& out)
{
	out<<"Usage: nigma [OPTION] INSTANCE"<<endl;
	for(vector<Option*>::iterator itr=_options.begin(), end=_options.end(); itr!=end; itr++){
		Option& option=**itr;
		out<<"  --"<<option.name();
		if(option.has_argument()){
			out<<"=["<<option.argument_name()<<"]";
		}
		out<<"    "<<option.description()<<endl;
	}

	out<<"  --"<<_opt_help.name()<<"    "<<_opt_help.description()<<endl;

	exit(0);
}

void OptionParser::output_invalid_option_and_exit(ostream& out, const char* argv)
{
	out<<"Invalid option: '"<<argv<<"'"<<endl;
	out<<"Try '--help' for more information."<<endl;
	exit(0);
}

void OptionParser::output_require_argument_and_exit(ostream& out, const char* argv)
{
	out<<"Require argument: '"<<argv<<"'"<<endl;
	out<<"Try '--help' for more information."<<endl;
	exit(0);
}

void OptionParser::configure(SolverConfig& config)
{
	config.preprocessing.timeout=_opt_preprocessing_timeout.value();
	config.partial_backtracking.enabled=_opt_partial_backtracking.value();
	config.restart.reuse_trail=_opt_reuse_trail.value();
	config.garbage_collect.garbage_ratio=_opt_garbage_ratio.value();
	config.status_output.enabled=_opt_verbose.value();
	config.assignment_output.enabled=_opt_display_assignments_if_sat.value();
	config.drup_output.enabled=_opt_output_drup_if_unsat.value();
	config.drup_output.dir=_opt_output_drup_dir.value();
}
