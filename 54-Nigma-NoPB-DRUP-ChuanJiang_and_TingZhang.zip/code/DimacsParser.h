#ifndef _DIMACSPARSER_HEADER
#define _DIMACSPARSER_HEADER

#include "Solver.h"

class DimacsParser
{
private:
	static const int MAX_LINE_LENGTH=256*1024;
	static const int MAX_LITERAL_LENGTH=32;

public:
	void parse_cnf(Solver& solver, const char* file_name);
};

#endif
