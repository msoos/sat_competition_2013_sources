#ifndef _EXITSTATUS_HEADER
#define _EXITSTATUS_HEADER

#define EX_SUCCESS 0
#define EX_OUT_OF_MEMORY 1
#define EX_TIMEOUT 2

#endif
