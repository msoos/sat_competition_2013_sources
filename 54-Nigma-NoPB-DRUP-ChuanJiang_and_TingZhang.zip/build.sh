#!/bin/bash

DIRCODE="code"
DIRBINARY="binary"
EXEC="nigma"

# Check the binary directory
if [ -d "$DIRBINARY" ]; then
  rm -rf "$DIRBINARY/*"
else
  mkdir -p "$DIRBINARY"
fi

# Compile the code
cd "$DIRCODE"
make BITS=64

# Copy the executable file to the binary directory
cd ..
cp "$DIRCODE/Release/$EXEC" "$DIRBINARY"

