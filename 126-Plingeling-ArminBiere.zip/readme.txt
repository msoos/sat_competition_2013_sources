Plingeling SAT Solver Version aqw-27d9fd4-130429

To compile run either

  ./build.sh

or

  mkdir binary
  cd code
  ./configure && make
  cp plingeling ../binary

This software is copyright 2010-2013, Armin Biere, JKU, Linz.  

This is only a restricted release of this software.

See 'license.txt' for more details on the permission to use this software.

All rights are reserved.  No warranty is implied.

Armin Biere
