// Copyright (c) 2011, Jingchao Chen, Donghua University,China.  All rights reserved.

#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include "D_Constants.h"
#include "interactSAT.h"
#ifdef _MSC_VER
  #include "Solver.h"
  #include "glue_Solver.h"
#else
  #include "../crypto/Solver.h"
  #include "../glue_bit/glue_Solver.h"
#endif

void release_occCls(PPS *pps);
void free_mem(int * & ptr);
void release_free_pps (PPS * & pps);
void check(int sol[],Stack<int> *clause);

bool parity (unsigned x);

using namespace crypto;
Solver *crptSolver=0;
int crypt_nFreeVars();
extern Minisat :: vec<int> in_exMap1;
extern int *ex_inMap1;

int Load_cryptSolver(PPS *pps, int *solution,int maxRestart, int & DfreeVars)
{ 
    char name[10];
    name[0] = '\0';
    int group=0;
    
    crptSolver=new Solver();

    printf("c crypto solver \n");
    
    crptSolver->conf.verbosity=2;
   // crptSolver->conf.verbosity=0;
    if(ex_inMap1==0) ex_inMap1=(int *) calloc (pps->numVar+1, sizeof (int));
    vec<Lit> lits;
    crptSolver->conf.maxRestarts=maxRestart; 
//CNF clause   
    int *pcls=pps->clause->begin();
	int *pend=pps->clause->end();
   	while(pcls < pend){
         int len=*pcls;
	     int mark=len & MARKBIT;
		 len=len>>FLAGBIT;
		 int *litp=pcls+1;
                 pcls+=len;
		 if(mark==DELETED) continue;
		 if(mark==CNF_CLS){
			 lits.clear();
			 for (; litp<pcls; litp++){
		        int lit=*litp;
				int vv=ABS(lit);
				if(ex_inMap1[vv]==0){
        			   int Vn=crptSolver->newVar();
                        ex_inMap1[vv]=Vn+1;
                        in_exMap1.push(vv);
   				}
				vv=ex_inMap1[vv]-1;
                lits.push(lit>0 ? Lit(vv, false) : Lit(vv, true));
			 }
	         bool ret=crptSolver->addClause(lits, group++, name);
	         if(ret==false) return UNSAT; //close a clause
		 }
	}

    if(pps->clausePos){
	delete pps->clausePos;
	pps->clausePos=0;
    }

    crptSolver->setPartSolution(solution,in_exMap1);
    DfreeVars=crypt_nFreeVars();
    int ret=crptSolver->solve_();
    DfreeVars-=crypt_nFreeVars();
    if(ret==SAT){
		crptSolver->copysolution(solution,in_exMap1,true);
		//check(solution, pps->clause);
    }
	
	if(ret!=_UNKNOWN) {
		delete crptSolver;
		crptSolver=0;
	}
	else crptSolver->dumpPartSolution(solution,in_exMap1);
	return ret; //UNSAT;
}

int cryptsolve(int *solution, int crypt_restart_inc, int & DfreeVars)
{ 
	crptSolver->conf.maxRestarts+=crypt_restart_inc;
    crptSolver->setPartSolution(solution,in_exMap1);
    DfreeVars=crypt_nFreeVars();
	int ret=crptSolver->solve_();
    DfreeVars-=crypt_nFreeVars();
	if(ret==SAT) crptSolver->copysolution(solution,in_exMap1,true);
	if(ret!=_UNKNOWN){
		delete crptSolver;
		crptSolver=0;
	}
	else crptSolver->dumpPartSolution(solution,in_exMap1);
	return ret; //UNSAT;
} 

int crypt_nFreeVars()
{
    return crptSolver->order_heap.size();
}

void deleteCryptsolver()
{
	if(crptSolver) {
		crptSolver=0;
		delete crptSolver;
	}
}

int Load_bigSolver(char *CNFfile,int * & solution);
int MidSolver(char *CNFfile, int * & solution);

int load_cryptSAT(char *CNFfile, Solver* csolver,int * & solution)
{
    char name[10];
    name[0] = '\0';
    int group=0;
    bool ret;
    int i,lastc,nextc,lit;
   
    FILE *fp=fopen(CNFfile,"r");
    if(fp==NULL) {
	   printf("c Cann't open file %s \n", CNFfile);
	   exit(1);
    }
    while ((lastc = fgetc(fp)) == 'c'){
	    while ((nextc = fgetc(fp)) != EOF && nextc != '\n');
    }
    ungetc(lastc,fp);
	int numatom,numClauses;
    if (fscanf(fp,"p cnf %i %i",&numatom,&numClauses) != 2) {
	     printf("c Bad input file \n");
	     exit(1);
    }
	printf("c %d variable %d clauses \n", numatom, numClauses);

    vec<Lit> lits;
    for(i = 0;i < numClauses;i++){
    	lits.clear();
        do {
		   if (fscanf(fp,"%i ",&lit) != 1) {
		        printf("c wrong CNF proposition \n");
		        exit(0);
		   }
	       if(lit != 0) {
         		int vv=ABS(lit);
				if(vv>numatom){
                      printf("c ERROR - extraneous literals\n");
	                  exit(0);
				}
				while (vv > (int)csolver->nVars()) csolver->newVar();
  				vv--;
                lits.push(lit>0 ? Lit(vv, false) : Lit(vv, true));
  			}
	  	} while(lit != 0);
	    ret=csolver->addClause(lits, group++, name);
	    if(ret==false) return UNSAT;
  	}
 	fclose(fp);
  	return _UNKNOWN;
}	

int LoadInitCryptSolver(char *CNFfile,int * & solution)
{ 
    Solver *cSolver=new Solver();
   
	printf("c init crypt Solver \n");
    
	cSolver->conf.verbosity=2;
//	cSolver->conf.verbosity=0;

    int rc=load_cryptSAT(CNFfile, cSolver,solution);
	if(rc!=_UNKNOWN){
		 delete cSolver;
      	 return rc;
	}
    
    cSolver->conf.maxRestarts=0x7fffffff;
	cSolver->gluesolve=true;
	
	rc=cSolver->solve_();
	if(rc==SAT) {
	     solution=(int *) calloc (cSolver->nVars()+1, sizeof (int));
		 cSolver->copysolution(solution,in_exMap1,false);
	}
	delete cSolver;
	return rc;
}
