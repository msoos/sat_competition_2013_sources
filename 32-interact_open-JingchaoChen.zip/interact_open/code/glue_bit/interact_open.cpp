/***************************************************************************************
interact_open -- Copyright (c) 2013, Jingchao Chen  Donghua University, China   

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include "D_Constants.h"
#include <signal.h>
#include "interactSAT.h"
#include "MersenneTwister.h"
#include "glue_Vec.h"

void displaySAT(Stack<int> *clause);
int originClauses;
float *size_diff;
int EdgeMatch=0;
int EdgeMatch_Solver(PPS *pps);
int InteractSolver( PPS *pps);
extern int nXor;

using namespace Minisat;

MTRand mtrand(100);
extern int **Leq;    //  literals for each active XOR clause

void release_pps (PPS *pps);
void release_free_pps (PPS * & pps);
void getclausePos(PPS *pps);
void release_occCls(PPS *pps);
void free_mem(int * & ptr);
void extend_solution(PPS *pps);

void forwardsubsume(PPS *pps);
int BinarySimplify(PPS *pps,char *tabuVar);
int SimplifySAT(PPS *pps,char *tabuVar);

void verify_output(int *solution);
void init_weight();
void check(int sol[],Stack<int> *clause);
void readSATProblem(char *CNFfile, PPS * & pps, bool stopread);

int Load_glueSolver(PPS *pps);

void setDoubleDataIndex(PPS *pps, bool add_delcls);

void sortClause(Stack<int> * & clause, int numcolumn,int & numClauses, int numvar, int delrepeat);
void SetClausePtr(int **clauseP,int *ClauseStart,int cntClauses);

int UnitPropSimplify(PPS *pps,bool multi_probe);

/*
 * A signal handling function.
 * For handling user interuption (Ctrl+c).
 * Print out execution stats and exit.
 *
 */
void SIGINT_handler(int signum) 
{
  printf("c \n");
  printf("c \n");
  printf("c INTERRUPTED \n");
  printf("c Time used: %fs\n",get_cpu_time());
  exit(0); 
}

/*
 * A signal handling function. 
 * For handling segmentation fault.
 * 
 * Print out indicator message and exit.
 */
void SIGSEGV_handler(int signum) 
{
  printf("c \n");
  printf("c \n");
  printf("c SEGMENTATION FAULT \n");
  printf("c \ns UNKNOWN\n");
  printf("c \n");
  exit(0); 
}

//time measuring function
double nowtime() 
{
#ifdef _MSC_VER
#include <ctime>
    return (double)clock() / CLOCKS_PER_SEC;
#else
  struct rusage u;
  if (getrusage (RUSAGE_SELF, &u)) return 0;
  double res = u.ru_utime.tv_sec + 1e-6 * u.ru_utime.tv_usec;
  res += u.ru_stime.tv_sec + 1e-6 * u.ru_stime.tv_usec;
  return res;
#endif
}

char *FileName;
int load_SAT(char *CNFfile,int * &solution);
double starttime;
int iargc;
char *iargv[3];

int main(int  argc, char *argv[])
{
   signal(SIGINT,SIGINT_handler);
   signal(SIGSEGV,SIGSEGV_handler);
   srand(INIT_RANDOM_SEED);
   iargc=argc;
   iargv[0]=argv[0];
   iargv[1]=argv[1];
   if (argc<2) {
       printf("c Using format: interact_open CNF_file\n");
       exit(0);
//        FileName=filename;
   }
   else FileName=argv[1];
   printf("c interact_open by Jingchao Chen, March 2013\n");
   printf("c input CNF file=%s \n",FileName);

   mtrand.seed(10);
   init_weight();

   starttime=nowtime();
   int *solution;
  
   int result=load_SAT(FileName,solution);
   switch(result) 
   {    case SAT:
   	     verify_output(solution);
	     result=10;
	     exit(result);
        case UNSAT:
 	     printf("c \ns UNSATISFIABLE\n"); 
	     result=20;
            break;
	    default:
               printf("c \ns UNKNOWN\n");
	      result=0;
   }
   printf("c \nc Running time=%f \n", nowtime()-starttime);
   exit(result);
   return result;
}

int init_simplify();

void SetClausePtr(int **clauseP,int *newPointer,int cntClauses)
{   
    for(int i=1; i<=cntClauses; i++) clauseP[i]=newPointer+(clauseP[i]-clauseP[0]);
	clauseP[0]=newPointer;
}

/* 
 * Prints the current solution 
 */
void print_solution(int sol[],int numVar)
{   
    printf("v ");
   // if(numVar>100) numVar=100;
    //FILE *fp=fopen("solution.txt","w+t");
    for(int i=1; i<=numVar; i++) if(sol[i]) printf("%d ", sol[i]);
    //for(int i=1; i<=numVar; i++) if(sol[i]) fprintf(fp,"%d ", sol[i]);
    printf("\nv 0\n");
    printf("c \nc Running time=%f \n", nowtime()-starttime);
    //fprintf(fp," 0 \n");
    //fclose(fp);
}

void copyXORclause(Stack<int> * & xorClause, int numXOR)
{   
   int i;
   xorClause = new Stack<int>;
   for(i=1; i<=numXOR; i++){
	    int len =(Leq[i]-Leq[i-1])+1;
		len=(len<<FLAGBIT) | XOR_CLS;
   		xorClause->push(len);
		for (int * px=Leq[i-1]; px<Leq[i]; px++) xorClause->push(*px);
   }	
}

int deletegarbage(PPS *pps);
int getBinClsNum(PPS *pps,int * & binNum);
void checkSort(Stack<int> * & clausePos,Stack<int> *clause, int bi, int ei);
void deleteClause(Stack<int> * & clause, bool xorcmp);

int UnitProp(int lit, PPS *pps, vec<int> & Queue) 
{
    int *unit=pps->unit;
    Stack<int> * clause=pps->clause;
    Stack<int> *occCls=pps->occCls; 
	unit[ABS(lit)]=lit;
    Queue.clear();
	Queue.push(lit);
	int sp1,sp,lt,rc,i,j,ForcedLit;
	sp1=0; sp=1;
	while(sp1<sp){
	 	lt=Queue[sp1++];
		lt=-lt;
		int numocc = occCls[lt];
		for (i = 0; i < numocc; i++) {
			    int cpos=occCls[lt][i];
                int len=(*clause)[cpos];
		        int mark=len & MARKBIT;
                if(mark==DELETED) continue; //remove;
		   	    len=len>>FLAGBIT;
		 		int m=0;
    	 	    bool val=false;
				for (j=1; j<len; j++){
				        int curlit=(*clause)[cpos+j];
				        int var=ABS(curlit); 
						if(unit[var]==-curlit) continue;
						m++;
						if(unit[var]==curlit) val=true; 
				        else ForcedLit=curlit;
				}
				if(!val){
					if(m==0) {rc=UNSAT; goto ret;}; //conflict
			  	    if(m==1) {
			             unit[ABS(ForcedLit)]=ForcedLit;
						 Queue.push(ForcedLit);
						 sp++;
					}
				}
		}
	}
	rc=_UNKNOWN;
ret:
    for(i=0; i<sp; i++) unit[ABS(Queue[i])]=0;
	return rc;
}

int UnitPropSimplify(PPS *pps,bool multi_probe)
{
	int * binNum;
	vec<int> Queue1;
        vec<int> Queue2;
  	int *book=(int *)calloc(pps->numVar+1,sizeof(int));
        int n=0;
	int i,rc=_UNKNOWN;
        if(pps->numVar>200000) multi_probe=false;
loop:
	setDoubleDataIndex(pps,false);
	int Bn=getBinClsNum(pps,binNum);
        int change=0;
	if(Bn>pps->numVar/2 && Bn>20000) goto out_end; //new idea 12/12/2011
	for(i=1; i<=pps->numVar; i++){//&& i<400000
			if(pps->unit[i]) continue; 
			if(binNum[i]==0 || binNum[-i]==0) continue;

			rc=UnitProp(-i, pps, Queue1);
			if(rc==UNSAT){ pps->unit[i]=i;	change++; continue;}

		   	rc=UnitProp(i, pps, Queue2);
			if(rc==UNSAT) {
					for(int k=Queue1.size()-1; k>=0; k--){
						int lit=Queue1[k]; pps->unit[ABS(lit)]=lit; 
					}
					pps->unit[i]=-i;
					change++;
		    		continue;
			}
		
			int k;
			for(k=Queue1.size()-1; k>=0; k--){ int lit=Queue1[k]; book[ABS(lit)]=lit;}
			for(k=Queue2.size()-1; k>=0; k--){
				int lit=Queue2[k]; 
				if(book[ABS(lit)]==lit) {
					pps->unit[ABS(lit)]=lit;
					change++;
					//printf("???? unit[%d]=%d ", ABS(lit),lit);
				}
			}
			for(k=Queue1.size()-1; k>=0; k--) { book[ABS(Queue1[k])]=0;}
			if(change<1 && !multi_probe){
				if(Queue1.size()>40 && Queue2.size()>40) break; //maxor128
			}
	}
out_end:
	free(binNum-pps->numVar);
    if(change){
		rc=deletegarbage(pps);
        if(rc==UNSAT) {
			free(book);
			return UNSAT;
		}
		binNum=0;
		n++;
		if(multi_probe && ( n<5 || (pps->numVar>200000 && n<3)) ) goto loop;
	}
   	
        free(book);
	printf("c failed literal probe #=%d bin cls#=%d \n",n,Bn);
	return rc;
}

void verify_output(int *solution)
{    PPS *s_pps;
     readSATProblem(FileName,s_pps, false);
     for(int i=1; i<=s_pps->numVar; i++){ //bug cube-11-h14 2012/1/1
	    if(solution[i]==0) {
		// printf(" u[%d]=0 ",i);
                solution[i]=i;
	     }
     }
     check(solution,s_pps->clause);
     printf("c \ns SATISFIABLE\n");
     print_solution(solution,s_pps->numVar);
     release_pps (s_pps);
}

int MidSolver(char *CNFfile, int * & solution)
{ 
    int rc;

    PPS * pps; //=(struct PPS *) calloc (1, sizeof (PPS));
    readSATProblem(FileName, pps,false);
    printf("c Clause#=%d  var#=%d  ratio=%d \n",pps->numClause,pps->numVar,pps->numClause/pps->numVar);
  
    pps->unit=(int *)calloc(pps->numVar+1,sizeof(int));
    nXor=0;
//	pre_solution=(int *)calloc(pps->numVar+1,sizeof(int));
//	readsolution(pre_solution);
    if(EdgeMatch){
         rc=EdgeMatch_Solver(pps);
         if(rc==SAT) goto sat_end;
    } 
    EdgeMatch=0;

    if(pps->numVar<1000000){
	   rc=SimplifySAT(pps, (char *)0);
           if(rc==UNSAT) return UNSAT;
	   rc=UnitPropSimplify(pps,true);
           if(rc==UNSAT) return UNSAT;
           rc=InteractSolver(pps);
           if(rc!=_UNKNOWN) goto sat_end;
     }

     rc=Load_glueSolver(pps);
sat_end:
     if(rc==SAT){
            extend_solution(pps);
	    solution=pps->unit;
	    pps->unit=0;
	    release_pps(pps);
     }
     return rc;
}

void init_weight()
{
	int i, longest_clause = 100; 
	
	size_diff = (float *) malloc(sizeof(float) * longest_clause );
	size_diff[0]=size_diff[1] = 0.0;
	for( i = 2; i < longest_clause; i++ )  size_diff[ i ] = (float)pow(5.0, 2.0-i);
}

void readSATProblem(char *CNFfile, PPS * & pps, bool stopread)
{
    int i,lastc,nextc,lit,size1=0,size2=0;
    int cnt1=0,cnt2=0,bigCls=0;
    static int reRead=0;
    FILE *fp=fopen(CNFfile,"r");
    if(fp==NULL) {
	   printf("c Cann't open file %s \n", CNFfile);
	   exit(1);
    }
    while ((lastc = fgetc(fp)) == 'c'){
	    while ((nextc = fgetc(fp)) != EOF && nextc != '\n');
    }
    ungetc(lastc,fp);
	int numatom,numClauses;
    if (fscanf(fp,"p cnf %i %i",&numatom,&numClauses) != 2) {
	     printf("c Bad input file \n");
	     exit(1);
    }

    originClauses=numClauses;
	pps=(struct PPS *) calloc (1, sizeof (PPS));
	pps->numClause=numClauses;
	pps->numVar=numatom;
    
	if((numClauses>20000000 || pps->numVar>8000000) && stopread) {
          fclose(fp);
		  return;
	}
	pps->clause=new Stack<int>; 
        Stack<int> * clsSAT=pps->clause;
	for(i = 0;i < numClauses;i++){
	        int clsbegin=clsSAT->nowpos();
		clsSAT->push(0);
                do {
		   if (fscanf(fp,"%i ",&lit) != 1) {
		        printf("c wrong CNF proposition \n");
		        exit(0);
		   }
	           if(lit != 0) {
         		clsSAT->push(lit);
				if(ABS(lit)>numatom){
                      printf("c ERROR - incorrect problem format or extraneous characters\n");
	                  exit(0);
				}
			}

		} while(lit != 0);
                int len =clsSAT->nowpos()-clsbegin;
                (*clsSAT)[clsbegin]=(len<<FLAGBIT) | CNF_CLS;
                if(len<16) continue;
                if(reRead==0){
                       bigCls++;
                       if(size1==0)   { size1=len; cnt1++; continue;}
	               if(size1==len) { cnt1++; continue;}
                       if(size2==0)   { size2=len; cnt2++; continue;}
                       if(size2==len) { cnt2++; continue;}
                       reRead=1;
                }
	}
        EdgeMatch=0;
        if(size1-1==cnt1/2 && size2-1==cnt2/2 && reRead==0){
            if(numatom>5000 && numatom<50000 && numClauses>100000 && numClauses <1000000 && numClauses <30*numatom && bigCls<1000 && numatom){
               printf("c %d size1=%d, %d size2=%d  bigCls=%d \n",cnt1, size1, cnt2, size2, bigCls);
               EdgeMatch=1;
            }
        }
        reRead=1;
 	fclose(fp);
}	

void check(int sol[],Stack<int> *clause)
{
     int len,sum,i,vi;

	 int *pcls=clause->begin();
	 int *pend=clause->end();
	 i=0;
  
	 while(pcls < pend){
                 len=*pcls;
		// int mark=len & MARKBIT;
		 len=len>>FLAGBIT;
		 int *lits=pcls+1;
    	         pcls+=len;
                 sum=0; i++;
                 for (; lits<pcls; lits++){
		     vi=*lits;
       	             int xi= vi < 0 ? -vi : vi; 
                     if(sol) {
			   if(sol[xi]==vi) sum+=1;
		      }
		 }
//		 printf (" s=%d ",sum);
		 if(sum==0 && sol) {
        	      printf ("c result something wrong at i=%d !!!!! \n",i);
		      exit(0);
                      int *lits=pcls+1-len;
		      for (; lits<pcls; lits++){
		           vi=*lits;
       	                   int xi= vi < 0 ? -vi : vi; 
                           printf("%d[%d] ",vi,sol[xi]);
		       }
		       exit(0);
  	          }
   }
   printf("c verified \n");
 //  getchar();
}

