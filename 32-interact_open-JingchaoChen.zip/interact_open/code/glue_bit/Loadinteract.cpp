// Copyright (c) 2011, Jingchao Chen, Donghua University,China.  All rights reserved.

#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include "D_Constants.h"
#include "interactSAT.h"

#ifdef _MSC_VER
#include "glue_Constants.h"
#include "glue_Solver.h"
#else
#include "glue_Constants.h"
#include "glue_Solver.h"
#endif

void release_occCls(PPS *pps);
void free_mem(int * & ptr);
void release_free_pps (PPS * & pps);


extern double starttime;
double nowtime();
using namespace Minisat;

void extend_unit_solution(Solver * solver);
int Load_lglSolver(PPS *pps, int & deltaFreeV, int conf_limit);
int lgl_cont_Solver(PPS *pps, int & DfreeVars, int conf_limit);
void delete_lgl_solver();
int MidSolver(char *CNFfile, int * & solution);

int Load_cryptSolver(PPS *pps, int *solution,int maxRestart,int &DfreeVars);
void deleteCryptsolver();
int cryptsolve(int *solution, int crypt_restart_inc, int & DfreeVars);
 
int lgl_freeVars();
int numatom,numClauses;
int lgl_load=0;
	
bool parity (unsigned x);
//{ bool res = false; while (x) res = !res, x &= x-1; 
//    return res; 
//}

vec<int> in_exMap1;
int *ex_inMap1=0;
int load_glueclause_Map(Solver* solver, PPS *pps,PPS *new_pps,vec<int> & in_exMap, int * & ex_inMap)
{   int i;
	bool ret;
    vec<Lit> lits;
	int binclauses=0;
	int FreeVarNo=in_exMap1.size();
	int Vn=1+FreeVarNo;
//CNF clause   
   	 int *pcls=pps->clause->begin();
	 int *pend=pps->clause->end();
	 i=0;
	 while (FreeVarNo > solver->nVars()) solver->newVar();

   	 while(pcls < pend){
         int len=*pcls;
	     int mark=len & MARKBIT;
		 len=len>>FLAGBIT;
		 int *litp=pcls+1;
         pcls+=len;
		 if(mark==DELETED) continue;
		 if(mark==CNF_CLS){
			 lits.clear();
			// int disp=0;
			// if(pcls-litp<3) {disp=1;printf("\n%d: ", i++);}
			 if(pcls-litp==2) binclauses++;
			 for (; litp<pcls; litp++){
		        int lit=*litp;
			//	if(disp) printf("%d ",lit);
			    int vv=ABS(lit);
				if(ex_inMap[vv]==0){
        			   while (Vn > solver->nVars()) solver->newVar();
                       ex_inMap[vv]=Vn++;
                       in_exMap.push(vv);
				}
				vv=ex_inMap[vv]-1;
        		lits.push( (lit > 0) ? mkLit(vv) : ~mkLit(vv));	
			 }
			 ret=solver->addClause(lits); //close a clause
			 if(ret==false) return UNSAT;
		 }
	 }
	 free_mem(pps->seen);
	 release_occCls(pps);
	 new_pps->numVar=Vn-1;
     solver->binclauses=binclauses;
	 return _UNKNOWN;
}

int final_solution(Solver * & solver, lbool ret, int * solution,vec<int> & in_exMap);

int Load_glueSolver(PPS *pps, int SolvePolicy, Solver * & solver)
{ 
    solver=new Solver();
    solver->verbosity = 2;
    solver->SolvePolicy=SolvePolicy;

    PPS * new_pps=(struct PPS *) calloc (1, sizeof (PPS));
    solver->g_pps=new_pps;
    
    int rc=load_glueclause_Map(solver, pps,new_pps, in_exMap1,ex_inMap1);
    if(rc==UNSAT) return final_solution(solver, l_False, (int *)0,in_exMap1);
    solver->assumptions.clear();
    return _UNKNOWN;
}


bool set_solver_solution(Solver * solver, int * solution,vec<int> & in_exMap);
void get_solver_solution(Solver * solver, int * solution, vec<int> & in_exMap);

int InteractSolver( PPS *pps)
{
    printf("c interactive solving cls#=%d var#=%d \n", pps->numClause, pps->numVar);
    int i;
    bool ret;
    int kk,rc,nF0;	
    int conf_limit;
    int dsum,lglconf_limit,max;
    int crypt_restart_inc;

    lbool res;
    Solver * solver[3];
    int DfreeVars[6],maxave=100000;

    solver[0]=solver[1]=solver[2]=0;
    if(numClauses>4000000 && numClauses>28*pps->numVar){//11pipe_k.cnf
           lglconf_limit=0x7fffffff;
           goto lgl_solve;
    }

    crypt_restart_inc=20;
    rc=Load_cryptSolver(pps, pps->unit,crypt_restart_inc,DfreeVars[4]);

    deleteCryptsolver();
    if(rc!=_UNKNOWN) goto solvend;

    if(ex_inMap1==0) ex_inMap1=(int *) calloc (pps->numVar+1, sizeof (int));

    dsum=0;
    for(i=0; i<3; i++){
         rc=Load_glueSolver(pps, i, solver[i]);
         if(rc==UNSAT) goto solvend;
	    
         solver[i]->con_limit=3000;
	 solver[i]->restartLimit=10;
   	     
	 ret=set_solver_solution(solver[i], pps->unit,in_exMap1);
         if (!ret) {rc=UNSAT; goto solvend;}
     	    
	 DfreeVars[i]=solver[i]->nFreeVars();
      	 res=solver[i]->solve_();
	 DfreeVars[i]-=solver[i]->nFreeVars();
      	 dsum+=DfreeVars[i];
	 if(res!=l_Undef) {
		 if(res==l_True) extend_unit_solution(solver[i]);
		 rc=final_solution(solver[i], res, pps->unit,in_exMap1);
                 goto solvend;   
	 }
	 get_solver_solution(solver[i], pps->unit,in_exMap1);
	 maxave=solver[0]->maxave;
    }
     lglconf_limit=100000;lgl_solve:  	
    rc=Load_lglSolver(pps, DfreeVars[3],lglconf_limit);
    lgl_load=1;
  //  if(rc!=_UNKNOWN) goto solvend;
solvend:
    for(i=0; i<3; i++){
	   if(solver[i]){
		    release_free_pps(solver[i]->g_pps);
		    delete solver[i];
	   }
    }
    if(ex_inMap1) free(ex_inMap1);
    if( lgl_load){
	delete_lgl_solver();
    }
    return rc;
}

//------------------------------------------------------------------

Solver *G_solver;
vec<int> in_exMap2;
int *ex_inMap2=0;
void new_glueSolver(int exVars)
{
	   G_solver=new Solver();
	   G_solver->binclauses=0;
       in_exMap2.clear();
       ex_inMap2=(int *) calloc (exVars+1, sizeof (int));
}

bool glue_addclause (Stack<int> & lits, int num)
{
	vec<Lit> glits;
	if(num==2) G_solver->binclauses++;
	
    int i=0;
	for(i=0; i<num; i++) {
        int lit=lits[i]; 
		int vv=ABS(lit);
		if(ex_inMap2[vv]==0){
        		 int Vn=G_solver->newVar();
                 ex_inMap2[vv]=Vn+1;
                 in_exMap2.push(vv);
		}
		vv=ex_inMap2[vv]-1;
       	glits.push( (lit > 0) ? mkLit(vv) : ~mkLit(vv));	
	}
	bool ret=G_solver->addClause(glits);
	return ret;
}

bool glue_addxorclause (Stack<int> & lits, int xorlen, int & exVar)
{
 	int xbuf[10];
	int size;

	Stack<int> sub_lits;
	for(int pos=0; pos<xorlen; pos+=size){
	     if(xorlen<=4) size=xorlen;
		 else{
			 if(pos+3>=xorlen) size=xorlen-pos;
			 else size=2;
		 }
		 int xs;
		 for(xs=0;xs<size; xs++) xbuf[xs]=lits[pos+xs];
		 if(pos)  xbuf[xs++]=exVar++;
		 if(size!=xorlen-pos) xbuf[xs++]=-exVar;
		 unsigned pow2=1<<xs;
      	 unsigned int j;
		 for(j=0; j<pow2; j++){ // XOR -> CNF
		   	   if(parity(j)) continue;
           	   unsigned bits=j;
		       sub_lits.shrink(0);
       		   for(int k=0; k<xs; k++) {
				     int lit=xbuf[k];
					 if(bits & 1) lit=-lit;
	                 sub_lits.push(lit);
					 bits=bits>>1;
        	   }
		       bool ret=glue_addclause(sub_lits, xs);
			   if(!ret) return false;
		 }
	}
	return true;
}

int glue_solve(int exVars,int * & solution)
{
	G_solver->verbosity = 1;
    G_solver->random_var_freq=0; 
    G_solver->SolvePolicy=4;
    PPS * new_pps=(struct PPS *) calloc (1, sizeof (PPS));
	new_pps->numVar=G_solver->nVars();
    G_solver->g_pps=new_pps;
   
//	printf("c glue solve... Var#=%d dec_vars=%d \n",G_solver->nVars(),(int)G_solver->dec_vars);

   	vec<Lit> dummy;
	lbool ret = G_solver->solveLimited(dummy);
    
	solution=(int *) calloc (exVars+1, sizeof (int));
	return final_solution(G_solver, ret, solution,in_exMap2);
}

