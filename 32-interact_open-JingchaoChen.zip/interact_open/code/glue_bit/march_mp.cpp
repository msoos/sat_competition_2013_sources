/* MARCH Satisfiability Solver

   Copyright (C) 2001-2009 M.J.H. Heule, J.E. van Zwieten, and M. Dufour.
   [marijn@heule.nl, jevanzwieten@gmail.com, mark.dufour@gmail.com]

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#include <stdlib.h>
#include <math.h>
#include <time.h>

#include "march.h"
#include "march_common.h"
#include "march_equivalence.h"
#include "march_lookahead.h"
#include "march_load.h"
#include "march_preselect.h"
#include "march_resolvent.h"
#include "march_solver.h"
#include "march_memory.h"
#include "march_var.h"

/*
void handleUNSAT()
{
	printf( "c main():: nodeCount: %i\n", nodeCount );
	printf( "c main():: time=%f\n", ((float)(clock()))/CLOCKS_PER_SEC );
#ifdef SATTEST
	flup = fopen("results.py","w");
	fprintf(flup,"nodes=%d\n",nodeCount);
	fprintf(flup,"lookaheads=%d\n", lookAheadCount);
	fprintf(flup,"time=%f\n", ((double)(clock()))/((double)(CLOCKS_PER_SEC)) );
	fclose(flup);
#endif
       	printf( "s UNSATISFIABLE\n" );
	
	disposeFormula();

	exit( EXIT_CODE_UNSAT);
}
*/

void getSolution( const int orignrofvars, int * & solution )
{
	int i;
	solution=(int *) calloc (orignrofvars+1, sizeof (int));
	for( i = 1; i <= orignrofvars; i++ ){
		if(timeAssignments[ i ] ==  VARMAX) solution[i]=i;
		else if( timeAssignments[ i ] == (VARMAX + 1) ) solution[i]=-i;
	}
}

//extern int local_find_tries, local_find_steps; 
//extern bool localfind;
//void  getlocalsolution(int *solution);
//int Local_search(int &tries,int & steps);
		
//0: unkown, 1:SAT, -1: UNSAT
int mix_march_solve(int * & Solution)
{
	int result,exitcode;
	result   = UNKNOWN;
	int unsatcode=-1;
	int satcode=1;
    int unkown=0;
 
	printf( "c switch to march \n");

   	initFormula();
	init_equivalence();

	if( simplify_formula() == UNSAT )
	{
		disposeFormula();
		return unsatcode;
	}
   // printf( "c preprocessing phase I completed:: there are now %i free variables and %i clauses.\n", freevars, nrofclauses );
	if( equivalence_reasoning() == UNSAT )	return unsatcode; //handleUNSAT();

    for(int i = 0; i < nrofclauses; i++ )
            if( Clength[ i ] > 3 )    { kSAT_flag = 1; break; }

	if( kSAT_flag )	printf("c using k-SAT heuristics (size based diff)\n");
	else		printf("c using 3-SAT heuristics (occurence based diff)\n");

#ifndef TERNARYLOOK
	if( resolvent_look() == UNSAT ) return unsatcode; //handleUNSAT();
#endif
     if( kSAT_flag )  allocate_big_clauses_datastructures();

	//TransformFormula();
    //printf( "c clause / variable ratio: ( %i / %i ) = %.2f\n", nrofclauses, nrofvars, (double) nrofclauses / nrofvars );

	depth                 = 0;   
    nodeCount             = 0;
    lookAheadCount        = 0;
    unitResolveCount      = 0;
	necessary_assignments = 0;

	if( initSolver() )
	{
#ifdef PROGRESS_BAR
		pb_init( 6 );
#endif
		result = distribution_branching();
	}
	else
	{
	//	printf( "c main():: conflict caused by unary equivalence clause found.\n" );
		result = UNSAT;
	}
	switch( result )
	{
	    case SAT:
			getSolution(original_nrofvars, Solution);
		    exitcode = satcode;
		    break;
	    case UNSAT: exitcode = unsatcode; break;
	    default: return unkown; 
    }
	disposeSolver();
	disposeFormula();
    return exitcode;
}

int march_do_solve();
int march_next_solve(int * & Solution)
{
	int unsatcode=-1,satcode=1,unkown=0;
   	int result,exitcode;
       result=march_do_solve();
	switch( result )
	{
	    case SAT:
		   getSolution(original_nrofvars, Solution);
		   exitcode = satcode;
		   break;
	    case UNSAT: exitcode = unsatcode; break;
	    default: exitcode=unkown; break; 
    }
    disposeSolver();
    disposeFormula();
    return exitcode;
}

