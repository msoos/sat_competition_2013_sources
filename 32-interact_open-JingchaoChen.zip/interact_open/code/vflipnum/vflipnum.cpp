#include "s_ubcsat.h"

int eCutoff=10000000;
int eSeed=123;

#ifdef __cplusplus 
namespace ubcsat {
#endif

extern BOOL bHaveWarnedUnitClause;

int VFNsatmain(int argc, char *argv[]) {
  
  InitSeed();
  SetupUBCSAT();

  AddAlgorithms();
  AddParameters();
  AddReports();
  AddDataTriggers();
  AddReportTriggers();
  AddLocal();

  ParseAllParameters(argc,argv);
 // printf("\n D: iCutoff=%I64u iNumRuns=%d \n",iCutoff,iNumRuns);
//  printf("\n B2:aN=%d sFilenameIn=%s \n",aNumActiveProcedures[ChooseCandidate],sFilenameIn);
  
  ActivateAlgorithmTriggers();
  ActivateReportTriggers();
 
  iSeed=eSeed;
  
  RunProcedures(PostParameters);
  RunProcedures(ReadInInstance);
  RunProcedures(PostRead);
  

  printf("c iSeed=%u \n", iSeed);
  RandomSeed(iSeed);

  RunProcedures(CreateData);
  RunProcedures(CreateStateInfo);
 
  iRun = 0;
  iNumSolutionsFound = 0;
  bTerminateAllRuns = 0;

  RunProcedures(PreStart);

  StartTotalClock();
  printf("c eCutoff=%d iNumRuns=%d \n",eCutoff,iNumRuns);
  if(bHaveWarnedUnitClause){
        if(eSeed < 130){ 
           eCutoff=3000000;
           printf("c nonlocal eCutoff=%d \n",eCutoff);
        }
  }

  while ((iRun < iNumRuns) && (! bTerminateAllRuns)) {
    iRun++;
    iStep = 0;
    bSolutionFound = 0;
    bTerminateRun = 0;
    bRestart = 1;
    RunProcedures(PreRun);
    StartRunClock();
   // while ((iStep < iCutoff) && (! bSolutionFound) && (! bTerminateRun)) {
     while ((iStep < (unsigned) eCutoff) && (! bSolutionFound) && (! bTerminateRun)) {
      iStep++;
      iFlipCandidate = 0;
      RunProcedures(PreStep);
      RunProcedures(CheckRestart);
      if (bRestart) {
        RunProcedures(PreInit);
        RunProcedures(InitData);
        RunProcedures(InitStateInfo);
        RunProcedures(PostInit);
        bRestart = 0;
      } 
	  else {
		RunProcedures(ChooseCandidate);
        //if(m==0) {RunProcedures(ChooseCandidate);}
        //else {RunProcedures3(ChooseCandidate);}
		RunProcedures(PreFlip);//
        RunProcedures(FlipCandidate);
        RunProcedures(UpdateStateInfo);
        RunProcedures(PostFlip); //
      }
		  
      RunProcedures(PostStep);
      RunProcedures(StepCalculations);
      RunProcedures(CheckTerminate);
    }

    StopRunClock();
    RunProcedures(RunCalculations);
    RunProcedures(PostRun);
    if (bSolutionFound) {
      iNumSolutionsFound++;
      if (iNumSolutionsFound == iFind) {
        bTerminateAllRuns = 1;
	  }
	}
}
  StopTotalClock();
  RunProcedures(FinalCalculations);
  RunProcedures(FinalReports);
  CleanExit();
  return(0);
  
}

char randomseed[20]="123"; 

char *myargv[100];
int myargc;

void init_aTriggers();

//int sparrowmain(int argc, char *argv[]) {
int VFNmain(char *Filename) {

  init_aTriggers();
  myargc = 0;
  //myargv[myargc++] = argv[0];
  myargv[myargc++] = (char *)"3";

  myargv[myargc++] =(char *)"-i";
 // myargv[myargc++] = argv[1];
  myargv[myargc++] = Filename;

  myargv[myargc++] =(char *) "-seed";
 // myargv[myargc++] = argv[2];
  myargv[myargc++] = randomseed;

  myargv[myargc++] =(char *) "-q";

  myargv[myargc++] =(char *) "-r";
  myargv[myargc++] =(char *) "satcomp";

  myargv[myargc++] =(char *) "-cutoff";
  myargv[myargc++] =(char *) "max";

  myargv[myargc++] =(char *) "-alg";
  myargv[myargc++] =(char *) "vflipnum";//"sparrow";
  myargv[myargc++] =(char *) "-v";
  myargv[myargc++] =(char *) "sat13";
  return(VFNsatmain(myargc,myargv));
}

#ifdef __cplusplus
}
#endif


