#ifndef CLAUSEOFFSET_H
#define CLAUSEOFFSET_H

#ifdef _MSC_VER
#include "stdint.h"
#else
#include <stdint.h>
#endif //_MSC_VER

typedef uint32_t ClauseOffset;

#endif //CLAUSEOFFSET_H
