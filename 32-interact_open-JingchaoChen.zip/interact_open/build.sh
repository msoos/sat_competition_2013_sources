#!/bin/bash

mkdir -p binary
cd code
./configure.sh

cd build/release
make 
cp bin/interact_open ../../../binary 
