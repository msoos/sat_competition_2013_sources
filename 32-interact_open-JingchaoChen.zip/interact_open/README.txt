interact_open 1.0 - An interaction solver with clasp, glue_bit, march_rw,vflipnum, Lingeling 587 and CryptoMiniSat  
---------------------------------------
interact_open is distributed under the GNU Public License, see file LICENSE.txt for details.
It is written in (mostly) Standard-C++ and was successfully built and run under 
Linux (x86-32, x86-64) using gcc.

Detailed information (including a User's manual) can be found at: 
  http://potassco.sourceforge.net/

Distribution contents:
  LICENSE.txt  - GNU Public License
  README.txt   - This file
  configure.sh - Simple script that creates Makefiles for building interact_open (library and application) 
  app/         - Source code directory of the command-line interface
  libclasp/    - Directory of the clasp (static) library (sources, documentation, unit tests)
  libprogram_opts/
               - Library for parsing command-line options (needed by app)
  glue_bit     - Source code directory of glue_bit, march_rw
  vflipnum     - Source code directory of vflipnum
  lgl          - Source code directory of Lingeling 587
  crypto       - Source code directory of CryptoMiniSat
  tools/       - Some additional files

------------------------- 
For compiling : 
   ./build.sh


For running
binary/interact_open BENCHNAME

------------------------------------------------ 
  
Make-based Build & Install
--------------------------
You'll need to have the GNU Compiler Collection (GCC) version 3 or
better installed in order to build interact_open. You'll also need GNU 
make 3.80 or better.
Note: 
 In the following it is assumed that 'make' is an alias for the installed GNU make. If this
 is not the case on your system, replace 'make' with the name of the GNU make  executable (e.g. gmake)

To configure the build:
  The configure-script supports different build configurations/options.
  Type 
    ./configure.sh --help 
  to get an overview of all supported options.
  
To build interact_open:
  ./configure.sh
  cd build/release
  make
  
To install interact_open:
  make install
	
  By default, 'make install' will install interact_open in '/usr/local/bin'
  You can specify an installation prefix other than '/usr/local' 
  by running the configure-script with the option '--prefix=PATH'.
  Alternatively, use option '--bindir=PATH' to directly specify the
  installation path. 

  Finally, you can always skip installation and simply copy the
  interact_open executable to a directory of your choice.
		
Usage
-----
	interact_open reads problem instances either from stdin, e.g 
	  cat problem | interact_open
	or from a given file, e.g
	  interact_open problem
	
	In addition to printing status information, interact_open also
	provides information about the computation via its exit status.
	The exit status is:
	  10: if the problem was found to be satisfiable
	  20: if the problem was proved to be unsatisfiable
	   0: if the satisfiability of problem is not known, 
	      because search was either interrupted or not started
	 127: if interact_open(clasp) ran out of memory
	Furthermore, the exit status of 1 indicates an error.


