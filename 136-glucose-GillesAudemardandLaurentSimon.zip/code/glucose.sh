#!/bin/csh

set bench = $argv[1]
set output = $TEMPDIR/$$.out

./glucose $bench $output

echo o proof DRUP
cat $output
rm $output
