Lingeling SAT Solver Version aqw-drup-10f7e20-130503

To compile run either

  ./build.sh

or

  mkdir binary
  cd code
  ./configure && make
  cp lingeling ../binary

This software is copyright 2010-2013, Armin Biere, JKU, Linz.  

This is only a restricted release of this software.

See 'license.txt' for more details on the permission to use this software.

All rights are reserved.  No warranty is implied.

Armin Biere
