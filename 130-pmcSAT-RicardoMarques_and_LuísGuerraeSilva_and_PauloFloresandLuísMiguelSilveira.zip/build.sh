#!/bin/bash

mkdir -p binary

cd code/pmcsat/core/
make rs
cp pmcsat_static ../../../binary
 
