pmcSAT - Author: Ricardo de Sousa Marques

For compiling: 
   ./build.sh

Usage:
./binary/pmcsat_static INPUT_FILE.cnf