/*****************************************************************************************[pmcsat.h]
Copyright (c) 2012-2013, Ricardo de Sousa Marques

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/

#include "../mtl/Sort.h"
#define EXPORTED_LIMIT 10000
#define CLAUSE_LIMIT 8

using namespace Minisat;

extern int nProcs;
static long reduceCount = 1;

vec<Lit> **learntClauses;
vec<Lit>  *learntUnits;

int** lastReadC;
int*  lastWriteC;

int** lastReadU;
int*  lastWriteU;

void Solver::atributePriorities(){
  
    if (tid > 3){
      vec<VarOccs> vrOccs;
      
      // Priority given according to the number of literal occurences (Threads 5 and 6)
      if (tid < 6){
        for (int i=0; i<nVars(); i++){        
          vrOccs.push(VarOccs(i, 0));
        }
        for (int i=0; i<nClauses(); i++){
          Clause &c = ca[clauses[i]];
          for (int j=0; j<c.size(); j++){
            vrOccs[var(c[j])].occs++;
          }
        }
      }
      
      // Priority given according to the number of common vars with a certain variable (Thread 7)
      else{
        vec<int> *commonVars;
        commonVars = new vec<int> [nVars()];

        for (int i=0; i<nClauses(); i++){
          Clause &c = ca[clauses[i]];
          for (int j=0; j<c.size(); j++){
            int v = var(c[j]);
            for (int k=j+1; k<c.size(); k++){
                commonVars[v].push(var(c[k]));
                commonVars[var(c[k])].push(v);
            }
          }
        }

        vrOccs.growTo(nVars());
        for (int i=0; i<nVars(); i++){
          sort(commonVars[i]);
          vrOccs[i].var = i;
          if (commonVars[i].size() < 2) vrOccs[i].occs = commonVars[i].size();
          else{
            int curr_var = -1;
            for (int j=0; j<commonVars[i].size(); j++){
              if (commonVars[i][j] != curr_var){
                curr_var = commonVars[i][j];
                vrOccs[i].occs++;
              }
            }  
          }
        }

        sort(vrOccs);
        int i=0;
        while(i < vrOccs.size()){
          int ind = vrOccs.nextdiff(i);
          int sz  = ind-i;
          for (int j=i; j<ind; j++) vrOccs[j].occs = sz;
          i = ind;
        }
        
        delete [] commonVars;
      }
      
      // Sorting of the occurences array
      sort(vrOccs);  
      
      // Decreasing priority
      if (tid == 4){
        int priority = 0;
        float min_occs = vrOccs[0].occs;
        for (int i=0; i<vrOccs.size(); i++){
          if (vrOccs[i].occs != min_occs){
            priority++, min_occs = vrOccs[i].occs;
          }
          setVarOrdering(vrOccs[i].var, priority);
        }
      }
      
      // Increasing priority
      else{
        int priority = 0;
        float max_occs = vrOccs.last().occs;
        for (int i=vrOccs.size()-1; i>=0; i--){
          if (vrOccs[i].occs != max_occs) priority++, max_occs = vrOccs[i].occs;
          setVarOrdering(vrOccs[i].var, priority);
        }
      }
    }

    else{
      for (int i=0; i<nVars(); i++){
          if (tid == 1) setVarOrdering(i, i*2/nVars());
          else if (tid == 2) setVarOrdering(i, 1-i*2/nVars());
          else if (tid == 3) setVarOrdering(i, i);
      }
    }
    rebuildOrderHeap();    
}

void Solver::initStructures(){
  
  learntClauses = new vec<Lit> *[nProcs];
  learntUnits   = new vec<Lit>  [nProcs];
  lastReadC     = new int*      [nProcs];
  lastReadU     = new int*      [nProcs];
  lastWriteC    = new int       [nProcs];
  lastWriteU    = new int       [nProcs];
      
  for(int i = 0; i < nProcs; i++){

    learntClauses[i] = new vec<Lit> [EXPORTED_LIMIT];
    lastReadC    [i] = new int      [nProcs];
    lastReadU    [i] = new int      [nProcs];
    
    for(int j = 0; j < nProcs; j++){
      
      lastReadC    [i][j] = 0;
      lastReadU    [i][j] = 0;
      lastWriteC      [j] = 0;
      lastWriteU      [j] = 0;
    }
    
    learntUnits[i].capacity(nVars());
  }
}

void Solver::propagateUnitLits(){

  for(int i = 0; i < unitLits.size(); i++){

    if(value(unitLits[i]) == l_Undef){
      uncheckedEnqueue(unitLits[i]);
    }
  }

  unitIndex = trail.size();
  unitLits.clear();
  
}


void Solver::exportLearntUnits(void){
  
  assert(decisionLevel() == 0);
  
  for (int i=unitIndex; i<trail.size(); i++){
    learntUnits[tid].push(trail[i]);
  }
  
  lastWriteU[tid] = learntUnits[tid].size();
  unitIndex       = trail.size();
          
}

void Solver::exportLearntClause(vec<Lit>& learnt){
 
  if (decisionLevel() == 0) {
    exportLearntUnits();
  }
    
  else if (learnt.size() < CLAUSE_LIMIT){
    
    learnt.copyTo(learntClauses[tid][lastWriteC[tid]]);
    lastWriteC[tid] = lastWriteC[tid] == (EXPORTED_LIMIT - 1) ? 0 : lastWriteC[tid]+1;
    
  }
}

void Solver::importLearntUnits(void){
    
  for (int i=0; i<nProcs; i++){
    
    if (i == tid) continue;
    
    int lastWrite = lastWriteU[i];
     
    for (int j=lastReadU[i][tid]; j<lastWrite; j++){      
      unitLits.push(learntUnits[i][j]);
    }
    
    lastReadU[i][tid] = lastWrite;
    
  }
}

void Solver::importLearntClauses(void){
  
  for(int i = 0; i < nProcs; i++){
    
    if(i == tid) continue;
    
    int first = lastReadC[i][tid];
    int last  = lastWriteC[i];
    
    if(first == last) continue;
    
    int end = last < first ? EXPORTED_LIMIT : last; 
    
    for(int j = first; j < end; j++) pushImportedClause(learntClauses[i][j]);
    
    if (last < first) for(int j = 0; j < last; j++) pushImportedClause(learntClauses[i][j]);

    lastReadC[i][tid] = (last == EXPORTED_LIMIT) ? 0 : last;
  }
}    

void Solver::pushImportedClause(vec<Lit>& lt){
  
  CRef cr = ca.alloc(lt, true);

  learnts.push(cr);
  attachClause(cr);
  claBumpActivity(ca[cr]);

}

void Solver::deleteStructures(){
  
  for (int i=0; i<nProcs; i++){
    delete [] lastReadC[i];
    delete [] lastReadU[i];
    delete [] learntClauses[i];
  }
  
  delete [] lastReadC;
  delete [] lastReadU;
  delete [] lastWriteC;
  delete [] lastWriteU;
  delete [] learntClauses;
  delete [] learntUnits;
  
}


void Solver::printClause(Clause &c){
  
  printf("Clause Size: %d: ", c.size());
  
    for (int j = 0; j < c.size(); j++)
        printf("%s%d ", sign(c[j]) ? "-" : "", var(c[j]));
    printf("\n");
}
