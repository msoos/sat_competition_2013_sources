
/***********************
 * gNovelty+GCwa , Greediness on Clause Weighting scheme 
 * based on gNovelty+
 *
 * version : 1.0
 * Author:    Thach-Thao Duong , Duc Nghia Pham
 * thao.duong@nicta.com, d.pham@griffith.edu.au
 *
 * Modified date:  April 30th, 2013
 *
 * Copyright by NICTA Queensland Australia
 ********************************/


Syntax to call the solver:

./gNovelty+GCwa <instance.cnf> <seed>
