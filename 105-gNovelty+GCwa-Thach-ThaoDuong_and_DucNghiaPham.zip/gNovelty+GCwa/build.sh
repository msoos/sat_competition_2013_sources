mkdir binary
rm binary/gNovelty+GCwa
cd code
make clean
make
cd ..
cp code/gNovelty+GCwa binary/
