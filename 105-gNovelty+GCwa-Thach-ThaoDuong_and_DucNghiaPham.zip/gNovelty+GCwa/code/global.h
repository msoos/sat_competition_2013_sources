/**********************************************************/
/* global.h, version 1.0                                  */
/*                                                        */
/* Duc Nghia Pham (d.n.pham@griffith.edu.au)              */
/*   IIIS, Griffith University, Australia                 */
/* February 2005                                          */
/**********************************************************/

#ifndef __MY_GLOBAL_H__
#define __MY_GLOBAL_H__k

//=== If the constant NT is set the program compiles under Windows NT.
//=== Currently, the timing then reflects user time.
#ifdef WIN32
	#define NT 1
#endif

/************************************/
/* Standard includes                */
/************************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

#ifdef WIN32
	#define random() rand()
	#define srandom(seed) srand(seed)
#endif

/***********************************************************/
/* Wrappers                                                */
/***********************************************************/
#define Lit(CLAUSE, POSITION) (clauses[CLAUSE][POSITION])
#define Var(CLAUSE, POSITION) (abs(Lit(CLAUSE,POSITION)))
//static int scratch;
//#define ABS(x) ((scratch=(x))>0?(scratch):(-scratch))

/**********************************************************/
/* Constants                                              */
/**********************************************************/
//#define MAXATOM2 500000			// maximum possible number of atoms
int MAXATOM;
//#define MAXATOM 1575207			// maximum possible number of atoms //resizes by Thao due to over limit of some file in SAT11 benchmark
//#define MAXCLAUSE 5000000		// maximum possible number of clauses
//#define MAXLITERAL 2*MAXATOM	// maximum possible number of literals
int MAXLITERAL;
//#define MAXLENGTH 500			// max num of literals which can be in a clause
#define MAXLENGTH 500			// max num of literals which can be in a clause //resizes by Thao due to over limit of some file in SAT11 benchmark
//#define STOREBLOCK 2000000		// size of block to malloc each time
#define STOREBLOCK 2010000		// size of block to malloc each time

#define CWBIG 1E30f				// quasi-infinity for CWTYPE
#define BIG 100000000			// quasi-infinity for integer

#define TRUE 1
#define FALSE 0
#define NOVALUE -1

#define DEFAULT_NUMTRIES 1			// default number of tries
#define DEFAULT_CUTOFF_FLIPS 100000	// default maximal number of flips per try
#define DEFAULT_TIMEOUT 1000000000
			// default maximal number of seconds per try
#define DEFAULT_TARGETCOST 0		// default cost to reach in order to have a solution
#define DEFAULT_PRINTSOL FALSE		// default flag determining whether to output solution

/**********************************************************/
/* Basic variables and data structures                    */
/**********************************************************/
int numAtoms;				// number of atoms in input formula
int numClauses;				// number of clauses in input formula
int numOrigClauses;			// number of clauses in the original input formula
int numLiterals;			// number of literals in input formula
long int flip;				// counter for flips
long int nullFlip;			// counter for nullFlips

//=== The numbering of atoms starts at 1. Not a is represented -a
//=== One dimensional arrays are statically allocated. Two dimensional
//=== arrays are dynamically allocated in the second dimension only.
//int atom[MAXATOM+1];			// value of each atom
int* atom;
//int *clauses[MAXCLAUSE];		// indexed as clauses[clause_num][literal_num]
int** clauses;
//int size[MAXCLAUSE];			// length of each clause
int* size;			// length of each clause

int numFalse;					// number of false clauses
//int falseClause[MAXCLAUSE];		// clauses which are false:
int* falseClause;		// clauses which are false:
//int whereFalse[MAXCLAUSE];		// where each clause is listed in falseClause:
int* whereFalse;		// where each clause is listed in falseClause:
					// whereFalse[c] = i <=> c is ith unsat. clause

//int numTrueLit[MAXCLAUSE];		// number of true literals in each clause
int* numTrueLit;		// number of true literals in each clause
//int critVar[MAXCLAUSE];			// the literal for clauses critically sat
int* critVar;			// the literal for clauses critically sat
//int *occurence[MAXLITERAL+1];	// where each literal occurs: indexed as
					// occurence[literal+MAXATOM][occurence_num]
int** occurence;
//int numOccurence[MAXLITERAL+1];		// number of times each literal occurs
int* numOccurence;

//int numMake[MAXATOM+1];			// number of clauses var makes when flipped.
//int numBreak[MAXATOM+1];		// number of clauses var breaks when flipped.

//int numDiff[MAXATOM+1];

//int solution[MAXATOM+1];		// where the last solution gets saved
int* solution;		// where the last solution gets saved
//int cost[MAXCLAUSE];			// cost associated with each clause
int costAllFalse;			// sum of costs associated w/ all false clauses
int lowCost;				// best costAllFalse seen so far
int lowFlips;				// number of flips it took to reach lowCost

FILE *fpInput;

/**********************************************************/
/* General parameters                                     */
/**********************************************************/
int seed;					// seed used for randomization
int numTries;				// number of tries
int cutoff;					// maximal number of flips per try
int timeout;				// maximal number of seconds per try
int targetCost;				// cost to reach in order to have a solution
int printSol;				// flag determining whether to output solution

/**********************************************************/
/*  Global Statistics                                     */
/**********************************************************/
long int totalFlips;			// total number of flips in all tries so far
long int totalNullFlips;		// total num of nullFlips in all tries so far
long int totalSuccessFlips;		// total num of flips in succesful tries so far
long int totalSuccessNullFlips;		// total num of null flips in succesful tries so far
int numSuccessTries;			// total number of successful tries so far
int smoothStages;				// number of times the smoothing was performed

/**********************************************************/
/* Timing                                                 */
/**********************************************************/
double expertime;
double trytime;

#endif
