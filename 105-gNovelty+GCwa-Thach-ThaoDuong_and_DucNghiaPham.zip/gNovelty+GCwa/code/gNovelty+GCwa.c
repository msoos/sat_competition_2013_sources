
/***********************
 * gNovelty+PCL, Trap Avoidance Heuristics
 * based on gNovelty+
 *
 * Author:    Thach-Thao Duong , Duc Nghia Pham
 * thao.duong@nicta.com, duc-nghia.pham@nicta.com
 *
 * Modified:  April 10nd, 2012
 *
 * Copyright by NICTA Queensland Australia
 ********************************/

/************************************/
/* Standard includes                */
/************************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>

#include "global.h"
#include "rtime.h"

/************************************/
/* Compilation flags                */
/************************************/
#define WEIGHTING 1

/**********************************************************/
/* DLS specific variables                                 */
/**********************************************************/
#define CWTYPE int
//#define CWTYPE double

//=== Weighting controlled variables
//CWTYPE clauseWeight[MAXCLAUSE];		// weight of a clause
int* clauseWeight;
//CWTYPE weightDiff[MAXATOM+1];		// the total weight difference if a variable if flipped
int* weightDiff;
//CWTYPE weightTotal;					// total clause weight

//int varLastChange[MAXATOM+1];
int* varLastChange;
//int variableWeight[MAXATOM+1];
int* variableWeight;

int numWeight;						// number of clauses with weight > 1
//int weightedClause[MAXCLAUSE];		// clauses which have weight > 1:
int* weightedClause;		// clauses which have weight > 1:
//int whereWeight[MAXCLAUSE];		// same as for whereFalse:
int* whereWeight;		// same as for whereFalse:
int smoothStages, weightCounter;

int smoothProb = 40;//setting for SAT2013 competition

//=== AdaptNovelty+ controlled variables

int lastAdaptFlip;
int lastAdaptNumFalse;

int adaptFlag = 1;


#define _weight_getScore(VAR)		(weightDiff[VAR])
#define _weight_setScore(VAR, VAL)	(weightDiff[VAR] = (CWTYPE) VAL)
#define _weight_adjScore(VAR, VAL)	(weightDiff[VAR] += VAL)
#define _weight_incScore(VAR, CLS)	(weightDiff[VAR] += clauseWeight[CLS])
#define _weight_decScore(VAR, CLS)	(weightDiff[VAR] -= clauseWeight[CLS])
/*
#define _num_getScore(VAR)		(numDiff[VAR])
#define _num_setScore(VAR, VAL)	(numDiff[VAR] = VAL)
#define _num_adjScore(VAR, VAL)	(numDiff[VAR] += VAL)
#define _num_incScore(VAR, CLS)	(numDiff[VAR] += 1)
#define _num_decScore(VAR, CLS)	(numDiff[VAR] -= 1)
*/
#define setScore(VAR, VAL) {		\
	_weight_setScore(VAR, VAL);		\
}

#define adjScore(VAR, VAL) {		\
	_weight_adjScore(VAR, VAL);		\
}

#define incScore(VAR, CLS) {		\
	_weight_incScore(VAR, CLS);		\
}

#define decScore(VAR, CLS) {		\
	_weight_decScore(VAR, CLS);		\
}

/**********************************************************/
/* ANOV parameters                                        */
/**********************************************************/
#define PROBABILITY int

PROBABILITY walkProb = 1;	// default random walk probability
PROBABILITY noise = 50;		// default noise (in percent)
PROBABILITY Beta = 0; //setting for SAT 2013 competition

int invPhi = 5;
int invTheta = 6;

/**********************************************************/
/*   Forward declarations                                 */
/**********************************************************/
void printUsage();
void parseParameters(int argc,char *argv[]);
void parseParametersComp(int argc,char *argv[]);
void scanInt(int argc, char *argv[], int i, int *varptr);
void scanFloat(int argc, char *argv[], int i, float *varptr);
void printHeader();
void printStatsHeader();
int  compareAbsInts(const void *a, const void *b);
void initInstance();
void init();
int  pickVar();
void flipAtom(int toflip);
void updateClauseWeights_Linear();
void updateClauseWeights_NULL();
void smooth();
void adaptNoveltyNoise();
//void updateStatsEndFlip();//DELETE FOR SAT
void updateStatsEndTry();
//DELETE FOR SAT void printStatsEndTry();
CWTYPE computeCurrentCost();
//DELETE FOR SAT void printFinalStats();
void printFinalStatsComp();
void saveSolution();
void printSolution();
void free_memory();
//void CheckDifferentFalseClause();
//int computeCurrentNumTrueLit(int c);
void clauseMoveFromTrueToFalse(int c);
void clauseMoveFromFalseToTrue(int c);
void findFalseClauseWeightMax();

//int malloc_neighbourVar[MAXATOM+1];//check if it is allocated memory
char* malloc_neighbourVar;
//int malloc_clauses[MAXCLAUSE];
char* malloc_clauses;
//int malloc_occurence[MAXLITERAL+1];
char* malloc_occurence;


//int *neighbourVar[MAXATOM2+1];
int** neighbourVar;

//int candVar[MAXATOM+1];
int* candVar;
//int isCandVar[MAXATOM+1];
char* isCandVar;
int numCandVar;

long int numWalks, numRWalks, numDBests, numFreqs, numSBests;

int minClauseSize, maxClauseSize;
void (*updateClauseWeights)() = NULL;


//double timeCost = 0;//DELETE FOR SAT
//long int flipCost = 0;//DELETE FOR SAT
//long int lowCostTotal = 0;//DELETE FOR SAT

int falseClauseWeightMax=1;
int falseClauseWeightMaxListSize = 0;
//int falseClauseWeightMaxList[MAXCLAUSE];
int* falseClauseWeightMaxList;
//int falseClauseWeight_InList[MAXCLAUSE];
int* falseClauseWeight_InList;

int try;

/************************************/
/* Main                             */
/************************************/
int main(int argc,char *argv[]) {
	
	double starttime;


	printHeader();

	seed = genRandomSeed();
	parseParameters(argc, argv);
	//parseParametersComp(argc, argv);
	srandom(seed);

	printf("c Reading instance ...<< %s >>\n",argv[1]);
	initInstance();


	totalFlips = totalNullFlips = 0;
	totalSuccessFlips = totalSuccessNullFlips = 0;
	numSuccessTries = 0;

	/*
	if (smoothProb == 100) {
		updateClauseWeights = &updateClauseWeights_NULL;
	} else {
		updateClauseWeights = &updateClauseWeights_Linear;
	}
	*/
	updateClauseWeights = &updateClauseWeights_Linear;
	//tenure = numAtoms / 30;
	
	printStatsHeader();
	initTimeCounter();

//	lowCost = BIG;
//	timeCost = 0;
//	flipCost = 0;
//	lowCostTotal = 0;
	for (try = 1; try <= numTries; ++try) {
		starttime = elapsedTime();
		flip = nullFlip = 0;

		init();

		numWalks  = 0;
		numRWalks = 0;

		while ((numFalse > targetCost) && (elapsedTime() - starttime < timeout)) {
			flip++;

			int var = pickVar();
			
			flipAtom(var);
			varLastChange[var] = flip;
			variableWeight[var]++;


			if (adaptFlag)
				adaptNoveltyNoise();

//			updateStatsEndFlip();//DELETE FOR SAT
			

		}
		trytime = elapsedTime() - starttime;
//		timeCost +=trytime;//DELETE FOR SAT
//		flipCost +=flip;//DELETE FOR SAT
//		lowCostTotal += lowCost;//DELETE FOR SAT
		updateStatsEndTry();
//		printStatsEndTry();//DELETE FOR SAT
	}
	expertime = elapsedTime();
//	printFinalStats();//DELETE FOR SAT
	printFinalStatsComp();

	free_memory();


	return 0;
}

int pickVar(void) {
	CWTYPE score, bestValue, secondBestValue;
	int bestVar, secondBestVar, maxVariableWeight, weight,lastChange, youngest;
	register int i, j, clause, var;
	int *clsptr;

	//flags = TRUE;
	bestVar = NOVALUE;
	
//	printf("\n--> numCandVar = %d : (var,variableWeight,varLastChange,Score) :",numCandVar);
	// version 1: favour the cost, breaking tie by flipping time
	if (numCandVar > 0) {
		bestValue = BIG;
		lastChange = flip;
		weight = BIG;

		i = NOVALUE;
		clsptr = candVar;
		for (j = 0; j < numCandVar; j++, clsptr++) {
			var = *clsptr;
			score = _weight_getScore(var); 
//			printf("\n (%d,%d,%d,%d) ",var,variableWeight[var],varLastChange[var],score);
			if (score < 0) {
				if (score < bestValue) {
					bestValue = score;
					lastChange = varLastChange[var];
					weight = variableWeight[var];
					bestVar = var;
				} else if (score == bestValue) {
//					if (varLastChange[var] < lastChange) {
					if (variableWeight[var] < weight){
						lastChange = varLastChange[var];
						weight = variableWeight[var];
						bestVar = var;
					}else if (variableWeight[var] == weight && varLastChange[var] < lastChange){
						lastChange = varLastChange[var];
						bestVar = var;
					}

				}
			} else {
				i = j;		isCandVar[var] = FALSE;
//				printf(" RevCandA(%d,%d) ",var,_weight_getScore(var));
//				printf(" Remove(%d,%d) ",var,_weight_getScore(var));
				//printf("r %d, ", var);
				break;
			}
		}
		clsptr++;
		
		if (i != NOVALUE) {
			for (j = i+1; j < numCandVar; j++, clsptr++) {
				var = *clsptr;
				score = _weight_getScore(var); 
//				printf("\n (%d,%d,%d,%d) ",var,variableWeight[var],varLastChange[var],score);
				if (score < 0) {
					candVar[i++] = var;
					if (score < bestValue) {
						bestValue = score;
						lastChange = varLastChange[var];
						weight = variableWeight[var];
						bestVar = var;
					} else if (score == bestValue) {
//						if (varLastChange[var] < lastChange) {
						if (variableWeight[var] < weight){
							lastChange = varLastChange[var];
							weight = variableWeight[var];
							bestVar = var;
						}else if (variableWeight[var] == weight && varLastChange[var] < lastChange){
							lastChange = varLastChange[var];
							bestVar = var;
						}
					}
				} else {
					isCandVar[var] = FALSE;
					//printf("r %d, ", var);
//					printf(" RevCandB(%d,%d) ",var,_weight_getScore(var));
//					printf(" Remove(%d,%d) ",var,_weight_getScore(var));
				}
			}
			numCandVar = i;
		}
	}
	//printf("\n");


	if (random()%100 < walkProb) {
		clause = falseClause[random() % numFalse];
		bestVar = Var(clause,(random() % size[clause]));
		++numRWalks;
//		printf("\n\t\tRandom walk at var = %d",bestVar);
	} else if (numCandVar <= 0){
		++numWalks;

		bestValue = secondBestValue = BIG;
		bestVar = secondBestVar = NOVALUE;
		if (random()%100 < Beta || falseClauseWeightMaxListSize==0){
			clause = falseClause[random() % numFalse];
//			printf("\nWithin Beta of %d or no Max Weight : randomly pick false clause = %d, ",Beta,clause);
		}
		else{
			clause = falseClauseWeightMaxList[random() % falseClauseWeightMaxListSize];
//			printf("\nNot Within Beta of %d pick greedly pick Max Weight of clause = %d",Beta,clause);
		}
		
		clsptr = clauses[clause];
//		printf("\n\t\tNumFalse = %d, Choose false clause = %d, size = %d",numFalse,clause,size[clause]);

		if (size[clause]>1){
			youngest = varLastChange[abs(*clsptr)];
			maxVariableWeight = variableWeight[abs(*clsptr)];
			for (j = 0; j < size[clause]; j++) {
				var = abs(*clsptr);

				//score = break[var] - make[var];
				score = _weight_getScore(var);
				lastChange = varLastChange[var];
				weight = variableWeight[var];

//				printf("\n (%d,%d,%d,%d) ",var,variableWeight[var],varLastChange[var],score);

				if (lastChange > youngest) {
					youngest = varLastChange[var];
				}
				if (weight > maxVariableWeight)
					maxVariableWeight = weight;

//				if ( (score < bestValue) || ((score == bestValue) && (lastChange < varLastChange[bestVar])) ) {
				if ( (score < bestValue) ||
						((score == bestValue) && (weight < variableWeight[bestVar]
						  || ( weight == variableWeight[bestVar] && lastChange < varLastChange[bestVar]))) ) {
					secondBestVar = bestVar;
					secondBestValue = bestValue;

					bestVar = var;
					bestValue = score;
//				} else if ( (score < secondBestValue) || ((score == secondBestValue) && (lastChange < varLastChange[secondBestVar])) ) {
				} else if ( (score < secondBestValue) ||
						((score == secondBestValue) && (weight < variableWeight[secondBestVar]
						 || (weight == variableWeight[secondBestVar] && lastChange < varLastChange[secondBestVar]))) ) {
					secondBestVar = var;
					secondBestValue = score;
				}

				clsptr++;
			}

			// From adaptg2wsat0
			/*
			if (random()%100 < (noise/10)) {
				var = Var(clause,(random() % size[clause]));
				if (size[clause] > 2) {
					while ( (var == bestVar) || (var == secondBestVar) ) {
						var = Var(clause,(random() % size[clause]));
					}
				}
				bestVar = var;
			} else
			*/
			// Novelty
//			printf("\nBestVar = %d, secondBestVar = %d, maxVariableWeight = %d, youngest age = %d",
//				bestVar,secondBestVar,maxVariableWeight,youngest);
			if (variableWeight[bestVar] == maxVariableWeight || varLastChange[bestVar] == youngest) {
				if ( (_weight_getScore(bestVar) == 0) || (random()%100 < noise) ) {
//					printf("\nvariableWeight[bestVar=%d]=%d == maxVariableWeight = %d || varLastChange[bestVar=%d]=%d == youngest = %d and score = 0 and in a noise %d",
//					bestVar,variableWeight[bestVar],maxVariableWeight,bestVar,varLastChange[bestVar],youngest,noise);
					bestVar = secondBestVar;
//					printf("\npick secondBest Var = %d",bestVar);
				}
			}

		}
		else
			bestVar = abs(*clsptr);

//		printf("\n\t\tNovelty jump at var = %d",bestVar);
		
	#ifdef WEIGHTING
		//(*updateClauseWeights)();
		//updateClauseWeights_NULL();
		updateClauseWeights_Linear();
	#endif
	
		//printf("flip %d\n", bestVar);
	}

	return bestVar;
}


void updateClauseWeights_NULL() {
	return;
}

void updateClauseWeights_Linear() {
//	printf("\nUpdateClauseWeights_Linear");
	register int c, i, j, var;
	
	#ifdef DETERMINISTIC_SMOOTHING
		if (++weightCounter > smoothProb) {
			smooth();
			weightCounter = 0;
			return;
		}
	#else
		if (random()%100 < smoothProb) {
			smooth();
			return;
		}
	#endif
	
	//printf("\n---- Start update weight ----\n");



	falseClauseWeightMax++;

	for (i = 0; i < numFalse; i++) {
		c = falseClause[i];

		if (++clauseWeight[c] == 2) {
			//=== Add clause to weighted list
			whereWeight[c] = numWeight;
			weightedClause[numWeight] = c;
			++numWeight;
			if (falseClauseWeightMax==2){
				falseClauseWeightMaxList[falseClauseWeightMaxListSize]=c;
				falseClauseWeight_InList[c]=falseClauseWeightMaxListSize;
				falseClauseWeightMaxListSize++;
			}
		}
/*		if (falseClauseWeightMax < clauseWeight[c]){
			falseclauseWeightMax=clauseWeight[c];
			falseClauseWeightMaxIndexListSize=1;
			falseCaluseWeightMaxIndex[0]=c;
			falseClauseWeight_In_MaxIndexList[c]=0;
		}*/
		for (j = 0; j < size[c]; j++) {
			var = Var(c, j);
			_weight_adjScore(var, -1);
//			if (!isCandVar[var] && (_weight_getScore(var) < 0) && (varLastChange[var] < flip-1)) {
			if (!isCandVar[var] && (_weight_getScore(var) < 0)) {
				candVar[numCandVar++] = var;
				isCandVar[var] = TRUE;
//				printf(" AddCandA(%d,%d) ",var,_weight_getScore(var));
				
				//printf("a %d, ", var);
			} 
		}
	}
	//printf("\n");
	//fflush(stdout);

//	printf("\nUpdate Clause Weight");

//	PrintClauseWeight();
//	PrintTrueClauseWeightMax();
//	PrintFalseClauseWeightMax();


}

void smooth() {
	register int c, i;

	//printf("\n---- Start reduce weight ----\n");


/*	if (trueClauseWeightMax>2)
		trueClauseWeightMax--;
	else if (trueClauseWeightMax==2){
		trueClauseWeightMax=1;
		trueClauseWeightMaxListSize = 0;
	}
*/

	for (i = 0; i < numWeight; i++) {
		c = weightedClause[i];
		if (numTrueLit[c] > 0) {//true clause
			if (--clauseWeight[c] == 1) {
				--numWeight;
				weightedClause[i] = weightedClause[numWeight];
				whereWeight[weightedClause[numWeight]] = i;
				i--;
//				index_temp = clauseWeight_Index_InList[c];
//				if (index_temp>0){ //clause number c i not longer in the trueClauseWeightMaxList anymore
//					trueClauseWeightMaxList[index_temp] = trueClauseWeightMaxList[trueClauseWeightMaxListSize];
//					trueClauseWeightMaxListSize--;
//				}

			}

			if (numTrueLit[c] == 1) {
				_weight_adjScore(critVar[c], -1);
				
//				if (!isCandVar[critVar[c]] && (_weight_getScore(critVar[c]) < 0) && (varLastChange[critVar[c]] < flip-1)) {
				if (!isCandVar[critVar[c]] && (_weight_getScore(critVar[c]) < 0) ) {
					candVar[numCandVar++] = critVar[c];
					isCandVar[critVar[c]] = TRUE;
//					printf(" RevCandC(%d,%d) ",critVar[c],_weight_getScore(critVar[c]));
					
					//printf("a %d, ", critVar[c]);
				} 
			}
		}
	}
	//printf("\n");
	//fflush(stdout);

	++smoothStages;
}

void adaptNoveltyNoise() {
	if ( (flip - lastAdaptFlip) > (numClauses / invTheta) ) {
		noise += (int) ((100 - noise) / invPhi);
		lastAdaptFlip = flip;
		lastAdaptNumFalse = numFalse;
	} else if (numFalse < lastAdaptNumFalse) {
		noise -= (int) (noise / invPhi / 2);
		lastAdaptFlip = flip;
		lastAdaptNumFalse = numFalse;
	}
}

void init() {
	register int i, j, lit;

	for (i = 0; i < numClauses; i++) {
		numTrueLit[i] = 0;
		clauseWeight[i] = 1;
//		trueClauseWeight_InList[i]=-1;
		falseClauseWeight_InList[i]=-1;
		
		// not used in the solver
		//trace[i] = 0.0;
        //stepSize[i] = pseudoStepSize;
	}

	numFalse = 0;
	numWeight = 0;
	nullFlip = 0;
	smoothStages = weightCounter = 0;

	for (i = 1; i < numAtoms+1; i++) {
		setScore(i, 0);
		varLastChange[i] = 0;
		variableWeight[i]=0;
	}

//	trueClauseWeightMax=1;
//	trueClauseWeightMaxListSize = 0;

	falseClauseWeightMax=1;
	falseClauseWeightMaxListSize = 0;

	for (i = 1; i < numAtoms+1; i++) atom[i] = random()%2;
    
	//=== Initialize the gradient cost
	for (i = 0; i < numClauses; i++) {
		for (j = 0; j < size[i]; j++){
			lit = Lit(i,j);
			if ((lit > 0) == atom[abs(lit)]) {
				numTrueLit[i]++;
				critVar[i] = abs(lit);
			}
		}
		if (numTrueLit[i] == 0) {
			whereFalse[i] = numFalse;
			falseClause[numFalse] = i;
			numFalse++;
		 
			//=== these variables make clause i
			for (j = 0; j < size[i]; j++) {
				decScore(Var(i,j), i);
			}
		} else if (numTrueLit[i] == 1) {
			//=== this variable breaks clause i
			incScore(critVar[i], i);
		}
	}
	lowCost = numFalse;
	
	numCandVar = 0;
	for (i = 1; i < numAtoms+1; i++) {
		if (_weight_getScore(i) < 0) {
			candVar[numCandVar++] = i;
			isCandVar[i] = TRUE;
//			printf(" AddCandB(%d,%d) ",i,_weight_getScore(i));

		} else {
			isCandVar[i] = FALSE;
//			printf(" RevCandD(%d,%d) ",i,_weight_getScore(i));
		}
	}

	// Adapt Novelty Noise
	if (adaptFlag) {
		lastAdaptFlip = flip;
		lastAdaptNumFalse = numFalse;
		noise = 0;
	}
}

void flipAtom(int toflip) {
	register int i, j, c, var;
	int toEnforce;
	int numocc;
	int *occptr, *ptr;
	
	if (toflip == NOVALUE) {
		totalNullFlips++;
		nullFlip++;
		return;
	}
	
	if (atom[toflip] > 0) toEnforce = -toflip;
	else toEnforce = toflip;

	//=== Flip the variable here.
	atom[toflip] = 1-atom[toflip];

	for (ptr = neighbourVar[toflip]; *ptr != NOVALUE; ptr++) {
		i = *ptr;
		if (_weight_getScore(i) >= 0 && isCandVar[i]==TRUE) {
			isCandVar[i] = FALSE;
//			printf(" RevCandE(%d,%d) ",i,_weight_getScore(i));
		}
		else if (isCandVar[i]==FALSE && _weight_getScore(i) < 0){
			isCandVar[i] = TRUE;
//			printf(" AddCandC(%d,%d) ",i,_weight_getScore(i));
		}
	}
	
	//=== Examine all occurrences of literals with toEnforce with old sign.
	//=== (these literals are made false; numTrueLit must be decremented in that clause)
	numocc = numOccurence[MAXATOM-toEnforce];
	occptr = occurence[MAXATOM-toEnforce];
	for (i = 0; i < numocc ;i++) {
		c = *(occptr++);
		if (--numTrueLit[c] == 0) {
			// clause c is no longer satisfied by lit with toflip; it's now false.
			falseClause[numFalse] = c;
			whereFalse[c] = numFalse++;
			
			clauseMoveFromTrueToFalse(c);

			//=== Decrement toflip's break.
			decScore(toflip, c);
			//=== Increment make of all vars in clause c.
			for (j = 0; j < size[c]; j++) {
				decScore(Var(c,j), c);
			}
		} else if (numTrueLit[c] == 1) {
			//=== Find the lit in this clause that makes it true, and inc its break.
			for (j = 0; j < size[c]; j++) {
				var = Var(c,j);
				if ((Lit(c,j) > 0) == atom[var]) {
					critVar[c] = var;
					incScore(var, c);
					break;
				}
			}
		}
	}

	//=== Examines all occurrences of literal with toEnforce with new sign 
	//=== (these literals are made true; numTrueLit must be incremented in that clause)
	numocc = numOccurence[MAXATOM+toEnforce];
	occptr = occurence[MAXATOM+toEnforce];
	for (i = 0; i < numocc; i++) {
		c = *(occptr++);
		if (++numTrueLit[c] == 1){
			// clause c is no longer unsatisfied by lit with toflip; it's now true.
			falseClause[whereFalse[c]] = falseClause[--numFalse];
			whereFalse[falseClause[numFalse]] = whereFalse[c];

			clauseMoveFromFalseToTrue(c);

			critVar[c] = toflip;
			incScore(toflip, c);
			//=== Decrement the make of all vars in clause c.
			for (j = 0; j < size[c]; j++) {
				incScore(Var(c,j), c);
			}
		} else if (numTrueLit[c] == 2){
			//=== Find the lit in this clause other than toflip that makes it true,
			//=== and decrement its break.
			for (j=0; j<size[c]; j++){
				var = Var(c,j);
				if( ((Lit(c,j) > 0) == atom[var]) && (toflip != var) ) {
					decScore(var, c);
					break;
				}
			}
		}
	}
	
	for (ptr = neighbourVar[toflip]; *ptr != NOVALUE; ptr++) {
		i = *ptr;	
		if (_weight_getScore(i) < 0) {
			if (!isCandVar[i]) {
				candVar[numCandVar++] = i;
				isCandVar[i] = TRUE;
//				printf(" AddCandD(%d,%d) ",i,_weight_getScore(i));
			}
		}
	}
}

void printUsage() {
	fprintf(stderr, "\nUsage:\n");
	fprintf(stderr, "  gnovelty+GCwa instance.cnf seed(integer)(optional) \n\n");
}

void parseParameters(int argc,char *argv[]) {


	numTries = DEFAULT_NUMTRIES;
	cutoff = DEFAULT_CUTOFF_FLIPS;
	timeout = DEFAULT_TIMEOUT;
//	timeout = 1000000000;
	targetCost = DEFAULT_TARGETCOST;
//	printSol = DEFAULT_PRINTSOL;
	printSol = TRUE;

	if (argc>3){///
		fprintf(stderr, "Bad Arguments (Need <= 2 arguments): gnovelty+GC instance.cnf seed(integer)(optinal) \n\n\n");
		exit(-1);
	}

	if (strcmp(argv[1],"-help")==0 || strcmp(argv[1],"-h")==0 ) {
		printUsage();
		exit(-1);
	}

	fpInput = fopen(argv[1], "r");
	if (fpInput == NULL) {
		fprintf(stderr, "ERROR - Cannot open input file\n");
		exit(-1);
	}

	adaptFlag = 1;		noise = 0;

	if (argc==3) scanInt(argc,argv,2,&seed);

}

void parseParametersComp(int argc,char *argv[]) {
	numTries = DEFAULT_NUMTRIES;
	cutoff = DEFAULT_CUTOFF_FLIPS;
	timeout = DEFAULT_TIMEOUT;
//	timeout = 1000000000;
	targetCost = DEFAULT_TARGETCOST;
//	printSol = DEFAULT_PRINTSOL;
	printSol = TRUE;

	fpInput = fopen(argv[1], "r");
	if (fpInput == NULL) {
		fprintf(stderr, "ERROR - Cannot open input file\n");
		exit(-1);
	}

	if (argc > 2) scanInt(argc, argv, 2, &seed);

	adaptFlag = 1;		noise = 0;
}

void scanInt(int argc, char *argv[], int i, int *varptr) {
	if (i>=argc || sscanf(argv[i],"%i",varptr)!=1){
		fprintf(stderr, "Bad argument %s\n", i<argc ? argv[i] : argv[argc-1]);
		exit(-1);
	}
}


void scanFloat(int argc, char *argv[], int i, float *varptr) {
	if (i>=argc || sscanf(argv[i],"%f",varptr)!=1){
		fprintf(stderr, "Bad argument %s\n", i<argc ? argv[i] : argv[argc-1]);
		exit(-1);
	}
}

int compareAbsInts(const void *a, const void *b) {
	int *va = (int *) a;
	int *vb = (int *) b;
	return ( abs(*va) - abs(*vb) );
}

void initInstance() {

	int i, j, lit, freestore, lastc, nextc;
	int *storeptr = 0;
	char buf[100];



//	int neighbours[MAXATOM2+1];


	int numNeighbours;
	int numocc, c, var, k;
	int *occptr, *ptr;

	lastc = '#';
	while (lastc != 'p') {
		while ((lastc = fgetc(fpInput)) == 'c') {
			while ((nextc = fgetc(fpInput)) != EOF && nextc != '\n');
		}
	}

	ungetc(lastc, fpInput);
	if (fscanf(fpInput, "p %s %i %i", buf, &numAtoms, &numClauses) != 3) {
		fprintf(stderr,"ERROR - Bad input file!\n");
		exit(-1);
	}

	int* neighbours = (int *) malloc( sizeof(int) * (numAtoms + 1) );

	MAXATOM = numAtoms+1;
	MAXLITERAL = MAXATOM*2;

//	printf("\nMAXATOM = %d, MAXLITERAL = %d",MAXATOM,MAXLITERAL);

	clauseWeight = (int *) malloc( sizeof(int) * (numClauses) );
	if (clauseWeight==NULL){
		fprintf(stderr,"ERROR - can not allocate memory of %d clause\n",numClauses);
		free_memory();
		exit(-1);
	}

	weightedClause = (int *) malloc( sizeof(int) * (numClauses) );
	if (weightedClause==NULL){
		fprintf(stderr,"ERROR - can not allocate memory of %d clause\n",numClauses);
		free_memory();
		exit(-1);
	}
	whereWeight = (int *) malloc( sizeof(int) * (numClauses) );
	if (whereWeight==NULL){
		fprintf(stderr,"ERROR - can not allocate memory of %d clause \n",numClauses);
		free_memory();
		exit(-1);
	}
	malloc_clauses = (char *) malloc( sizeof(char) * (numClauses) );
	if (malloc_clauses==NULL){
			fprintf(stderr,"ERROR - can not allocate memory of %d clause\n",numClauses);
			free_memory();
			exit(-1);
		}
	for(i=0;i<numClauses;i++)
		malloc_clauses[i]=0;

	clauses = (int **) malloc( sizeof(int*) * (numClauses) );
	if (clauses==NULL){
			fprintf(stderr,"ERROR - can not allocate memory of %d clause\n",numClauses);
			free_memory();
			exit(-1);
		}
	size = (int *) malloc( sizeof(int) * (numClauses) );
	if (size==NULL){
			fprintf(stderr,"ERROR - can not allocate memory of %d clause\n",numClauses);
			free_memory();
			exit(-1);
		}
	falseClause = (int *) malloc( sizeof(int) * (numClauses) );
	if (falseClause==NULL){
			fprintf(stderr,"ERROR - can not allocate memory of %d clause\n",numClauses);
			free_memory();
			exit(-1);
		}
	whereFalse = (int *) malloc( sizeof(int) * (numClauses) );
	if (whereFalse==NULL){
			fprintf(stderr,"ERROR - can not allocate memory of %d clauses\n",numClauses);
			free_memory();
			exit(-1);
		}
	numTrueLit = (int *) malloc( sizeof(int) * (numClauses) );
	if (numTrueLit==NULL){
			fprintf(stderr,"ERROR - can not allocate memory of %d clauses\n",numClauses);
			free_memory();
			exit(-1);
		}
	critVar = (int *) malloc( sizeof(int) * (numClauses) );
	if (critVar==NULL){
			fprintf(stderr,"ERROR - can not allocate memory of %d clauses\n",numClauses);
			free_memory();
			exit(-1);
		}

	falseClauseWeightMaxList = (int*) malloc(sizeof(int) * (numClauses));
	if (falseClauseWeightMaxList==NULL){
			fprintf(stderr,"ERROR - can not allocate memory of %d clauses\n",numClauses);
			free_memory();
			exit(-1);
		}

	

	falseClauseWeight_InList = (int*) malloc(sizeof(int) * (numClauses));

	if (falseClauseWeight_InList==NULL){
		fprintf(stderr,"ERROR - can not allocate memory of %d clauses\n",numClauses);
		free_memory();
		exit(-1);

	}



	atom = (int *) malloc( sizeof(int) * (numAtoms + 1) );
	if (atom==NULL){
			fprintf(stderr,"ERROR - can not allocate memory of variables %d\n",numAtoms+1);
			free_memory();
			exit(-1);
		}
	occurence = (int **) malloc( sizeof(int*) * (MAXLITERAL + 1) );
	if (occurence==NULL){
		fprintf(stderr,"ERROR - can not allocate memory of variables %d\n",MAXLITERAL + 1);
		free_memory();
		exit(-1);
	}
	numOccurence = (int *) malloc( sizeof(int) * (MAXLITERAL + 1) );
	if (numOccurence==NULL){
		fprintf(stderr,"ERROR - can not allocate memory of variables %d\n",MAXLITERAL + 1);
		free_memory();
		exit(-1);
	}

	solution = (int *) malloc( sizeof(int) * (numAtoms + 1) );
	if (solution==NULL){
		fprintf(stderr,"ERROR - can not allocate memory of variables %d\n",numAtoms+1);
		free_memory();
		exit(-1);
	}
	weightDiff = (int *) malloc( sizeof(int) * (numAtoms + 1) );
	if (weightDiff==NULL){
		fprintf(stderr,"ERROR - can not allocate memory of variables %d\n",numAtoms+1);
		free_memory();
		exit(-1);
	}

	varLastChange = (int *) malloc( sizeof(int) * (numAtoms + 1) );;
	if (varLastChange==NULL){
		fprintf(stderr,"ERROR - can not allocate memory of variables %d\n",numAtoms+1);
		free_memory();
		exit(-1);
	}

	variableWeight = (int *) malloc( sizeof(int) * (numAtoms + 1) );;
	if (variableWeight==NULL){
		fprintf(stderr,"ERROR - can not allocate memory of variables %d\n",numAtoms+1);
		free_memory();
		exit(-1);
	}
	malloc_neighbourVar = (char *) malloc( sizeof(char) * (numAtoms + 1) );
	if (malloc_neighbourVar==NULL){
		fprintf(stderr,"ERROR - can not allocate memory of variables %d\n",numAtoms+1);
		free_memory();
		exit(-1);
	}
	for(i=0;i<numAtoms+1;i++)
		malloc_neighbourVar[i]=0;

	malloc_occurence = (char *) malloc( sizeof(char) * (MAXLITERAL + 1) );
	if (malloc_occurence==NULL){
		fprintf(stderr,"ERROR - can not allocate memory of variables %d\n",MAXLITERAL + 1);
		free_memory();
		exit(-1);
	}
	for(i=0;i<MAXLITERAL + 1;i++)
		malloc_occurence[i]=0;

	neighbourVar = (int **) malloc( sizeof(int*) * (numAtoms + 1) );
	if (neighbourVar==NULL){
		fprintf(stderr,"ERROR - can not allocate memory of variables %d\n",(numAtoms + 1));
		free_memory();
		exit(-1);
	}
	candVar = (int *) malloc( sizeof(int) * (numAtoms + 1) );
	if (candVar==NULL){
		fprintf(stderr,"ERROR - can not allocate memory of variables %d\n",(numAtoms + 1));
		free_memory();
		exit(-1);
	}

	isCandVar = (char *) malloc( sizeof(char) * (numAtoms + 1) );
	if (isCandVar==NULL){
			fprintf(stderr,"ERROR - can not allocate memory of variables %d\n",(numAtoms + 1));
			free_memory();
			exit(-1);
		}

	if (strcmp("cnf", buf) != 0 ) {
		fprintf(stderr, "ERROR - Bad input file\n");
		exit(-1);
	}

/*	if (numAtoms > MAXATOM) {
		fprintf(stderr,"ERROR - too many atoms of %d\n",numAtoms);
		exit(-1);
	}
*/


	freestore = 0;
	numLiterals = 0;
	for (i = 0; i < MAXLITERAL+1; i++) numOccurence[i] = 0;

	minClauseSize = maxClauseSize = NOVALUE;
	int tt_extention = 1;
	for (i = 0; i < numClauses; i++) {
		size[i] = -1;
		tt_extention = 1;
		if (freestore < MAXLENGTH) { //of gnovelty1.2
			storeptr = (int *) malloc( sizeof(int) * STOREBLOCK );
			if (storeptr==NULL){
				fprintf(stderr,"ERROR - can not allocate memory of clause %d size %d*%d=%d int\n",i,tt_extention,STOREBLOCK,tt_extention*STOREBLOCK);
				free_memory();
				exit(-1);
			}
			malloc_clauses[i]=1;
			freestore = STOREBLOCK;
		}
		clauses[i] = storeptr;
//		cost[i] = 1;

		do {
			size[i]++;
/*			if (size[i] > MAXLENGTH) {
				fprintf(stderr, "ERROR - clause too long of %d\n",size[i]);
				exit(-1);
			}*/
			if (fscanf(fpInput, "%i ", &lit) != 1) {
				fprintf(stderr, "ERROR - Bad input file\n");
				exit(-1);
			}
			if (lit != 0) {
				*(storeptr++) = lit;

				freestore--;
				numLiterals++;

				numOccurence[lit+MAXATOM]++;
			}

//			printf("\nfreestore = %d",freestore);
			if (freestore==0){
//				printf("\nEEEE");
				tt_extention++;
				storeptr = (int *) malloc( sizeof(int) * (tt_extention*STOREBLOCK) );
				if (storeptr==NULL){
					fprintf(stderr,"ERROR - can not allocate memory of clause %d size %d*%d=%d int\n",i,tt_extention,STOREBLOCK,tt_extention*STOREBLOCK);
					free_memory();
					exit(-1);
				}
				int l;
				for(l=0;l<size[i];l++){
					
					storeptr[l]=clauses[i][l];
				}

				if (malloc_clauses[i]==1)
					free(clauses[i]);

				malloc_clauses[i]=1;
				clauses[i]=storeptr;
				storeptr+=size[i];
				freestore = STOREBLOCK;
			}
			else if (freestore<0){
				fprintf(stderr,"ERROR - in memory allocation freestore = %d < 0",freestore);
			}

		} while (lit != 0);
		qsort(clauses[i], size[i], sizeof(int), compareAbsInts);
		if ( (size[i] < minClauseSize) || (minClauseSize == NOVALUE) ) minClauseSize = size[i];
		if ( (size[i] > maxClauseSize) || (maxClauseSize == NOVALUE) ) maxClauseSize = size[i];
	}
	fclose(fpInput);
	if (size[0] == 0) {
		fprintf(stderr,"ERROR - incorrect problem format or extraneous characters\n");
		exit(-1);
	}



	for (i = 0; i < MAXLITERAL+1; i++) {
		if (freestore < numOccurence[i]) {
//			storeptr = (int *) malloc( sizeof(int) * STOREBLOCK );//origianl gnovelty
			storeptr = (int *) malloc( sizeof(int) * (numOccurence[i]) );//original gnovelty
			if (storeptr==NULL){
				fprintf(stderr,"ERROR - can not allocate memory of occurence %d size %d int\n",i,numOccurence[i]);
				free_memory();
				exit(-1);
			}
			malloc_occurence[i]=1;
			freestore = numOccurence[i];
		}
		occurence[i] = storeptr;
		freestore -= numOccurence[i];
		storeptr += numOccurence[i];
		numOccurence[i] = 0;
	}


	for (i = 0; i < numClauses; i++) {
		for (j = 0; j < size[i]; j++) {

			occurence[Lit(i,j)+MAXATOM][numOccurence[Lit(i,j)+MAXATOM]] = i;

			numOccurence[Lit(i,j)+MAXATOM]++;
		}
	}



	for (i = 1; i < numAtoms+1; i++) neighbours[i] = 0;

	for (i = 1; i < numAtoms+1; i++) {

		numNeighbours = 0;

		numocc = numOccurence[MAXATOM-i];
		occptr = occurence[MAXATOM-i];
		for (j = 0; j < numocc ; j++) {
			c = *(occptr++);
			for (k = 0, ptr = clauses[c]; k < size[c]; k++, ptr++) {
				var = abs(*ptr);
				if ((neighbours[var] != i) && (var != i)) {
					neighbours[var] = i;
					numNeighbours++;
				}
			}
		}

		numocc = numOccurence[MAXATOM+i];
		occptr = occurence[MAXATOM+i];
		for (j = 0; j < numocc ; j++) {
			c = *(occptr++);
			for (k = 0, ptr = clauses[c]; k < size[c]; k++, ptr++) {
				var = abs(*ptr);
				if ((neighbours[var] != i) && (var != i)) {
					neighbours[var] = i;
					numNeighbours++;
				}
			}
		}

		if (freestore < ++numNeighbours) {
//			storeptr = (int *) malloc( sizeof(int) * STOREBLOCK );
			storeptr = (int *) malloc( sizeof(int) * numNeighbours );
			if (storeptr==NULL){
				fprintf(stderr,"ERROR - can not allocate memory of neighbourVar of var %d size %d\n",i,numNeighbours);
				free_memory();
				exit(-1);
			}
			malloc_neighbourVar[i]=1;
			freestore = numNeighbours;
		}
		neighbourVar[i] = storeptr;

		freestore -= numNeighbours;

		if (numNeighbours > 1) {
			for (j = 1; j < numAtoms+1; j++) {
				if (neighbours[j] == i) {
					*(storeptr++) = j;
					if (--numNeighbours == 1) {
						*(storeptr++) = NOVALUE;
						break;
					}
				}
			}
		} else {
			*(storeptr++) = NOVALUE;
		}
	}




	free(neighbours);
}

void printHeader() {
	printf("c +-------------------------------------------------------------------------------------------------+\n");
	printf("c | gNovelty+GCwa, Greediness on Clause weighting, break ties by variable weights and variable ages |\n");
	printf("c +-------------------------------------------------------------------------------------------------+\n");
	printf("c gnovelty+GCwa -h for help\nc \n");
}

void printStatsHeader() {
	printf("c Problem instance: numAtoms = %i, numClauses = %i, numLiterals = %i\n",numAtoms, numClauses, numLiterals);
	printf("c General parameters: seed = %d, timeout = %d secs, targetCost = %d, print solution: ", seed, timeout, targetCost);
	printf( printSol?"yes":"no");
	printf("\nc gNovelty+PCL parameters: walkprob = %.2f, smoothprob = %.2f, noise = ", (double) walkProb/100, (double) smoothProb/100);
	printf(	adaptFlag?"adaptive":"%.2f", (double) noise/100);
	printf("\nc Beta = %d",Beta);

	printf("\nc tries = %d\nc \n",numTries);

//	DELETE FOR SAT
/*	printf("  best    flips     final     total       num      total    percentage	 num	  num	\n");
	printf("  cost    until    #unsat     flips       walk	  seconds   flip	 random	  null	\n");
	printf("  this     best      this     - null	      	   this     - nullFlip	 walk	  flip	\n");
	printf("   try     soln       try     Flip        	   try      over		        \n");
	printf("                                      			    flip			\n");
	printf("                                    			    - nullflip			\n");
*/
	fflush(stdout);
}
//DELETE FOR SAT
/*
void printStatsEndTry() {
	printf("%6d %8d %9d %9ld %9ld %9.2lf", lowCost, lowFlips, numFalse, flip - nullFlip, numWalks, trytime);
	printf(" %10.2lf", (double) ((numWalks - nullFlip)*100)/(flip-nullFlip));
	printf(" %9ld %9ld", numRWalks, nullFlip);
	printf("\n");
	fflush(stdout);

}
*/
void updateStatsEndTry() {
//	totalFlips += flip;

	if (numFalse <= targetCost) {
		saveSolution();
		numSuccessTries++;
//		totalSuccessFlips += flip;
//		totalSuccessNullFlips += nullFlip;
	}
	int k = computeCurrentCost();
	if ( k != numFalse) {
		fprintf(stderr, "Program error, verification of assignment cost fails %d != %d !\n",k,numFalse);
		exit(-1);
	}
}
//DELETE FOR SAT
/*
void updateStatsEndFlip() {
	if (numFalse < lowCost) {
		lowCost = numFalse;
		lowFlips = flip - nullFlip;

		//fprintf(stderr, "New best %5d at flip# %10d\n", lowCost, flip);
	}
}
//DELETE FOR SAT
void printFinalStats(void) {
	printf("\ntotal elapsed seconds = %f\n", expertime);
	printf("average flips per second = %ld\n", (long)((totalFlips - totalNullFlips)/expertime));
	printf("number solutions found = %d\n", numSuccessTries);
	printf("final success rate = %f\n", ((double)numSuccessTries * 100.0)/numTries);
	printf("average length successful tries including nulls = %li\n",
		 		 		 		 numSuccessTries ? (totalSuccessFlips/numSuccessTries) : 0);
	if (numSuccessTries > 0) {
		printf("mean flips for successful tries = %.6f\n",
			numSuccessTries ? ((double) (totalSuccessFlips - totalSuccessNullFlips)/numSuccessTries) : 0);
	}



	printf("SuccessfulRuns = %d\n",numSuccessTries);
	printf("CPUTime_Mean = %f\n",(float)timeCost/numTries);
	printf("Steps_Mean = %ld\n",flipCost/numTries);
	printf("BestSolution_Mean = %ld\n",lowCostTotal/numTries);
	if (numSuccessTries > 0) {
			printf("ASSIGNMENT FOUND\n");
			if (printSol == TRUE) printSolution();
		} else printf("ASSIGNMENT NOT FOUND\n");

}
*/
void printFinalStatsComp() {
	if (numSuccessTries > 0) {
		printf("s SATISFIABLE\n");
		if (printSol == TRUE) printSolution();
		printf("c Done in %f seconds, flips = %lu\n", expertime,flip);
		exit(10);
	} else {
		printf("s UNKNOWN\n");
		exit(0);
	}
}

CWTYPE computeCurrentCost() {
	int i, j, sat;
	CWTYPE result = 0;

	for (i = 0; i < numClauses; i++) {
		sat = FALSE;
		for (j = 0; j < size[i]; j++) {
			if ( (Lit(i,j) > 0) == atom[Var(i,j)] ){
				sat = TRUE;
				break;
			}
		}
		//if (!sat) result += cost[i];
		if (!sat) result++;
	}
	return result;
}
/*
int computeCurrentNumTrueLit(int c){
	int numTrue = 0;
	int j;
	for (j = 0; j < size[c]; j++) {
		if ( (Lit(c,j) > 0) == atom[Var(c,j)] ){
			numTrue++;
		}
	}
	return numTrue;

}
*/
void saveSolution(void) {
	register int i;

	for (i = 1; i < numAtoms+1; i++)
		solution[i] = atom[i];

	//saveUnitVariableValue();
}


void printSolution(void) {
	register int i;

	int j;
	i=1;
	while(i<numAtoms+1){
		printf("v");
		for(j=0;j<40 && i<numAtoms+1;j++,i++)
			printf(" %i", solution[i] == 1 ? i : -i);
		printf("\n");
	}
	printf("v 0\n");
	fflush(stdout);
}

void free_memory(){
	int i;
	


	for(i=0;i<MAXLITERAL + 1;i++)
		if (malloc_occurence[i]==1)
			free(occurence[i]);
	for(i=0;i<numClauses;i++)
		if (malloc_clauses[i]==1)
			free(clauses[i]);

	for (i = 0; i < numAtoms+1; i++){
		if (malloc_neighbourVar[i] ==1)
			free(neighbourVar[i]);
	}
	if (clauseWeight!=NULL) free(clauseWeight);
	if (weightedClause!=NULL) free(weightedClause);
	if (whereWeight!=NULL) free(whereWeight);
	if (malloc_clauses!=NULL) free(malloc_clauses);
	if (clauses!=NULL) free(clauses);
	if (size!=NULL)free(size);
	if (falseClause!=NULL) free(falseClause);
	if (whereFalse!=NULL)free(whereFalse);
	if (numTrueLit!=NULL) free(numTrueLit);
	if (critVar!=NULL) free(critVar);
	if (falseClauseWeightMaxList!=NULL) free(falseClauseWeightMaxList);
	if (falseClauseWeight_InList!=NULL) free(falseClauseWeight_InList);

	if (atom!=NULL) free(atom);
	if (occurence!=NULL) free(occurence);
	if (numOccurence!=NULL) free(numOccurence);
	if (solution!=NULL) free(solution);
	if (weightDiff!=NULL) free(weightDiff);
	if (varLastChange!=NULL) free(varLastChange);
	if (variableWeight!=NULL) free(variableWeight);
	if (malloc_neighbourVar!=NULL) free(malloc_neighbourVar);
	if (malloc_occurence!=NULL) free(malloc_occurence);
	if (neighbourVar!=NULL) free(neighbourVar);
	if (candVar!=NULL) free(candVar);
	if (isCandVar!=NULL) free(isCandVar);
}

void clauseMoveFromTrueToFalse(int c){
//	printf("\nclause %d move from TRUE to FALSE",c);
	int k;
	//Add clause to falseClauseWeigthMax if it is actually the max among false clauses
	if (clauseWeight[c]>falseClauseWeightMax){
		//delete falseClauseWeigth_InList
		for(k=0;k<falseClauseWeightMaxListSize;k++){
			int cc = falseClauseWeightMaxList[k];
			falseClauseWeight_InList[cc] = -1;
		}
		falseClauseWeightMax = clauseWeight[c];
		falseClauseWeightMaxList[0]=c;
		falseClauseWeightMaxListSize = 1;
		falseClauseWeight_InList[c] = 0;
	}
	else if (falseClauseWeightMax>1 && clauseWeight[c]==falseClauseWeightMax){
		falseClauseWeightMaxList[falseClauseWeightMaxListSize]=c;
		falseClauseWeight_InList[c]=falseClauseWeightMaxListSize;
		falseClauseWeightMaxListSize++;
	}
//	PrintClauseWeight();
//	PrintFalseClauseWeightMax();
}


void clauseMoveFromFalseToTrue(int c){
//	printf("\nclause %d move from FALSE to TRUE",c);
	int k;
	//remove clause from falseClauseWeightMax if it is has the max in falseClauseWeightMax
	if (falseClauseWeightMax>1 && clauseWeight[c]==falseClauseWeightMax){
		k = falseClauseWeight_InList[c];
		if (k<0){
			printf("\nERROR clauseWeight[%d] = falseClauseWeightMax = %d while falseClauseWeightmax_InList[%d] = %d",c,falseClauseWeightMax,c,k);
			exit(-1);
		}
		else {
			falseClauseWeight_InList[c] = -1;
			if (falseClauseWeightMaxListSize>1){
				if (k == falseClauseWeightMaxListSize-1){
					falseClauseWeightMaxListSize--;
				}
				else{
					int cc = falseClauseWeightMaxList[falseClauseWeightMaxListSize-1];
					falseClauseWeightMaxList[k] = falseClauseWeightMaxList[falseClauseWeightMaxListSize-1];
					falseClauseWeightMaxListSize--;
					falseClauseWeight_InList[cc] = k;
				}
			}
			else {
//				printf("\nFind falseClauseWeigthMax");
				findFalseClauseWeightMax();
			}
		}
	}
//	PrintClauseWeight();
//	PrintFalseClauseWeightMax();
}

void findFalseClauseWeightMax(){

	int i,c;
	falseClauseWeightMax = 1;
	falseClauseWeightMaxListSize = 0;
	for (i = 0; i < numFalse; i++) {
		c = falseClause[i];
		if (clauseWeight[c] > falseClauseWeightMax) {
			//Delete falseClauseWeightMax
			int j;
			for(j=0;j<falseClauseWeightMaxListSize;j++){
				falseClauseWeight_InList[falseClauseWeightMaxList[j]]=-1;
			}
			falseClauseWeightMax = clauseWeight[c];
			falseClauseWeightMaxList[0]=c;
			falseClauseWeightMaxListSize=1;
			falseClauseWeight_InList[c]=0;

		}
		else if (falseClauseWeightMax>1 && clauseWeight[c] == falseClauseWeightMax) {
			falseClauseWeightMaxList[falseClauseWeightMaxListSize]=c;
			falseClauseWeight_InList[c]=falseClauseWeightMaxListSize;
			falseClauseWeightMaxListSize++;

		}
	}

}

