mkdir binary
cd code/sattime2013 
icc sattime2013bis.c -O3 -static -o sattime  
#gcc sattime2013bis.c -O3 -o sattime 
cp sattime ../../binary
cd ..
./compile
cp go_sattime.sh ../binary
cp SCSeq.sh ../binary
cp clasp ../binary
