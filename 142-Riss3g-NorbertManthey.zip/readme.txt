riss3g version SAT Competition 2013
------------------------------------------
Authors:
------------------------------------------
code riss3g: Norbert Manthey - TU Dresden - norbert.manthey@tu-dresden.de
------------------------------------------

Compile & execute:
------------------------------------------
call the build.sh script 
cd binary
execute with ./riss3g.sh <instance>
------------------------------------------

Further Details
------------------------------------------
See SAT Competition 2013 solver description for further details!
------------------------------------------
