/**
 * Implementation of the data structures available in org.sat4j.specs.
 * Those classes were previously located in org.sat4j.minisat.core.
 */

package org.sat4j.core;

