/**
 * Tools to be used on top of an {@link org.sat4j.specs.ISolver}.
 */

package org.sat4j.tools;

