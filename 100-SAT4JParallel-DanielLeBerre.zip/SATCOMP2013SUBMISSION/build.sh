#!/bin/bash
BUILD=build
mkdir $BUILD
mkdir binary
cd code
javac -d ../$BUILD @files
cp sat4j.version ../$BUILD
cd ..
jar cmf code/manifest.mf binary/sat4j2013.jar -C $BUILD .
cp unsatproof.sh binary
rm -R $BUILD
