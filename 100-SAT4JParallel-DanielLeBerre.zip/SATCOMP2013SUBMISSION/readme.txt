SAT4J 2013
Daniel Le Berre
http://www.sat4j.org/

TO BUILD THE SOLVER

./build.sh

The file sat4j2013.jar is available in the directory binary

HOW TO RUN THE SOLVER

Default settings
java -jar sat4j2013.jar file.cnf

Certified unsat tracks
java -DUNSATPROOF=prooffile.txt -jar sat4j2013.jar file.cnf

Parallel tracks
java -jar sat4j2013.jar Parallel file.cnf

MEMORY SETTINGS

By default, the Oracle JVM does not use all the available memory.
A specific memory setting is necessary for using the 16 GB of memory
of the competition nodes.
Unfortunately, those settings are not accurate, especially when running
a 64 bits JVM. Different versions on different OS may behave quite differently.
As such, those settings may need to be adjusted for the competition environment.

By default, the setting is to use 12GB for the stack size.
java -Xms12g -Xmx12g -jar sat4j2013.jar file.cnf

The 12g might need to be decreased to have a total amount of memory used by the JVM
below the 16GB limit.
