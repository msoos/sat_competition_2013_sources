#!/bin/sh
rm -rf binary
mkdir binary
cd code; make all
cp Sparrow+CP3.sh ../binary
