#!/bin/bash
export FM=$PWD/code/SatELite/ForMani

mkdir binary

cp code/SRSeq.sh binary/
cp code/relback.sh binary/
cp code/SRSeqSattime.sh binary/

cd code/sattime2013 
icc sattime2013bis.c -O3 -static -o sattime
  
mv sattime ../../binary

cd ../SatELite/SatELite
make clean
make r
mv SatELite_release ../../../binary

cd ../../relback/core
make clean
make rs
mv relback_static ../../../binary


 
