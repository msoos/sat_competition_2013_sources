#!/bin/bash

if [ "x$1" = "x" ]; then
  echo "USAGE: SRSeq.sh INSTANCE -s SEED  cutofftime -tmp TMPDIR"
  exit 1
fi

echo "c Starting sattime"
./SRSeqSattime.sh $1 $3 $4
X=$?
if [ $X != 10 ]; then
  echo "c Starting Relback"
if [ "x$6" != "x" ]; then
./relback.sh $1 -tmp $6
X=$?
exit $X
fi
./relback_static $1
X=$?
exit $X
fi

