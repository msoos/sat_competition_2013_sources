gcc code/gb_flip.c code/dk-3-look.c -O2 -o binary/dk-3-look
gcc code/gb_flip.c code/dk-k-look.c -O2 -o binary/dk-k-look
cp code/dk-run.sh binary/
