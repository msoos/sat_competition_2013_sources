Author:
Mate Soos (soos.mate@gmail.com)

Name:
forl

Description:
A special version of CryptoMiniSat prepared for SAT Comp'13

* This version does not output UNSAT proofs
* Only single-threaded
* Uses M4RI linear algebra library from
    http://m4ri.sagemath.org/downloads/
  with licence GPLv2

Needs:
* boost
* cmake

Build:
Use "cmake -DCMAKE_BUILD_TYPE=Release"

Usage:
./forl-nodrup problem.CNF
