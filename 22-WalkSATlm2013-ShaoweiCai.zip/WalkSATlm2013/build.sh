#!/bin/bash

mkdir binary

cd code

make

cp WalkSATlm2013 ../binary/WalkSATlm2013

