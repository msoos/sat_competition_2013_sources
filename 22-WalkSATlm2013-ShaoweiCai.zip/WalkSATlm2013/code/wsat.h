/*********************************** WalkSATlm2013 ************************************
** WalkSATlm2013, is a local search solver for SAT.                                  **
** It is designed and implemented by Shaowei Cai during 2012-2013.                   **
** For random 3-SAT instances, WalkSATlm2013 simply calls WalkSAT.                   **
** For random k-SAT instances with k>3, WalkSATlm2013 calls the WalkSATlm algorithm. **
** WalkSATlm woks the same with WalkSAT except for the tie-breaking mechanism, where **
** it utilizes lmake(x)=a*make(x)+b*make_2(x) and picks the one with the greatest    **
** lmake value. This modification improves the algorithm dramatically for random     **
** k-SAT with k>3.                                                                   **
** Reference: Improving WalkSAT for Random k-Satisfiability Problem with k>3,        **
**            in Proc. of AAAI-2013.                                                 **
** You can find me on www.shaoweicai.net, or email to shaoweicai.cs@gmail.com.       **
**************************************************************************************/


#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cmath>

using namespace std;

/* limits on the size of the problem. */
#define MAX_VARS    4000010
#define MAX_CLAUSES 17000000

#define pop(stack) stack[--stack ## _fill_pointer]
#define push(item, stack) stack[stack ## _fill_pointer++] = item

// Define a data structure for a literal in clauses
struct lit {
		//int	clause_num;		//clause num, begin with 0
     	int	var_num;		//variable num, begin with 1
     	bool sense;			//is 1 for positive literals, 0 for negative literals.
};

/*parameters of the instance*/
int     num_vars;			//var index from 1 to num_vars
int     num_clauses;		//clause index from 0 to num_clauses-1
int		max_clause_len;
int		min_clause_len;
double	ratio;				//clause to variable ratio

/* literal arrays */				
int*	var_poslit[MAX_VARS];				//var_lit[v][j]: the clause number of the clause that the j'th positive literal of v occurs in.
int*	var_neglit[MAX_VARS];
int		var_poslit_count[MAX_VARS];
int		var_neglit_count[MAX_VARS];

lit*	clause_lit[MAX_CLAUSES];			//clause_lit[i][j] means the j'th literal of clause i.
int		clause_lit_count[MAX_CLAUSES]; 		// amount of literals in each clause				
			
/* Information about the variables. */
int		bbreak[MAX_VARS];			//break(x), the smaller the better
//int		gmake[MAX_VARS];			//combination of make(x) and pmake(x)


/* Information about the clauses */
int     sat_count[MAX_CLAUSES];			
int		sat_var[MAX_CLAUSES];

//unsat clauses stack
int		unsat_stack[MAX_CLAUSES];		//store the unsat clause number
int		unsat_stack_fill_pointer;
int		index_in_unsat_stack[MAX_CLAUSES];//which position is a clause in the unsat_stack

/* Information about solution */
bool     cur_soln[MAX_VARS];	//the current solution, with 1's for True variables, and 0's for False variables

//cutoff
int		max_tries = 100000;
unsigned int   	max_flips = 4000000000u;
unsigned int	 step;


const int   	  MY_RAND_MAX_INT =   10000000;
const float 	BASIC_SCALE = 0.0000001; //1.0f/MY_RAND_MAX_FLOAT;

double 		wp; // the noise parameter


int build_instance(char *filename)
{
	char    line[1024];
	char    tempstr1[10];
	char    tempstr2[10];
	int     cur_lit;
	int     i,j;
	int		v,c;//var, clause
	
	ifstream infile(filename);
	if(infile==NULL) {
		cout<<"Invalid filename: "<< filename<<endl;
		return 0;
	}

	/*** build problem data structures of the instance ***/
	infile.getline(line,1024);
	while (line[0] != 'p') infile.getline(line,1024);

	sscanf(line, "%s %s %d %d", tempstr1, tempstr2, &num_vars, &num_clauses);
	ratio = (double)num_clauses/num_vars;
	
	for (c = 0; c < num_clauses; c++) clause_lit_count[c] = 0;
	for (v=1; v<=num_vars; ++v) 
	{
		var_poslit_count[v] = 0;
		var_neglit_count[v] = 0;
	}
	
	max_clause_len = 0;
	min_clause_len = num_vars;
	
	int *temp_lit = new int [num_vars+1];//local
		
	//Now, read the clauses, one at a time.
	for (c = 0; c < num_clauses; c++) 
	{
		infile>>cur_lit;
		while (cur_lit != 0) { 
			temp_lit[clause_lit_count[c]] = cur_lit;
			clause_lit_count[c]++;
		
			infile>>cur_lit;
		}
		
		clause_lit[c] = new lit[clause_lit_count[c]+1];
		
		for(i=0; i<clause_lit_count[c]; ++i)
		{
			//clause_lit[c][i].clause_num = c;
			clause_lit[c][i].var_num = abs(temp_lit[i]);
			if (temp_lit[i] > 0) 
			{
				clause_lit[c][i].sense = 1;
				var_poslit_count[clause_lit[c][i].var_num]++;
			}
			else 
			{
				clause_lit[c][i].sense = 0;
				var_neglit_count[clause_lit[c][i].var_num]++;
			}
		}
		
		clause_lit[c][i].var_num = 0; 
		//clause_lit[c][i].clause_num = -1;
		
		if(clause_lit_count[c] > max_clause_len)
			max_clause_len = clause_lit_count[c];
		else if(clause_lit_count[c] < min_clause_len)
			min_clause_len = clause_lit_count[c];
	}
	infile.close();
	
	delete[] temp_lit;
	
	//creat var literal arrays
	for (v=1; v<=num_vars; ++v)
	{
		var_poslit[v] = new int[var_poslit_count[v]+1];
		var_poslit_count[v] = 0;	//reset to 0, for build up the array
		
		var_neglit[v] = new int[var_neglit_count[v]+1];
		var_neglit_count[v] = 0;
	}
	//scan all clauses to build up var literal arrays
	for (c = 0; c < num_clauses; ++c) 
	{
		for(i=0; i<clause_lit_count[c]; ++i)
		{
			v = clause_lit[c][i].var_num;
			
			if(clause_lit[c][i].sense==1)
			{
				var_poslit[v][var_poslit_count[v]] = c;
				++var_poslit_count[v];
			}
			else 
			{
				var_neglit[v][var_neglit_count[v]] = c;
				++var_neglit_count[v];
			}
		}
	}
	
	for (v=1; v<=num_vars; ++v)
	{
		//var_poslit[v][var_poslit_count[v]].var_num = 0;
		var_poslit[v][var_poslit_count[v]]=-1;
		
		//var_neglit[v][var_neglit_count[v]].var_num = 0;
		var_neglit[v][var_neglit_count[v]]=-1;
	}
	
	return 1;
}


void free_memory()
{
	int i;
	for (i = 0; i < num_clauses; i++) 
	{
		delete[] clause_lit[i];
	}
	
	for(i=1; i<=num_vars; ++i)
	{
		delete[] var_poslit[i];
		delete[] var_neglit[i];
	}
}


inline
void unsat(int clause)
{
	index_in_unsat_stack[clause] = unsat_stack_fill_pointer;
	push(clause,unsat_stack);
}


inline
void sat(int clause)
{
	int index,last_unsat_clause;

	//since the clause is satisfied, its position can be reused to store the last_unsat_clause
	last_unsat_clause = pop(unsat_stack);
	index = index_in_unsat_stack[clause];
	unsat_stack[index] = last_unsat_clause;
	index_in_unsat_stack[last_unsat_clause] = index;
}

//initiation of the algorithm
void init()
{
	int 		v,c;
	int			i,j;
	int			clause;
	
	//init solution
	for (v = 1; v <= num_vars; v++) {
		if(rand()%2==1) cur_soln[v] = 1;
		else cur_soln[v] = 0;
	}

	/* figure out sat_count, and init unsat_stack */
	unsat_stack_fill_pointer = 0;
	for (c=0; c<num_clauses; ++c) 
	{
		sat_count[c] = 0;
		
		for(j=0; j<clause_lit_count[c]; ++j)
		{
			if (cur_soln[clause_lit[c][j].var_num] == clause_lit[c][j].sense)
			{
				sat_count[c]++;
				sat_var[c] = clause_lit[c][j].var_num;	
			}
		}

		if (sat_count[c] == 0) unsat(c);
	}

	/*calculate the break values*/
	int * truep, * falsep;
	for (v=1; v<=num_vars; v++) 
	{
		bbreak[v] = 0;
		
		if (cur_soln[v]==1)
		{
			for (truep=var_poslit[v]; (c=*truep)!=-1; truep++)
			{
				if (sat_count[c]==1) bbreak[v]++;
			}	
		}
		else
		{
			for (falsep=var_neglit[v]; (c=*falsep)!=-1; falsep++)
			{
				if (sat_count[c]==1) bbreak[v]++;
			}	
		}
	}

}

void flip_simp(int flipvar)
{
	int c;
	int * truep, * falsep;
	
	cur_soln[flipvar] = 1 - cur_soln[flipvar];
	
	if (cur_soln[flipvar]==1) {truep=var_poslit[flipvar]; falsep=var_neglit[flipvar];}
	else {truep = var_neglit[flipvar]; falsep = var_poslit[flipvar];}
	
	for (; (c=*truep)!=-1; truep++)
	{
		++sat_count[c];
		if (sat_count[c] == 1) sat(c); // sat_count from 0 to 1
	}
	
	for (; (c=*falsep)!=-1; falsep++)
	{
		--sat_count[c];
		if (sat_count[c] == 0) unsat(c); //	last_unsatvar[c]=flipvar;
	}
}
 
void flip_update(int flipvar)
{
	int i,j;
	int v,c;
	int index,last_goodvar;
	lit* clause_c;
	
	int * truep, * falsep;

	cur_soln[flipvar] = 1 - cur_soln[flipvar];
	
	if (cur_soln[flipvar]==1) {truep=var_poslit[flipvar]; falsep=var_neglit[flipvar];}
	else {truep = var_neglit[flipvar]; falsep = var_poslit[flipvar];}
	
	//update related clauses and neighbor vars
	for (; (c=*truep)!=-1; truep++)
	{
		++sat_count[c];
			
		if (sat_count[c] == 2) 
			bbreak[sat_var[c]]--;
		else if (sat_count[c] == 1) 
		{
			sat_var[c] = flipvar;//record the only true lit's var
			bbreak[flipvar]++;
			sat(c);
		}
	}
	
	for (; (c=*falsep)!=-1; falsep++)
	{
		clause_c = clause_lit[c];
		--sat_count[c];
		if (sat_count[c] == 1) 
		{
			for(j=0; j<clause_lit_count[c]; ++j)
			{
				if(clause_c[j].sense == cur_soln[clause_c[j].var_num] )
				{
					sat_var[c] = clause_c[j].var_num;
					bbreak[clause_c[j].var_num]++;
					break;
				}
			}
		}
		else if (sat_count[c] == 0) 
		{
			bbreak[flipvar]--;
			unsat(c);
		}
	}
}

void (* flip)(int flipvar);

/*the following functions are non-algorithmic*/

void print_solution()
{
     int    i;

    cout<<"v ";
    for (i=1; i<=num_vars; i++) {
		if(cur_soln[i]==0) cout<<"-";
		cout<<i;
		
		if(i%10==0) 
		{
			cout<<endl;
			cout<<"v ";
		}
		else cout<<' ';
     }
     cout<<"0"<<endl;
}


int verify_sol()
{
	int c,j; 
	int flag;
	
	for (c = 0; c<num_clauses; ++c) 
	{
		flag = 0;
		for(j=0; j<clause_lit_count[c]; ++j)
			if (cur_soln[clause_lit[c][j].var_num] == clause_lit[c][j].sense) {flag = 1; break;}

		if(flag ==0){//output the clause unsatisfied by the solution
			cout<<"clause "<<c<<" is not satisfied"<<endl;
			
			for(j=0; j<clause_lit_count[c]; ++j)
			{
				if(clause_lit[c][j].sense==0)cout<<"-";
				cout<<clause_lit[c][j].var_num<<" ";
			}
			cout<<endl;
			
			for(j=0; j<clause_lit_count[c]; ++j)
				cout<<cur_soln[clause_lit[c][j].var_num]<<" ";
			cout<<endl;

			return 0;
		}
	}
	return 1;
}

