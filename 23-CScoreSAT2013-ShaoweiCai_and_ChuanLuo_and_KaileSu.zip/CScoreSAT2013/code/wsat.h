#include "basis.h"

void flip_simp(int flipvar)
{
	int c;
	cur_soln[flipvar] = 1 - cur_soln[flipvar];
	
	for(lit *q = var_lit[flipvar]; (c=q->clause_num)!=-1; q++)
	{
		if(cur_soln[flipvar] == q->sense)
		{
			++sat_count[c];
			if (sat_count[c] == 1) sat(c);
		}
		else
		{
			--sat_count[c];
			if (sat_count[c] == 0) unsat(c);
		}
	}
}
 
int pickvar_wsat()
{
	int		k,c,v,ci;
	int 	bestvar_array[100];
	int		bestvar_count;
	int		best_bbreak;
	lit		*p, *q;
	
	c = unsat_stack[rand()%unsat_stack_fill_pointer];
	
    v = clause_lit[c][0].var_num;
    bbreak[v]=0;
    for(q = var_lit[v]; (ci=q->clause_num)!=-1; q++)
    {
        if (sat_count[ci]==1 && q->sense==cur_soln[v]) 
            bbreak[v]++;
    }
    best_bbreak = bbreak[v];
    bestvar_array[0] = v;
    bestvar_count = 1;
	
	for(k=1; k<clause_lit_count[c]; ++k)
	{
		v = clause_lit[c][k].var_num;
		bbreak[v]=0;
		for(q = var_lit[v]; (ci=q->clause_num)!=-1; q++)
		{
			if (sat_count[ci]==1 && q->sense==cur_soln[v]) 
			{
				bbreak[v]++;
                if (bbreak[v]>best_bbreak) break;
			}
		}
		
		if (bbreak[v] < best_bbreak)
		{
			best_bbreak = bbreak[v];
			bestvar_array[0] = v;
			bestvar_count = 1;
		}
		else if (bbreak[v] == best_bbreak)
		{
			bestvar_array[bestvar_count]=v;
			++bestvar_count;
		}
	}
	
	if(best_bbreak == 0) return bestvar_array[rand()%bestvar_count];
    
	if( (rand()%MY_RAND_MAX_INT)*BASIC_SCALE < wp) return clause_lit[c][rand()%clause_lit_count[c]].var_num;
	else	return bestvar_array[rand()%bestvar_count];
	
}