#ifndef _BASIS_H_
#define _BASIS_H_

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cmath>

using namespace std;

/* limits on the size of the problem. */
#define MAX_VARS    4000010
#define MAX_CLAUSES 17000000

#define pop(stack) stack[--stack ## _fill_pointer]
#define push(item, stack) stack[stack ## _fill_pointer++] = item

// Define a data structure for a literal in the SAT problem.
struct lit {
	int             clause_num;		//clause num, begin with 0
    int             var_num;		//variable num, begin with 1
    bool            sense;			//is 1 for true literals, 0 for false literals.
};

/*parameters of the instance*/
int     KSAT;
int     num_vars;                   //var index from 1 to num_vars
int     num_clauses;                //clause index from 0 to num_clauses-1
int		max_clause_len;
int		min_clause_len;
double  ratio;

/* literal arrays */				
lit*	var_lit[MAX_VARS];                  //var_lit[i][j] means the j'th literal of var i.
int		var_lit_count[MAX_VARS];			//amount of literals of each var
lit*	clause_lit[MAX_CLAUSES];			//clause_lit[i][j] means the j'th literal of clause i.
int		clause_lit_count[MAX_CLAUSES]; 		// amount of literals in each clause			
			
/* Information about the clauses */			
int     sat_count[MAX_CLAUSES];			

//unsat clauses stack
int		unsat_stack[MAX_CLAUSES];           //store the unsat clause number
int		unsat_stack_fill_pointer;
int		index_in_unsat_stack[MAX_CLAUSES];  //which position does a clause stays in the unsat_stack

/* Information about solution */
bool    cur_soln[MAX_VARS];

//cutoff
int                max_tries = 10000;
unsigned int       max_flips = 4000000000u;
unsigned int 	   step;

//for probability
const int   	  MY_RAND_MAX_INT = 10000000;
const float 	  BASIC_SCALE = 0.0000001; //1.0f/MY_RAND_MAX_FLOAT;

/***************** begin data structure for CScoreSAT ***************************/
#define MAX_VARS_LARGEKSAT    1000010
#define MAX_CLAUSES_LARGEKSAT 10000010

//sat var 
int		sat_var[MAX_CLAUSES_LARGEKSAT];
int		sat_var2[MAX_CLAUSES_LARGEKSAT];

// cc based on variables' neighbors
bool	conf_change[MAX_VARS_LARGEKSAT];
int     use_neighbor=0;
int*    var_neighbor[MAX_VARS_LARGEKSAT];
int		var_neighbor_count[MAX_VARS_LARGEKSAT];

// for comprehensive score
int     score[MAX_VARS_LARGEKSAT];	
int		pscore[MAX_VARS_LARGEKSAT];
int 	divisor; //cscore = score+pscore/divisor;
int 	delta_age;//hscore = cscore + age/delta_age;

int     clause_weight[MAX_CLAUSES_LARGEKSAT];	
unsigned int		time_stamp[MAX_VARS_LARGEKSAT];

//configuration changed decreasing variables (score>0 and confchange=1)
int		goodvar_stack[MAX_VARS_LARGEKSAT];		
int		goodvar_stack_fill_pointer;
bool	already_in_goodvar_stack[MAX_VARS_LARGEKSAT];
/****************** end data structure for CScoreSAT ***************************/

/***************** begin data structure for WalkSAT ***************************/
int     bbreak[MAX_VARS];
double 	wp; // the noise parameter
/***************** end data structure for WalkSAT ***************************/

int  build_instance(char *filename);
void init();
void build_neighbor_relation();
void free_memory_common();


/* satisfy and unsatisfy a clause*/
inline void unsat(int clause)
{
	index_in_unsat_stack[clause] = unsat_stack_fill_pointer;
	push(clause,unsat_stack);
}

inline void sat(int clause)
{
	int index,last_unsat_clause;
    
	//since the clause is satisfied, its position can be reused to store the last_unsat_clause
	last_unsat_clause = pop(unsat_stack);
	index = index_in_unsat_stack[clause];
	unsat_stack[index] = last_unsat_clause;
	index_in_unsat_stack[last_unsat_clause] = index;
}


int build_instance(char *filename)
{
	char            line[10240];
    int             temp_lit[10240];
	char            tempstr1[10];
	char            tempstr2[10];
	int             cur_lit;
	int             i,v,c;
	
	ifstream infile(filename);
	if(infile==NULL) 
    {
        cout<<"Invalid filename: "<<filename<<endl;
        return 0;
    }

	/*** build problem data structures of the instance ***/
	infile.getline(line,10240);
	while (line[0] != 'p')
		infile.getline(line,10240);

	sscanf(line, "%s %s %d %d", tempstr1, tempstr2, &num_vars, &num_clauses);
	ratio = (double)num_clauses/num_vars;
	
	if(num_vars>=MAX_VARS || num_clauses>=MAX_CLAUSES)
	{
		cout<<"the size of instance exceeds out limitation, please enlarge MAX_VARS and (or) MAX_CLAUSES."<<endl;
		exit(-1);
	}
	
	for (c = 0; c < num_clauses; c++) clause_lit_count[c] = 0;
	for (v=1; v<=num_vars; ++v) var_lit_count[v] = 0;
		
	max_clause_len = 0;
	min_clause_len = num_vars;
	
	//Now, read the clauses, one at a time.
	for (c = 0; c < num_clauses; c++) 
	{
		infile>>cur_lit;

		while (cur_lit != 0) { 
			temp_lit[clause_lit_count[c]] = cur_lit;
			clause_lit_count[c]++;
		
			infile>>cur_lit;
		}
		
		clause_lit[c] = new lit[clause_lit_count[c]+1];
		
		for(i=0; i<clause_lit_count[c]; ++i)
		{
			clause_lit[c][i].clause_num = c;
			clause_lit[c][i].var_num = abs(temp_lit[i]);
			if (temp_lit[i] > 0) clause_lit[c][i].sense = 1;
				else clause_lit[c][i].sense = 0;
			
			var_lit_count[clause_lit[c][i].var_num]++;
		}
		clause_lit[c][i].var_num=0; 
		clause_lit[c][i].clause_num = -1;
		
		if(clause_lit_count[c] > max_clause_len)
			max_clause_len = clause_lit_count[c];
		else if(clause_lit_count[c] < min_clause_len)
			min_clause_len = clause_lit_count[c];
	}
	infile.close();

	//creat var literal arrays
	for (v=1; v<=num_vars; ++v)
	{
		var_lit[v] = new lit[var_lit_count[v]+1];
		var_lit_count[v] = 0;	//reset to 0, for build up the array
	}
	//scan all clauses to build up var literal arrays
	for (c = 0; c < num_clauses; ++c) 
	{
		for(i=0; i<clause_lit_count[c]; ++i)
		{
			v = clause_lit[c][i].var_num;
			var_lit[v][var_lit_count[v]] = clause_lit[c][i];
			++var_lit_count[v];
		}
	}
	for (v=1; v<=num_vars; ++v) var_lit[v][var_lit_count[v]].clause_num=-1;
	
	//problem type
	if(max_clause_len == min_clause_len) KSAT = max_clause_len;
	else KSAT = 0; //non-ksat.

	return 1;
}

void init()
{
	int 		v,c,i;
    
	//init solution
	for (v = 1; v <= num_vars; v++) {
		if(rand()%2==1) cur_soln[v] = 1;
		else cur_soln[v] = 0;
	}
    
	/* figure out sat_count, and init unsat_stack */
	unsat_stack_fill_pointer = 0;
	for (c=0; c<num_clauses; ++c) 
	{
		sat_count[c] = 0;
		
		for(i=0; i<clause_lit_count[c]; ++i)
		{
			if (cur_soln[clause_lit[c][i].var_num] == clause_lit[c][i].sense)
			{
				sat_count[c]++;
				sat_var[c] = clause_lit[c][i].var_num;	
			}
		}
        
		if (sat_count[c] == 0) unsat(c);
	}
	
	if(KSAT>3)
	{
        for (c = 0; c<num_clauses; c++) 
            clause_weight[c] = 1;
        
        for (v = 1; v <= num_vars; v++) 
        {
            score[v] = 0;
            pscore[v] = 0;
            time_stamp[v] = 0;
            conf_change[v] = 1;
        }
        
        /*figure out var score*/
        for (v=1; v<=num_vars; v++) 
        {
            for(i=0; i<var_lit_count[v]; ++i)
            {
                c = var_lit[v][i].clause_num;
                if (sat_count[c]==0) score[v]++;
                else if (sat_count[c]==1 && var_lit[v][i].sense==cur_soln[v]) score[v]--;
            }
        }
        
		int flag;
		//compute pscore and record sat_var and sat_var2 for 2-sat clauses
		for (c=0; c<num_clauses; ++c) 
		{
			if (sat_count[c]==1)
			{
				for(i=0; i<clause_lit_count[c];++i)
				{
					v=clause_lit[c][i].var_num;
					if(v!=sat_var[c])pscore[v]++;
				}
			}
			else if(sat_count[c]==2)
			{
				flag=0;
				for(i=0; i<clause_lit_count[c];++i)
				{
					v=clause_lit[c][i].var_num;
					if(clause_lit[c][i].sense == cur_soln[v])
					{
						pscore[v]--;
						if(flag==0){sat_var[c] = v; flag=1;}
						else	{sat_var2[c] = v; break;}
					}
				}
			}
		}
        
        //init goodvars stack
        goodvar_stack_fill_pointer = 0;
        for (v=1; v<=num_vars; v++) 
        {
            if(score[v]>0)// && conf_change[v]==1)
            {
                already_in_goodvar_stack[v] = 1;
                push(v,goodvar_stack);
            }
            else already_in_goodvar_stack[v] = 0;
        }
        
        //setting for the virtual var 0
        time_stamp[0]=0;
        pscore[0]=0;
        
        //build neighbor relations for variables, as CScoreSAT utilizes CC based on variables' neighbors
        build_neighbor_relation();
	}
}


void build_neighbor_relation()
{
	int*	neighbor_flag = new int[num_vars+1];
	int     i,j,count;
	int 	v,c;
    
	for(v=1; v<=num_vars; ++v)
	{
		var_neighbor_count[v] = 0;
        
		for(i=1; i<=num_vars; ++i)
			neighbor_flag[i] = 0;
		neighbor_flag[v] = 1;
		
		for(i=0; i<var_lit_count[v]; ++i)
		{
			c = var_lit[v][i].clause_num;
			for(j=0; j<clause_lit_count[c]; ++j)
			{
				if(neighbor_flag[clause_lit[c][j].var_num]==0)
				{
					var_neighbor_count[v]++;
					neighbor_flag[clause_lit[c][j].var_num] = 1;
				}
			}
		}
        
		neighbor_flag[v] = 0;
        
		var_neighbor[v] = new int[var_neighbor_count[v]+1];
        
		count = 0;
		for(i=1; i<=num_vars; ++i)
		{
			if(neighbor_flag[i]==1)
			{
				var_neighbor[v][count] = i;
				count++;
			}
		}
		var_neighbor[v][count]=0;
	}
    
    use_neighbor = 1;
	
	delete[] neighbor_flag; neighbor_flag=NULL;
    
}



void print_solution()
{
     int    i;

     cout<<"v ";
     for (i=1; i<=num_vars; i++) {
         if(cur_soln[i]==0) cout<<"-";
         cout<<i;
         
         if(i%10==0) cout<<endl<<"v ";
         else cout<<' ';
     }
     cout<<"0"<<endl;
}


int verify_sol()
{
	int c,j; 
	int flag;
	
	for (c = 0; c<num_clauses; ++c) 
	{
		flag = 0;
		for(j=0; j<clause_lit_count[c]; ++j)
			if (cur_soln[clause_lit[c][j].var_num] == clause_lit[c][j].sense) {flag = 1; break;}

		if(flag ==0)
        {   //output the clause unsatisfied by the solution
			cout<<"clause "<<c<<" is not satisfied"<<endl;
			
			for(j=0; j<clause_lit_count[c]; ++j)
			{
				if(clause_lit[c][j].sense==0)cout<<"-";
				cout<<clause_lit[c][j].var_num<<" ";
			}
			cout<<endl;
			
			for(j=0; j<clause_lit_count[c]; ++j)
				cout<<cur_soln[clause_lit[c][j].var_num]<<" ";
			cout<<endl;

			return 0;
		}
	}
	return 1;
}


void free_memory()
{
	int i;
	for (i = 0; i < num_clauses; i++) 
		if(clause_lit[i]!=NULL) delete[] clause_lit[i];
    
	for(i=1; i<=num_vars; ++i)
		if (var_lit[i]!=NULL) delete[] var_lit[i];
    
    if (use_neighbor==1) {
        for(i=1; i<=num_vars; ++i)
            if(var_neighbor[i]!=NULL) delete[] var_neighbor[i];
    }
}

#endif

