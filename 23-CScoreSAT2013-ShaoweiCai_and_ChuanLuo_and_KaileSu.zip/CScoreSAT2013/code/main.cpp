/*********************************** CScoreSAT2013 ************************************
** CScoreSAT2013, is a local search solver for SAT.                                  **
** It is designed and implemented by Shaowei Cai during 2012-2013.                   **
** For random 3-SAT instances, CScoreSAT2013 simply calls WalkSAT.                   **
** For random k-SAT instances with k>3, CScoreSAT2013 calls the CScoreSAT algorithm. **
** You can find me on www.shaoweicai.net, or email to shaoweicai.cs@gmail.com.       **
**************************************************************************************/

/*********************************** CScoreSAT ****************************************
** CScoreSAT, is a local search algorithm for SAT, and is especially good at solving **
** instances with long clauses.                                                      **
** It is designed and implemented by Shaowei Cai during 2012-2013.                   **
** Main ideas:                                                                       **
** Comprehensive Score: cscore(x)=score(x)+subscore(x)/d.                            **
** Hybrid Score: score(x) = cscore(x)+age(x)/b.                                      **
** CScoreSAT picks a varialbe to flip according to the cscore funtion in the greedy  **
** search mode, and does so according to the hscore function in the diversification  **
** search mode.                                                                      **
** Reference: Comprehensive Score: Towards Efficient Local Search for SAT with Long  **
**            Clauses, In Proc. IJCAI-2013.                                          **
**************************************************************************************/


#include "basis.h"
#include "wsat.h"
#include "cscore.h"

#include <sys/times.h> //these two h files are for linux
#include <unistd.h>

void (* flip)(int);
int (* pickvar) ();

//set functions in the algorithm
void set_fun_and_par()
{	
	if(max_clause_len<=3)
	{
		flip = flip_simp;
		pickvar = pickvar_wsat;
        
        /*if(ratio<=4.23) wp = 0.567;
		else if (ratio<4.26) wp = 1.62425-0.25*ratio;
		else wp = 3.541 - 0.7*ratio;*/
		
		if(ratio<=4.22) wp = 0.567;
		else if(ratio<=4.23) wp = 0.567-(ratio-4.2)/20;
		else if (ratio<4.26) wp = 0.561-(ratio-4.252)*7/30;
		else wp = 0.554-(ratio-4.267)*2/5;
		
		cout<<"c Algorithmic: WalkSAT"<<endl;
		cout<<"c Algorithmic: Noise = "<<wp<<endl;

	}
	else 
    {
		flip = flip_large;
		pickvar = pickvar_large;
        
        divisor = 13 - max_clause_len;
        if(divisor<3) divisor=3;
        delta_age = 2000;
        
        if(max_clause_len==4) smooth_probability = 0.62;
        
        else if(max_clause_len==5) smooth_probability = 0.045*ratio - 0.29; //(0.61-0.66)
        
        else if(max_clause_len==6) smooth_probability = 0.9;
        
        else if(max_clause_len>=7) smooth_probability = 0.92;
        
        cout<<"c Algorithmic: CScoreSAT"<<endl;
        cout<<"c Algorithmic: cscore=score+subscore/d, d = "<<divisor<<endl;
        cout<<"c Algorithmic: hscore=cscore+age/b, b = "<<delta_age<<endl;
		cout<<"c Algorithmic: Smooth Probability for PAWS = "<<smooth_probability<<endl;
	}
}


void local_search(int max_flips)
{
	int flipvar;
    
	for (step = 0; step<max_flips; step++)
	{
		if(unsat_stack_fill_pointer==0) return;
		
		flipvar = pickvar();
		flip(flipvar);
	}
}


int main(int argc, char* argv[])
{
	int     seed,tries;
	int		satisfy_flag=0;
	struct tms start, stop;
	
	cout<<"c This is CScoreSAT2013 [Version 2013.4.8] [Author: Shaowei Cai]."<<endl;
	
	times(&start);

	if (build_instance(argv[1])==0) return -1;
     
    sscanf(argv[2],"%d",&seed);
    
    //sscanf(argv[3],"%f",&smooth_probability);
    //sscanf(argv[4],"%d",&large_clause_count_threshold);
    //sscanf(argv[5],"%d",&delta_age);

    srand(seed);
    //cout<<seed<<' ';

    cout<<"c Instance: Max clause length = "<<max_clause_len<<endl;
    cout<<"c Instance: Min clause length = "<<min_clause_len<<endl;
	cout<<"c Instance: Number of variables = "<<num_vars<<endl;
	cout<<"c Instance: Number of clauses = "<<num_clauses<<endl;
	cout<<"c Instance: Ratio = "<<ratio<<endl;
	cout<<"c Algorithmic: Random seed = "<<seed<<endl;
    
	set_fun_and_par();
	
	init();
	
	for (tries = 0; tries < max_tries; tries++) 
	{
		 local_search(max_flips);
		 
		 if (unsat_stack_fill_pointer==0) 
		 {
		 	if(verify_sol()==1) {satisfy_flag = 1; break;}
		    else cout<<"c Sorry, something is wrong."<<endl;/////
		 }
	}

	if(satisfy_flag==1)
    {
    	cout<<"s SATISFIABLE"<<endl;
		print_solution();
    }
    else  cout<<"s UNKNOWN"<<endl;
    
    times(&stop);
	double comp_time = double(stop.tms_utime - start.tms_utime +stop.tms_stime - start.tms_stime) / sysconf(_SC_CLK_TCK);
    
    cout<<"c solveSteps = "<<tries<<" tries + "<<step<<" steps (each try has "<<max_flips<<" steps)."<<endl;
    cout<<"c solveTime = "<<comp_time<<endl;
	 
	free_memory();

    return 0;
}
