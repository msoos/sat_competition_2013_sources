
#ifndef _CSCORESAT_H_
#define _CSCORESAT_H_

#include "basis.h"

void flip_large(int flipvar);
int  pickvar_large();
void update_clause_weights();

void flip_large(int flipvar)
{
	cur_soln[flipvar] = 1 - cur_soln[flipvar];
	
	int  c,v;
	lit* clause_c;
	lit* p;
	
	int org_flipvar_score = score[flipvar];
    int org_flipvar_pscore = pscore[flipvar];

	//update related clauses and neighbor vars
	for(lit *q = var_lit[flipvar]; (c=q->clause_num)>=0; q++)
	{
		clause_c = clause_lit[c];

		if(cur_soln[flipvar] == q->sense)
		{
			++sat_count[c];
			
			if(sat_count[c] == 3)
			{
				pscore[sat_var[c]]++;
				pscore[sat_var2[c]]++;
			}
			
			else if (sat_count[c] == 2) //sat_count from 1 to 2
			{
				score[sat_var[c]] += clause_weight[c];
				sat_var2[c]=flipvar;
				
				for(p=clause_c; p->var_num!=0; p++) pscore[p->var_num]--;
			}
			else if (sat_count[c] == 1) // sat_count from 0 to 1
			{
				sat_var[c] = flipvar;//record the only true lit's var
				
				for(p=clause_c; (v=p->var_num)!=0; p++) 
				{
					score[v] -= clause_weight[c];
					pscore[v]++;
				}
				
				sat(c);
			}
		}
		else // cur_soln[flipvar] != cur_lit.sense
		{
			--sat_count[c];
			if (sat_count[c] == 2)
			{	
				for(p=clause_c; (v=p->var_num)!=0; p++)
				{
					if(p->sense == cur_soln[v])
					{
						pscore[v]--;
                        sat_var[c]=v;
                        break;
					}
				}
                for(p++; (v=p->var_num)!=0; p++)
				{
					if(p->sense == cur_soln[v])
					{
						pscore[v]--;
                        sat_var2[c]=v;
                        break;
					}
				}
			}
			else if (sat_count[c] == 1) //sat_count from 2 to 1
			{				
				for(p=clause_c; p->var_num!=0; p++) ++pscore[p->var_num];
				
				if(sat_var[c]==flipvar)
				{	
					sat_var[c]=sat_var2[c];
				}
				score[sat_var[c]] -= clause_weight[c];
			}
			else if (sat_count[c] == 0) //sat_count from 1 to 0
			{
				for(p=clause_c; (v=p->var_num)!=0; p++)
				{
					score[v] += clause_weight[c];
					pscore[v]--;
				}

				unsat(c);
				
			}//end else if
			
		}//end else
	}

	//update information of flipvar
	score[flipvar] = -org_flipvar_score;
    pscore[flipvar] = -org_flipvar_pscore;
	
	/*update CC */
	int index;
	
	conf_change[flipvar] = 0;
	//remove the vars no longer goodvar in goodvar stack 
	for(index=goodvar_stack_fill_pointer-1; index>=0; index--)
	{
		v = goodvar_stack[index];
		if(score[v]<0 || (score[v]==0 && pscore[v]<divisor) )
		{
			goodvar_stack[index] = pop(goodvar_stack);
			already_in_goodvar_stack[v] = 0;
		}	
	}

	//update all flipvar's neighbor's conf_change to be 1, add goodvar
	int* intp;
	for(intp=var_neighbor[flipvar]; (v=*intp)!=0; intp++)
	{
		conf_change[v] = 1;
		
		if( (score[v]>0 || (score[v]==0 && pscore[v]>=divisor) ) && already_in_goodvar_stack[v] ==0)
		{
			push(v,goodvar_stack);
			already_in_goodvar_stack[v] = 1;
		}
	}
    
    time_stamp[flipvar] = step;
}


int pickvar_large()
{
	int         i,k,c,v;
	int         best_var, best_score, score_gap;
	lit*		clause_c;
	
	/*CCD (configuration changed decreasing) mode, the level with configuation chekcing*/
	if(goodvar_stack_fill_pointer>0)
	{
		best_var = goodvar_stack[0];
		
		for(i=1; i<goodvar_stack_fill_pointer; ++i)
		{
			v=goodvar_stack[i];
            score_gap = (score[v] - score[best_var]) + (pscore[v] - pscore[best_var])/divisor;
            if(score_gap>0)	best_var = v;
            else if(score_gap==0 && time_stamp[v]<time_stamp[best_var] ) best_var = v;
		}
		
		return best_var;
	}
    
	/**Diversification Mode**/
	update_clause_weights();
	
	/*random walk*/
	c = unsat_stack[rand()%unsat_stack_fill_pointer];
	clause_c = clause_lit[c];
	best_var = clause_c[0].var_num;
    
    for(k=1; k<clause_lit_count[c]; ++k)
    {
        v=clause_c[k].var_num;
        
        score_gap = (score[v] - score[best_var]) + (pscore[v] - pscore[best_var])/divisor+ (time_stamp[best_var]-time_stamp[v])/delta_age;
        if(score_gap>0)	best_var = v;
        else if(score_gap==0 && time_stamp[v]<time_stamp[best_var] ) best_var = v;
    }
    
	return best_var;
}


/**********************************clause weighting (PAWS) for large ksat with k>3*************************************************/

float  smooth_probability;
int    large_clause_count_threshold=10;
int    large_weight_clauses[MAX_CLAUSES];
int    large_weight_clauses_count=0;	

void update_clause_weights()
{
    int i, j, c, v;
    
	if( (rand()%MY_RAND_MAX_INT)*BASIC_SCALE<smooth_probability && large_weight_clauses_count>large_clause_count_threshold )//smooth
	{
		for(i=0; i<large_weight_clauses_count; i++)
        {
            c = large_weight_clauses[i];
            if(sat_count[c]>0)
            {
                clause_weight[c]--;
                
                if(clause_weight[c]==1)
                {
                    large_weight_clauses[i] = large_weight_clauses[--large_weight_clauses_count];
                    i--;
                }
                if(sat_count[c] == 1)
                {
                    v = sat_var[c];
                    score[v]++;
                    if(score[v]>0 || (score[v]==0 && pscore[v]>=divisor) )
                    {
                        if(conf_change[v]>0  && already_in_goodvar_stack[v] ==0)//
                        {
                            push(v,goodvar_stack);
                            already_in_goodvar_stack[v] =1;
                        }
                    }
                }
            }
        }//for
	}
	else //increase
	{
		for(i=0; i < unsat_stack_fill_pointer; ++i)
        {
            c = unsat_stack[i];
            clause_weight[c]++;
            if(clause_weight[c] == 2)
                large_weight_clauses[large_weight_clauses_count++] = c;
            
            for(lit* p=clause_lit[c]; (v=p->var_num)!=0; p++)
            {
                score[v]++;
                
                if(score[v]==1 || (score[v]==0 && pscore[v]>=divisor) )
                {
                    if(conf_change[v]>0  && already_in_goodvar_stack[v] ==0)
                    {
                        push(v,goodvar_stack);
                        already_in_goodvar_stack[v] =1;
                    }
                }
            }//small for
        }//for
	}
}


#endif

