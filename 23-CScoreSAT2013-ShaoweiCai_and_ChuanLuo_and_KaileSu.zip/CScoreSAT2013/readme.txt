This is CScoreSAT2013 version 2013.4.8.
Author: Shaowei Cai.
Email: shaoweicai.cs@gmail.com

To build the solver, please run build.sh, and it will generate a new folder /binary and compile the codes to generate the CScoreSAT2013 binary; 
additionally, the CScoreSAT2013 binary will be copied to the /binary folder.

Please run CScoreSAT2013 as
CScoreSAT2013 <instance file> <random seed>
