#!/bin/bash

mkdir binary

cd code

make

cp CScoreSAT2013 ../binary/CScoreSAT2013

