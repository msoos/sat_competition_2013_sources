Author:
Mate Soos (soos.mate@gmail.com)

Name:
strangenight

This is the same version of the code that was submitted to SAT Comp'11 as CryptoMiniSat "Strange Night", but with disjoint component finding turned off and a correct compilation script.

Notes:
* Does not provide UNSAT proofs
* Runs multi-threaded

how to use:
* single-threaded:
  ./strangenight --threads=1 problem.CNF

* muti-threaded:
  ./strangenight --threads=4 problem.CNF

