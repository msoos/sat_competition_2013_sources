#!/bin/bash

mkdir binary
cd binary
cmake -DCMAKE_BUILD_TYPE=Release ../code/
make -j
