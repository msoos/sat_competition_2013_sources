SparrowToRiss version SAT Competition 2013
------------------------------------------
Authors:
------------------------------------------
code Sparrow2013HC: Adrian Balint - Ulm University - adrian.balint@uni-ulm.de
code Riss+CP3: Norbert Manthey - TU Dresden - norbert.manthey@tu-dresden.de
based on code of glucose 2.1 
------------------------------------------

Compile & execute:
------------------------------------------
call the build.sh script 
cd binary
execute with ./SparrowToRiss.sh <instance> <seed>
------------------------------------------

Further Details
------------------------------------------
See SAT Competition 2013 solver description for further details!
------------------------------------------