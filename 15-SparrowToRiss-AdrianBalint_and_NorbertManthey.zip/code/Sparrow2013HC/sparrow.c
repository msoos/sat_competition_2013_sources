/**
 * sparrow.c v 2013HC
 * This code is based on the code used in the SAT 2010 paper.
 * The code is simplified and improved.
 * Original code was based on gNovelty+ code, which seems
 * to be strongly based on the walksat code by H. Kautz and B. Selmann
 * This is 2013HC competition version (HC stands for hard combinatorial)
 * Author: Adrian Balint
 */

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/times.h>
#include <string.h>
#include <limits.h>
#include <float.h>
#include <getopt.h>
#include <signal.h>

/*----DEFINEs----*/
//use weights or not!
#define WEIGHTS
//keep track of score, or of make, break
#define SCORE
//use gradient based search like in G2WSAT
#define GRADIENT
#undef LLONG_MAX
#define LLONG_MAX 9223372036854775807


#define MAXCLAUSELENGTH 10000 //maximum number of literals per clause
#define STOREBLOCK  20000

#define BIGINT unsigned long long int

#define getScore(VAR) (score[VAR])
#define setScore(VAR,VAL) (score[VAR]=VAL)
#define adjScore(VAR,VAL) (score[VAR]+=VAL)

#define incScore(VAR,CLS) (score[VAR]+=clauseWeight[CLS])
#define decScore(VAR,CLS) (score[VAR]-=clauseWeight[CLS])
#define BASECW 1 //base clause weight, when score used 1
/*--------*/

/*----Instance data (independent from assignment)----*/
/** The numbers of variables. */
int numVars;
/** The number of clauses. */
int numClauses;
/** The number of literals. */
int numLiterals;
/** The value of the variables. The numbering starts at 1 and the possible values are 0 or 1. */
int *atom;
/** The clauses of the formula represented as: clause[clause_number][literal_number].
 * The clause and literal numbering start both at 0.*/
int **clause;
/** The length of each clause.  */
int *clauseSize;
/**min and max clause length*/
int maxClauseSize;
int minClauseSize;
/** The number of occurrence of each literal.*/
int *numOccurrence;
/** The clauses where each literal occurs. For literal i : occurrence[i+MAXATOMS][j] gives the clause =
 * the j'th occurrence of literal i.  */
int **occurrence;
int maxNumOccurences = 0; //maximum number of occurences for a literal
/** neighbourVar[i] contains the array with all variables that are in the same clause with variable i*/
int **neighbourVar;
/*--------*/

/**----Assignment dependent data----*/
/** The number of false clauses.*/
int numFalse;
/** Array containing all clauses that are false. Managed as a list.*/
int *falseClause;
/** whereFalse[i]=j tells that clause i is listed in falseClause at position j.  */
int *whereFalse;
/** The number of true literals in each clause. */
int *numTrueLit;
/** critVar[i]=j tells that for clause i the variable j is critically responsible for satisfying i.*/
int *critVar1;
/**score[i] tells how the overall weigths of the clauses will change if i is flipped*/
int bestVar;

int *score;
BIGINT *varLastChange;

/*----Gradient variables----*/
int gradient;
/**number of decresing varaibles*/
int numDecVar;
/** decVar is a list of all variables that when flipped decrease the number of unsat clauses. */
int *decVar;
int *isCandVar;
/*--------*/

/*----Weighting variables----*/
int sp; //smoothing probability
int *clauseWeight; //the weight of  each clause
/*this saves the extra weight the variables gets in a weighted algorithm instantiation*/
int numWeight; //the number of clauses with weight>1
int *weightedClause; //a list with all clauses with weight>1
int *whereWeight; //whereWeight[i]=j tells that clause i is at position j in weightedClause
/*--------*/

/**----Statistics variables----*/BIGINT statNumGWalks;
BIGINT statNumSmooth; //how often a smoothing has been done.
/*--------*/

/*----Sparrow variables----*/
/** Look-up table for the exponential function within Sparrow. The values are computed in the initSparrowProbs method.*/
int const MAXSCORE=20;
double *scorePow;
double *scorePowPlus;
/** contains the probabilities of the variables from an unsatisfied clause*/
double *probs;
double c0, c1, inv_c3;
int c2, c3;
/*--------*/

/*----Input file variables----*/
FILE *fp;
char *fileName;
/*---------*/

/** Run time variables variables*/BIGINT seed;
BIGINT maxTries = LLONG_MAX;
BIGINT maxFlips = LLONG_MAX;
BIGINT flip;
float timeOut = FLT_MAX;
int run = 1;
int printSol = 1;
double tryTime;
double totalTime = 0.;
long ticks_per_second;
int bestNumFalse;
//Sparrow parameters flags - inidcates if the parameters were set on the command line
int c0_spec = 0, c1_spec = 0, c2_spec = 0, c3_spec = 0, sp_spec = 0;
/*---------*/

/*----Statistics variables----*/
BIGINT *timesFlipped; //stores the number of times a variable was fliped
FILE *sfp1=NULL;
char *sfileName1=NULL; //statistics file
FILE *sfp2=NULL;
char *sfileName2=NULL; //statistics file
struct varStat {
	int var;
	unsigned long long int stat;
};
/*---------*/

inline int abs(int a) {
	return (a < 0) ? -a : a;
}

int compare(void const *a, void const *b) { //for reversed order!
	struct varStat left = *((struct varStat *) a);
	struct varStat right = *((struct varStat *) b);
	if (left.stat < right.stat)
		return 1;
	if (left.stat > right.stat)
		return -1;
	return 0;
}

inline void printFormulaProperties() {
	fprintf(stderr, "c %-20s:  %s\n", "Instance name", fileName);
	fprintf(stderr, "c %-20s:  %d\n", "Number of variables", numVars);
	fprintf(stderr, "c %-20s:  %d\n", "Number of literals", numLiterals);
	fprintf(stderr, "c %-20s:  %d\n", "Number of Clauses", numClauses);
	fprintf(stderr, "c %-20s:  %d\n", "MaxNumOccurences", maxNumOccurences);
	fprintf(stderr, "c %-20s:  %d\n", "MaxClauseSize", maxClauseSize);
	fprintf(stderr, "c %-20s:  %d\n", "MinClauseSize", minClauseSize);
	fprintf(stderr, "c %-20s:  %6.4f\n", "Ratio", (float) numClauses / (float) numVars);
}

inline void printHeader() {
	fprintf(stderr, "---------------Sparrow 2013 SAT Solver---------------\n");
}

inline void printSolverParameters() {
	fprintf(stderr, "\nc Sparrow 2013 Parameters: \n");
	fprintf(stderr, "c %-20s: %6.4f\n", "c0", c0);
	fprintf(stderr, "c %-20s: %6.4f\n", "c1", c1);
	fprintf(stderr, "c %-20s: %d\n", "c2", c2);
	fprintf(stderr, "c %-20s: %d\n", "c3", c3);
	fprintf(stderr, "c %-20s: %5.3f\n", "smoothing prob.", ((float) sp / 1000));
	fprintf(stderr, "c %-20s: %lli\n", "seed", seed);
	fflush(stderr);
}

inline void printSolution() {
	register int i;
	printf("v ");
	for (i = 1; i <= numVars; i++) {
		if (i % 21 == 0)
			printf("\nv ");
		if (atom[i] == 1)
			printf("%d ", i);
		else
			printf("%d ", -i);
	}
	printf("0\n");
}
//print the solutin on 1 line
void printSolution1line() {
	register int i;
	printf("v ");
	for (i = 1; i <= numVars; i++) {
		if (atom[i] == 1)
			printf("%d ", i);
		else
			printf("%d ", -i);
	}
	printf("0\n");
}

void printStatistics() {
	int i;
	if (sfileName1 != NULL) {
		sfp1 = NULL;

		sfp1 = fopen(sfileName1, "w");
		if (sfp1 == NULL) {
			fprintf(stderr, "c Error: Not able to open statistics file: %s\n", sfileName1);
			exit(-1);
		}
		fprintf(stderr,"c writing sorted flipping history to file :%s\n",sfileName1);
		//most flipped variable first
		//construct the struct data
		struct varStat *vs = (struct varStat*) malloc(sizeof(struct varStat) * (numVars + 1));
		vs[0].var = 0;
		vs[0].stat = LLONG_MAX;
		for (i = 1; i <= numVars; i++) {
			vs[i].var = i;
			vs[i].stat = timesFlipped[i];
		}
		qsort(vs, numVars + 1, sizeof(struct varStat), compare);
		for (i = 1; i <= numVars; i++) {
			fprintf(sfp1, "%d\n", vs[i].var);
		}
		fclose(sfp1);
		free(vs);
	}
	if (sfileName2 != NULL) {
		sfp2 = NULL;
		sfp2 = fopen(sfileName2, "w");
		if (sfp2 == NULL) {
			fprintf(stderr, "c Error: Not able to open statistics file: %s\n", sfileName2);
			exit(-1);
		}
		fprintf(stderr,"c writing sorted literal age history to file :%s\n",sfileName2);
		//oldest non flipped variable first with polarity
		//construct the struct data
		struct varStat *vs = (struct varStat*) malloc(sizeof(struct varStat) * (numVars + 1));
		vs[0].var = 0;
		vs[0].stat = LLONG_MAX;
		for (i = 1; i <= numVars; i++) {
			vs[i].var = i;
			vs[i].stat = flip - varLastChange[i];
		}
		qsort(vs, numVars + 1, sizeof(struct varStat), compare);
		for (i = 1; i <= numVars; i++) {
			fprintf(sfp2, "%d\n", atom[vs[i].var] ? vs[i].var : -vs[i].var);
		}
		fclose(sfp2);
		free(vs);
	}
	return;
}

inline void printEndStatistics() {
	fprintf(stderr, "c EndStatistics:\n");
	fprintf(stderr, "c %-30s: %-9lli\n", "numFlips", flip);
	fprintf(stderr, "c %-30s: %-9lli (%4.2f%%) \n", "numProbWalks ", flip - statNumGWalks, 100 * (flip - statNumGWalks) / (float) flip);
	fprintf(stderr, "c %-30s: %-9lli (%4.2f%%) \n", "gradientWalks", statNumGWalks, 100 * (double) statNumGWalks / (double) flip);
	fprintf(stderr, "c %-30s: %-8.3f\n", "flips/sec", (double) flip / tryTime);
	fprintf(stderr, "c %-30s: %-8.3f\n", "Try CPU Time", tryTime);
	fprintf(stderr, "c %-30s: %-8.3fsec\n", "Total CPU Time", totalTime);
	fflush(stderr);
	printStatistics();
}

inline void printStatsEndFlip() {
	if (numFalse < bestNumFalse) {
		//fprintf(stderr, "%8lli numFalse: %5d\n", flip, numFalse);
		bestNumFalse = numFalse;
	}
}

void allocateMemory() {
	// Allocating memory for the instance data (independent from the assignment).
	numLiterals = numVars * 2;
	atom = (int*) malloc(sizeof(int) * (numVars + 1));
	clause = (int**) malloc(sizeof(int*) * (numClauses + 2));
	clauseSize = (int*) malloc(sizeof(int) * (numClauses + 2));
	numOccurrence = (int*) malloc(sizeof(int) * (numLiterals + 1));
	occurrence = (int**) malloc(sizeof(int*) * (numLiterals + 1));
	neighbourVar = (int**) malloc(sizeof(int*) * (numVars+1));

	// Allocating memory for the assignment dependent data.
	falseClause = (int*) malloc(sizeof(int) * (numClauses + 2));
	whereFalse = (int*) malloc(sizeof(int) * (numClauses + 2));
	numTrueLit = (int*) malloc(sizeof(int) * (numClauses + 2));
	critVar1 = (int*) malloc(sizeof(int) * (numClauses + 1));
	score = (int*) malloc(sizeof(int) * (numVars + 1));

	decVar = (int*) malloc(sizeof(int) * (numVars + 1));
	isCandVar = (int*) malloc(sizeof(int) * (numVars + 1));

	varLastChange = (BIGINT*) malloc(sizeof(BIGINT) * (numVars + 1));
	timesFlipped = (BIGINT*) malloc(sizeof(BIGINT) * (numVars + 1));

	clauseWeight = (int*) malloc(sizeof(int) * (numClauses + 2));
	weightedClause = (int*) malloc(sizeof(int) * (numClauses + 2));
	whereWeight = (int*) malloc(sizeof(int) * (numClauses + 2));
}

void parseFile() {
	register int i, j, k;
	int lit, r;
	int tatom;
	char c;

	long filePos;
	int numNeighbours, cla, var;
	fp = NULL;
	fp = fopen(fileName, "r");
	if (fp == NULL) {
		fprintf(stderr, "c Error: Not able to open the file: %s", fileName);
		exit(-1);
	}

	// Start scanning the header and set numVars and numClauses
	for (;;) {
		c = fgetc(fp);
		if (c == 'c') //comment line - skip content
			do {
				c = fgetc(fp); //read the complete comment line until a eol is detected.
			} while ((c != '\n') && (c != EOF));
		else if (c == 'p') { //p-line detected
			if (fscanf(fp, "%*s %d %d", &numVars, &numClauses)) //%*s should match with "cnf"
				break;
		} else {
			fprintf(stderr, "c No parameter line found! Computing number of atoms and number of clauses from file!\n");
			r = fseek(fp, -1L, SEEK_CUR); //try to unget c
			if (r == -1) {
				fprintf(stderr, "c Error: Not able to seek in file: %s", fileName);
				exit(-1);
			}
			filePos = ftell(fp);
			if (r == -1) {
				fprintf(stderr, "c Error: Not able to obtain position in file: %s", fileName);
				exit(-1);
			}

			numVars = 0;
			numClauses = 0;
			for (; fscanf(fp, "%i", &lit) == 1;) {
				if (lit == 0)
					numClauses++;
				else {
					tatom = abs(lit);
					if (tatom > numVars)
						numVars = tatom;
				}
			}
			fprintf(stderr, "c numVars: %d numClauses: %d\n", numVars, numClauses);

			r = fseek(fp, filePos, SEEK_SET); //try to rewind the file to the beginning of the formula
			if (r == -1) {
				fprintf(stderr, "c Error: Not able to seek in file: %s", fileName);
				exit(-1);
			}

			break;
		}
	}
	// Finished scanning header.
	//allocating memory to use!
	allocateMemory();

	int *numOccurrenceT = (int*) malloc(sizeof(int) * (numLiterals + 1));

	int freeStore = 0;
	int *tempClause = 0;
	for (i = 1; i <= numClauses; i++) {
		clauseSize[i] = 0;
		critVar1[i] = 0;
		whereFalse[i] = -1;
		whereWeight[i] = -1;
	}

	for (i = 0; i < numLiterals + 1; i++) {
		numOccurrence[i] = 0;
		numOccurrenceT[i] = 0;
	}

	for (i = 1; i <= numClauses; i++) {
		if (freeStore <= MAXCLAUSELENGTH) {
			tempClause = (int*) malloc(sizeof(int) * STOREBLOCK);
			freeStore = STOREBLOCK;
		}
		clause[i] = tempClause;
		do {
			r = fscanf(fp, "%i", &lit);
			if (lit != 0) {
				clauseSize[i]++;
				*tempClause++ = lit;
				numOccurrenceT[numVars + lit]++;
			} else {
				*tempClause++ = 0; //0 sentinel as literal!
			}
			freeStore--;
		} while (lit != 0);
	}

	for (i = 0; i < numLiterals + 1; i++) {
		occurrence[i] = (int*) malloc(sizeof(int) * (numOccurrenceT[i] + 1));
		if (numOccurrenceT[i] > maxNumOccurences)
			maxNumOccurences = numOccurrenceT[i];
	}
	maxClauseSize = 0;
	minClauseSize = MAXCLAUSELENGTH;
	for (i = 1; i <= numClauses; i++) {
		if (clauseSize[i] > maxClauseSize)
			maxClauseSize = clauseSize[i];
		if (clauseSize[i] < minClauseSize)
			minClauseSize = clauseSize[i];
		for (j = 0; j < clauseSize[i]; j++) {
			lit = clause[i][j];
			occurrence[lit + numVars][numOccurrence[lit + numVars]++] = i;
		}
		occurrence[lit + numVars][numOccurrence[lit + numVars]] = 0; //sentinel at the end!
	}

	//Now the maximum size of a clause is determined!
	probs = (double*) malloc(sizeof(double) * (maxClauseSize + 1));

	//Constructing the neighbor array from the occurrence-arrays .
	freeStore = 0;
	int *tempNeighbour = 0;
	int isNeighbour[numVars + 1]; //isNeighbour[j]=i means that j is a neighbor-var of i.

	for(i = 1; i <= numVars; i++) {
		isNeighbour[i] = 0;
	}
	for (i = 1; i <= numVars; i++) {
		numNeighbours = 0;
		//first take a look at all positive occurrences of i
		for (j = 0; j < numOccurrence[numVars + i]; j++) {
			cla = occurrence[i + numVars][j];
			for (k = 0; k < clauseSize[cla]; k++) {
				var = abs(clause[cla][k]);
				if ((isNeighbour[var] != i) && (var != i)) { //if it is not all ready marked as a neighbor of i mark it.
					isNeighbour[var] = i;
					numNeighbours++;
				}
			}
		}
		//then take a look at all negative occurrence of i
		for (j = 0; j < numOccurrence[numVars - i]; j++) {
			cla = occurrence[numVars - i][j];
			for (k = 0; k < clauseSize[cla]; k++) {
				var = abs(clause[cla][k]);
				if ((isNeighbour[var] != i) && (var != i)) { //if it is not all ready marked as a neighbor of i mark it.
					isNeighbour[var] = i;
					numNeighbours++;
				}
			}
		}
		if (freeStore < numNeighbours + 1) {
			tempNeighbour = (int*) malloc(sizeof(int) * STOREBLOCK);
			freeStore = STOREBLOCK;
		}
		neighbourVar[i] = tempNeighbour;
		freeStore -= numNeighbours + 1;
		if (numNeighbours >= 1) {
			for (j = 1; j <= numVars; j++) {
				if (isNeighbour[j] == i) {
					*(tempNeighbour++) = j;
					numNeighbours--;
					if (numNeighbours == 0) {
						*(tempNeighbour++) = 0;
						break;
					}
				}
			}
		} else
			*(tempNeighbour++) = 0;
	}
	free(numOccurrenceT);
	fclose(fp);

}

void init() {
	register int i, j;
	int critLit = 0, lit;
	ticks_per_second = sysconf(_SC_CLK_TCK);
	statNumGWalks = 0; //how often a gradient walk was done
	statNumSmooth = 0; //how often a smoothing has been done.
	numFalse = 0;
	numWeight = 0;
	for (i = 1; i <= numClauses; i++) {
		numTrueLit[i] = 0;
		critVar1[i] = 0;
		whereFalse[i] = -1;
		whereWeight[i] = -1;
	}

	for (i = 1; i <= numVars; i++) {
		atom[i] = rand() % 2;
		score[i] = 0;
		varLastChange[i] = 0; //-1 means never changed
		timesFlipped[i]=0;
	}

	//pass trough all clauses and apply the assignment previously generated
	for (i = 1; i <= numClauses; i++) {
		for (j = 0; j < clauseSize[i]; j++) {
			lit = clause[i][j];
			if (atom[abs(lit)] == (lit > 0)) {
				numTrueLit[i]++;
				critLit = lit;
			}
		}
		if (numTrueLit[i] == 1) {
			//if the clause has only one literal that causes it to be sat,
			//then this var. will break the sat of the clause if flipped.
			critVar1[i] = abs(critLit);
			score[abs(critLit)]--;
		} else if (numTrueLit[i] == 0) {
			//add this clause to the list of unsat caluses.
			falseClause[numFalse] = i;
			whereFalse[i] = numFalse;
			numFalse++;

			//if the clause is unsat fliping any variable from it will make it sat
			//-> increase the score of all variables within this clause

			for (j = 0; j < clauseSize[i]; j++) {
				score[abs(clause[i][j])]++;
			}
		}
		clauseWeight[i] = BASECW;
	}
	numDecVar = 0;
	//add all variables that are decreasing to the list of decreasing variables.
	for (i = 1; i <= numVars; i++)
		if (getScore(i) > 0) {
			decVar[numDecVar] = i;
			numDecVar++;
			isCandVar[i] = 1;
		} else {
			isCandVar[i] = 0;
		}
}

/** Checks wether the assignment from atom is a satisfying assignment.*/
int checkAssignment() {
	register int i, j;
	int sat, lit;
	for (i = 1; i <= numClauses; i++) {
		sat = 0;
		for (j = 0; j < clauseSize[i]; j++) {
			lit = clause[i][j];
			if (atom[abs(lit)] == (lit > 0))
				sat = 1;
		}
		if (sat == 0) {
			fprintf(stderr, "\nClause %d is unsatified by assignment\n", i);
			return 0;
		}
	}
	return 1;
}

void smooth2() { //for all weighted !!!satisfied!!! clauses decrease the score by 1
	register int i, c, var;
	for (i = 0; i < numWeight; i++) {
		c = weightedClause[i];
		if (numTrueLit[c] > 0) {
			if (--clauseWeight[c] == BASECW) { //remove from the list of weighted clauses
				numWeight--;
				weightedClause[i] = weightedClause[numWeight];
				whereWeight[weightedClause[i]] = i;
				whereWeight[c] = -1;
				i--;
			}
			if (numTrueLit[c] == 1) {
				var = critVar1[c];
				//clause lost one weight and critvar had this weight as negative, so we have to add one to the weigth of var
				adjScore(var, 1);
				if ((getScore(var) > 0) && (!isCandVar[var]) && (varLastChange[var] < flip - 1)) {
					isCandVar[var] = 1;
					decVar[numDecVar] = var;
					numDecVar++;
				}
			}
		}
	}
	statNumSmooth++;
}

void updateWeights() { //for all unsat clauses increase the weight by 1.
	int i, j;
	int c, var;
	for (i = 0; i < numFalse; i++) {
		c = falseClause[i];
		clauseWeight[c]++;
		if ((whereWeight[c] == -1) && (clauseWeight[c] > BASECW)) { //add to the list of weigthedClause
			weightedClause[numWeight] = c;
			whereWeight[c] = numWeight;
			numWeight++;
		}
		j = 0;
		while ((var = abs(clause[c][j]))) {
			score[var]++;
			if ((!isCandVar[var]) && (getScore(var) > 0) && (varLastChange[var] < flip - 1)) {
				isCandVar[var] = 1;
				decVar[numDecVar] = var;
				numDecVar++;
			}
			j++;
		}
	}
}

inline void pickVar() {
	register int i, j;
	int var;
	int bestScore = -numClauses;
	double probAge = 1.0, baseAge;
	BIGINT varChanged = 0;
	int scoreVar;
	int rClause; //randomly choosen clause.
	//g2Wsat part - the greedy part - if there is a variable that decreases the number of variables then choose the best one.

	if (numDecVar > 0) {
		//find the variable with the best score, and the following variable with same score.
		for (i = 0; i < numDecVar; i++) {
			var = decVar[i];
			scoreVar = getScore(var);
			if (scoreVar > 0) {
				if (bestScore < scoreVar) {
					bestScore = scoreVar;
					bestVar = var;
					varChanged = varLastChange[var];
				} else if (bestScore == scoreVar) //found one with the same score
					if (varLastChange[var] < varChanged) { //check if it is younger
						bestVar = var; //this var being younger is chosen.
						varChanged = varLastChange[var];
					}
			} else {
				numDecVar--;
				decVar[i] = decVar[numDecVar];
				//whereDecVar[decVar[numDecVar]]=i;
				isCandVar[var] = 0;
				i--;
			}
		}
	}

	if (bestScore != -numClauses) {
		statNumGWalks++;
	} else {
		//new probability distribution replacing adaptNovelty+
		//a variable is YOUNG if it was flipped not long time ago
		//a variable is OLD if it was flipped long ago in the past, or not at all
		rClause = falseClause[rand() % numFalse];
		double sumProb = 0;
		i = 0;
		while ((var = abs(clause[rClause][i]))) {
			scoreVar = getScore(var);
			if (scoreVar < -MAXSCORE)
				probs[i] = scorePow[MAXSCORE];
			else {
				if (scoreVar > 0) {
					probs[i] = 1.0;
				} else {
					probs[i] = scorePow[abs(scoreVar)];
				}
			}
			varChanged = varLastChange[var];
			baseAge = (double) (flip - varChanged) * inv_c3;
			for (j = 0, probAge = 1.0; j < c2; j++)
				probAge *= baseAge;
			probAge += 1.0;
			probs[i] *= probAge;
			sumProb += probs[i];
			i++;
		}

		double randPosition = (double) (rand()) / RAND_MAX * sumProb;
		sumProb = 0.0;
		for (i = 0; i < clauseSize[rClause]; i++) {
			sumProb += probs[i];
			if (sumProb >= randPosition)
				break;
		}
		bestVar = abs(clause[rClause][i]);
		updateWeights();
		if (sp < 1000) {
			if (rand() % 1000 < sp)
				smooth2();
			//	else
			//		updateWeights();
		}
	}
	return;
}

inline void flipAtom() {
	register int i, j;
	int var;
	int tClause; //temporary clause variable
	int xMakesSat = 0; //tells which literal of x will make the clauses where it appears sat.
	if (atom[bestVar] == 1)
		xMakesSat = -bestVar; //if x=1 then all clauses containing -x will be made sat after fliping bestVar
	else
		xMakesSat = bestVar; //if x=0 then all clauses containing x will be made sat after fliping bestVar

	atom[bestVar] = 1 - atom[bestVar];
	//all Neighbours of x with score>0 are considered candVars without taking into account if they are in decVar or not.
	//trough this mechanism we can avoid that a variable that was fliped and increased the number of false variable is added to the
	//decVar array - this variable is not promissing.
	i = 0;
	while ((var = neighbourVar[bestVar][i])) {
		isCandVar[var] = (getScore(var) > 0);
		i++;
	}

	//1. all clauses that contain the literal xMakesSat will become SAT, if they where not already sat.
	//numOccurenceX = numOccurrence[numVars + xMakesSat];

	i = 0;
	while ((tClause = occurrence[xMakesSat + numVars][i])) {
		//tClause = occurrence[xMakesSat + numVars][i];
		//if the clause is unsat it will become SAT so it has to be removed from the list of unsat-clauses.
		if (numTrueLit[tClause] == 0) {
			//remove from unsat-list
			falseClause[whereFalse[tClause]] = falseClause[--numFalse]; //overwrite this clause with the last clause in the list.
			whereFalse[falseClause[numFalse]] = whereFalse[tClause];
			whereFalse[tClause] = -1;

			critVar1[tClause] = abs(xMakesSat); //this variable is now critically responsible for satisfying tClause
			//adapt the scores of the variables
			//the score of x has to be decreased by one because x is critical and will break this clause if fliped.
			decScore(bestVar, tClause);
			//the scores of all variables from tClause have to be decreased by one because tClause is not UNSAT any more
			j = 0;
			while ((var = abs(clause[tClause][j]))) {
				decScore(var, tClause);
				j++;
			}
		} else {
			//if the clause is satisfied by only one literal then the score has to be increased by one for this var.
			//because fliping this variable will no longer break the clause
			if (numTrueLit[tClause] == 1) {
				incScore(critVar1[tClause], tClause);
			}
		}
		//if the number of numTrueLit[tClause]>=2 then nothing will change in the scores
		numTrueLit[tClause]++; //the number of true Lit is increased.
		i++;
	}

	//2. all clauses that contain the literal -xMakesSat=0 will not be longer satisfied by variable x.
	//all this clauses contained x as a satisfying literal
	i = 0;
	while ((tClause = occurrence[numVars - xMakesSat][i])) {
		if (numTrueLit[tClause] == 1) { //then xMakesSat=1 was the satisfying literal.
			//this clause gets unsat.
			falseClause[numFalse] = tClause;
			whereFalse[tClause] = numFalse;
			numFalse++;
			//the score of x has to be increased by one because it is not breaking any more for this clause.
			incScore(bestVar, tClause);
			//the scores of all variables have to be increased by one ; inclusive x because flipping them will make the clause again sat
			j = 0;
			while ((var = abs(clause[tClause][j]))) {
				incScore(var, tClause);
				j++;
			}
		} else if (numTrueLit[tClause] == 2) { //find which literal is true and make it critical and decrease its score
			j = 0;
			while ((var = abs(clause[tClause][j]))) {
				if (((clause[tClause][j] > 0) == atom[abs(var)])) { //x can not be the var anymore because it was flipped //&&(xMakesSat!=var)
					critVar1[tClause] = var;
					decScore(var, tClause);
					break;
				}
				j++;
			}
		}
		numTrueLit[tClause]--;
		i++;
	}

	//acoordant to G2WSAT only the scores of variables within neighbourVar[x] have changed.
	i = 0;
	while ((var = neighbourVar[bestVar][i])) {
		if ((getScore(var) > 0) && (!isCandVar[var])) { //is not in the list of decreasing variables
			//add to decVar
			decVar[numDecVar] = var;
			//whereDecVar[var]=numDecVar;
			numDecVar++;
		}
		i++;
	}
}

double elapsed_seconds(void) {
	double answer;
	static struct tms prog_tms;
	static long prev_times = 0;
	(void) times(&prog_tms);
	answer = ((double) (((long) prog_tms.tms_utime) - prev_times)) / ((double) ticks_per_second);
	prev_times = (long) prog_tms.tms_utime;
	return answer;
}

void printUsage() {
	printf("\nSparrow version 2013\n");
	printf("Code Authors: Adrian Balint\n");
	printf("Algo Authors: Adrian Balint & Andreas Fröhlich\n");
	printf("Citation: Adrian Balint & Andreas Fröhlich: Improving Stochastic Local Search for SAT with a New Probability Distribution, SAT 2010\n");
	printf("Ulm University - Institute of Theoretical Computer Science\n");
	printf("----------------------------------------------------------\n");
	printf("\nUsage of sparrow:\n");
	printf("./sparrow [options] <DIMACS CNF instance> [<seed>]\n");
	printf("\nSparrow options:\n");
	printf("--c1 <double_value> : c1 constant from the Sparrow heuristic (default: 3sat:2.15; 5sat:2.855; 7sat:6.5)\n");
	printf("--c2 <int_value> : c2 constant from the Sparrow heuristic (default: 3sat,5sat,7sat:4)\n");
	printf("--c3 <int_value> : c3 constant from the Sparrow heuristic (default: 3sat,7sat:10⁵; 5sat:0.75*10⁵)\n");
	printf("--sp <double_value> : smoothing probability inherited from gNovelty+ heuristic (default: 3sat:0.347; 5sat:1.0; 7sat:0.83)"
			"(values between [0..1.0] only the first 3 digits after dot will be taken into account)\n");
	printf("\nFurther options:\n");
	printf("--maxflips <int_value> : maximum number of flips per try (default: LLONG_MAX)\n");
	printf("--runs <int_value> : number of tries to solve the problem (default: LLONG_MAX)\n");
	printf("-a or --printsolution : print solution (default: OFF)\n");
	printf("--actfile <filename> : print to file statistics about the most flipped variable sorted descending \n");
	printf("--agefile <filename> : print to file the statistics about the oldest literals \n");
	printf("-h or --help : print usage \n\n");
}

void initSparrow() {
	scorePow = (double*) malloc(sizeof(double) * MAXSCORE);
	scorePowPlus = (double*) malloc(sizeof(double) * MAXSCORE);
	int i;
	for (i = 0; i < MAXSCORE; i++)
		scorePowPlus[i] = pow(c0, i);
	for (i = 0; i < MAXSCORE; i++) {
		scorePow[i] = pow(c1, -i);
	}
	inv_c3 = 1. / c3;
}

void parseParameters(int argc, char *argv[]) {
	double spParam;
	//define the argument parser
	static const struct option long_options[] =
			{ { "actfile", required_argument, 0, 'f' }, { "agefile", required_argument, 0, 'g' }, { "c1", required_argument, 0, 'b' }, { "c2", required_argument, 0, 'e' }, { "c3", required_argument, 0, 'd' }, { "sp", required_argument, 0, 'p' }, { "runs", required_argument, 0, 't' }, { "maxflips", required_argument, 0, 'm' }, { "printSolution", no_argument, 0, 'a' }, { "help", no_argument, 0, 'h' }, { "c0 constant", required_argument, 0, 'c' }, { 0, 0, 0, 0 } };
	while (optind < argc) {
		int index = -1;
		struct option * opt = 0;
		int result = getopt_long(argc, argv, "b:e:d:p:t:m:ahc:g:f:", long_options, &index); //
		if (result == -1)
			break; /* end of list */
		switch (result) {
		case 'h':
			printUsage();
			exit(0);
			break;
		case 'f': //this stands for statistics file
			sfileName1 = optarg;
			break;
		case 'g': //this stands for statistics file
			sfileName2 = optarg;
			break;
		case 'c': //this stands for c0
			c0 = atof(optarg);
			c0_spec = 1;
			break;
		case 'b': //this stands for c1
			c1 = atof(optarg);
			c1_spec = 1;
			break;
		case 'e': //this stands for c2
			c2 = atoi(optarg);
			c2_spec = 1;
			break;
		case 'd': //this stands for c3
			c3 = atoi(optarg);
			c3_spec = 1;
			break;
		case 'p': //this stands for sp
			spParam = atof(optarg);
			sp_spec = 1;
			sp = spParam * 1000;
			break;
		case 't': //maximum number of tries to solve the problems within the cutoff
			maxTries = strtoll(optarg, NULL, 0);
			break;
		case 'm': //maximum number of flips to solve the problem
			maxFlips = strtoll(optarg, NULL, 0);
			break;
		case 'a': //print assigment of variables
			printSol = 1;
			break;
		case 0: /* all parameter that do not */
			/* appear in the optstring */
			opt = (struct option *) &(long_options[index]);
			printf("'%s' was specified.", opt->name);
			if (opt->has_arg == required_argument
			)
				printf("Arg: <%s>", optarg);
			printf("\n");
			break;
		default:
			printf("parameter not known!\n");
			printUsage();
			exit(0);
			break;
		}
	}
	if (optind == argc) {
		printf("ERROR: You have to specify at least an instance file!\n");
		printUsage();
		exit(0);
	}
	fileName = *(argv + optind);

	if (argc > optind + 1) {
		seed = atoi(*(argv + optind + 1));
		if (seed == 0)
			printf("c there might be an error in the command line or is your seed 0?\n");
	} else
		seed = time(0);
}

void handle_interrupt() {
	fprintf(stderr, "\nCought signal... Exiting\n ");
	tryTime = elapsed_seconds();
	fprintf(stderr, "\nc UNKNOWN best(%d) (%-15.5fsec)\n", bestNumFalse, tryTime);
	fflush(stderr);
	exit(-1);
}

void setupSignalHandler() {
	signal(SIGTERM, handle_interrupt);
	signal(SIGINT, handle_interrupt);
	signal(SIGQUIT, handle_interrupt);
	signal(SIGABRT, handle_interrupt);
	signal(SIGKILL, handle_interrupt);
}

void setupSparrowParameters() {
	if (!c0_spec)
		c0 = 1.0;
	if (maxClauseSize <= 3) {
		fprintf(stderr, "c %-20s:  %s\n", "Parameter setting ", "3 SAT");
		if (!c1_spec)
			c1 = 2.15;
		if (!c2_spec)
			c2 = 4;
		if (!c3_spec)
			c3 = 100000;
		if (!sp_spec)
			sp = 347;
	} else if (maxClauseSize <= 5) {
		fprintf(stderr, "c %-20s:  %s\n", "Parameter setting ", "5 SAT");
		if (!c1_spec)
			c1 = 2.85;
		if (!c2_spec)
			c2 = 4;
		if (!c3_spec)
			c3 = 75000;
		if (!sp_spec)
			sp = 1000;
	} else {
		fprintf(stderr, "c %-20s:  %s\n", "Parameter setting  ", "7 SAT");
		if (!c1_spec)
			c1 = 6.5;
		if (!c2_spec)
			c2 = 4;
		if (!c3_spec)
			c3 = 100000;
		if (!sp_spec)
			sp = 830;
	}
	if (c3 == 0) {
		printf("ERROR c3 = 0 not allowed!");
		exit(0);
	} else if ((sp < 0) || (sp > 1000)) {
		printf("ERROR ps is a probability -> 0<=sp<=1");
		exit(0);
	}
}

int main(int argc, char *argv[]) {
	//if there should be more than one try to solve the problem
	BIGINT try;
	tryTime = 0.;
	parseParameters(argc, argv);
	parseFile();
	printFormulaProperties();
	setupSparrowParameters(); //call only after parsing file!!!
	//Initialize the look up table of Sparrow
	initSparrow();
	setupSignalHandler();
	printSolverParameters();
	fprintf(stderr, "c %-20s: %lli\n", "maxTries", maxTries);
	fprintf(stderr, "c %-20s: %lli\n", "maxFlips", maxFlips);
	fprintf(stderr, "c %-20s: \n", "-->Starting solver");

	srand(seed);

	for (try = 0; try < maxTries; try++) {
		init();
		bestNumFalse = numClauses;
		for (flip = 0; flip < maxFlips; flip++) {
			if (numFalse == 0)
				break;
			pickVar();
			timesFlipped[bestVar]++;
			flipAtom();
			varLastChange[bestVar] = flip;
			printStatsEndFlip(); //update bestNumFalse
		}
		tryTime = elapsed_seconds();
		totalTime += tryTime;
		if (numFalse == 0) {
			if (!checkAssignment()) {
				fprintf(stderr, "c ERROR the assignment is not valid!");
				printf("c UNKNOWN");
				return 0;
			} else {
				printEndStatistics();
				printf("s SATISFIABLE\n");
				//if (printSol == 1)
				printSolution1line();
				return 10;
			}
		} else
			printf("c UNKNOWN best(%4d) current(%4d) (%-15.5fsec)\n", bestNumFalse, numFalse, tryTime);
	}
	printEndStatistics();
	if (maxTries > 1)
		printf("c %-30s: %-8.3fsec\n", "Mean time per try", totalTime / (double) try);
	return 0;
}

