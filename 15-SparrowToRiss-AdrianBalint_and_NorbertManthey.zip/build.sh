#!/bin/sh
rm -rf binary
mkdir binary
cd code; make all
cp SparrowToRiss.sh ../binary
