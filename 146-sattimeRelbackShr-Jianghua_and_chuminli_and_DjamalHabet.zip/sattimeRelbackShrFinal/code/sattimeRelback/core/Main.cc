#include "sattime.h"
#include <pthread.h>
#include <sys/time.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "Relbackapp.h"

pthread_t clasp_tid;
int sattime_retVal = 0;
int clasp_retVal = 0;
int var_argc;
char ** var_argv;
FILE *file_out = NULL;

pthread_mutex_t mutex_lock = PTHREAD_MUTEX_INITIALIZER;

extern int go_sovler_relback(int argc, char** argv);

void chseed() {
	int seed;
	struct timeval tv;
	struct timezone tzp;
	gettimeofday(&tv, &tzp);
	seed = ((tv.tv_sec & 0177) * 1000000) + tv.tv_usec;
	srand(seed);
}

void * solver_relback(void *arg) {
	go_relback(2, var_argv);
	pthread_exit((void *) 0);
}

void setCpuAffinity() {
	int cpu_no;
	cpu_set_t mask;
	int cpu_num = sysconf(_SC_NPROCESSORS_CONF);
	chseed();
	cpu_no = (rand() % cpu_num);
	CPU_ZERO(&mask);
	CPU_SET(cpu_no, &mask);
	sched_setaffinity(0, sizeof(mask), &mask);
}

int main(int argc, char* argv[]) {
	int ret = 0;
	var_argc = argc;
	var_argv = argv;
	//setCpuAffinity();
	pthread_mutex_init(&mutex_lock, NULL);
	ret = build_simple_sat_instance(argv[1]);
	if (ret == 1) {
		pthread_create(&clasp_tid, NULL, solver_relback, NULL);
		go_sattime(var_argc, var_argv);
	} else {
		solver_relback(NULL);
	}
}
