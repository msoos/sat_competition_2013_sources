/*
 * sattime2011.h
 *
 *  Created on: 2013-4-19
 *      Author: jianghua
 */

#ifndef SATTIME2011_H_
#define SATTIME2011_H_
#endif /* SATTIME2011_H_ */
int verify_sol_input(char *input_file);
int build_simple_sat_instance(char *input_file);
int uneven_var(int var, int total_steps) ;
int simplify_formula();
int satisfyUnitClause(int clause);
int diversifyForUneven(int random_clause_unsat, int best_var);
int assignValue(int var, int value);
int go_sattime(int argc, char *argv[]);
#ifndef NULL
#define NULL 0
#endif

