/*
 * relback.h
 *
 *  Created on: 2013-4-19
 *      Author: jianghua
 */

#ifndef RELBACK_H_
#define RELBACK_H_
#endif 

#ifndef NULL
#define NULL 0
#endif

int go_relback(int argc, char* argv[]);

