#!/bin/bash
export FM=$PWD/code/SatELite/ForMani

mkdir binary

cd ./code/sattimeRelback/core
make rs
cp sattimeRelbackShr_static ../../../binary
mv ../../../binary/sattimeRelbackShr_static ../../../binary/sattimeRelbackShr
make clean 
