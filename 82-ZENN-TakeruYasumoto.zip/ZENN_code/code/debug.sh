#! /bin/sh

export MROOT=$PWD

rm -rf sinn_debug
make -C core
cp core/sinn ./sinn_debug