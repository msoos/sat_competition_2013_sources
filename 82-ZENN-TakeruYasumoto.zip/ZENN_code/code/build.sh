#! /bin/sh

export MROOT=$PWD

rm -rf sinn
make -C simp r
cp simp/sinn_release ./sinn