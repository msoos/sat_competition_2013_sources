#! /bin/sh

export MROOT=$PWD

rm -rf sinn
rm -rf sinn_debug
make -C core clean
make -C simp clean
