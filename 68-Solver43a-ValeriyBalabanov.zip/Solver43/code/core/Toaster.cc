#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include <math.h>
#include <time.h>
#include <cstring>
#include <zlib.h>
#include "ToasterTypes.h"

using namespace std;

//****************************************************************************************
//------------------------------------ Parser --------------------------------------------
//****************************************************************************************
static const int Mybuffer_size = 1048576;

class MyStreamBuffer {
    gzFile        in;
    unsigned char buf[Mybuffer_size];
    int           pos;
    int           size;

    void MyassureLookahead() {
        if (pos >= size) {
            pos  = 0;
            size = gzread(in, buf, sizeof(buf)); } }

public:
    explicit MyStreamBuffer(gzFile i) : in(i), pos(0), size(0) { MyassureLookahead(); }

    int  operator *  () const { return (pos >= size) ? EOF : buf[pos]; }
    void operator ++ ()       { pos++; MyassureLookahead(); }
    int  position    () const { return pos; }
};

static inline bool MyisEof(MyStreamBuffer& in) { return *in == EOF;  }
static inline bool MyisEof(const char*   in) { return *in == '\0'; }

template<class B>
static void MyskipWhitespace(B& in) {
    while ((*in >= 9 && *in <= 13) || *in == 32)
        ++in; }


template<class B>
static void MyskipLine(B& in) {
    for (;;){
        if (MyisEof(in)) return;
        if (*in == '\n') { ++in; return; }
        ++in; } }

template<class B>
static int MyparseInt(B& in) {
    int     val = 0;
    bool    neg = false;
    MyskipWhitespace(in);
    if      (*in == '-') neg = true, ++in;
    else if (*in == '+') ++in;
    if (*in < '0' || *in > '9') fprintf(stderr, "PARSE ERROR! Unexpected char: %c\n", *in), exit(3);
    while (*in >= '0' && *in <= '9')
        val = val*10 + (*in - '0'),
        ++in;
    return neg ? -val : val; }

template<class B>
static bool Mymatch(B& in, const char* str) {
    int i;
    for (i = 0; str[i] != '\0'; i++)
        if (in[i] != str[i])
            return false;

    in += i;

    return true; 
}

template<class B>
static bool MyeagerMatch(B& in, const char* str) {
    for (; *str != '\0'; ++str, ++in)
        if (*str != *in)
            return false;
    return true; }
    
template<class B>
static void MyreadClause(B& in, vector<int> *lits) {
    int     parsed_lit;
    int found=0;
    (*lits).clear();
    for (;;)
    	{
        parsed_lit = MyparseInt(in);
        if (parsed_lit == 0) break;
        if ((*lits).size()==0) {(*lits).push_back(parsed_lit);}
        else 
        	{
        	found=0;
        	for (int i=0;i<=(*lits).size()-1;i++)
        		{
        		if ((*lits)[i]==-parsed_lit) {(*lits).clear();found=-1;break;}
        		else if ((*lits)[i]==parsed_lit) {found=1;break;}
        		}
        	if (found==-1) {break;}
        	else if (found==0) {(*lits).push_back(parsed_lit);}
        	}
    	}
}

template<class B>
static void Myparse_DIMACS_main(B& in, vector<clause> *circuit,int *numvars,int *numclauses) {
    vector<int> lits;
    clause cl1;
    
    cl1.answer=0;
    cl1.temp=0;
    cl1.current_answer=0;
   
    (*circuit).clear();
    for (;;)
    	{
        MyskipWhitespace(in);
        if (*in == EOF) {break;}
		else if (*in == 'p')
			{
	  		 if (MyeagerMatch(in, "p cnf"))
	  			{
	    		(*numvars)    = MyparseInt(in);
	    		(*numclauses) = MyparseInt(in);
	    		if (((*numvars)>2000000)||((*numclauses)>10000000)) {return;}
	    		} 
	  		else {printf("c PARSE ERROR! Unexpected char: %c\n", *in), exit(3);}
	  		}
        else if (*in == 'c' || *in == 'p') MyskipLine(in);
        else 
        	{
        	MyreadClause(in, &lits);
        	if (lits.size()>0) 
        		{
        		cl1.literals=lits;
        		cl1.current_size=cl1.literals.size();
        		cl1.lit_answers.clear();
        		for (int  i=0;i<=lits.size()-1;i++) {cl1.lit_answers.push_back(0);}
            	(*circuit).push_back(cl1);
            	}
    		}
    	}
    (*numclauses)=(*circuit).size();
}

static void Myparse_DIMACS(gzFile input_stream, vector<clause> *circuit,int *numvars,int *numclauses) {
    MyStreamBuffer in(input_stream);
    Myparse_DIMACS_main(in, circuit, numvars, numclauses); }

//****************************************************************************************
//------------------------------------ MAIN ----------------------------------------------
//****************************************************************************************

int Toaster(int *ONtoaster,gzFile in,string pattern, int *numvars,int *numclauses,vector<variable> *entries, vector<clause> *circuit,vector<clause> *circuit_original,vector<clause> *removed,int verbosity)
{
	//if ((*ONtoaster)==0) {Myparse_DIMACS(in,circuit,numvars,numclauses);gzclose(in);return 0;}
	//------------------ variable declaration ----------------------
	int num_vars=(*numvars);
	int num_clauses=(*numclauses);
	int num_removed=0;
	int num_added=0;
	int num_blocked=0;
	int answer=0;
	int counter=0;
	int varcount=0;
	int round=0;
	int num_2cls=0;
	int num_3cls=0;
	int num_4cls=0;
	int improved=0;
	int reason=0;
	int  pattern_iterator=0;
	vector<int> unit_q;
	vector<int> temp_add;
	vector<clause> cls2vec;
	variable var1;
	string file_name;
	clock_t start,newtime,newtime1;
	
	//---------------- tuned variables ---------------------
	//*********************
	//int verbosity=1;
	int depth=-1; // depth in bce
	int num_chosen=0; // num_chosen in deep pure
	int roundMAX=1; // max number of rounds in main
	int inner_limit=10; // inner_limit in var probing
	int NUMlimit=-1; //limit in adding clauses
	int ONadding=1;
	int ONbce=1;
	int ONunit=1;
	int ONresolve=0;
	int ONprobe=1;
	int ONbve=1;
	int ONdefinition=1;
	int ONwritetocnf=0;
	float timelimit=5;
	//pattern="uvbadptuvbadp";
	//string pattern="";
		/*
		u - unit propagation;
		v - variable elimination;
		b - blocked elimination;
		a - add blocked;
		d - definitions;
		r - resolution on 2 clauses;
		p - probing of vars;
		t - temp clear (remove added clauses);
		common pattern: "uvbadptuvbadp";
		*/ 
	//*********************
	//------------------ reading input file --------------------------
	srand(time(NULL));
	start=clock();
	cls2vec.clear();
	unit_q.clear();
	cout.precision(2);
	
	Myparse_DIMACS(in,circuit,numvars,numclauses);
	gzclose(in);
	num_vars=(*numvars);
	num_clauses=(*numclauses);
		
	if ((num_vars>2000000)||(num_clauses>10000000)) 
		{
		(*ONtoaster)=0;
		//newtime=clock();
		//if (verbosity>0) {cout << "c - Reading the instance.. OK!  Totally clauses: " << (*circuit).size() << "; Vars: " << num_vars << "; Time: " << fixed << (double)(newtime-start)/CLOCKS_PER_SEC << endl;}
		return 0;
		}
	else if ((num_clauses>4000000)||(num_vars>1000000)) {pattern="ua";}
	else {(*circuit_original)=(*circuit);}
	
	if ((verbosity > 0)&&((*ONtoaster)!=0)) {cout << "c -------------------- Running Toaster Preprocessor --------------------- " << endl;}
	var1.answer=0;
	var1.temp_answer=0;
	var1.current_assignment=-1;
	var1.positive.clear();
	var1.negative.clear();
	var1.pos_index.clear();
	var1.neg_index.clear();
	
	for (int i=0;i<=num_vars-1;i++) 
		{
		var1.name=i+1;
		var1.definition=i+1;
		(*entries).push_back(var1);
		}
		
	answer=ReconstructUnit(circuit,entries,&temp_add,&unit_q);
	newtime=clock();
	if (verbosity>0) {cout << "c - Reading the instance.. OK!  Totally clauses: " << (*circuit).size() << "; Vars: " << num_vars << "; Time: " << fixed << (double)(newtime-start)/CLOCKS_PER_SEC << endl;}
	if (verbosity>1) 
		{
		cout << "c   - 2  clauses:  " <<  num_2cls << endl;
		cout << "c   - 3  clauses:  " <<  num_3cls << endl;
		cout << "c   - 4+ clauses:  " <<  num_4cls << endl;
		}

//****************** ROUND-BASED repetition of the simplification ***********************
counter=1;
improved=1;
while ( (((improved!=0)&&((round<roundMAX)||(roundMAX==-1)))&&(pattern.length()==0)) || ((pattern_iterator<pattern.length())&&(pattern.length()>0)) ) 
	{
	improved=0;
	reason=0;
	round++;
	if ((verbosity>0)&&(pattern.length()==0)) {cout << "c     * * * * *  ROUND "	<< round << "  * * * * *   " << endl;}
	//---------------------------- Unit propagation -----------------------------
	if (( (pattern.length()==0)&&(ONunit==1) )||((pattern.length()>0)&&(pattern[pattern_iterator]=='u')))
		{
		pattern_iterator++;
		if (unit_q.size()>0) { 
		if (verbosity>0) {cout << "c - Unit propagation..";}
		newtime=clock();
		answer=UnitPropagation(circuit,entries,&counter,&unit_q,timelimit,removed);
		if (answer==1) {cout << endl;return 1;}
		answer=ReconstructUnit(circuit,entries,&temp_add,&unit_q);
		num_removed=counter;
		if (counter!=0) {reason=1;improved=1;}
		newtime1=clock();
		unit_q.clear();
		if (verbosity>0) {cout << " OK! Removed: " << num_removed << " clauses; Time: " << fixed << (double)(newtime1-newtime)/CLOCKS_PER_SEC << endl;}
		}}
	//---------------------------- Variable elimination  -------------------------	
	if (( (pattern.length()==0)&&(ONbve==1) )||((pattern.length()>0)&&(pattern[pattern_iterator]=='v')))
		{
		if (verbosity>0) {cout << "c - Variable elimination..";}	
		newtime=clock();
		answer=VarElim(num_vars,circuit,entries,&counter,&varcount,timelimit,removed);
		num_removed+=counter;
		if ((improved==0)&&(varcount!=0)) {reason=2;improved=1;}
		newtime1=clock();
		if (verbosity>0) {cout << " OK!  Removed: " << varcount << " vars; " << counter << " clauses; Time: " << fixed << (double)(newtime1-newtime)/CLOCKS_PER_SEC << endl;}
		pattern_iterator++;
		}
//---------------------------- Remove by deep pure  -------------------------	
	if (( (pattern.length()==0)&&(ONbce==1) )||((pattern.length()>0)&&(pattern[pattern_iterator]=='b')))
		{
		if (verbosity>0) {cout << "c - Blocked elimination..";}	
		newtime=clock();
		answer=MainDeepPure(num_vars,circuit,entries,&counter,num_chosen,depth,&num_2cls,&num_3cls,&num_4cls,timelimit,removed);
		num_blocked=counter;
		num_removed+=counter;
		if ((improved==0)&&(counter>0)) {reason=3;improved=1;}
		newtime1=clock();
		if (verbosity>0) {cout << " OK!  Removed: " << counter << " clauses; Time: " << fixed << (double)(newtime1-newtime)/CLOCKS_PER_SEC << endl;}
		if (verbosity>2) 
			{
			cout << "c   - removed 2  clauses:  " <<  num_2cls << endl;
			cout << "c   - removed 3  clauses:  " <<  num_3cls << endl;
			cout << "c   - removed 4+ clauses:  " <<  num_4cls << endl;
			}
		pattern_iterator++;
		}
	//---------------------------- Adding blocked clauses  ----------------------
	if (( (pattern.length()==0)&&(ONadding==1)&&(round==1) )||((pattern.length()>0)&&(pattern[pattern_iterator]=='a')))
		{
		newtime=clock();	
		answer=Reconstruct(circuit);
		if ((*circuit).size()>1000000) {NUMlimit=(*circuit).size();}
		if (verbosity>0) {cout << "c - Adding blocked..";}	
		answer=AddBlocked(num_vars,circuit,&temp_add,entries,&counter,NUMlimit,timelimit);
		num_added=counter;
		//if ((improved==1)&&(reason==3)&&(num_added==num_blocked)) {reason=4;improved=0;}
		num_removed-=counter;
		newtime1=clock();
		if (verbosity>0) {cout << " OK!  Added:   " << counter << " clauses; Time: " << fixed << (double)(newtime1-newtime)/CLOCKS_PER_SEC << endl;}
		pattern_iterator++;
		}
	//---------------------------- Finding definitions  --------------------------
	if (( (pattern.length()==0)&&(ONdefinition==1)&&(round==1) )||((pattern.length()>0)&&(pattern[pattern_iterator]=='d')))
		{
		newtime=clock();	
		if (verbosity>0) {cout << "c - Seeking definitions..";}	
		answer=FindDefinitions(num_vars,circuit,entries,&counter,timelimit,removed);
		if (counter>0) {answer=ReconstructUnit(circuit,entries,&temp_add,&unit_q);}
		num_added=counter;
		if ((improved==0)&&(counter>0)) {reason=4;improved=1;}
		newtime1=clock();
		if (verbosity>0) {cout << " OK!  Found:   " << counter << " definitions; Time: " << fixed << (double)(newtime1-newtime)/CLOCKS_PER_SEC << endl;}
		pattern_iterator++;
		}
	//---------------------------- Resolutions of 2-clauses  ----------------------
	if (( (pattern.length()==0)&&(ONresolve==1) )||((pattern.length()>0)&&(pattern[pattern_iterator]=='r')))
		{
		if (verbosity>0) {cout << "c - Resolution on 2 cls..";}	
		newtime=clock();
		answer=Resolve2cls(num_vars,circuit,entries,&counter,&unit_q,timelimit);
		num_removed+=counter;
		if ((reason!=4)&&(improved==0)&&((counter!=0)||(unit_q.size()!=0))) {reason=5;improved=1;}
		newtime1=clock();
		if (verbosity>0) {cout << " OK! Units: " << unit_q.size() << "; Removed clauses: " << counter << "; Time: " << fixed << (double)(newtime1-newtime)/CLOCKS_PER_SEC << endl;}
		pattern_iterator++;
		}
	//---------------------------- Unit probing -----------------------------------
	if (( (pattern.length()==0)&&(ONprobe==1)&&(round==1) )||((pattern.length()>0)&&(pattern[pattern_iterator]=='p')))
		{
		if (verbosity>0) {cout << "c - Unit probing..";}	
		newtime=clock();
		answer=UnitProbe(num_vars,circuit,entries,&counter,&unit_q,inner_limit,timelimit);
		num_removed+=counter;
		if ((improved==0)&&(unit_q.size()!=0)) {reason=5;improved=1;}
		newtime1=clock();
		if (verbosity>0) {cout << " OK! Units: " << unit_q.size() << "; Time: " << fixed << (double)(newtime1-newtime)/CLOCKS_PER_SEC << endl;}
		pattern_iterator++;
		}
	//---------------------------- Removing added blocked clauses  -----------------
	if ((((num_added>0)&&((round<roundMAX)||((roundMAX==-1)&&(improved==1))))&&(pattern.size()==0))||((pattern.length()>0)&&(pattern[pattern_iterator]=='t'))) {pattern_iterator++;num_added=0;answer=RemoveTemp(circuit,&temp_add,entries);}
	//---------------------------- Last round adding blocked clauses  --------------
	if ((((roundMAX==-1)&&(improved==0))||((roundMAX!=-1)&&(round>=roundMAX)))&&(ONadding==1)&&(roundMAX!=1)&&(pattern.length()==0)) 
		{
		newtime=clock();	
		answer=Reconstruct(circuit);
		if ((*circuit).size()>1000000) {NUMlimit=(*circuit).size()/3;}
		if (verbosity>0) {cout << "c - Adding blocked..";}	
		answer=AddBlocked(num_vars,circuit,&temp_add,entries,&counter,NUMlimit,timelimit);
		num_added=counter;
		num_removed-=counter;
		newtime1=clock();
		if (verbosity>0) {cout << " OK!  Added:   " << counter << " clauses; Time: " << fixed << (double)(newtime1-newtime)/CLOCKS_PER_SEC << endl;}
		}
	}
//*******************************************************************************************
	if ((verbosity>0)&&(pattern.length()==0)) {cout << "c     * * * * * * * * * * * * * * *   " << endl;}
	//---------------------------- Writing output  ------------------------------
	if (ONwritetocnf==1) {
	if (verbosity>0) {cout << "c - Writing into output file.. ";}
	newtime=clock();
	answer = WriteOutput(file_name,circuit,num_vars,&num_removed,&num_2cls,&num_3cls,&num_4cls);
	newtime1=clock();
	if (verbosity>0) {cout << "OK! Time: " << fixed << (double)(newtime1-newtime)/CLOCKS_PER_SEC << endl;
	cout << "c - Finish! New / old clauses: " << num_removed << "/" << num_clauses << " clauses; Total time: "<< fixed << (double)(newtime1-start)/CLOCKS_PER_SEC << endl;}
	if (verbosity>1) 
		{
		cout << "c   - 2  clauses:  " <<  num_2cls << endl;
		cout << "c   - 3  clauses:  " <<  num_3cls << endl;
		cout << "c   - 4+ clauses:  " <<  num_4cls << endl;
		}
	if (verbosity>0) {cout << endl;}}

//-------------- finished program ------------------
return 0;
}

//****************************************************************************************
//----------------------------- MAIN deep pure -------------------------------------------
//****************************************************************************************
int MainDeepPure(int numvars, vector<clause> *circuit, vector<variable> *entries, int *counter,int num_chosen,int depth,int *num_2cls,int *num_3cls,int *num_4cls,float timelimit,vector<clause> *removed) {

int answer=0;
int counter_pass=0;
int round=0;
float localtimelimit=timelimit;
float timeellapsed=0;
clock_t start,newtime;

start=clock();
(*counter)=1;
	
while (((timeellapsed<timelimit)||(timelimit==-1))&&((round<depth)||(depth==-1))&&((*counter)!=0))
	{
	round++;
	answer=RemoveClauses(numvars,circuit,entries,&counter_pass,depth,timelimit,localtimelimit,removed);
	answer=Finalize(circuit,entries,counter,num_2cls,num_3cls,num_4cls);
	newtime=clock();
	timeellapsed=(double)(newtime-start)/CLOCKS_PER_SEC;
	localtimelimit=timelimit-timeellapsed;
	counter_pass+=(*counter);
	}
	
(*counter)=counter_pass;
return 0;
}
//****************************************************************************************
//----------------------------- Finalize -------------------------------------------------
//****************************************************************************************
int Finalize(vector<clause> *circuit, vector<variable> *entries, int *counter,int *num_2cls,int *num_3cls,int *num_4cls) {

int lit_index=0;

	(*counter)=0;
	(*num_2cls)=0;
	(*num_3cls)=0;
	(*num_4cls)=0;

	for (int  i=0;i<=(*circuit).size()-1;i++)
		{
		(*circuit)[i].current_size=(*circuit)[i].literals.size();
		if (((*circuit)[i].answer==1)&&((*circuit)[i].literals.size()!=2))
			{
			if ((*circuit)[i].literals.size()==2) {(*num_2cls)++;}
			else if ((*circuit)[i].literals.size()==3) {(*num_3cls)++;}
			else if ((*circuit)[i].literals.size()>=4) {(*num_4cls)++;}
			(*circuit)[i].answer=2;
			(*counter)++;
			for (int  j=0;j<=(*circuit)[i].literals.size()-1;j++)
				{
				lit_index=(*circuit)[i].literals[j];
				if (lit_index>0) {(*entries)[abs(lit_index)-1].pos_size--;}
				else if (lit_index<0) {(*entries)[abs(lit_index)-1].neg_size--;}
				}
			(*circuit)[i].literals.clear();
			(*circuit)[i].lit_answers.clear();
			}
		else if ((*circuit)[i].answer!=2)
			{
			(*circuit)[i].answer=0;
			(*circuit)[i].current_answer=0;
			}
		}
		
return 0;
}
//****************************************************************************************
//------------------------------- Remove clauses -----------------------------------------
//****************************************************************************************

int RemoveClauses(int num_vars, vector<clause> *circuit, vector<variable> *entries, int *counter_pass,int depth,float timelimit,float localtimelimit,vector<clause> *removed){

	int found=0;
	float timeellapsed=0;
	vector<int> positive,negative;
	clock_t start,newtime;
	
	start=clock();

	for (int  i=0;i<=(*entries).size()-1;i++)
		{
		if ((*entries)[i].answer!=2) 
			{
			positive=(*entries)[i].positive;
			negative=(*entries)[i].negative;
		
			if (positive.size()>0) {
			for (int  j=0;j<=positive.size()-1;j++)
				{
				if (((*circuit)[positive[j]].answer!=2)&&(((*circuit)[positive[j]].answer!=1)||((*circuit)[positive[j]].literals.size()==2)))
					{
					found=0;
					if (negative.size()>0) {
					for (int  k=0;k<=negative.size()-1;k++)
						{
						if (((*circuit)[negative[k]].answer!=2)&&(((*circuit)[negative[k]].answer!=1)||((*circuit)[negative[k]].literals.size()==2)))
							{
							if (Distance(&((*circuit)[positive[j]]),&((*circuit)[negative[k]]),entries)==1) {found=1;break;}
							}
						}}
					if (found==0) 
						{
						(*circuit)[positive[j]].answer=1;
						(*circuit)[positive[j]].reasonvar=(i+1);
						(*circuit)[positive[j]].removedreason=2;
						if ((*circuit)[positive[j]].literals.size()!=2) {(*removed).push_back((*circuit)[positive[j]]);}
						}
					}
				}}

			if (negative.size()>0) {
			for (int  j=0;j<=negative.size()-1;j++)
				{
				if (((*circuit)[negative[j]].answer!=2)&&(((*circuit)[negative[j]].answer!=1)||((*circuit)[negative[j]].literals.size()==2)))
					{
					found=0;
					if (positive.size()>0) {
					for (int  k=0;k<=positive.size()-1;k++)
						{
						if (((*circuit)[positive[k]].answer!=2)&&(((*circuit)[positive[k]].answer!=1)||((*circuit)[positive[k]].literals.size()==2)))
							{
							if (Distance(&((*circuit)[negative[j]]),&((*circuit)[positive[k]]),entries)==1) {found=1;break;}
							}
						}}
					if (found==0) 
						{
						(*circuit)[negative[j]].answer=1;
						(*circuit)[negative[j]].reasonvar=-(i+1);
						(*circuit)[negative[j]].removedreason=2;
						if ((*circuit)[negative[j]].literals.size()!=2) {(*removed).push_back((*circuit)[negative[j]]);}
						}
					}
				}}
			}
		newtime=clock();
		timeellapsed=(double)(newtime-start)/CLOCKS_PER_SEC;
		if (((timeellapsed)>localtimelimit)&&(timelimit!=-1)) {break;}
		}

return 0;
}

//****************************************************************************************
//------------------------------- FindDefinitions ----------------------------------------
//****************************************************************************************

int FindDefinitions(int num_vars, vector<clause> *circuit,vector<variable> *entries,int *counter,float timelimit,vector<clause> *removed) {

vector<int> definitions;
vector<int> sorted;
clause cl1,cl2;
int literal;
int answer=0;
int i=0;
clock_t start,newtime;
float timeellapsed=0;

start=clock();

(*counter)=0;
sorted.clear();

answer=SortVars(&sorted,entries);

for (int  l=0;l<=(*entries).size()-1;l++)
	{
	definitions.clear();
	i=sorted[l];
	if (((*entries)[i].positive.size()>0)&&((*entries)[i].negative.size()>0)&&((*entries)[i].answer!=2)) {	
	for (int  j=0;j<=(*entries)[i].positive.size()-1;j++)
		{
		if (((*circuit)[(*entries)[i].positive[j]].literals.size()==2)&&((*circuit)[(*entries)[i].positive[j]].answer!=2)) 
			{
			cl1=(*circuit)[(*entries)[i].positive[j]];
			literal=((abs(cl1.literals[0])-1)==i) ? cl1.literals[1] : cl1.literals[0];
			for (int  k=0;k<=(*entries)[i].negative.size()-1;k++)
				{
				if (((*circuit)[(*entries)[i].negative[k]].literals.size()==2)&&((*circuit)[(*entries)[i].negative[k]].answer!=2)) 
					{
					cl1=(*circuit)[(*entries)[i].negative[k]];
					if (((cl1.literals[0]==-literal)||(cl1.literals[1]==-literal))&&((*entries)[abs(literal)-1].answer!=2))
						{
						definitions.push_back(-literal);
						break;
						}
					}
				}
			}
		}
	if (definitions.size()>0)
		{
		for (int  j=0;j<=definitions.size()-1;j++)
			{
			if ((abs(definitions[j])!=(i+1))&&((*entries)[abs(definitions[j])-1].answer!=2))
				{
				(*counter)++;
				answer=AssignDefinitions(circuit,entries,definitions[j],(*entries)[i].name,removed);
				}
			}
		}}
	newtime=clock();
	timeellapsed=(double)(newtime-start)/CLOCKS_PER_SEC;
	if (((timeellapsed)>timelimit)&&(timelimit!=-1)) {break;}
	}

return 0;
}

//****************************************************************************************
//------------------------------- AssignDefinitions --------------------------------------
//****************************************************************************************

int AssignDefinitions(vector<clause> *circuit,vector<variable> *entries,int oldvar,int newvar,vector<clause> *removed) {

int index1,index2;
int found=0;
int lit_index=0;
int sign=1;
clause cl1;

if (oldvar<0) {newvar=-newvar;}
oldvar=abs(oldvar);

while (2>1)
	{
	if (abs(newvar)!=(*entries)[abs(newvar)-1].definition) 
		{
		if (newvar<0) {sign*=-1;}
		newvar=(*entries)[abs(newvar)-1].definition;
		}
	else {break;}
	}
	
newvar*=sign;
(*entries)[oldvar-1].definition=newvar;
(*entries)[oldvar-1].answer=2;

cl1.removedreason=4;
cl1.reasonvar=oldvar;
cl1.literals.clear();
cl1.literals.push_back(oldvar);
cl1.literals.push_back(-newvar);
(*removed).push_back(cl1);
cl1.literals.clear();
cl1.reasonvar=-oldvar;
cl1.literals.push_back(-oldvar);
cl1.literals.push_back(newvar);
(*removed).push_back(cl1);

for (int  i=0;i<=(*entries)[oldvar-1].positive.size()-1;i++)
	{
	index1=(*entries)[oldvar-1].positive[i];
	if ((*circuit)[index1].answer!=2) {
	if (newvar>0)
		{
		found=0;
		for (int  j=0;j<=(*entries)[abs(newvar)-1].negative.size()-1;j++)
			{
			index2=(*entries)[abs(newvar)-1].negative[j];
			if (index1==index2) {found=1;break;}
			}
		if (found==1) 
			{
			(*circuit)[index1].answer=2;
			for (int  j=0;j<=(*circuit)[index1].literals.size()-1;j++)
				{
				lit_index=(*circuit)[index1].literals[j];
				if (lit_index>0) {(*entries)[abs(lit_index)-1].pos_size--;}
				else if (lit_index<0) {(*entries)[abs(lit_index)-1].neg_size--;}
				}
			}
		
		found=0;
		for (int  j=0;j<=(*entries)[abs(newvar)-1].positive.size()-1;j++)
			{
			index2=(*entries)[abs(newvar)-1].positive[j];
			if (index1==index2) {found=1;break;}
			}
		if (found==0) 
			{
			(*entries)[abs(newvar)-1].positive.push_back(index1);
			(*entries)[abs(newvar)-1].pos_index.push_back((*entries)[oldvar-1].pos_index[i]);
			(*entries)[abs(newvar)-1].pos_size++;
			(*circuit)[index1].literals[(*entries)[oldvar-1].pos_index[i]]=newvar;
			}
		else if (found==1)
			{
			(*circuit)[index1].lit_answers[(*entries)[oldvar-1].pos_index[i]]=1;
			}
		}	
	else if (newvar<0)
		{
		found=0;
		for (int  j=0;j<=(*entries)[abs(newvar)-1].positive.size()-1;j++)
			{
			index2=(*entries)[abs(newvar)-1].positive[j];
			if (index1==index2) {found=1;break;}
			}
		if (found==1) 
			{
			(*circuit)[index1].answer=2;
			for (int  j=0;j<=(*circuit)[index1].literals.size()-1;j++)
				{
				lit_index=(*circuit)[index1].literals[j];
				if (lit_index>0) {(*entries)[abs(lit_index)-1].pos_size--;}
				else if (lit_index<0) {(*entries)[abs(lit_index)-1].neg_size--;}
				}
			}
		
		found=0;
		for (int  j=0;j<=(*entries)[abs(newvar)-1].negative.size()-1;j++)
			{
			index2=(*entries)[abs(newvar)-1].negative[j];
			if (index1==index2) {found=1;break;}
			}
		if (found==0) 
			{
			(*entries)[abs(newvar)-1].negative.push_back(index1);
			(*entries)[abs(newvar)-1].neg_index.push_back((*entries)[oldvar-1].pos_index[i]);
			(*entries)[abs(newvar)-1].neg_size++;
			(*circuit)[index1].literals[(*entries)[oldvar-1].pos_index[i]]=newvar;
			}
		else if (found==1)
			{
			(*circuit)[index1].lit_answers[(*entries)[oldvar-1].pos_index[i]]=1;
			}
		}	
	}}

for (int  i=0;i<=(*entries)[oldvar-1].negative.size()-1;i++)
	{
	index1=(*entries)[oldvar-1].negative[i];
	if ((*circuit)[index1].answer!=2) {
	if (newvar>0)
		{
		found=0;
		for (int  j=0;j<=(*entries)[abs(newvar)-1].positive.size()-1;j++)
			{
			index2=(*entries)[abs(newvar)-1].positive[j];
			if (index1==index2) {found=1;break;}
			}
		if (found==1) 
			{
			(*circuit)[index1].answer=2;
			for (int  j=0;j<=(*circuit)[index1].literals.size()-1;j++)
				{
				lit_index=(*circuit)[index1].literals[j];
				if (lit_index>0) {(*entries)[abs(lit_index)-1].pos_size--;}
				else if (lit_index<0) {(*entries)[abs(lit_index)-1].neg_size--;}
				}
			}
		
		found=0;
		for (int  j=0;j<=(*entries)[abs(newvar)-1].negative.size()-1;j++)
			{
			index2=(*entries)[abs(newvar)-1].negative[j];
			if (index1==index2) {found=1;break;}
			}
		if (found==0) 
			{
			(*entries)[abs(newvar)-1].negative.push_back(index1);
			(*entries)[abs(newvar)-1].neg_index.push_back((*entries)[oldvar-1].neg_index[i]);
			(*entries)[abs(newvar)-1].neg_size++;
			(*circuit)[index1].literals[(*entries)[oldvar-1].neg_index[i]]=-newvar;
			}
		else if (found==1)
			{
			(*circuit)[index1].lit_answers[(*entries)[oldvar-1].neg_index[i]]=1;
			}
		}
		
	else if (newvar<0)
		{
		found=0;
		for (int  j=0;j<=(*entries)[abs(newvar)-1].negative.size()-1;j++)
			{
			index2=(*entries)[abs(newvar)-1].negative[j];
			if (index1==index2) {found=1;break;}
			}
		if (found==1) 
			{
			(*circuit)[index1].answer=2;
			for (int  j=0;j<=(*circuit)[index1].literals.size()-1;j++)
				{
				lit_index=(*circuit)[index1].literals[j];
				if (lit_index>0) {(*entries)[abs(lit_index)-1].pos_size--;}
				else if (lit_index<0) {(*entries)[abs(lit_index)-1].neg_size--;}
				}
			}
		
		found=0;
		for (int  j=0;j<=(*entries)[abs(newvar)-1].positive.size()-1;j++)
			{
			index2=(*entries)[abs(newvar)-1].positive[j];
			if (index1==index2) {found=1;break;}
			}
		if (found==0) 
			{
			(*entries)[abs(newvar)-1].positive.push_back(index1);
			(*entries)[abs(newvar)-1].pos_index.push_back((*entries)[oldvar-1].neg_index[i]);
			(*entries)[abs(newvar)-1].pos_size++;
			(*circuit)[index1].literals[(*entries)[oldvar-1].neg_index[i]]=-newvar;
			}
		else if (found==1)
			{
			(*circuit)[index1].lit_answers[(*entries)[oldvar-1].neg_index[i]]=1;
			}
		}	
	}}
	
(*entries)[oldvar-1].positive.clear();
(*entries)[oldvar-1].pos_index.clear();
(*entries)[oldvar-1].negative.clear();
(*entries)[oldvar-1].neg_index.clear();

return 0;
}

//****************************************************************************************
//--------------------------------- Write Output -----------------------------------------
//****************************************************************************************

int WriteOutput(string file_name,vector<clause> *circuit,int num_vars,int *num_removed,int *num_2cls,int *num_3cls,int *num_4cls) {	
	
	ofstream output;
	
	file_name=file_name+".toast.cnf";	
	output.open(file_name.c_str());
	
	(*num_removed)=0;
	(*num_2cls)=0;
	(*num_3cls)=0;
	(*num_4cls)=0;
	
	for (int  i=0;i<=(*circuit).size()-1;i++) 
		{
		if (((*circuit)[i].answer!=2)) {(*num_removed)++;} //||((*circuit)[i].literals.size()<=2)
		}
	
	output << "p cnf " << num_vars << " " << (*num_removed) << endl;
	for (int  i=0;i<=(*circuit).size()-1;i++)
		{
		if (((*circuit)[i].answer!=2)) //||((*circuit)[i].literals.size()<=2)
			{
			if ((*circuit)[i].literals.size()==2) {(*num_2cls)++;}
			else if ((*circuit)[i].literals.size()==3) {(*num_3cls)++;}
			else if ((*circuit)[i].literals.size()>=4) {(*num_4cls)++;}
			for (int  j=0;j<=(*circuit)[i].literals.size()-1;j++) {output << (*circuit)[i].literals[j] << " ";}
			output << "0" << endl;
			}
		}
	output.close();

return 0;
}

//****************************************************************************************
//---------------------------------- PrintHelp -------------------------------------------
//****************************************************************************************
void PrintHelp() {

cout << endl << "Please specify correct parameters" << endl << endl;

return;
}

//****************************************************************************************
//---------------------------------- ParseOptions ----------------------------------------
//****************************************************************************************

int ParseOptions(int argc,char * argv[],string *file_name,int *verbosity,int *depth,int *NUM_MAX,int *num_chosen,int *roundMAX,int *inner_limit,int *ONadding,int *ONbce,int *ONunit,int *ONresolve,int *ONbve,int *ONprobe,int *ONdefinition,string *pattern,int *globaltimelimit) {

int allok=0;
int found=0;
int number=0;
string word,prefix,suffix;

if (argc<2) {return 1;}
else 
	{
	for (int i=1;i<=argc-1;i++)
		{
		word=argv[i];
		if ((word=="-h")||(word=="-help")) {return 1;}
		else if (word=="-verb") {(*verbosity)=1;}
		else if (word=="-noverb") {(*verbosity)=0;}
		else if (word=="-onadd") {(*ONadding)=1;}
		else if (word=="-offadd") {(*ONadding)=0;}
		else if (word=="-onbce") {(*ONbce)=1;}
		else if (word=="-offbce") {(*ONbce)=0;}
		else if (word=="-onbve") {(*ONbve)=1;}
		else if (word=="-offbve") {(*ONbve)=0;}
		else if (word=="-onunit") {(*ONunit)=1;}
		else if (word=="-offunit") {(*ONunit)=0;}
		else if (word=="-onresolve") {(*ONresolve)=1;}
		else if (word=="-offresolve") {(*ONresolve)=0;}
		else if (word=="-onprobe") {(*ONprobe)=1;}
		else if (word=="-offprobe") {(*ONprobe)=0;}
		else if (word=="-ondefine") {(*ONdefinition)=1;}
		else if (word=="-offdefine") {(*ONdefinition)=0;}
		else 
			{
			found=word.find("=");
			if (found>=0)
				{
				prefix=word.substr(0,found);
				if (prefix=="-nummax") 
					{
					suffix=word.substr(found+1,word.length()-found);
					number=atoi(suffix.c_str());
					if ((number>0)||(number==-1)) {(*NUM_MAX)=number;}
					else {return 1;}
					}
				else if (prefix=="-verb") 
					{
					suffix=word.substr(found+1,word.length()-found);
					number=atoi(suffix.c_str());
					if ((number>0)||(number==-1)) {(*verbosity)=number;}
					else {return 1;}
					}
				else if (prefix=="-depth") 
					{
					suffix=word.substr(found+1,word.length()-found);
					number=atoi(suffix.c_str());
					if ((number>0)||(number==-1)) {(*depth)=number;}
					else {return 1;}
					}
				else if (prefix=="-numchosen") 
					{
					suffix=word.substr(found+1,word.length()-found);
					number=atoi(suffix.c_str());
					if ((number>0)||(number==-1)) {(*num_chosen)=number;}
					else {return 1;}
					}
				else if (prefix=="-roundmax") 
					{
					suffix=word.substr(found+1,word.length()-found);
					number=atoi(suffix.c_str());
					if ((number>0)||(number==-1)) {(*roundMAX)=number;}
					else {return 1;}
					}
				else if (prefix=="-innerlimit") 
					{
					suffix=word.substr(found+1,word.length()-found);
					number=atoi(suffix.c_str());
					if ((number>0)||(number==-1)) {(*inner_limit)=number;}
					else {return 1;}
					}
				else if (prefix=="-timelimit") 
					{
					suffix=word.substr(found+1,word.length()-found);
					number=atoi(suffix.c_str());
					if ((number>0)||(number==-1)) {(*globaltimelimit)=number;}
					else {return 1;}
					}
				else if (prefix=="-pattern") 
					{
					suffix=word.substr(found+1,word.length()-found);
					for (int  j=0;j<=suffix.length()-1;j++)
						{
						if ((suffix[j]!='u')&&(suffix[j]!='v')&&(suffix[j]!='b')&&(suffix[j]!='a')&&(suffix[j]!='d')&&(suffix[j]!='r')&&(suffix[j]!='p')&&(suffix[j]!='t')) {return 1;}
						}
					(*pattern)=suffix;
					}
				else if (allok==0) {(*file_name)=word;allok=1;}
				}
			else if (allok==0) {(*file_name)=word;allok=1;}
			}
		}
	}

if (allok==0) {return 1;}
return 0;
}

//****************************************************************************************
//------------------------------- Distance -----------------------------------------------
//****************************************************************************************

int Distance(clause *clause1, clause *clause2,vector<variable> *entries){

	int dist=0;
	for (int  i=0;i<=(*clause1).literals.size()-1;i++) 
		{
		for (int  j=0;j<=(*clause2).literals.size()-1;j++)
			{
			if ( abs((*clause1).literals[i])==abs((*clause2).literals[j]) ) 
				{
				if (((*clause1).literals[i]==-(*clause2).literals[j])&&((*entries)[abs((*clause1).literals[i])-1].current_assignment==-1))//&&
				//((*entries)[abs((*clause1).literals[i])-1].answer!=2))//&&((*clause1).lit_answers[i]!=1)&&((*clause2).lit_answers[j]!=1)) 
					{dist++; if (dist>=2) {return dist;}}
				break;
				} 
			}
		}
return dist;
}

//****************************************************************************************
//------------------------------- Reconstruct --------------------------------------------
//****************************************************************************************

int Reconstruct(vector<clause> *circuit) {

/*for (int  i=0;i<=(*circuit).size()-1;i++)
	{
	if (((*circuit)[i].answer==2)&&((*circuit)[i].literals.size()<=2)) {(*circuit)[i].answer=0;}
	}
*/
return 0;
}

//****************************************************************************************
//------------------------------- FindCommon --------------------------------------------
//****************************************************************************************

int FindCommon(int varname,vector<int> *arrays, vector<clause> *circuit,vector<int> *common) {

vector<int> local;
vector<int> iterators;
int found=0;
int  counter=0;
int  index=0;
(*common).clear();


if ((*arrays).size()<=0) {return 0;}
else 
	{
	for (int  j=0;j<=(*arrays).size()-1;j++)
		{
		if ((*circuit)[(*arrays)[j]].answer!=2) {
		for (int  i=0;i<=(*circuit)[(*arrays)[j]].literals.size()-1;i++)
			{
			if ((*circuit)[(*arrays)[j]].literals[i]!=varname) 
				{(*common).push_back((*circuit)[(*arrays)[j]].literals[i]);}
			}
		index=j;
		break;
		}}
	}
if ((*common).size()==0) {return 0;}

if ((*arrays).size()>index+1) {
for (int  i=index+1;i<=(*arrays).size()-1;i++)
	{
	if ((*circuit)[(*arrays)[i]].answer!=2) {
	local=(*circuit)[(*arrays)[i]].literals;
	counter=0;
	while (counter<=(*common).size()-1)
		{
		found=0;
		for (int  k=0;k<=local.size()-1;k++) {if ((*common)[counter]==local[k]) {found=1;break;}}
		if (found==0) 
			{
			(*common).erase((*common).begin()+counter);
			if ((*common).size()==0) {return 0;}
			}
		else {counter++;}
		}}
	}}
/*	
if ((*arrays).size()<=0) {return 0;}
else 
	{	
	for (int  j=0;j<=(*arrays).size()-1;j++)
		{
		if ((*circuit)[(*arrays)[j]].answer!=2) {
		for (int  i=0;i<=(*circuit)[(*arrays)[j]].literals.size()-1;i++)
			{
			if ((*circuit)[(*arrays)[j]].literals[i]!=varname) 
				{(*common).push_back((*circuit)[(*arrays)[j]].literals[i]);}
			}
			break;
			}
		}
	}	
*/	
return 0;
}

//****************************************************************************************
//------------------------------- AddBlocked ---------------------------------------------
//****************************************************************************************

int AddBlocked(int num_vars, vector<clause> *circuit,vector<int> *temp_add,vector<variable> *entries,int *counter,int NUMlimit,float timelimit) {

vector<int> local;
vector<int> common;
vector<int> commoncopy;
vector<int> sorted;
int answer=0;
clause addclause;
int found=0;
int i=0;
int MAXcommon=-1;//20000;
float timeellapsed=0;
clock_t start,newtime;

	
start=clock();
(*counter)=0;
addclause.answer=-1;
addclause.temp=1;
addclause.current_answer=-1;
addclause.current_size=2;
addclause.lit_answers.clear();
addclause.lit_answers.push_back(0);
addclause.lit_answers.push_back(0);
(*temp_add).clear();
common.clear();
sorted.clear();


answer=SortVars(&sorted,entries);

for (int  l=0;l<=(*entries).size()-1;l++)
	{
	i=sorted[l];
	if (((*entries)[i].positive.size()>0)&&((*entries)[i].negative.size()>0)&&((*entries)[i].answer!=2)) {
	local=(*entries)[i].positive;
	answer=FindCommon((*entries)[i].name,&local,circuit,&common);
	commoncopy.clear();
	if (common.size()!=0)
		{
		addclause.literals.clear();
		addclause.literals.push_back(-(*entries)[i].name);
		for (int  j=0;j<=common.size()-1;j++)
			{
			found=0;
			for (int  k=0;k<=(*entries)[i].negative.size()-1;k++)
				{
				if (((*circuit)[(*entries)[i].negative[k]].literals.size()==2)&&((*circuit)[(*entries)[i].negative[k]].answer!=2))
					{
					if (((*circuit)[(*entries)[i].negative[k]].literals[0]==-common[j])||((*circuit)[(*entries)[i].negative[k]].literals[1]==-common[j])) {found=1; break;}
					}
				}
			if (found==0) {commoncopy.push_back(common[j]);if ((int(commoncopy.size())>MAXcommon)&&(MAXcommon!=-1)) {break;}}
			}
		}
	
	if (commoncopy.size()>0)
		{
		for (int  j=0;j<=commoncopy.size()-1;j++)
				{
				(*counter)++;
				addclause.literals.push_back(-commoncopy[j]);
				(*temp_add).push_back((*circuit).size());
				(*circuit).push_back(addclause);
				(*entries)[i].negative.push_back((*circuit).size()-1);
				(*entries)[i].neg_index.push_back(0);
				(*entries)[i].neg_size++;
				(*entries)[i].current_neg_size++;
				if (commoncopy[j]<0)
					{
					(*entries)[-commoncopy[j]-1].positive.push_back((*circuit).size()-1);
					(*entries)[-commoncopy[j]-1].pos_index.push_back(1);
					(*entries)[-commoncopy[j]-1].pos_size++;
					(*entries)[-commoncopy[j]-1].current_pos_size++;
					}
				else if (commoncopy[j]>0)
					{
					(*entries)[commoncopy[j]-1].negative.push_back((*circuit).size()-1);
					(*entries)[commoncopy[j]-1].neg_index.push_back(1);
					(*entries)[commoncopy[j]-1].neg_size++;
					(*entries)[commoncopy[j]-1].current_neg_size++;
					}
				if (((*counter)>NUMlimit)&&(NUMlimit!=-1)) {return 0;}
				addclause.literals.pop_back();
				}
		}
	else {
	commoncopy.clear();
	local=(*entries)[i].negative;
	answer=FindCommon(-(*entries)[i].name,&local,circuit,&common);
	if (common.size()!=0)
		{
		addclause.literals.clear();
		addclause.literals.push_back((*entries)[i].name);
		for (int  j=0;j<=common.size()-1;j++)
			{
			found=0;
			for (int  k=0;k<=(*entries)[i].positive.size()-1;k++)
				{
				if (((*circuit)[(*entries)[i].positive[k]].literals.size()==2)&&((*circuit)[(*entries)[i].positive[k]].answer!=2))
					{
					if (((*circuit)[(*entries)[i].positive[k]].literals[0]==-common[j])||((*circuit)[(*entries)[i].positive[k]].literals[1]==-common[j])) {found=1; break;}
					}
				}	
			if (found==0) {commoncopy.push_back(common[j]);if ((int(commoncopy.size())>MAXcommon)&&(MAXcommon!=-1)) {break;}}
			}
		}
		
		if (commoncopy.size()>0)
			{
			for (int  j=0;j<=commoncopy.size()-1;j++)
				{
				(*counter)++;
				addclause.literals.push_back(-commoncopy[j]);
				(*temp_add).push_back((*circuit).size());
				(*circuit).push_back(addclause);
				(*entries)[i].positive.push_back((*circuit).size()-1);
				(*entries)[i].pos_index.push_back(0);
				(*entries)[i].pos_size++;
				(*entries)[i].current_pos_size++;
				if (commoncopy[j]<0)
					{
					(*entries)[-commoncopy[j]-1].positive.push_back((*circuit).size()-1);
					(*entries)[-commoncopy[j]-1].pos_index.push_back(1);
					(*entries)[-commoncopy[j]-1].pos_size++;
					(*entries)[-commoncopy[j]-1].current_pos_size++;
					}
				else if (commoncopy[j]>0)
					{
					(*entries)[commoncopy[j]-1].negative.push_back((*circuit).size()-1);
					(*entries)[commoncopy[j]-1].neg_index.push_back(1);
					(*entries)[commoncopy[j]-1].neg_size++;
					(*entries)[commoncopy[j]-1].current_neg_size++;
					}
				if (((*counter)>NUMlimit)&&(NUMlimit!=-1)) {return 0;}
				addclause.literals.pop_back();
				}
			}
		}}
	newtime=clock();
	timeellapsed=(double)(newtime-start)/CLOCKS_PER_SEC;
	if (((timeellapsed)>timelimit)&&(timelimit!=-1)) {break;}
	}

return 0;
}
//****************************************************************************************
//------------------------------- SortVars -----------------------------------------------
//****************************************************************************************
int SortVars(vector<int> *sorted,vector<variable> *entries) {

int heuristics=1;
int answer=0;

(*sorted).clear();
//---------------- according to variable order -----------------
for (int  i=0;i<=(*entries).size()-1;i++) {(*sorted).push_back(i);}
//---------------- heuristical ---------------------------------
if (heuristics==1) {answer=FastSort(sorted,entries);}

return 0;
}
//****************************************************************************************
//------------------------------- FastSort -----------------------------------------------
//****************************************************************************************
int FastSort(vector<int> *sorted,vector<variable> *entries) {

vector<int> first,second;
int answer=0;
int chosen_index=0;

first.clear();
second.clear();

if ((*sorted).size()<=1) {return 0;}

chosen_index=(*sorted).size()/2;

for (int i=0;i<=chosen_index-1;i++) {first.push_back((*sorted)[i]);}
answer=FastSort(&first,entries);
for (int i=chosen_index;i<=int((*sorted).size()-1);i++) {second.push_back((*sorted)[i]);}
answer=FastSort(&second,entries);
answer=Merge(sorted,&first,&second,entries);
	
return 0;
}	
//****************************************************************************************
//------------------------------- Merge --------------------------------------------------
//****************************************************************************************
int Merge(vector<int> *sorted,vector<int> *first,vector<int> *second,vector<variable> *entries) {

int  index1=0;
int  index2=0;
(*sorted).clear();

while ((index1<(*first).size())||(index2<(*second).size()))
	{
	if (index1>=(*first).size())
		{
		(*sorted).push_back((*second)[index2]);
		index2++;
		}
	else if (index2>=(*second).size())
		{
		(*sorted).push_back((*first)[index1]);
		index1++;
		}
	else 
		{
		if (((*entries)[(*first)[index1]].pos_size+(*entries)[(*first)[index1]].neg_size) > ((*entries)[(*second)[index2]].pos_size+(*entries)[(*second)[index2]].neg_size) )
			{(*sorted).push_back((*first)[index1]);index1++;}
		else 
			{(*sorted).push_back((*second)[index2]);index2++;}
		}
	}

return 0;
}

//****************************************************************************************
//------------------------------- Remove Temp --------------------------------------------
//****************************************************************************************

int RemoveTemp(vector<clause> *circuit,vector<int> *temp_add,vector<variable> *entries) {

int index=0;

if ((*temp_add).size()>0) {
for (int i=(*temp_add).size()-1;i>=0;i--)
	{
	if (((*circuit)[(*temp_add)[i]].temp==1)&&((*circuit)[(*temp_add)[i]].answer!=2))
		{
		(*circuit)[(*temp_add)[i]].answer=2;
		for (int  j=0;j<=(*circuit)[(*temp_add)[i]].literals.size()-1;j++)
			{
			index=(*circuit)[(*temp_add)[i]].literals[j];
			if (index>0) {(*entries)[abs(index)-1].pos_size--;(*entries)[abs(index)-1].current_pos_size--;}
			else {(*entries)[abs(index)-1].neg_size--;(*entries)[abs(index)-1].current_neg_size--;}
			}
		}
	}}

return 0;
}

//****************************************************************************************
//------------------------------- Unit Probing -------------------------------------------
//****************************************************************************************

int UnitProbe(int num_vars,vector<clause> *circuit, vector<variable> *entries, int *counter, vector<int> *unit_q,int innerlimit,float timelimit){

vector<int> watchlist;
vector<int> changedcls;
int lit_index1=0;
int sign1=0;
int counter_unit=0;
int found=0;
int clsindex=0;;
int  litindex=0;
int watchlit=0;
int depthindex=0;
int found_unit=0;
clause unitcls,clause1;
float timeellapsed=0;
clock_t start, newtime;

start=clock();
(*counter)=0;
//(*unit_q).clear();
watchlist.clear();
unitcls.literals.clear();
unitcls.lit_answers.clear();
unitcls.lit_answers.push_back(0);
unitcls.answer=0;
unitcls.temp=0;
unitcls.current_answer=0;
unitcls.current_size=1;
	
	
for (int i=0;i<=2*num_vars-1;i++)
	{
	changedcls.clear();
	watchlist.clear();
	watchlist.push_back(i-2*(i%2)+1);
	depthindex=0;
	found_unit=0;
	if ((*entries)[i/2].answer!=2) {
	while ((found_unit==0)&&(depthindex<int(watchlist.size()))&&((depthindex<innerlimit)||(innerlimit==-1)))
		{
		watchlit=watchlist[depthindex]-2*(watchlist[depthindex]%2)+1;
		if ((watchlit%2)==0)
			{
			if ((*entries)[watchlit/2].positive.size()>0) {
			for (int  j=0;j<=(*entries)[watchlit/2].positive.size()-1;j++)
				{
				clsindex=(*entries)[watchlit/2].positive[j];
				if ((*circuit)[clsindex].answer!=2)
					{
					(*circuit)[clsindex].current_size--;
					changedcls.push_back(clsindex);
					}
				if (((*circuit)[clsindex].answer!=2)&&((*circuit)[clsindex].current_size<=1))
					{
					if ((*circuit)[clsindex].current_size==0) {found_unit=1;break;}
					
					litindex=0;
					while (litindex<(*circuit)[clsindex].literals.size())
						{
						found=0;
						lit_index1=(*circuit)[clsindex].literals[litindex];
						if (lit_index1<0) {sign1=1;} else {sign1=0;}
						
						for (int  k=0;k<=watchlist.size()-1;k++)
							{
							if ((watchlist[k]==(2*(abs(lit_index1)-1)+sign1))||(watchlist[k]==(2*(abs(lit_index1)-1)+1-sign1))) {found=1;break;}
							}
						if (found==0) {break;}
						litindex++;
						}
				
					if (found==0)
						{
						watchlist.push_back(2*(abs(lit_index1)-1)+sign1);						
						if (i==(2*(abs(lit_index1)-1)+sign1)) {found_unit=1;break;}
						}
					}
				}}
			} 
		
		else 
			{
			if ((*entries)[watchlit/2].negative.size()>0) {
			for (int  j=0;j<=(*entries)[watchlit/2].negative.size()-1;j++)
				{
				clsindex=(*entries)[watchlit/2].negative[j];
				if ((*circuit)[clsindex].answer!=2)
					{
					(*circuit)[clsindex].current_size--;
					changedcls.push_back(clsindex);
					}
				if (((*circuit)[clsindex].answer!=2)&&((*circuit)[clsindex].current_size<=1))
					{
					if ((*circuit)[clsindex].current_size==0) {found_unit=1;break;}
					
					litindex=0;
					while (litindex<(*circuit)[clsindex].literals.size())
						{
						found=0;
						lit_index1=(*circuit)[clsindex].literals[litindex];
						if (lit_index1<0) {sign1=1;} else {sign1=0;}
						
						for (int  k=0;k<=watchlist.size()-1;k++)
							{
							if ((watchlist[k]==(2*(abs(lit_index1)-1)+sign1))||(watchlist[k]==(2*(abs(lit_index1)-1)+1-sign1))) {found=1;break;}
							}
						if (found==0) {break;}
						litindex++;
						}
				
					if (found==0)
						{
						watchlist.push_back(2*(abs(lit_index1)-1)+sign1);						
						if (i==(2*(abs(lit_index1)-1)+sign1)) {found_unit=1;break;}
						}
					}
				}}
			} 		
		depthindex++;
		}
		
	if (found_unit==1) 
		{
		counter_unit++;
		unitcls.literals.clear();
		if ((i%2)==0)
			{
			unitcls.literals.push_back(i/2+1);
			(*entries)[i/2].positive.push_back((*circuit).size());
			(*entries)[i/2].pos_index.push_back(0);
			(*entries)[i/2].pos_size++;
			(*entries)[i/2].current_pos_size++;
			}
		else
			{
			unitcls.literals.push_back(-((i+1)/2));
			(*entries)[(i-1)/2].negative.push_back((*circuit).size());
			(*entries)[(i-1)/2].neg_index.push_back(0);
			(*entries)[(i-1)/2].neg_size++;
			(*entries)[(i-1)/2].current_neg_size++;
			}
		(*unit_q).push_back((*circuit).size());
		(*circuit).push_back(unitcls);
		}
		
	if (changedcls.size()>0)
		{
		for (int  j=0;j<=changedcls.size()-1;j++)
			{
			(*circuit)[changedcls[j]].current_size=(*circuit)[changedcls[j]].literals.size();
			}
		}}
	newtime=clock();
	timeellapsed=(double)(newtime-start)/CLOCKS_PER_SEC;
	if (((timeellapsed)>timelimit)&&(timelimit!=-1)) {break;}	
	}	
	
return 0;
}

//****************************************************************************************
//------------------------------- Resolution ---------------------------------------------
//****************************************************************************************

int Resolve2cls(int num_vars,vector<clause> *circuit,vector<variable> *entries,int *counter,vector<int> *unit_q,float timelimit) {

vector<int> watchlist;
int lit_index1=0;
int sign1=0;
int counter_unit=0;
int found=0;
int clsindex=0;;
int litindex=0;
int watchlit=0;
int innerlimit=-1; // ** important **
int depthindex=0;
int found_unit=0;
clause unitcls,clause1;
float timeellapsed=0;
clock_t start,newtime;

start=clock();
(*counter)=0;
(*unit_q).clear();
watchlist.clear();
unitcls.literals.clear();
unitcls.lit_answers.clear();
unitcls.lit_answers.push_back(0);
unitcls.answer=0;
unitcls.temp=0;
unitcls.current_answer=0;
unitcls.current_size=1;

//------------- new -------------------

for (int i=0;i<=2*num_vars-1;i++)
	{
	watchlist.clear();
	watchlist.push_back(i-2*(i%2)+1);
	depthindex=0;
	found_unit=0;
	if ((*entries)[i/2].answer!=2) {
	while ((found_unit==0)&&(depthindex<int(watchlist.size()))&&((depthindex<innerlimit)||(innerlimit==-1)))
		{
		watchlit=watchlist[depthindex]-2*(watchlist[depthindex]%2)+1;
		if ((watchlit%2)==0)
			{
			if ((*entries)[watchlit/2].positive.size()>0) {
			for (int  j=0;j<=(*entries)[watchlit/2].positive.size()-1;j++)
				{
				clsindex=(*entries)[watchlit/2].positive[j];
				if (((*circuit)[clsindex].answer!=2)&&((*circuit)[clsindex].literals.size()==2))
					{
					if ((*circuit)[clsindex].literals[0]==(*entries)[watchlit/2].name) {litindex=1;}
					else {litindex=0;}
					lit_index1=(*circuit)[clsindex].literals[litindex];
					if (lit_index1<0) {sign1=1;} else {sign1=0;}
					
					found=0;
					for (int  k=0;k<=watchlist.size()-1;k++)
						{
						if (watchlist[k]==(2*(abs(lit_index1)-1)+sign1)) {found=1;break;}
						}
					if (found==0)
						{
						watchlist.push_back(2*(abs(lit_index1)-1)+sign1);						
						if (i==(2*(abs(lit_index1)-1)+sign1)) {found_unit=1;break;}
						}
					}
				}}
			} 
		
		else 
			{
			if ((*entries)[(watchlit-1)/2].negative.size()>0) {
			for (int  j=0;j<=(*entries)[(watchlit-1)/2].negative.size()-1;j++)
				{
				clsindex=(*entries)[(watchlit-1)/2].negative[j];
				if (((*circuit)[clsindex].answer!=2)&&((*circuit)[clsindex].literals.size()==2))
					{
					if ((-(*circuit)[clsindex].literals[0])==(*entries)[(watchlit-1)/2].name) {litindex=1;}
					else {litindex=0;}
					lit_index1=(*circuit)[clsindex].literals[litindex];
					if (lit_index1<0) {sign1=1;} else {sign1=0;}
					
					found=0;
					for (int  k=0;k<=watchlist.size()-1;k++)
						{
						if (watchlist[k]==(2*(abs(lit_index1)-1)+sign1)) {found=1;break;}
						}
					if (found==0)
						{
						watchlist.push_back(2*(abs(lit_index1)-1)+sign1);					
						if (i==(2*(abs(lit_index1)-1)+sign1)) {found_unit=1;break;}
						}
					}
				}}
			} 		
		depthindex++;
		}
	
	//--------------------- removing clauses ----------------------	
	if (((i%2)==0)&&((*entries)[i/2].positive.size()>0))
		{
		for (int  j=0;j<=(*entries)[i/2].positive.size()-1;j++)
			{
			clsindex=(*entries)[i/2].positive[j];
			if ((found_unit==1)&&((*circuit)[clsindex].answer!=2))
				{
				(*counter)++;
				(*circuit)[clsindex].answer=2;
				(*entries)[i/2].current_pos_size--;
				}
			else if (((*circuit)[clsindex].answer!=2)&&((*circuit)[clsindex].literals.size()>2)) {
			for (int  k=0;k<=(*circuit)[clsindex].literals.size()-1;k++)
				{
				lit_index1=(*circuit)[clsindex].literals[k];
				if (lit_index1<0) {sign1=1;} else {sign1=0;}
				found=0;
				for (int  l=0;l<=watchlist.size()-1;l++)
					{
					if (watchlist[l]==2*(abs(lit_index1)-1)+sign1) {found=1;break;}
					}
				if (found==1) 
					{
					(*counter)++;
					(*circuit)[clsindex].answer=2;
					(*entries)[i/2].current_pos_size--;
					break;
					}
				}}
			}
		}
	else if (((i%2)==1)&&((*entries)[(i-1)/2].negative.size()>0))
		{
		for (int  j=0;j<=(*entries)[(i-1)/2].negative.size()-1;j++)
			{
			clsindex=(*entries)[(i-1)/2].negative[j];
			if ((found_unit==1)&&((*circuit)[clsindex].answer!=2))
				{
				(*counter)++;
				(*circuit)[clsindex].answer=2;
				(*entries)[(i-1)/2].current_neg_size--;
				}
			else if (((*circuit)[clsindex].answer!=2)&&((*circuit)[clsindex].literals.size()>2)) {
			for (int  k=0;k<=(*circuit)[clsindex].literals.size()-1;k++)
				{
				lit_index1=(*circuit)[clsindex].literals[k];
				if (lit_index1<0) {sign1=1;} else {sign1=0;}
				found=0;
				for (int  l=0;l<=watchlist.size()-1;l++)
					{
					if (watchlist[l]==2*(abs(lit_index1)-1)+sign1) {found=1;break;}
					}
				if (found==1) 
					{
					(*counter)++;
					(*circuit)[clsindex].answer=2;
					(*entries)[(i-1)/2].current_neg_size--;
					break;
					}
				}}
			}
		}
	
	//-------------------------------------------------------------
		
	if (found_unit==1) 
		{
		counter_unit++;
		unitcls.literals.clear();
		if ((i%2)==0)
			{
			unitcls.literals.push_back(i/2+1);
			(*entries)[i/2].positive.push_back((*circuit).size());
			(*entries)[i/2].pos_index.push_back(0);
			(*entries)[i/2].pos_size++;
			(*entries)[i/2].current_pos_size++;
			}
		else
			{
			unitcls.literals.push_back(-((i+1)/2));
			(*entries)[(i-1)/2].negative.push_back((*circuit).size());
			(*entries)[(i-1)/2].neg_index.push_back(0);
			(*entries)[(i-1)/2].neg_size++;
			(*entries)[(i-1)/2].current_neg_size++;
			}
		(*unit_q).push_back((*circuit).size());
		(*circuit).push_back(unitcls);
		}}
	newtime=clock();
	timeellapsed=(double)(newtime-start)/CLOCKS_PER_SEC;
	if (((timeellapsed)>timelimit)&&(timelimit!=-1)) {break;}	
	}
//-------------------------------------

return 0;
}

//****************************************************************************************
//------------------------------- Unit Propagation ---------------------------------------
//****************************************************************************************

int UnitPropagation(vector< clause > *circuit, vector< variable > *entries, int *counter, vector<int> *unit_q,float timelimit,vector<clause> *removed){

	clause clause1;
	int unit_literal;
	int  i,j;
	int index;
	int index_inside;
	int counter_new=0;
	
	i=0;
	while (i<(*unit_q).size())
		{
		if ((*circuit)[(*unit_q)[i]].answer!=2) {
		j=0;
		while ((*circuit)[(*unit_q)[i]].lit_answers[j]==1) {j++;}
		unit_literal=(*circuit)[(*unit_q)[i]].literals[j];

		if (unit_literal>0)
			{
			(*entries)[abs(unit_literal)-1].current_assignment=1;
			if ((*entries)[abs(unit_literal)-1].positive.size()>0)
				{
				for (j=0;j<=(*entries)[abs(unit_literal)-1].positive.size()-1;j++)
					{
					index=(*entries)[abs(unit_literal)-1].positive[j];
					if ((index!=(*unit_q)[i])&&((*circuit)[index].answer!=2))
						{(*circuit)[index].answer=2;(*entries)[abs(unit_literal)-1].pos_size--;counter_new++;}
					}
				}
			if ((*entries)[abs(unit_literal)-1].negative.size()>0)
				{
				for (j=0;j<=(*entries)[abs(unit_literal)-1].negative.size()-1;j++)
					{
					index=(*entries)[abs(unit_literal)-1].negative[j];
					index_inside=(*entries)[abs(unit_literal)-1].neg_index[j];

					if ((index!=(*unit_q)[i])&&((*circuit)[index].answer!=2)&&((*circuit)[index].lit_answers[index_inside]!=1))
						{
						(*circuit)[index].lit_answers[index_inside]=1;
						(*circuit)[index].current_size--;
		
						if ((*circuit)[index].current_size==0) {cout << "conflict!!!!" << endl;return 1;}
						if ((*circuit)[index].current_size==1) {(*unit_q).push_back(index);}
						}
					}
				}
			}
		else 
			{
			(*entries)[abs(unit_literal)-1].current_assignment=0;
			if ((*entries)[abs(unit_literal)-1].negative.size()>0)
				{
				for (j=0;j<=(*entries)[abs(unit_literal)-1].negative.size()-1;j++)
					{
					index=(*entries)[abs(unit_literal)-1].negative[j];
					if ((index!=(*unit_q)[i])&&((*circuit)[index].answer!=2))
						{(*circuit)[index].answer=2;(*entries)[abs(unit_literal)-1].neg_size--;counter_new++;}
					}
				}
			
			if ((*entries)[abs(unit_literal)-1].positive.size()>0)
				{
				for (j=0;j<=(*entries)[abs(unit_literal)-1].positive.size()-1;j++)
					{
					index=(*entries)[abs(unit_literal)-1].positive[j];
					index_inside=(*entries)[abs(unit_literal)-1].pos_index[j];
				
					if ((index!=(*unit_q)[i])&&((*circuit)[index].answer!=2)&&((*circuit)[index].lit_answers[index_inside]!=1))
						{
						(*circuit)[index].lit_answers[index_inside]=1;
						(*circuit)[index].current_size--;
						
						if ((*circuit)[index].current_size==0) {cout << "conflict!!!!" << endl;return 1;}
						if ((*circuit)[index].current_size==1) {(*unit_q).push_back(index);}
						}
					}
				}
			}
		  (*entries)[abs(unit_literal)-1].answer=2;
		  (*entries)[abs(unit_literal)-1].positive.clear();
		  (*entries)[abs(unit_literal)-1].pos_index.clear();		
		  (*entries)[abs(unit_literal)-1].negative.clear();
		  (*entries)[abs(unit_literal)-1].neg_index.clear();		
		  (*circuit)[(*unit_q)[i]].answer=2;
		  counter_new++;
		  }
		i++;
		}
(*counter)=counter_new;
return 0;
}

//****************************************************************************************
//------------------------------- ReconstructUnit ----------------------------------------
//****************************************************************************************

int ReconstructUnit(vector<clause> *circuit, vector<variable> *entries,vector<int> *temp_add,vector<int> *unit_q) {

clause cl1;
int  index=0;
int  index_lit=0;
variable lit1;
vector<clause> circuit_copy;

circuit_copy.clear();
(*temp_add).clear();

if ((*entries).size()>0) {
for (int  i=0;i<=(*entries).size()-1;i++)
	{
	(*entries)[i].positive.clear();
	(*entries)[i].negative.clear();
	(*entries)[i].pos_index.clear();
	(*entries)[i].neg_index.clear();
	(*entries)[i].pos_size=0;
	(*entries)[i].neg_size=0;
	(*entries)[i].current_pos_size=0;
	(*entries)[i].current_neg_size=0;
	}}

while (index <= (*circuit).size()-1)
	{
	if ((*circuit)[index].answer==2) {index++;}
	else 
		{
		cl1=(*circuit)[index];
		index_lit=0;
		while (index_lit <= cl1.literals.size()-1)
			{
			if (cl1.lit_answers[index_lit]==1) 
				{
				cl1.literals.erase(cl1.literals.begin()+index_lit);
				cl1.lit_answers.erase(cl1.lit_answers.begin()+index_lit);
				}
			else 
				{
				if (cl1.literals[index_lit]>0)
					{
					(*entries)[abs(cl1.literals[index_lit])-1].positive.push_back(circuit_copy.size());
					(*entries)[abs(cl1.literals[index_lit])-1].pos_index.push_back(index_lit);
					(*entries)[abs(cl1.literals[index_lit])-1].pos_size++;
					(*entries)[abs(cl1.literals[index_lit])-1].current_pos_size++;
					}
				else if (cl1.literals[index_lit]<0)
					{
					(*entries)[abs(cl1.literals[index_lit])-1].negative.push_back(circuit_copy.size());
					(*entries)[abs(cl1.literals[index_lit])-1].neg_index.push_back(index_lit);
					(*entries)[abs(cl1.literals[index_lit])-1].neg_size++;
					(*entries)[abs(cl1.literals[index_lit])-1].current_neg_size++;
					}
				index_lit++;
				}
			}
		if ((*circuit)[index].temp==1) {(*temp_add).push_back(circuit_copy.size());}
		cl1.current_size=cl1.literals.size();
		if (cl1.current_size==1) {(*unit_q).push_back(circuit_copy.size());}
		circuit_copy.push_back(cl1);
		index++;
		}
	}
(*circuit)=circuit_copy;
	
return 0;
}

//****************************************************************************************
//-------------------------------- VarElim -----------------------------------------------
//****************************************************************************************
int VarElim(int num_vars,vector<clause> *circuit,vector<variable> *entries,int *counter,int *varcount,float timelimit,vector<clause> *removed) {

int bound=0;
int score=0;
int answer=0;
int index=0;
vector<int> sorted;
float timeellapsed=0;
clock_t start,newtime;

start=clock();
(*counter)=0;
(*varcount)=0;
answer=SortVars(&sorted,entries);

for (int  i=0;i<=(*entries).size()-1;i++)
	{
	index=sorted[i];
	if ((*entries)[index].answer!=2)
		{
		answer=CountScore(index,circuit,entries,&score);
		if (score<=bound) 
			{
			(*varcount)++;
			answer=Eliminate(index,circuit,entries,counter,removed);	
			(*entries)[index].answer=2;	
			(*entries)[index].positive.clear();
			(*entries)[index].pos_index.clear();		
			(*entries)[index].negative.clear();
			(*entries)[index].neg_index.clear();		
			}
		}
	newtime=clock();
	timeellapsed=(double)(newtime-start)/CLOCKS_PER_SEC;
	if (((timeellapsed)>timelimit)&&(timelimit!=-1)) {break;}
	}

return 0;
}

//****************************************************************************************
//-------------------------------- CountScore --------------------------------------------
//****************************************************************************************
int CountScore(int index,vector<clause> *circuit,vector<variable> *entries,int *score) {

int answer=0;
int ind1=0;
int ind2=0;
int score_max=10;

if (((*entries)[index].pos_size==0)||((*entries)[index].neg_size==0)) {(*score)=-1;return 0;}
(*score)=(-(*entries)[index].pos_size-(*entries)[index].neg_size)/1.5;

for (int  i=0;i<=(*entries)[index].positive.size()-1;i++)
	{
	ind1=(*entries)[index].positive[i];
	if ((*circuit)[ind1].answer!=2) 
		{
		for (int  j=0;j<=(*entries)[index].negative.size()-1;j++)
			{
			ind2=(*entries)[index].negative[j];
			if ((*circuit)[ind2].answer!=2) 
				{
				answer=Distance(&((*circuit)[ind1]),&((*circuit)[ind2]),entries);
				if (answer==1) {(*score)++;}
				}
			if ((*score)>score_max) {return 0;}
			}
		}
	}

return 0;
}
//****************************************************************************************
//-------------------------------- Eliminate ---------------------------------------------
//****************************************************************************************
int Eliminate(int index,vector<clause> *circuit,vector<variable> *entries,int *counter,vector<clause> *removed) {

clause clause1;
int ind1=0;
int ind2=0;
int litindex=0;
int answer=0;
int found=0;

clause1.answer=0;
clause1.current_answer=0;
clause1.current_size=0;
clause1.temp=0;

//--------- add new clauses ----------------
if (((*entries)[index].positive.size()>0)&&((*entries)[index].negative.size()>0)) {
for (int  i=0;i<=(*entries)[index].positive.size()-1;i++)
	{
	ind1=(*entries)[index].positive[i];
	if ((*circuit)[ind1].answer!=2) 
		{
		for (int  j=0;j<=(*entries)[index].negative.size()-1;j++)
			{
			ind2=(*entries)[index].negative[j];
			if ((*circuit)[ind2].answer!=2) 
				{
				answer=Distance(&((*circuit)[ind1]),&((*circuit)[ind2]),entries);
				if (answer==1)
					{
					clause1.literals.clear();
					clause1.lit_answers.clear();
					for (int  k=0;k<=(*circuit)[ind1].literals.size()-1;k++)
						{
						litindex=(*circuit)[ind1].literals[k];
						if (litindex!=(index+1))
							{
							if (litindex>0) 
								{
								(*entries)[abs(litindex)-1].positive.push_back((*circuit).size());
								(*entries)[abs(litindex)-1].pos_index.push_back(clause1.literals.size());
								(*entries)[abs(litindex)-1].current_pos_size++;
								(*entries)[abs(litindex)-1].pos_size++;
								}
							else 
								{
								(*entries)[abs(litindex)-1].negative.push_back((*circuit).size());
								(*entries)[abs(litindex)-1].neg_index.push_back(clause1.literals.size());
								(*entries)[abs(litindex)-1].current_neg_size++;
								(*entries)[abs(litindex)-1].neg_size++;
								}
							clause1.literals.push_back(litindex);
							clause1.lit_answers.push_back(0);
							clause1.current_size++;
							}
						}
					for (int  k=0;k<=(*circuit)[ind2].literals.size()-1;k++)
						{
						litindex=(*circuit)[ind2].literals[k];
						found=0;
						if (clause1.literals.size()>0) {
						for (int  l=0;l<=clause1.literals.size()-1;l++)
							{
							if (litindex==clause1.literals[l]) {found=1;break;}
							}}
						if ((litindex!=(-index-1))&&(found==0))
							{
							if (litindex>0) 
								{
								(*entries)[abs(litindex)-1].positive.push_back((*circuit).size());
								(*entries)[abs(litindex)-1].pos_index.push_back(clause1.literals.size());
								(*entries)[abs(litindex)-1].current_pos_size++;
								(*entries)[abs(litindex)-1].pos_size++;
								}
							else 
								{
								(*entries)[abs(litindex)-1].negative.push_back((*circuit).size());
								(*entries)[abs(litindex)-1].neg_index.push_back(clause1.literals.size());
								(*entries)[abs(litindex)-1].current_neg_size++;
								(*entries)[abs(litindex)-1].neg_size++;
								}
							clause1.literals.push_back(litindex);
							clause1.lit_answers.push_back(0);
							clause1.current_size++;
							}
						}
					(*circuit).push_back(clause1);
					(*counter)--;
					}
				}
			}
		}
	}}	

//--------- remove old clauses -------------				
if ((*entries)[index].positive.size()>0) {	
for (int  i=0;i<=(*entries)[index].positive.size()-1;i++)
	{
	ind1=(*entries)[index].positive[i];
	if ((*circuit)[ind1].answer!=2)
		{
		(*circuit)[ind1].answer=2;
		(*circuit)[ind1].removedreason=3;
		(*circuit)[ind1].reasonvar=index+1;
		(*removed).push_back((*circuit)[ind1]);
		(*counter)++;
		for (int  k=0;k<=(*circuit)[ind1].literals.size()-1;k++)
			{
			litindex=(*circuit)[ind1].literals[k];
			if (litindex>0) {(*entries)[abs(litindex)-1].current_pos_size--;(*entries)[abs(litindex)-1].pos_size--;}
			else {(*entries)[abs(litindex)-1].current_neg_size--;(*entries)[abs(litindex)-1].neg_size--;}
			}
		(*circuit)[ind1].literals.clear();
		(*circuit)[ind1].lit_answers.clear();
		}
	}}
	
if ((*entries)[index].negative.size()>0) {	
for (int  i=0;i<=(*entries)[index].negative.size()-1;i++)
	{
	ind1=(*entries)[index].negative[i];
	if ((*circuit)[ind1].answer!=2)
		{
		(*circuit)[ind1].answer=2;
		(*circuit)[ind1].removedreason=3;
		(*circuit)[ind1].reasonvar=-(index+1);
		(*removed).push_back((*circuit)[ind1]);
		(*counter)++;
		for (int  k=0;k<=(*circuit)[ind1].literals.size()-1;k++)
			{
			litindex=(*circuit)[ind1].literals[k];
			if (litindex>0) {(*entries)[abs(litindex)-1].current_pos_size--;(*entries)[abs(litindex)-1].pos_size--;}
			else {(*entries)[abs(litindex)-1].current_neg_size--;(*entries)[abs(litindex)-1].neg_size--;}
			}
		(*circuit)[ind1].literals.clear();
		(*circuit)[ind1].lit_answers.clear();
		}
	}}

return 0;
}

//****************************************************************************************
//------------------------------- Subsumption --------------------------------------------
//****************************************************************************************
int Subsumption(vector< clause > *circuit, vector< variable > *entries, int *counter){

(*counter)=0;

return 0;
}

//****************************************************************************************
//------------------------------- ReconstructSat -----------------------------------------
//****************************************************************************************
int ReconstructSat(vector<clause> *circuit_original,vector<variable> *entries, vector<clause> *removed,vector<int> *assignments) {

clause cl1;
int satisfied=0;
int vval=0;

if ((*removed).size() > 0 ) {

//--- reconstruct definitions ---
int def=0;
int sign=1;
for (int i=0;i<=int((*entries).size()-1);i++)
	{
    if ((*entries)[i].definition!=(i+1))
        {
        vval=i+1;
        def=(*entries)[i].definition;
        sign=1;
        while (2>1)
			{
			if (abs(def)!=(*entries)[abs(def)-1].definition) 
				{
				if (def<0) {sign*=-1;}
				def=(*entries)[abs(def)-1].definition;
				}
			else {break;}
			}
		def*=sign;
		sign = (def<0) ? -1 : 1;
		(*entries)[i].definition=def;
    	if (def<0) {vval*=-1;}
        if ((*assignments)[abs(def)-1]<0) {vval*=-1;}
        (*assignments)[i]=vval;
        }
    } 
//---------------------------------	

for (int i=(*removed).size()-1;i>=0;i--)
	{
	cl1=(*removed)[i];
	if (cl1.removedreason==2) //bce
		{
		satisfied=0;
		if (cl1.literals.size()>0) {
		for (int  j=0;j<=cl1.literals.size()-1;j++)
			{
			if ((*assignments)[abs(cl1.literals[j])-1]==cl1.literals[j]) {satisfied=1;break;}
			}
		if (satisfied==0) {(*assignments)[abs(cl1.reasonvar)-1]*=-1;}}
		}
	else if (cl1.removedreason==3) //bve
		{
		satisfied=0;
		if (cl1.literals.size()>0) {
		for (int  j=0;j<=cl1.literals.size()-1;j++)
			{
			if ((*assignments)[abs(cl1.literals[j])-1]==cl1.literals[j]) {satisfied=1;break;}
			}
		if (satisfied==0) {(*assignments)[abs(cl1.reasonvar)-1]*=-1;}}
		}
	else if (cl1.removedreason==4) //definition
		{
		satisfied=0;
		if (cl1.literals.size()>0) {
		for (int  j=0;j<=cl1.literals.size()-1;j++)
			{
			if ((*assignments)[abs(cl1.literals[j])-1]==cl1.literals[j]) {satisfied=1;break;}
			}
		if (satisfied==0) {(*assignments)[abs(cl1.reasonvar)-1]*=-1;}}
		}
	}
	
//verify that all removed clauses have been satisfied
for (int i=0;i<=(*circuit_original).size()-1;i++)
	{
	cl1=(*circuit_original)[i];
	satisfied=0;
	if (cl1.literals.size()>0) {
	for (int  j=0;j<=cl1.literals.size()-1;j++)
		{
		if ((*assignments)[abs(cl1.literals[j])-1]==cl1.literals[j]) {satisfied=1;break;}
		}
	if (satisfied==0) {return 1;}}
	}}
	
return 0;
}