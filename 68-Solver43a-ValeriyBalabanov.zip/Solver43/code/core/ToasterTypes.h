#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include <math.h>
#include <time.h>
#include <cstring>
#include <zlib.h>

using namespace std;
//----------------------------------------------------------------------------------------
typedef struct variable_ variable;
typedef struct clause_ clause;

struct clause_
	{
	int answer;		//answer=0 - initial; 1 - can be removed for current assignment (also includes that clause evaluates to 1);
					//-1 - can't be removed for the current assignment; 
					//2 - can be removed in general; -2 - can't be removed!!!
	int removedreason; //1 - unit; 2 - bce; 3 - bve; 4 - definition;
	int reasonvar; //variable, responsible for removing;
	int current_answer;
	int current_size;
	int temp; //0 - for regular clauses; 1 - for temp clauses;
	vector<int> literals;
	vector<int> lit_answers;
	};

struct variable_
	{
	int answer; //answer=0 - initial; 2 - can be removed;
	int temp_answer; //used for unit probing;
	int name;
	int pos_size; //current sizes;
	int neg_size;
	int definition; //originally equal to itself;
	int current_pos_size;
	int current_neg_size;
	int current_assignment; //-1 - unassigned;
	vector<int> positive;
	vector<int> pos_index;
 	vector<int> negative;
	vector<int> neg_index;
	};
//----------------------------------------------------------------------------------------
//------------ **** MAIN functions ***** ----------------
int Toaster(int *ONtoaster,gzFile in,string pattern, int *num_vars,int *num_clauses,vector<variable> *entries, vector<clause> *circuit,vector<clause> *circuit_original, vector<clause> *removed,int verbosity);
int ParseOptions(int argc,char * argv[],string *file_name,int *verbosity,int *depth,int *NUM_MAX,int *num_chosen,int *roundMAX,int *inner_limit,int *ONadding,int *ONbce,int *ONunit,int *ONresolve,int *ONbve,int *ONprobe,int *ONdefinition,string *pattern,int *globaltimelimit);
int ParseInput(string file_name,int *num_vars,int *num_clauses,vector<clause> *circuit,vector<variable> *entries,vector<int> *unit_q,int *num_2cls,int *num_3cls,int *num_4cls);
int UnitPropagation(vector< clause > *circuit, vector< variable > *entries, int *counter, vector<int> *unit_q,float timelimit,vector<clause> *removed);
int Subsumption(vector< clause > *circuit, vector< variable > *entries, int *counter,float timelimit); //not implemented yet
int VarElim(int num_vars,vector<clause> *circuit,vector<variable> *entries,int *counter,int *varcount,float timelimit,vector<clause> *removed);
int MainDeepPure(int numvars, vector< clause > *circuit, vector< variable > *entries, int *counter,int num_chosen,int depth,int *num_2cls,int *num_3cls,int *num_4cls,float timelimit,vector<clause> *removed);
int AddBlocked(int num_vars,vector<clause> *circuit,vector<int> *temp_add,vector<variable> *entries,int *counter,int num_chosen,float timelimit);
int Resolve2cls(int num_vars,vector<clause> *circuit,vector<variable> *entries,int *counter,vector<int> *unit_q,float timelimit);
int UnitProbe(int num_vars,vector<clause> *circuit, vector<variable> *entries, int *counter, vector<int> *unit_q,int innerlimit,float timelimit);
int FindDefinitions(int num_vars, vector<clause> *circuit,vector<variable> *entries,int *counter,float timelimit,vector<clause> *removed);
int ReconstructSat(vector<clause> *circuit,vector<variable> *entries, vector<clause> *removed,vector<int> *assignments);
//------------ **** Function helpers **** ---------------
void PrintHelp();
int Distance(clause *clause1, clause *clause2,vector<variable> *entries);
int DetectPure(vector< clause > *circuit, vector< variable > *entries);
int RemoveClauses(int num_vars, vector<clause> *circuit, vector<variable> *entries, int *counter_pass,int depth,float timelimit, float localtimelimit,vector<clause> *removed);
int WriteOutput(string file_name,vector<clause> *circuit,int num_vars,int *num_removed,int *num_2cls,int *num_3cls,int *num_4cls);
int ChooseVars(int round, int num_vars, int num_chosen, vector<clause> *circuit, vector<variable> *entries, vector<int> *chosen_vars); //also assign all 0s
int AssignVars(int index,int numvars,vector<clause> *circuit, vector<variable> *entries, vector<int> *chosen_vars); //changes ass of one var in hamming code manner
int DetectUnsat(int *index,vector<clause> *circuit,vector<int> *unsat_array); //detecting if some clause is 0 under current assignment;
int ResetAssign(vector<clause> *circuit,vector<variable> *entries);
int CheckBlocked(vector<clause> *circuit);
int Finalize(vector< clause > *circuit, vector< variable > *entries, int *counter,int *num_2cls,int *num_3cls,int *num_4cls);
int FindCommon(int varname,vector<int> *arrays, vector<clause> *circuit,vector<int> *common);
int Reconstruct(vector<clause> *circuit);
int ReconstructUnit(vector<clause> *circuit, vector<variable> *entries,vector<int> *temp_add,vector<int> *unit_q);
int SortVars(vector<int> *sorted,vector<variable> *entries);
int FastSort(vector<int> *sorted,vector<variable> *entries);
int Merge(vector<int> *sorted,vector<int> *first,vector<int> *second,vector<variable> *entries);
int Eliminate(int index,vector<clause> *circuit,vector<variable> *entries,int *counter,vector<clause> *removed);
int CountScore(int index,vector<clause> *circuit,vector<variable> *entries,int *score);
int RemoveTemp(vector<clause> *circuit,vector<int> *temp_add,vector<variable> *entries);
int AssignDefinitions(vector<clause> *circuit,vector<variable> *entries,int oldvar,int newvar,vector<clause> *removed);