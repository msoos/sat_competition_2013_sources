For static compiling: 
./build.sh


For running: 
./solver43_static BENCHNAME