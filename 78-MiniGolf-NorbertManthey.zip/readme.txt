MiniGolf version SAT Competition 2013
------------------------------------------
Authors:
------------------------------------------
code MiniGolf: Norbert Manthey - TU Dresden - norbert.manthey@tu-dresden.de
------------------------------------------

Compile & execute:
------------------------------------------
call the build.sh script 
cd binary
execute with ./minigolf <instance> 
------------------------------------------

Further Details
------------------------------------------
See SAT Competition 2013 solver description for further details!
------------------------------------------
