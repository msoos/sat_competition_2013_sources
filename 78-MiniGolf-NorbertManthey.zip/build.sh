#!/bin/sh
rm -rf binary
mkdir binary
cd code/minisat22/simp; make rs MROOT=..
cd ../../..
cp code/minisat22/simp/minigolf_static binary/minigolf
