DimetheusMPS README.

Solver:  DimetheusMPS
Author:  Oliver Gableske (oliver@gableske.net)
Website: https://www.gableske.net/dimetheus
Version: 1.700
License: See ./license.txt.

In order to compile the solver, simply type
./build.sh
in the root directory of this package (where you found this readme.txt file).

The script will attempt to load a globus compiler module. This might fail. If
this fails, we assume that the gcc command invokes the GNU C Compiler in version
4.4. or higher.

Compiling the solver is fully automatized. After everything went through you
will find the binary DimetheusMPS in the binary folder. The build.sh script
will attempt to call the binary to output its version. If you see this version
information, then everything should be fine.

The solver is supposed to be running in the RANDOM SAT TRACK of the SAT Competition
2013. In order to run the solver on formula bla.cnf, issue the following command 
(in the directory of the binary):

./DimetheusMPS -formula bla.cnf -seed 101 -guide 5

The formula name obviously depends on the file that contains the formula to be
solved in DIMACS CNF input format. The seed must be a natural number. The guide
value MUST be set to 5. This will result in the SLS-based MID solver using
rho-sigma-PMP-i as described in the PDF file. No further parameters are necessary.
