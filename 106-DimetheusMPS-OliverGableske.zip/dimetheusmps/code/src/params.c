/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#include "dimetheus.h"

uint32_t params_isBaseParam(char* paramname){
	//This method checks the given parameter name and return whether this is a base parameter. Base parameters are those that
	//are given to the main component or those that can be arbitrarily set like file-names.
	if (!strcmp("-formula",paramname)){
		return 1;
	} else if (!strcmp("-seed",paramname)){
		return 1;
	} else if (!strcmp("-printAssignment",paramname)){
		return 1;
	} else if (!strcmp("-guide",paramname)){
		return 1;
	} else if (!strcmp("-prepOutput",paramname)){
		return 1;
	} else if (!strcmp("-inpOutput",paramname)){
		return 1;
	} else if (!strcmp("-cdclOutput",paramname)){
		return 1;
	} else if (!strcmp("-slsOutput",paramname)){
		return 1;
	} else if (!strcmp("-mpOutput",paramname)){
		return 1;
	}

	return 1;
}

//Helper methods for reading from the command line.
void params_readInteger(int argc, char *argv[], int32_t i, int *varptr) {
	if (i >= argc || sscanf(argv[i],"%i", varptr)!=1){
		printf("c ERROR. Reading the integer: %s.\n", i<argc ? argv[i] : argv[argc-1]);
		main_returnCode = BADPARAM;
	}
}

void params_readUnsignedInteger(int argc, char *argv[], int32_t i, unsigned int *varptr) {
	if (i >= argc || sscanf(argv[i],"%u", varptr)!=1){
		printf("c ERROR. Reading the unsigned integer: %s.\n", i<argc ? argv[i] : argv[argc-1]);
		main_returnCode = BADPARAM;
	}
}

void params_readFloat(int argc, char *argv[], int32_t i, float *varptr) {
	if (i >= argc || sscanf(argv[i],"%f", varptr)!=1){
		printf("c ERROR. Reading the float: %s.\n", i<argc ? argv[i] : argv[argc-1]);
		main_returnCode = BADPARAM;
	}
}

void params_readDouble(int argc, char *argv[], int32_t i, double *varptr) {
	if (i >= argc || sscanf(argv[i],"%lf", varptr)!=1){
		printf("c ERROR. Reading the double: %s.\n", i<argc ? argv[i] : argv[argc-1]);
		main_returnCode = BADPARAM;
	}
}

//Main algorithm related.
void params_readFormulaFile(int argc,char* argv[],int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -formula... ");
	#endif

	//The file is opened here, but we leave it open until it has been read completely. See main.c:initializeMain().
	param_formula = fopen(argv[paramNumber], "r");
	if (param_formula == NULL) {
		printf("\nc ERROR. You must specify an input file that you have read access to!\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		printf("%s opened.\n", argv[paramNumber]);
		#endif
	}
}

void params_readSeed(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -seed... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_seed);
	#ifdef VERBOSE
	if (main_returnCode == UNKNOWN) printf("%d.\n",param_seed);
	#endif
}

void params_readPrintAssignment(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -printAssignment... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_printAssignment);
	if (param_printAssignment != 0 && param_printAssignment != 1){
		printf("\nc ERROR. The printAssignment value must be either 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_printAssignment);
		#endif
	}
}

void params_readGuide(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -guide... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_guide);
	if (param_guide != 999 && param_guide != 1000 && (param_guide < GUIDE_MINVALUE || param_guide > GUIDE_MAXVALUE)){
		printf("\nc ERROR. The guide value must be at least %d and at most %d, or 999 or 1000.\n",
				GUIDE_MINVALUE, GUIDE_MAXVALUE);
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_guide);
		#endif
	}
}

//Classification related.
void params_readClassifyStrategy(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -classifyStrategy... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_classifyStrategy);
	if (param_classifyStrategy != 999
			&& (param_classifyStrategy < CLASSIFY_STRATEGY_MINVALUE || param_classifyStrategy > CLASSIFY_STRATEGY_MAXVALUE)){
		printf("\nc ERROR. The classifyStrategy value must be at least %d and at most %d.\n",
				CLASSIFY_STRATEGY_MINVALUE, CLASSIFY_STRATEGY_MAXVALUE);
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_classifyStrategy);
		#endif
	}
}

//Adaptation related.
void params_readAdaptAssumeRandom(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -adaptAssumeRandom... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_adaptAssumeRandom);
	if (param_adaptAssumeRandom < 0 || param_adaptAssumeRandom > 1){
		printf("\nc ERROR. The adaptAssumeRandom value must be at least 0 and at most 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_adaptAssumeRandom);
		#endif
	}
}

void params_readAdaptStrategy(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -adaptStrategy... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_adaptStrategy);
	if (param_adaptStrategy != 999
			&& (param_adaptStrategy < ADAPT_STRATEGY_MINVALUE || param_adaptStrategy > ADAPT_STRATEGY_MAXVALUE)){
		printf("\nc ERROR. The adaptStrategy value must be at least %d and at most %d.\n",
				ADAPT_STRATEGY_MINVALUE, ADAPT_STRATEGY_MAXVALUE);
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_adaptStrategy);
		#endif
	}
}

void params_readAdaptPrepStrategy(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -adaptPrepStrategy... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_adaptPrepStrategy);
	if (param_adaptStrategy < 0 || param_adaptStrategy > 1){
		printf("\nc ERROR. The adaptPrepStrategy value must be 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_adaptPrepStrategy);
		#endif
	}
}

void params_readAdaptPrepStrategyParams(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -adaptPrepStrategyParams... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_adaptPrepStrategyParams);
	if (param_adaptPrepStrategyParams < 0 || param_adaptPrepStrategyParams > 1){
		printf("\nc ERROR. The adaptPrepStrategyParams value must be 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_adaptPrepStrategyParams);
		#endif
	}
}

void params_readAdaptInpStrategy(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -adaptInpStrategy... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_adaptInpStrategy);
	if (param_adaptInpStrategy < 0 || param_adaptInpStrategy > 1){
		printf("\nc ERROR. The adaptInpStrategy value must be 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_adaptInpStrategy);
		#endif
	}
}

void params_readAdaptInpStrategyParams(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -adaptInpStrategyParams... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_adaptInpStrategyParams);
	if (param_adaptInpStrategyParams < 0 || param_adaptInpStrategyParams > 1){
		printf("\nc ERROR. The adaptInpStrategyParams value must be 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_adaptInpStrategyParams);
		#endif
	}
}

void params_readAdaptSearchStrategy(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -adaptSearchStrategy... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_adaptSearchStrategy);
	if (param_adaptSearchStrategy < 0 || param_adaptSearchStrategy > 1){
		printf("\nc ERROR. The adaptSearchStrategy value must be 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_adaptSearchStrategy);
		#endif
	}
}

void params_readAdaptSearchStrategyParams(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -adaptSearchStrategyParams... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_adaptSearchStrategyParams);
	if (param_adaptSearchStrategyParams < 0 || param_adaptSearchStrategyParams > 1){
		printf("\nc ERROR. The adaptSearchStrategyParams value must be 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_adaptSearchStrategyParams);
		#endif
	}
}

void params_readAdaptMpUR(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -adaptMpUR... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_adaptMpUR);
	if (param_adaptMpUR < 0 || param_adaptMpUR > 1){
		printf("\nc ERROR. The adaptMpUR must be 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_adaptMpUR);
		#endif
	}
}

void params_readAdaptMpURParams(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -adaptMpURParams... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_adaptMpURParams);
	if (param_adaptMpURParams < 0 || param_adaptMpURParams > 1){
		printf("\nc ERROR. The adaptMpURParams must be 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_adaptMpURParams);
		#endif
	}
}

void params_readAdaptSlsPAFVR(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -adaptSlsPAFVR... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_adaptSlsPAFVR);
	if (param_adaptSlsPAFVR < 0 || param_adaptSlsPAFVR > 1){
		printf("\nc ERROR. The adaptSlsPAFVR must be 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_adaptSlsPAFVR);
		#endif
	}
}

void params_readAdaptSlsPAFVRParams(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -adaptSlsPAFVRParams... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_adaptSlsPAFVRParams);
	if (param_adaptSlsPAFVRParams < 0 || param_adaptSlsPAFVRParams > 1){
		printf("\nc ERROR. The adaptSlsPAFVRParams must be 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_adaptSlsPAFVRParams);
		#endif
	}
}

void params_readAdaptSlsAI(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -adaptSlsAI... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_adaptSlsAI);
	if (param_adaptSlsAI < 0 || param_adaptSlsAI > 1){
		printf("\nc ERROR. The adaptSlsAI must be 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_adaptSlsAI);
		#endif
	}
}

void params_readAdaptSlsAIParams(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -adaptSlsAIParams... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_adaptSlsAIParams);
	if (param_adaptSlsAIParams < 0 || param_adaptSlsAIParams > 1){
		printf("\nc ERROR. The adaptSlsAIParams must be 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_adaptSlsAIParams);
		#endif
	}
}

void params_readAdaptCdclSVR(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -adaptCdclSVR... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_adaptCdclSVR);
	if (param_adaptCdclSVR < 0 || param_adaptCdclSVR > 1){
		printf("\nc ERROR. The adaptCdclSVR must be 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_adaptCdclSVR);
		#endif
	}
}

void params_readAdaptCdclSVRParams(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -adaptCdclSVRParams... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_adaptCdclSVRParams);
	if (param_adaptCdclSVRParams < 0 || param_adaptCdclSVRParams > 1){
		printf("\nc ERROR. The adaptCdclSVRParams must be 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_adaptCdclSVRParams);
		#endif
	}
}

void params_readAdaptCdclSVAI(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -adaptCdclSVAI... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_adaptCdclSVAI);
	if (param_adaptCdclSVAI < 0 || param_adaptCdclSVAI > 1){
		printf("\nc ERROR. The adaptCdclSVAI must be 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_adaptCdclSVAI);
		#endif
	}
}

void params_readAdaptCdclSVAIParams(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -adaptCdclSVAIParams... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_adaptCdclSVAIParams);
	if (param_adaptCdclSVAIParams < 0 || param_adaptCdclSVAIParams > 1){
		printf("\nc ERROR. The adaptCdclSVAIParams must be 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_adaptCdclSVAIParams);
		#endif
	}
}

void params_readAdaptCdclSDR(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -adaptCdclSDR... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_adaptCdclSDR);
	if (param_adaptCdclSDR < 0 || param_adaptCdclSDR > 1){
		printf("\nc ERROR. The adaptCdclSDR must be 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_adaptCdclSDR);
		#endif
	}
}

void params_readAdaptCdclSDRParams(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -adaptCdclSDRParams... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_adaptCdclSDRParams);
	if (param_adaptCdclSDRParams < 0 || param_adaptCdclSDRParams > 1){
		printf("\nc ERROR. The adaptCdclSDRParams must be 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_adaptCdclSDRParams);
		#endif
	}
}

void params_readAdaptCdclSDDI(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -adaptCdclSDDI... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_adaptCdclSDDI);
	if (param_adaptCdclSDDI < 0 || param_adaptCdclSDDI > 1){
		printf("\nc ERROR. The adaptCdclSDDI must be 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_adaptCdclSDDI);
		#endif
	}
}

void params_readAdaptCdclSDDIParams(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -adaptCdclSDDIParams... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_adaptCdclSDDIParams);
	if (param_adaptCdclSDDIParams < 0 || param_adaptCdclSDDIParams > 1){
		printf("\nc ERROR. The adaptCdclSDDIParams must be 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_adaptCdclSDDIParams);
		#endif
	}
}

void params_readAdaptCdclCAR(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -adaptCdclCAR... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_adaptCdclCAR);
	if (param_adaptCdclCAR < 0 || param_adaptCdclCAR > 1){
		printf("\nc ERROR. The adaptCdclCAR must be 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_adaptCdclCAR);
		#endif
	}
}

void params_readAdaptCdclCARParams(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -adaptCdclCARParams... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_adaptCdclCARParams);
	if (param_adaptCdclCARParams < 0 || param_adaptCdclCARParams > 1){
		printf("\nc ERROR. The adaptCdclCARParams must be 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_adaptCdclCARParams);
		#endif
	}
}

void params_readAdaptCdclSLR(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -adaptCdclSLR... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_adaptCdclSLR);
	if (param_adaptCdclSLR < 0 || param_adaptCdclSLR > 1){
		printf("\nc ERROR. The adaptCdclSLR must be 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_adaptCdclSLR);
		#endif
	}
}

void params_readAdaptCdclSLRParams(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -adaptCdclSLRParams... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_adaptCdclSLRParams);
	if (param_adaptCdclSLRParams < 0 || param_adaptCdclSLRParams > 1){
		printf("\nc ERROR. The adaptCdclSLRParams must be 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_adaptCdclSLRParams);
		#endif
	}
}

void params_readAdaptCdclSOR(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -adaptCdclSOR... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_adaptCdclSOR);
	if (param_adaptCdclSOR < 0 || param_adaptCdclSOR > 1){
		printf("\nc ERROR. The adaptCdclSOR must be 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_adaptCdclSOR);
		#endif
	}
}

void params_readAdaptCdclSORParams(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -adaptCdclSORParams... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_adaptCdclSORParams);
	if (param_adaptCdclSORParams < 0 || param_adaptCdclSORParams > 1){
		printf("\nc ERROR. The adaptCdclSORParams must be 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_adaptCdclSORParams);
		#endif
	}
}

void params_readAdaptCdclCBJLR(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -adaptCdclCBJLR... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_adaptCdclCBJLR);
	if (param_adaptCdclCBJLR < 0 || param_adaptCdclCBJLR > 1){
		printf("\nc ERROR. The adaptCdclCBJLR must be 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_adaptCdclCBJLR);
		#endif
	}
}

void params_readAdaptCdclCBJLRParams(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -adaptCdclCBJLRParams... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_adaptCdclCBJLRParams);
	if (param_adaptCdclCBJLRParams < 0 || param_adaptCdclCBJLRParams > 1){
		printf("\nc ERROR. The adaptCdclCBJLRParams must be 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_adaptCdclCBJLRParams);
		#endif
	}
}

void params_readAdaptCdclRR(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -adaptCdclRR... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_adaptCdclRR);
	if (param_adaptCdclRR < 0 || param_adaptCdclRR > 1){
		printf("\nc ERROR. The adaptCdclRR must be 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_adaptCdclRR);
		#endif
	}
}

void params_readAdaptCdclRRParams(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -adaptCdclRRParams... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_adaptCdclRRParams);
	if (param_adaptCdclRRParams < 0 || param_adaptCdclRRParams > 1){
		printf("\nc ERROR. The adaptCdclRRParams must be 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_adaptCdclRRParams);
		#endif
	}
}

void params_readAdaptCdclMR(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -adaptCdclMR... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_adaptCdclMR);
	if (param_adaptCdclMR < 0 || param_adaptCdclMR > 1){
		printf("\nc EMROR. The adaptCdclMR must be 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_adaptCdclMR);
		#endif
	}
}

void params_readAdaptCdclMRParams(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -adaptCdclMRParams... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_adaptCdclMRParams);
	if (param_adaptCdclMRParams < 0 || param_adaptCdclMRParams > 1){
		printf("\nc EMROR. The adaptCdclMRParams must be 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_adaptCdclMRParams);
		#endif
	}
}

void params_readAdaptCdclIR(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -adaptCdclIR... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_adaptCdclIR);
	if (param_adaptCdclIR < 0 || param_adaptCdclIR > 1){
		printf("\nc EIROR. The adaptCdclIR must be 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_adaptCdclIR);
		#endif
	}
}

void params_readAdaptCdclIRParams(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -adaptCdclIRParams... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_adaptCdclIRParams);
	if (param_adaptCdclIRParams < 0 || param_adaptCdclIRParams > 1){
		printf("\nc EIROR. The adaptCdclIRParams must be 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_adaptCdclIRParams);
		#endif
	}
}

void params_readAdaptCdclAR(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -adaptCdclAR... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_adaptCdclAR);
	if (param_adaptCdclAR < 0 || param_adaptCdclAR > 1){
		printf("\nc EAROR. The adaptCdclAR must be 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_adaptCdclAR);
		#endif
	}
}

void params_readAdaptCdclARParams(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -adaptCdclARParams... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_adaptCdclARParams);
	if (param_adaptCdclARParams < 0 || param_adaptCdclARParams > 1){
		printf("\nc EAROR. The adaptCdclARParams must be 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_adaptCdclARParams);
		#endif
	}
}

//Preprocessing related.
void params_readPrepOutput(int argc,char* argv[],int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -prepOutput... ");
	#endif
	param_prepOutput = fopen(argv[paramNumber], "w");
	if (param_prepOutput == NULL) {
		printf("\nc ERROR. You must specify an output file that you have write access to!\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		printf("%s opened.\n", argv[paramNumber]);
		#endif
	}
}

void params_readPrepReviveCls(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -prepReviveCls... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_prepReviveCls);
	if (param_prepReviveCls != 0 && param_prepReviveCls != 1){
		printf("\nc ERROR. The prepReviveCls value must be 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_prepReviveCls);
		#endif
	}
}

void params_readPrepACCEMax(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -prepACCEMax... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_prepACCEMax);
	if (param_prepACCEMax < 0){
		printf("\nc ERROR. The prepACCEMax value must be non-negative.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_prepACCEMax);
		#endif
	}
}

void params_readPrepACCEMinClsSize(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -prepACCEMinClsSize... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_prepACCEMinClsSize);
	if (param_prepACCEMinClsSize < 2){
		printf("\nc ERROR. The prepACCEMinClsSize value must be at least 2.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_prepACCEMinClsSize);
		#endif
	}
}

void params_readPrepACCESaturate(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -prepACCEMax... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_prepACCESaturate);
	if (param_prepACCESaturate != 0 && param_prepACCESaturate != 1){
		printf("\nc ERROR. The prepACCESaturate value must be either 0 or 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_prepACCESaturate);
		#endif
	}
}

void params_readPrepNIVERMax(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -prepNIVERMax... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_prepNIVERMax);
	if (param_prepNIVERMax < 0){
		printf("\nc ERROR. The prepNIVERMax value must be non-negative.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_prepNIVERMax);
		#endif
	}
}

void params_readPrepATEMin(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -prepATEMin... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_prepATEMin);
	if (param_prepATEMin < 0){
		printf("\nc ERROR. The prepATEMin value must be non-negative.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_prepATEMin);
		#endif
	}
}

void params_readPrepGEMaxAONN(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -prepGEMaxAONN... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_prepGEMaxAONN);
	if (param_prepGEMaxAONN < 0){
		printf("\nc ERROR. The prepGEMaxAONN value must be non-negative.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_prepGEMaxAONN);
		#endif
	}
}

void params_readPrepGEMaxXOR(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -prepGEMaxXOR... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_prepGEMaxXOR);
	if (param_prepGEMaxXOR < 0){
		printf("\nc ERROR. The prepGEMaxXOR value must be non-negative.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_prepGEMaxXOR);
		#endif
	}
}

void params_readPrepTERNARYLitMax(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -prepTERNARYLitMax... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_prepTERNARYLitMax);
	if (param_prepTERNARYLitMax < 0){
		printf("\nc ERROR. The prepTERNARYLitMax value must be non-negative.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_prepTERNARYLitMax);
		#endif
	}
}

void params_readPrepTERNARYMax(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -prepTERNARYMax... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_prepTERNARYMax);
	if (param_prepTERNARYMax < 0){
		printf("\nc ERROR. The prepTERNARYMax value must be non-negative.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_prepTERNARYMax);
		#endif
	}
}

void params_readPrepNHBRMin(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -prepNHBRMin... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_prepNHBRMin);
	if (param_prepTERNARYMax < 0){
		printf("\nc ERROR. The prepNHBRMin value must be non-negative.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_prepNHBRMin);
		#endif
	}
}

void params_readPrepStrategy(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -prepStrategy... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_prepStrategy);
	if (param_prepStrategy!=999 && (param_prepStrategy<PREP_STRATEGY_MINVALUE || param_prepStrategy>PREP_STRATEGY_MAXVALUE)){
		printf("\nc ERROR. The prepStrategy must be at least %d and at most %d.\n",
				PREP_STRATEGY_MINVALUE, PREP_STRATEGY_MAXVALUE);
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_prepStrategy);
		#endif
	}
}

//In-processing related.
void params_readInpStrMaxSize(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -inpStrMaxSize... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_inpStrMaxSize);
	if (param_inpStrMaxSize < 0){
		printf("\nc ERROR. The inpStrMaxSize must be at least 0.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_inpStrMaxSize);
		#endif
	}
}

void params_readInpTernaryLitMax(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -inpTernaryLitMax... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_inpTernaryLitMax);
	if (param_inpTernaryLitMax < 0){
		printf("\nc ERROR. The inpTernaryLitMax must be at least 0.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_inpTernaryLitMax);
		#endif
	}
}

void params_readInpTernaryMax(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -inpTernaryMax... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_inpTernaryMax);
	if (param_inpTernaryMax < 0){
		printf("\nc ERROR. The inpTernaryMax must be at least 0.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_inpTernaryMax);
		#endif
	}
}

void params_readInpNiverMax(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -inpNiverMax... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_inpNiverMax);
	if (param_inpNiverMax < 0){
		printf("\nc ERROR. The inpNiverMax must be at least 0.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_inpNiverMax);
		#endif
	}
}

void params_readInpGEMaxAONN(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -inpGEMaxAONN... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_inpGEMaxAONN);
	if (param_inpGEMaxAONN < 0){
		printf("\nc ERROR. The inpGEMaxAONN must be at least 0.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_inpGEMaxAONN);
		#endif
	}
}

void params_readInpGEMaxXOR(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -inpGEMaxXOR... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_inpGEMaxXOR);
	if (param_inpGEMaxXOR < 0){
		printf("\nc ERROR. The inpGEMaxXOR must be at least 0.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_inpGEMaxXOR);
		#endif
	}
}

void params_readInpNHBRMin(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -inpNHBRMin... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_inpNHBRMin);
	if (param_inpNHBRMin < 0){
		printf("\nc ERROR. The inpNHBRMin must be at least 0.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_inpNHBRMin);
		#endif
	}
}

void params_readInpStrategy(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -inpStrategy... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_inpStrategy);
	if (param_inpStrategy != 999 && (param_inpStrategy < INP_STRATEGY_MINVALUE || param_inpStrategy > INP_STRATEGY_MAXVALUE)){
		printf("\nc ERROR. The inpStrategy must be at least %d and at most %d.\n",
				INP_STRATEGY_MINVALUE, INP_STRATEGY_MAXVALUE);
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_inpStrategy);
		#endif
	}
}

//Search related.
void params_readSearchMIDBlockSize(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -searchMIDBlockSize... ");
	#endif
	double value;
	params_readDouble(argc, argv, paramNumber, &value);
	param_searchMIDBlockSize = (float_ty) value;
	if (param_searchMIDBlockSize < ZERO || param_searchMIDBlockSize > ONE){
		printf("\nc ERROR. The searchMIDBlockSize must be at least 0.0 and at most 1.0.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%f.\n",param_searchMIDBlockSize);
		#endif
	}
}

void params_readSearchMinClsImpact(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -searchMinClsImpact... ");
	#endif
	double value;
	params_readDouble(argc, argv, paramNumber, &value);
	param_searchMinClsImpact = (float_ty) value;
	if (param_searchMinClsImpact < ZERO || param_searchMinClsImpact > ONE){
		printf("\nc ERROR. The searchMinClsImpact must be at least 0.0 and at most 1.0.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%f.\n",param_searchMinClsImpact);
		#endif
	}
}

void params_readSearchImpactMaxFactor(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -searchImpactMaxFactor... ");
	#endif
	double value;
	params_readDouble(argc, argv, paramNumber, &value);
	param_searchImpactMaxFactor = (float_ty) value;
	if (param_searchImpactMaxFactor < ZERO ){
		printf("\nc ERROR. The searchImpactMaxFactor must be at least 0.0.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%f.\n",param_searchImpactMaxFactor);
		#endif
	}
}

void params_readSearchStrategy(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -searchStrategy... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_searchStrategy);
	if (param_searchStrategy!=999
			&& (param_searchStrategy < SEARCH_STRATEGY_MINVALUE || param_searchStrategy > SEARCH_STRATEGY_MAXVALUE)){
		printf("\nc ERROR. The searchStrategy must be at least %d and at most %d.\n",
				SEARCH_STRATEGY_MINVALUE, SEARCH_STRATEGY_MAXVALUE);
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_searchStrategy);
		#endif
	}
}

//MP
void params_readMpMaxNumIterations(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -mpMaxNumIterations... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_mpMaxNumIterations);
	if (param_mpMaxNumIterations < 0){
		printf("\nc ERROR. The mpMaxNumIterations value must be non-negative.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_mpMaxNumIterations);
		#endif
	}
}

void params_readMpMaxConvergenceDiff(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -mpMaxConvergenceDiff... ");
	#endif
	double value;
	params_readDouble(argc, argv, paramNumber, &value);
	param_mpMaxConvergenceDiff = (float_ty) value;
	if (param_mpMaxConvergenceDiff < 0.0001f || param_mpMaxConvergenceDiff > 0.5f){
		printf("\nc ERROR. The mpMaxConvergenceDiff value must be at least 0.0001 and at most 0.5.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%u.\n", (uint32_t)param_mpMaxConvergenceDiff);
		#endif
	}
}

void params_readMpMaxMagnetization(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -mpMaxMagnetization... ");
	#endif
	double value;
	params_readDouble(argc, argv, paramNumber, &value);
	param_mpMaxMagnetization = (float_ty) value;
	if (param_mpMaxMagnetization < 0.0001f || param_mpMaxMagnetization > 0.5){
		printf("\nc ERROR. The mpMaxMagnetization value must be at least 0.0001 and at most 0.5.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%u.\n", (uint32_t)param_mpMaxMagnetization);
		#endif
	}
}

void params_readMpEpsilon(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -mpEpsilon... ");
	#endif
	double value;
	params_readDouble(argc, argv, paramNumber, &value);
	param_mpEpsilon = (float_ty) value;
	if (param_mpEpsilon < 0.0001f || param_mpEpsilon > 0.5f){
		printf("\nc ERROR. The mpEpsilon must be at least 0.0001 and at most 0.5.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%f.\n",param_mpEpsilon);
		#endif
	}
}

void params_readMpRho(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -mpRho... ");
	#endif
	double value;
	params_readDouble(argc, argv, paramNumber, &value);
	param_mpRho = (float_ty) value;
	if (param_mpRho < 0.0f || param_mpRho > 1.0f){
		printf("\nc ERROR. The mpRho must be at least 0.0 and at most 1.0.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%f.\n",param_mpRho);
		#endif
	}
}

void params_readMpSigma(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -mpSigma... ");
	#endif
	double value;
	params_readDouble(argc, argv, paramNumber, &value);
	param_mpSigma = (float_ty) value;
	if (param_mpSigma < 0.0f || param_mpSigma > 1.0f){
		printf("\nc ERROR. The mpSigma must be at least 0.0 and at most 1.0.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%f.\n",param_mpSigma);
		#endif
	}
}

void params_readMpUpdateRule(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -mpUpdateRule... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_mpUpdateRule);
	if (param_mpUpdateRule < MP_UPDATERULE_MINVALUE || param_mpUpdateRule > MP_UPDATERULE_MAXVALUE){
		printf("\nc ERROR. The mpUpdateRule must be at least %d and at most %d.\n",
				MP_UPDATERULE_MINVALUE,MP_UPDATERULE_MAXVALUE);
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_mpUpdateRule);
		#endif
	}
}

//SLS
void params_readSlsMaxFlipsFactor(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -slsMaxFlipsFactor... ");
	#endif
	double value;
	params_readDouble(argc, argv, paramNumber, &value);
	param_slsMaxFlipsFactor = (float_ty) value;
	if (param_slsMaxFlipsFactor < 0.0f){
		printf("\nc ERROR. The slsMaxFlipsFactor must be non-negative.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%f.\n",param_slsMaxFlipsFactor);
		#endif
	}
}

void params_readSlsMaxTries(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -slsMaxTries... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_slsMaxTries);
	if (param_slsMaxTries < 0){
		printf("\nc ERROR. The slsMaxTries must be at least 0.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_slsMaxTries);
		#endif
	}
}

void params_readSlsNoise(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -slsNoise... ");
	#endif
	double value;
	params_readDouble(argc, argv, paramNumber, &value);
	param_slsNoise = (float_ty) value;
	if (param_slsNoise < 0.0f || param_slsNoise > 1.0f){
		printf("\nc ERROR. The slsNoise must be at least 0.0 and at most 1.0.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%f.\n",param_slsNoise);
		#endif
	}
}

void params_readSlsProbsatCB(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -slsProbsatCB... ");
	#endif
	double value;
	params_readDouble(argc, argv, paramNumber, &value);
	param_slsProbsatCB = (float_ty) value;
	if (param_slsProbsatCB <= 0.0f){
		printf("\nc ERROR. The slsProbsatCB must be a positive value.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%f.\n",param_slsProbsatCB);
		#endif
	}
}

void params_readSlsProbsatCBShift(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -slsProbsatCBShift... ");
	#endif
	double value;
	params_readDouble(argc, argv, paramNumber, &value);
	param_slsProbsatCBShift = (float_ty) value;
	if (param_slsProbsatCBShift < 0.0f){
		printf("\nc ERROR. The slsProbsatCBShift must be a non-negative value.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%f.\n",param_slsProbsatCBShift);
		#endif
	}
}

void params_readSlsPickAndFlipVarRule(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -slsPickAndFlipVarRule... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_slsPickAndFlipVarRule);
	if (param_slsPickAndFlipVarRule < SLS_PICKANDFLIPVARRULE_MINVALUE
			|| param_slsPickAndFlipVarRule > SLS_PICKANDFLIPVARRULE_MAXVALUE){
		printf("\nc ERROR. The slsPickAndFlipVarRule must be at least %d and at most %d.\n",
				SLS_PICKANDFLIPVARRULE_MINVALUE,SLS_PICKANDFLIPVARRULE_MAXVALUE);
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_slsPickAndFlipVarRule);
		#endif
	}
}

void params_readSlsAssInitRule(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -slsAssInitRule... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_slsAssInitRule);
	if (param_slsAssInitRule < SLS_ASSINITRULE_MINVALUE
			|| param_slsAssInitRule > SLS_ASSINITRULE_MAXVALUE){
		printf("\nc ERROR. The slsAssInitRule must be at least %d and at most %d.\n",
				SLS_ASSINITRULE_MINVALUE,SLS_ASSINITRULE_MAXVALUE);
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_slsAssInitRule);
		#endif
	}
}

//CDCL
void params_readCdclOutput(int argc,char* argv[],int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -cdclOutput... ");
	#endif
	param_cdclOutput = fopen(argv[paramNumber], "w");
	if (param_cdclOutput == NULL) {
		printf("\nc ERROR. You must specify an CDCL output file that you have write access to!\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		printf("%s opened.\n", argv[paramNumber]);
		#endif
	}
}

void params_readCdclRestartStagMaxFrac(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -cdclRestartStagMaxFrac... ");
	#endif
	double value;
	params_readDouble(argc, argv, paramNumber, &value);
	param_cdclRestartStagMaxFrac = (float_ty) value;
	if (param_cdclRestartStagMaxFrac < ZERO || param_cdclRestartStagMaxFrac > ONE){
		printf("\nc ERROR. The cdclRestartStagMaxFrac must be at least 0.0 and at most 1.0.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%f.\n",param_cdclRestartStagMaxFrac);
		#endif
	}
}

void params_readCdclRestartInnerouterInit(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -cdclRestartInnerouterInit... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_cdclRestartInnerouterInit);
	if (param_cdclRestartInnerouterInit <= 1){
		printf("\nc ERROR. The cdclRestartLubyUnit must be greater 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_cdclRestartInnerouterInit);
		#endif
	}
}

void params_readCdclRestartInnerouterInc(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -cdclRestartInnerouterInc... ");
	#endif
	double value;
	params_readDouble(argc, argv, paramNumber, &value);
	param_cdclRestartInnerouterInc = (float_ty) value;
	if (param_cdclRestartInnerouterInc < ONE){
		printf("\nc ERROR. The cdclRestartInnerouterInc must be at least 1.0.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%f.\n",param_cdclRestartInnerouterInc);
		#endif
	}
}

void params_readCdclRestartLubyUnit(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -cdclRestartLubyUnit... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_cdclRestartLubyUnit);
	if (param_cdclRestartLubyUnit <= 0){
		printf("\nc ERROR. The cdclRestartLubyUnit must be greater 0.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_cdclRestartLubyUnit);
		#endif
	}
}

void params_readCdclRestartVarAgiIncBump(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -cdclRestartVarAgiIncBump... ");
	#endif
	double value;
	params_readDouble(argc, argv, paramNumber, &value);
	param_cdclRestartVarAgiIncBump = (float_ty) value;
	if (param_cdclRestartVarAgiIncBump < ONE){
		printf("\nc ERROR. The cdclRestartVarAgiIncBump must be at least 1.0.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%f.\n",param_cdclRestartVarAgiIncBump);
		#endif
	}
}

void params_readCdclRestartMaxAgiFrac(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -cdclRestartMaxAgiFrac... ");
	#endif
	double value;
	params_readDouble(argc, argv, paramNumber, &value);
	param_cdclRestartMaxAgiFrac = (float_ty) value;
	if (param_cdclRestartMaxAgiFrac < ZERO || param_cdclRestartMaxAgiFrac > ONE){
		printf("\nc ERROR. The cdclRestartMaxAgiFrac must be between 0.0 and 1.0.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%f.\n",param_cdclRestartMaxAgiFrac);
		#endif
	}
}

void params_readCdclRestartMaxAgiOutFrac(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -cdclRestartMaxAgiOutFrac... ");
	#endif
	double value;
	params_readDouble(argc, argv, paramNumber, &value);
	param_cdclRestartMaxAgiOutFrac = (float_ty) value;
	if (param_cdclRestartMaxAgiOutFrac < ZERO || param_cdclRestartMaxAgiOutFrac > ONE){
		printf("\nc ERROR. The cdclRestartMaxAgiOutFrac must be between 0.0 and 1.0.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%f.\n",param_cdclRestartMaxAgiOutFrac);
		#endif
	}
}

void params_readCdclSelectVarActIncBump(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -cdclSelectVarActIncBump... ");
	#endif
	double value;
	params_readDouble(argc, argv, paramNumber, &value);
	param_cdclSelectVarActIncBump = (float_ty) value;
	if (param_cdclSelectVarActIncBump < ONE){
		printf("\nc ERROR. The cdclSelectVarActIncBump must be at least 1.0.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%f.\n",param_cdclSelectVarActIncBump);
		#endif
	}
}

void params_readCdclSelectVarActInit(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -cdclSelectVarActInit... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_cdclSelectVarActInit);
	if (param_cdclSelectVarActInit < CDCL_SELECTVARRULE_VARACTINIT_MINVALUE ||
			param_cdclSelectVarActInit > CDCL_SELECTVARRULE_VARACTINIT_MAXVALUE){
		printf("\nc ERROR. The cdclSelectVarActInit must be at least %d and at most %d.\n",
				CDCL_SELECTVARRULE_VARACTINIT_MINVALUE,CDCL_SELECTVARRULE_VARACTINIT_MAXVALUE);
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_cdclSelectVarActInit);
		#endif
	}
}

void params_readCdclSelectVarRandProb(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -cdclSelectVarRandProb... ");
	#endif
	double value;
	params_readDouble(argc, argv, paramNumber, &value);
	param_cdclSelectVarRandProb = (float_ty) value;
	if (param_cdclSelectVarRandProb < ZERO || param_cdclSelectVarRandProb > ONE){
		printf("\nc ERROR. The cdclSelectVarRandProb must be at least 0.0 and at most 1.0.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%f.\n",param_cdclSelectVarRandProb);
		#endif
	}
}

void params_readCdclSelectDirMinFlipDist(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -cdclSelectDirMinFlipDist... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_cdclSelectDirMinFlipDist);
	if (param_cdclSelectDirMinFlipDist < 0){
		printf("\nc ERROR. The cdclSelectDirMinFlipDist must be at least 0.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_cdclSelectDirMinFlipDist);
		#endif
	}
}

void params_readCdclSelectDirDirInit(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -cdclSelectDirDirInit... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_cdclSelectDirDirInit);
	if (param_cdclSelectDirDirInit < CDCL_SELECTDIRRULE_DIRINIT_MINVALUE ||
			param_cdclSelectDirDirInit > CDCL_SELECTDIRRULE_DIRINIT_MAXVALUE){
		printf("\nc ERROR. The cdclSelectDirDirInit must be at least %d and at most %d.\n",
				CDCL_SELECTDIRRULE_DIRINIT_MINVALUE,CDCL_SELECTDIRRULE_DIRINIT_MAXVALUE);
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_cdclSelectDirDirInit);
		#endif
	}
}

void params_readCdclMaintenanceMinDev(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -cdclMaintenanceMinDev... ");
	#endif
	double value;
	params_readDouble(argc, argv, paramNumber, &value);
	param_cdclMaintenanceMinDev = (float_ty) value;
	if (param_cdclMaintenanceMinDev < ZERO || param_cdclMaintenanceMinDev > ONE){
		printf("\nc ERROR. The cdclMaintenanceMinDev must be between 0.0 and 1.0.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%f.\n",param_cdclMaintenanceMinDev);
		#endif
	}
}

void params_readCdclMaintenanceMaxAvg(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -cdclMaintenanceMaxAvg... ");
	#endif
	double value;
	params_readDouble(argc, argv, paramNumber, &value);
	param_cdclMaintenanceMaxAvg = (float_ty) value;
	if (param_cdclMaintenanceMaxAvg < ZERO){
		printf("\nc ERROR. The cdclMaintenanceMaxAvg must be at least 0.0.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%f.\n",param_cdclMaintenanceMaxAvg);
		#endif
	}
}

void params_readCdclMaintenanceActIncBump(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -cdclMaintenanceActIncBump... ");
	#endif
	double value;
	params_readDouble(argc, argv, paramNumber, &value);
	param_cdclMaintenanceActIncBump = (float_ty) value;
	if (param_cdclMaintenanceActIncBump < ONE){
		printf("\nc ERROR. The cdclMaintenanceActIncBump must be at least 1.0.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%f.\n",param_cdclMaintenanceActIncBump);
		#endif
	}
}

void params_readCdclMaintenanceInitial(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -cdclMaintenanceInitial... ");
	#endif
	double value;
	params_readDouble(argc, argv, paramNumber, &value);
	param_cdclMaintenanceInitial = (float_ty) value;
	if (param_cdclMaintenanceInitial <= ZERO){
		printf("\nc ERROR. The cdclMaintenanceInitial must be greater zero.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%f.\n",param_cdclMaintenanceInitial);
		#endif
	}
}

void params_readCdclMaintenanceIncrease(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -cdclMaintenanceIncrease... ");
	#endif
	double value;
	params_readDouble(argc, argv, paramNumber, &value);
	param_cdclMaintenanceIncrease = (float_ty) value;
	if (param_cdclMaintenanceIncrease <= ONE){
		printf("\nc ERROR. The cdclMaintenanceIncrease must be greater one.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%f.\n",param_cdclMaintenanceIncrease);
		#endif
	}
}

void params_readCdclMaintenanceBase(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -cdclMaintenanceBase... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_cdclMaintenanceBase);
	if (param_cdclMaintenanceBase < 2){
		printf("\nc ERROR. The cdclMaintenanceBase must be at least 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_cdclMaintenanceBase);
		#endif
	}
}

void params_readCdclMaintenanceBoost(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -cdclMaintenanceBoost... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_cdclMaintenanceBoost);
	if (param_cdclMaintenanceBoost < 2){
		printf("\nc ERROR. The cdclMaintenanceBoost must be at least 1.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_cdclMaintenanceBoost);
		#endif
	}
}

void params_readCdclIRTERNARYLitMax(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -cdclIRTERNARYLitMax... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_cdclIRTERNARYLitMax);
	if (param_cdclIRTERNARYLitMax < 0){
		printf("\nc ERROR. The cdclIRTERNARYLitMax must be at least 0.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_cdclIRTERNARYLitMax);
		#endif
	}
}

void params_readCdclIRTERNARYMax(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -cdclIRTERNARYMax... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_cdclIRTERNARYMax);
	if (param_cdclIRTERNARYMax < 0){
		printf("\nc ERROR. The cdclIRTERNARYMax must be at least 0.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_cdclIRTERNARYMax);
		#endif
	}
}

void params_readCdclIRNIVERMax(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -cdclIRNIVERMax... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_cdclIRNIVERMax);
	if (param_cdclIRNIVERMax < 0){
		printf("\nc ERROR. The cdclIRNIVERMax must be at least 0.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_cdclIRNIVERMax);
		#endif
	}
}

void params_readCdclIRGEMaxAONN(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -cdclIRGEMaxAONN... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_cdclIRGEMaxAONN);
	if (param_cdclIRGEMaxAONN < 0){
		printf("\nc ERROR. The cdclIRGEMaxAONN must be at least 0.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_cdclIRGEMaxAONN);
		#endif
	}
}

void params_readCdclIRGEMaxXOR(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -cdclIRGEMaxXOR... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_cdclIRGEMaxXOR);
	if (param_cdclIRGEMaxXOR < 0){
		printf("\nc ERROR. The cdclIRGEMaxXOR must be at least 0.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_cdclIRGEMaxXOR);
		#endif
	}
}

void params_readCdclIRStrMaxSize(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -cdclIRStrMaxSize... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_cdclIRStrMaxSize);
	if (param_cdclIRStrMaxSize < 0){
		printf("\nc ERROR. The cdclIRStrMaxSize must be at least 0.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_cdclIRStrMaxSize);
		#endif
	}
}

void params_readCdclIRNHBRMin(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -cdclIRNHBRMin... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_cdclIRNHBRMin);
	if (param_cdclIRNHBRMin < 0){
		printf("\nc ERROR. The cdclIRNHBRMin must be at least 0.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_cdclIRNHBRMin);
		#endif
	}
}

void params_readCdclIRMinConfDistance(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -cdclIRMinConfDistance... ");
	#endif
	double value;
	params_readDouble(argc, argv, paramNumber, &value);
	param_cdclIRMinConfDistance = (float_ty) value;
	if (param_cdclIRMinConfDistance < ZERO){
		printf("\nc ERROR. The cdclIRMinConfDistance must be non negative.\n");
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%f.\n",param_cdclIRMinConfDistance);
		#endif
	}
}

void params_readCdclSelectVarRule(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -cdclSelectVarRule... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_cdclSelectVarRule);
	if (param_cdclSelectVarRule < CDCL_SELECTVARRULE_MINVALUE
			|| param_cdclSelectVarRule > CDCL_SELECTVARRULE_MAXVALUE){
		printf("\nc ERROR. The cdclSelectVarRule must be at least %d and at most %d.\n",
				CDCL_SELECTVARRULE_MINVALUE,CDCL_SELECTVARRULE_MAXVALUE);
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_cdclSelectVarRule);
		#endif
	}
}

void params_readCdclSelectDirRule(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -cdclSelectDirRule... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_cdclSelectDirRule);
	if (param_cdclSelectDirRule < CDCL_SELECTDIRRULE_MINVALUE
			|| param_cdclSelectDirRule > CDCL_SELECTDIRRULE_MAXVALUE){
		printf("\nc ERROR. The cdclSelectDirRule must be at least %d and at most %d.\n",
				CDCL_SELECTDIRRULE_MINVALUE,CDCL_SELECTDIRRULE_MAXVALUE);
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_cdclSelectDirRule);
		#endif
	}
}

void params_readCdclConflictAnalysisRule(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -cdclConflictAnalysisRule... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_cdclConflictAnalysisRule);
	if (param_cdclConflictAnalysisRule < CDCL_CONFLICTANALYSISRULE_MINVALUE
			|| param_cdclConflictAnalysisRule > CDCL_CONFLICTANALYSISRULE_MAXVALUE){
		printf("\nc ERROR. The cdclConflictAnalysisRule must be at least %d and at most %d.\n",
				CDCL_CONFLICTANALYSISRULE_MINVALUE,CDCL_CONFLICTANALYSISRULE_MAXVALUE);
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_cdclConflictAnalysisRule);
		#endif
	}
}

void params_readCdclStrLearnedRule(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -cdclStrLearnedRule... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_cdclStrLearnedRule);
	if (param_cdclStrLearnedRule < CDCL_STRLEARNEDRULE_MINVALUE
			|| param_cdclStrLearnedRule > CDCL_STRLEARNEDRULE_MAXVALUE){
		printf("\nc ERROR. The cdclStrLearnedRule must be at least %d and at most %d.\n",
				CDCL_STRLEARNEDRULE_MINVALUE,CDCL_STRLEARNEDRULE_MAXVALUE);
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_cdclStrLearnedRule);
		#endif
	}
}

void params_readCdclStrOtherRule(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -cdclStrOtherRule... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_cdclStrOtherRule);
	if (param_cdclStrOtherRule < CDCL_STROTHERRULE_MINVALUE
			|| param_cdclStrOtherRule > CDCL_STROTHERRULE_MAXVALUE){
		printf("\nc ERROR. The cdclStrOtherRule must be at least %d and at most %d.\n",
				CDCL_STROTHERRULE_MINVALUE,CDCL_STROTHERRULE_MAXVALUE);
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_cdclStrOtherRule);
		#endif
	}
}

void params_readCdclComputeBJLRule(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -cdclComputeBJLRule... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_cdclComputeBJLRule);
	if (param_cdclComputeBJLRule < CDCL_COMPUTEBJLRULE_MINVALUE
			|| param_cdclComputeBJLRule > CDCL_COMPUTEBJLRULE_MAXVALUE){
		printf("\nc ERROR. The cdclComputeBJLRule must be at least %d and at most %d.\n",
				CDCL_COMPUTEBJLRULE_MINVALUE,CDCL_COMPUTEBJLRULE_MAXVALUE);
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_cdclComputeBJLRule);
		#endif
	}
}

void params_readCdclRestartRule(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -cdclRestartRule... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_cdclRestartRule);
	if (param_cdclRestartRule < CDCL_RESTARTRULE_MINVALUE
			|| param_cdclRestartRule > CDCL_RESTARTRULE_MAXVALUE){
		printf("\nc ERROR. The cdclRestartRule must be at least %d and at most %d.\n",
				CDCL_RESTARTRULE_MINVALUE,CDCL_RESTARTRULE_MAXVALUE);
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_cdclRestartRule);
		#endif
	}
}

void params_readCdclMaintenanceRule(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -cdclMaintenanceRule... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_cdclMaintenanceRule);
	if (param_cdclMaintenanceRule < CDCL_MAINTENANCERULE_MINVALUE
			|| param_cdclRestartRule > CDCL_MAINTENANCERULE_MAXVALUE){
		printf("\nc ERROR. The cdclRestartRule must be at least %d and at most %d.\n",
				CDCL_MAINTENANCERULE_MINVALUE,CDCL_MAINTENANCERULE_MAXVALUE);
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_cdclMaintenanceRule);
		#endif
	}
}

void params_readCdclInprocessingRule(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -cdclInprocessingRule... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_cdclInprocessingRule);
	if (param_cdclInprocessingRule < CDCL_INPROCESSINGRULE_MINVALUE
			|| param_cdclInprocessingRule > CDCL_INPROCESSINGRULE_MAXVALUE){
		printf("\nc ERROR. The cdclInprocessingRule must be at least %d and at most %d.\n",
				CDCL_INPROCESSINGRULE_MINVALUE,CDCL_INPROCESSINGRULE_MAXVALUE);
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_cdclInprocessingRule);
		#endif
	}
}

void params_readCdclAbortRule(int argc, char* argv[], int32_t paramNumber){
	#ifdef VERBOSE
	printf("c   -cdclAbortRule... ");
	#endif
	params_readInteger(argc, argv, paramNumber, &param_cdclAbortRule);
	if (param_cdclAbortRule < CDCL_ABORTRULE_MINVALUE
			|| param_cdclAbortRule > CDCL_ABORTRULE_MAXVALUE){
		printf("\nc ERROR. The cdclAbortRule must be at least %d and at most %d.\n",
				CDCL_ABORTRULE_MINVALUE,CDCL_ABORTRULE_MAXVALUE);
		main_returnCode = BADPARAM;
	} else {
		#ifdef VERBOSE
		if (main_returnCode == UNKNOWN) printf("%d.\n",param_cdclAbortRule);
		#endif
	}
}

void params_printHelp(){
	printf("c Help:\n");
    printf("c  Usage:   ./dimetheus -param1 value1 ... -paramN valueN\n");
    printf("c  Example: ./dimetheus -formula ../cnfs/tiny.cnf -seed 101\n");
    printf("c\n");
    printf("c Help on GUIDES:\n");
    printf("c  If you use the -guide parameter you must carefully check below what parameters this guide ENFORCES.\n"
    	   "c  Any parameter presented has a set of allowed values for the guide given in brackets. You must either provide\n"
    	   "c  one of these values or none at all (in which case a default is picked which is marked in < > should there be\n"
    	   "c  more than one option available). Any parameter not enforced can be set arbitrarily according to its bounds.\n");
    printf("c\n");
    printf("c Help on CLASSIFICATION:\n");
    printf("c  The -classifyStrategy determines what classification to use. This does, however, only influence what attributes\n"
    	   "c  of the formula are computed. These attributes can then be used by an adapter.\n");
    printf("c Help on ADAPTION:\n");
    printf("c  The -adaptStrategy determines what type of adaption the solver will undergo. It may adapt the plug-in\n"
    	   "c  implementation to use as well as the parameter settings for such a plug-in. It may also adapt the\n"
    	   "c  preprocessing in-processing and search strategy depending on the guide. It is important to understand\n"
    	   "c  that the possibility to adapt parameters will override any user provided parameters. If you want to provide\n"
    	   "c  specific parameters yourself, you must check what module these parameters belong to and then disable the\n"
    	   "c  adaptation for this module. Any guide will provide the information what it will adapt. In case a specific\n"
    	   "c  module is not listed in the guide help, it will not be adapted.\n");
    printf("c\n");
    printf("c Help on PARAMETERS:\n");
    //MAIN
    printf("c   MAIN:\n");
    printf("c    -h                      [] Print this help.\n");
    printf("c    -v                      [] Print detailed version information.\n");
    printf("c    -formula                [char*] MANDATORY. The relative path and filename of the target DIMACS CNF formula.\n");
    printf("c    -seed                   [int|%d] "
    		"The seed for the random number generator.\n",
    		PARAM_DEFAULT_SEED);
    printf("c    -printAssignment        [bool|%d] "
    		"Set this to 0 if you do not want to see the solution.\n",
    		PARAM_DEFAULT_PRINTASSIGNMENT);
    printf("c    -guide                  [uint|%d] "
    		"Uses a pre-defined set of strategies and parameters. Check below.\n",
    		PARAM_DEFAULT_GUIDE);
    main_guide_printHelp();

    //CLASSIFY
    printf("c   CLASSIFICATION:\n");
    printf("c    -classifyStrategy       [uint|%d] "
    		"The type of classification strategy that is being used.\n",
    		PARAM_DEFAULT_CLASSIFYSTRATEGY);
    classify_strategies_printHelp();

    //ADAPT
    printf("c   ADAPTATION:\n");
    printf("c    -adaptAssumeRandom      [bool|%d] "
    		"Tells the adaptation strategy to assume a random instance no matter what.\n",
    		PARAM_DEFAULT_ADAPTASSUMERANDOM);
    printf("c    -adaptStrategy          [bool|%d] "
    		"The type of adaption strategy that is being used.\n",
    		PARAM_DEFAULT_ADAPTSTRATEGY);
    adapt_strategies_printHelp();
    printf("c    -adaptPrepStrategy      [bool|%d] "
    		"Determines if adapting the preprocessing strategy is allowed.\n",
    		PARAM_DEFAULT_ADAPTPREPSTRATEGY);
    printf("c    -adaptPrepStrategyParams [bool|%d] "
    		"Determines if it is allowed to adapt the preprocessing strategy parameters (currently none).\n",
    		PARAM_DEFAULT_ADAPTPREPSTRATEGYPARAMS);
    printf("c    -adaptInpStrategy       [bool|%d] "
    		"Determines if adapting the in-processing strategy is allowed.\n",
    		PARAM_DEFAULT_ADAPTINPSTRATEGY);
    printf("c    -adaptInpStrategyParams [bool|%d] "
    		"Determines if it is allowed to adapt the in-processing strategy parameters (currently none).\n",
    		PARAM_DEFAULT_ADAPTINPSTRATEGYPARAMS);
    printf("c    -adaptSearchStrategy    [bool|%d] "
    		"Determines if adapting the search strategy is allowed.\n",
    		PARAM_DEFAULT_ADAPTSEARCHSTRATEGY);
    printf("c    -adaptSearchStrategyParams [bool|%d] "
    		"Determines if it is allowed to adapt the search strategy parameters (-searchMIDBlockSize).\n",
    		PARAM_DEFAULT_ADAPTSEARCHSTRATEGYPARAMS);
    printf("c    -adaptMpUR              [bool|%d] "
    		"Whether it is allowed to adapt its message passing update and bias computation rule (UR, -mpUpdateRule).\n",
    		PARAM_DEFAULT_ADAPTMPUR);
    printf("c    -adaptMpURParams        [bool|%d] "
    		"Whether it is allowed to adapt the UR parameters (-mpRho, -mpSigma).\n",
    		PARAM_DEFAULT_ADAPTMPURPARAMS);
    printf("c    -adaptSlsPAFVR          [bool|%d] "
    		"Whether it is allowed to adapt the pick and flip variable rule (PAFVR, -slsPickAndFlipVarRule).\n",
    		PARAM_DEFAULT_ADAPTSLSPAFVR);
    printf("c    -adaptSlsPAFVRParams    [bool|%d] "
    		"Whether it is allowed to adapt the PAFVR parameters (-slsNoise, -slsProbsatCB, -slsProbsatCBShift).\n",
    		PARAM_DEFAULT_ADAPTSLSPAFVRPARAMS);
    printf("c    -adaptSlsAI             [bool|%d] "
    		"Whether it is allowed to adapt the initialize assignment rule (AI, -slsAssInitRule).\n",
    		PARAM_DEFAULT_ADAPTSLSAI);
    printf("c    -adaptSlsAIParams       [bool|%d] "
    		"Whether it is allowed to adapt the AI parameters (currently none).\n",
    		PARAM_DEFAULT_ADAPTSLSAIPARAMS);
    printf("c    -adaptCdclSVR           [bool|%d] "
    		"Whether it is allowed to adapt the select variable rule (SVR, -cdclSelectVarRule).\n",
    		PARAM_DEFAULT_ADAPTCDCLSVR);
    printf("c    -adaptCdclSVRParams     [bool|%d] "
    		"Whether it is allowed to adapt the SVR parameters (-cdclSelectVarActIncBump, -cdclSelectVarRandProb).\n",
    		PARAM_DEFAULT_ADAPTCDCLSVRPARAMS);
    printf("c    -adaptCdclSVAI          [bool|%d] "
    		"Whether it is allowed to adapt the select variable activity initialization (SVAI, -cdclSelectVarActInit).\n",
    		PARAM_DEFAULT_ADAPTCDCLSVAI);
    printf("c    -adaptCdclSVAIParams    [bool|%d] "
    		"Whether it is allowed to adapt the SVAI parameters (currently none).\n",
    		PARAM_DEFAULT_ADAPTCDCLSVAIPARAMS);
    printf("c    -adaptCdclSDR           [bool|%d] "
    		"Whether it is allowed to adapt the select direction rule (SDR, -cdclSelectDirRule).\n",
    		PARAM_DEFAULT_ADAPTCDCLSDR);
    printf("c    -adaptCdclSDRParams     [bool|%d] "
    		"Whether it is allowed to adapt the SDR parameters (currently none).\n",
    		PARAM_DEFAULT_ADAPTCDCLSDRPARAMS);
    printf("c    -adaptCdclSDDI          [bool|%d] "
    		"Whether it is allowed to adapt the select direction direction initialization (SDDI, -cdclSelectDirDirInit).\n",
    		PARAM_DEFAULT_ADAPTCDCLSDDI);
    printf("c    -adaptCdclSDDIParams    [bool|%d] "
    		"Whether it is allowed to adapt the SDDI parameters (currently none).\n",
    		PARAM_DEFAULT_ADAPTCDCLSDDIPARAMS);
    printf("c    -adaptCdclCAR           [bool|%d] "
    		"Whether it is allowed to adapt the conflict analysis rule (CAR, -cdclConflictAnalysisRule)\n",
    		PARAM_DEFAULT_ADAPTCDCLCAR);
    printf("c    -adaptCdclCARParams     [bool|%d] "
    		"Whether it is allowed to adapt the CAR parameters (currently none).\n",
    		PARAM_DEFAULT_ADAPTCDCLCARPARAMS);
    printf("c    -adaptCdclSLR           [bool|%d] "
    		"Whether it is allowed to adapt the strengthen learned rule (SLR, -cdclStrLearnedRule).\n",
    		PARAM_DEFAULT_ADAPTCDCLSLR);
    printf("c    -adaptCdclSLRParams     [bool|%d] "
    		"Whether it is allowed to adapt the SLR parameters (currently none).\n",
    		PARAM_DEFAULT_ADAPTCDCLSLRPARAMS);
    printf("c    -adaptCdclSOR           [bool|%d] "
    		"Whether it is allowed to adapt the strengthen other rule (SOR, -cdclStrOtherRule).\n",
    		PARAM_DEFAULT_ADAPTCDCLSOR);
    printf("c    -adaptCdclSORParams     [bool|%d] "
    		"Whether it is allowed to adapt the SOR parameters (currently none)\n",
    		PARAM_DEFAULT_ADAPTCDCLSORPARAMS);
    printf("c    -adaptCdclCBJLR         [bool|%d] "
    		"Whether it is allowed to adapt the compute back-jump level rule (CBJLR, -cdclComputeBJLRule).\n",
    		PARAM_DEFAULT_ADAPTCDCLCBJLR);
    printf("c    -adaptCdclCBJLRParams   [bool|%d] "
    		"Whether it is allowed to adapt the CBJLR parameters (currently none).\n",
    		PARAM_DEFAULT_ADAPTCDCLCBJLRPARAMS);
    printf("c    -adaptCdclRR            [bool|%d] "
    		"Whether it is allowed to adapt the restart rule (RR, -cdclRestartRule).\n",
    		PARAM_DEFAULT_ADAPTCDCLRR);
    printf("c    -adaptCdclRRParams      [bool|%d] "
    		"Whether it is allowed to adapt the RR parameters (currently none).\n",
    		PARAM_DEFAULT_ADAPTCDCLRRPARAMS);
    printf("c    -adaptCdclMR            [bool|%d] "
    		"Whether it is allowed to adapt the maintenance rule (MR, -cdclMaintenanceRule).\n",
    		PARAM_DEFAULT_ADAPTCDCLMR);
    printf("c    -adaptCdclMRParams      [bool|%d] "
    		"Whether it is allowed to adapt the MR parameters (currently none).\n",
    		PARAM_DEFAULT_ADAPTCDCLMRPARAMS);
    printf("c    -adaptCdclIR            [bool|%d] "
    		"Whether it is allowed to adapt the in-processing rule (IR, -cdclInprocessingRule).\n",
    		PARAM_DEFAULT_ADAPTCDCLIR);
    printf("c    -adaptCdclIRParams      [bool|%d] "
    		"Whether it is allowed to adapt the IR parameters (currently none).\n",
    		PARAM_DEFAULT_ADAPTCDCLIRPARAMS);
    printf("c    -adaptCdclAR            [bool|%d] "
    		"Whether it is allowed to adapt the abort rule (AR, -cdclAbortRule).\n",
    		PARAM_DEFAULT_ADAPTCDCLAR);
    printf("c    -adaptCdclARParams      [bool|%d] "
    		"Whether it is allowed to adapt the AR parameters (currently none).\n",
    		PARAM_DEFAULT_ADAPTCDCLARPARAMS);

    //PREPROCESSOR
    printf("c   PREPROCESSING:\n");
    printf("c    -prepOutput             [char*]* "
    		"The relative path and filename to store the result from preprocessing.\n");
    printf("c    -prepReviveCls          [bool|%d] "
    		"Set this to 1 if you want to bring back specific removed clauses after preprocessing finishes.\n",
    		PARAM_DEFAULT_PREPREVIVECLS);
    printf("c    -prepACCEMax            [uint|%d] "
    		"Max literal occurrences of a literal whose clauses are checked by ACCE.\n",
    		PARAM_DEFAULT_PREPACCEMAX);
    printf("c    -prepACCEMinClsSize     [uint|%d] "
    		"Minimum size a clause must have before it is checked with ACCE.\n",
    		PARAM_DEFAULT_PREPACCEMINCLSSIZE);
    printf("c    -prepACCESaturate       [uint|%d] "
    		"Perform each clause check in ACCE only once or re-add them to the queue.\n",
    		PARAM_DEFAULT_PREPACCESATURATE);
    printf("c    -prepNIVERMax           [uint|%d] "
    		"Max literal occurrences for a variable that is checked by NIVER.\n",
    		PARAM_DEFAULT_PREPNIVERMAX);
    printf("c    -prepATEMin             [uint|%d] "
    		"Minimum size of a clause that is to be checked by separate ATE.\n",
    		PARAM_DEFAULT_PREPATEMIN);
    printf("c    -prepGEMaxAONN          [uint|%d] "
    		"Maximum number of resolvents allowed to be added when extracting an AND/OR/NAND/NOR gate in GE.\n",
    		PARAM_DEFAULT_PREPGEMAXAONN);
    printf("c    -prepGEMaxXOR           [uint|%d] "
    		"Maximum number of resolvents allowed to be added when extracting an XOR gate in GE.\n",
    		PARAM_DEFAULT_PREPGEMAXXOR);
    printf("c    -prepTERNARYLitMax      [uint|%d] "
    		"Maximum number of 3-clauses that can be learned per literal in ternary resolution per call.\n",
    		PARAM_DEFAULT_PREPTERNARYLITMAX);
    printf("c    -prepTERNARYMax         [uint|%d] "
    		"Maximum number of 3-clauses that can be learned in total in ternary resolution per call.\n",
    		PARAM_DEFAULT_PREPTERNARYMAX);
    printf("c    -prepNHBRMin            [uint|%d] "
    		"Minimum number of implications for a literal to be used in NHBR.\n",
    		PARAM_DEFAULT_PREPNHBRMIN);
    printf("c    -prepStrategy           [uint|%d] "
    		"The type of preprocessing strategy that is being used.\n",
    		PARAM_DEFAULT_PREPSTRATEGY);
    prep_strategies_printHelp();

    //IN-PROCESSOR
    printf("c   IN-PROCESSING:\n");
    printf("c    -inpStrMaxSize          [uint|%d] "
    		"The maximum clause size allowed for doing strengthening with it.\n",
    		PARAM_DEFAULT_INPSTRMAXSIZE);
    printf("c    -inpTernaryLitMax       [uint|%d] "
    		"Maximum number of learned ternary clauses for a single literal in a call to TERNARY resolution.\n",
    		PARAM_DEFAULT_INPTERNARYLITMAX);
    printf("c    -inpTernaryMax          [uint|%d] "
    		"Maximum number of learned ternary clauses for all literals in a call to TERNARY resolution.\n",
    		PARAM_DEFAULT_INPTERNARYMAX);
    printf("c    -inpNiverMax            [uint|%d] "
    		"Maximum total occurrence of a variable to be checked with NIVER.\n",
    		PARAM_DEFAULT_INPNIVERMAX);
    printf("c    -inpGEMaxAONN           [uint|%d] "
    		"Maximum number of resolvents allowed to be added when extracting AND/OR/NAND/NOR gates in GE.\n",
    		PARAM_DEFAULT_INPGEMAXAONN);
    printf("c    -inpGEMaxXOR            [uint|%d] "
    		"Maximum number of resolvents allowed to be added when extracting XOR gates in GE.\n",
    		PARAM_DEFAULT_INPGEMAXXOR);
    printf("c    -inpNHBRMin             [uint|%d] "
    		"Minimum number of implications for a literal to be used in NHBR.\n",
    		PARAM_DEFAULT_INPNHBRMIN);
    printf("c    -inpStrategy            [uint|%d] "
    		"The type of in-processing strategy that is being used.\n",
    		PARAM_DEFAULT_INPSTRATEGY);
    inp_strategies_printHelp();

    //SEARCH
    printf("c  SEARCH:\n");
    printf("c    -searchMIDBlockSize     [float|%f] "
    		"The fraction of variables of the formula we want to assign with MID as a block in search.\n",
    		PARAM_DEFAULT_SEARCHMIDBLOCKSIZE);
    printf("c    -searchMinClsImpact     [float|%f] "
    		"The minimum impact a learned clause must have on MP before it is retained as learned clause.\n",
    		PARAM_DEFAULT_SEARCHMINCLSIMPACT);
    printf("c    -searchImpactMaxFactor  [float|%f] "
    		"This times the number of variables gives the maximum impact of learned things for MP before it is disabled.\n",
    		PARAM_DEFAULT_SEARCHIMPACTMAXFACTOR);
    printf("c    -searchStrategy         [uint|%d] "
    		"The type of search strategy that is being used.\n",
    		PARAM_DEFAULT_SEARCHSTRATEGY);
    search_strategies_printHelp();

    //MP
    printf("c   MP:\n");
    printf("c    -mpMaxNumIterations     [uint|%d] "
    		"The number of message passing rounds before non-convergence is claimed.\n",
    		PARAM_DEFAULT_MPMAXNUMITERATIONS);
    printf("c    -mpMaxConvergenceDiff   [float|%f] "
    		"The maximum difference allowed for updated messages before convergence is claimed.\n",
    		PARAM_DEFAULT_MPMAXCONVERGENCEDIFF);
    printf("c    -mpMaxMagnetization     [float|%f] "
    		"The maximum global magnetization allowed such that we assume a paramagnetic state.\n",
    		PARAM_DEFAULT_MPMAXMAGNETIZATION);
    printf("c    -mpEpsilon              [float|%f] "
    		"The smallest fraction we allow for a message before we treat it as zero.\n",
    		PARAM_DEFAULT_MPEPSILON);
    printf("c    -mpRho                  [float|%f] "
    		"Controls the interpolation of BP (rho->0) and SP (rho->1) in the rho based URs.\n",
    		PARAM_DEFAULT_MPRHO);
    printf("c    -mpSigma                [float|%f] "
    		"Controls the interpolation of non-EM (sigma->0) and EM (sigma->1) in the sigma based URs.\n",
    		PARAM_DEFAULT_MPSIGMA);
    printf("c    -mpUpdateRule           [int|%d] "
    		"Determines the MP update rule to use (UR plug-in).\n",
    		PARAM_DEFAULT_MPUPDATERULE);
    mp_updateRules_printHelp();

    //SLS
    printf("c   SLS:\n");
    printf("c    -slsMaxFlipsFactor      [float|%f] "
    		"Determines the amount of flips per try. Set 0 for unlimited.\n",
    		PARAM_DEFAULT_SLSMAXFLIPSFACTOR);
    printf("c    -slsMaxTries            [uint|%d] "
    		"The number of tries (aka. restarts) the SLS is allowed to perform. Set 0 for unlimited.\n",
    		PARAM_DEFAULT_SLSMAXTRIES);
    printf("c    -slsNoise               [float|%f] "
    		"A noise parameter that can be used in various SLS heuristics, i.e. in WalkSAT.\n",
    		PARAM_DEFAULT_SLSNOISE);
    printf("c    -slsProbsatCB           [float|%f] "
    		"This parameter is used as the brake base constant to compute ProbSAT scores.\n",
    		PARAM_DEFAULT_SLSPROBSATCB);
    printf("c    -slsProbsatCBShift      [float|%f] "
    		"This parameter is used to shift the brake values to compute ProbSAT scores.\n",
    		PARAM_DEFAULT_SLSPROBSATCBSHIFT);
    printf("c    -slsPickAndFlipVarRule  [uint|%d] "
    		"Determines what heuristic to use to pick and flip SLS variable assignments (PAFVR plug-in).\n",
    		PARAM_DEFAULT_SLSPICKANDFLIPVARRULE);
    sls_pickAndFlipVarRules_printHelp();
    printf("c    -slsAssInitRule  [uint|%d] "
    		"Determines how the SLS initializes its initial assignment (AI plug-in).\n",
    		PARAM_DEFAULT_SLSASSINITRULE);
    sls_assInitRules_printHelp();

    //CDCL
    printf("c   CDCL:\n");
    printf("c    -cdclOutput             [char*] "
    		"The relative path and filename to store the current CDCL formula.\n");
    printf("c    -cdclRestartStagMaxFrac [float|%f] "
    		"When the computed stack stagnation is above this value, we do not do a restart in the RR.\n",
    		PARAM_DEFAULT_CDCLRESTARTSTAGMAXFRAC);
    printf("c    -cdclRestartInnerouterInit [uint|%d] "
    		"How many conflict need to be found initially in the inner/outer restart strategy.\n",
    		PARAM_DEFAULT_CDCLRESTARTINNEROUTERINIT);
    printf("c    -cdclRestartInnerouterInc [float|%f] "
    		"The increase factor for the outer bound in the inner/outer restart strategy.\n",
    		PARAM_DEFAULT_CDCLRESTARTINNEROUTERINC);
    printf("c    -cdclRestartLubyUnit    [uint|%d] "
    		"The basic value for the luby series (reluctant doubling sequence).\n",
    		PARAM_DEFAULT_CDCLRESTARTLUBYUNIT);
    printf("c    -cdclRestartVarAgiIncBump [float|%f] "
    		"The value with which we bump the increase value for variable agilities (NOT the agilities) in RR.\n",
    		PARAM_DEFAULT_CDCLRESTARTVARAGIINCBUMP);
    printf("c    -cdclRestartMaxAgiFrac  [float|%f] "
    		"The maximum fraction of variable with high agility allowed in a restart for the RR.\n",
    		PARAM_DEFAULT_CDCLRESTARTMAXAGIFRAC);
    printf("c    -cdclRestartMaxAgiOutFrac [float|%f] "
    		"The maximum fraction of variable with high agility allowed in an outer restart for the RR.\n",
    		PARAM_DEFAULT_CDCLRESTARTMAXAGIOUTFRAC);
    printf("c    -cdclSelectVarActIncBump [float|%f] "
    		"The value with which we bump the increase value for variable activities (NOT the activities) in SVR/CAR.\n",
    		PARAM_DEFAULT_CDCLSELECTVARACTINCBUMP);
    printf("c    -cdclSelectVarRandProb  [float|%f] "
    		"The probability to select a variable at random for decision if the SVR supports it.\n",
    		PARAM_DEFAULT_CDCLSELECTVARRANDPROB);
    printf("c    -cdclSelectDirMinFlipDist [uint|%d] "
    		"Minimum distance in DL1 decisions before flipping the assignment to a DL1 decision again.\n",
    		PARAM_DEFAULT_CDCLSELECTDIRMINFLIPDIST);
    printf("c    -cdclMaintenanceMinDev  [float|%f] "
    		"If the standard deviation in scaled LBD values is below this, we perform activity based CDBM.\n",
    		PARAM_DEFAULT_CDCLMAINTENANCEMINDEV);
    printf("c    -cdclMaintenanceMaxAvg  [float|%f] "
    		"If the average in scaled LBD values is above this, we perform activity based CDBM.\n",
    		PARAM_DEFAULT_CDCLMAINTENANCEMAXAVG);
    printf("c    -cdclMaintenanceActIncBump [float|%f] "
    		"The value with which we bump the increase value for clause activities (NOT the activities) in SVR/CAR.\n",
    		PARAM_DEFAULT_CDCLMAINTENANCEACTINCBUMP);
    printf("c    -cdclMaintenanceInitial [float|%f] "
    		"The fraction of initial clauses (not counting reasons) we need before we do the first clause maintenance.\n",
    		PARAM_DEFAULT_CDCLMAINTENANCEINITIAL);
    printf("c    -cdclMaintenanceIncrease [float|%f] "
    		"The value with which we increase the target number of learned clauses for clause maintenance.\n",
    		PARAM_DEFAULT_CDCLMAINTENANCEINCREASE);
    printf("c    -cdclMaintenanceBase    [int|%d] "
    		"The absolute number of initial clauses that must be learned before CDBM.\n",
    		PARAM_DEFAULT_CDCLMAINTENANCEBASE);
    printf("c    -cdclMaintenanceBoost   [int|%d] "
    		"How many more clauses do we want to learn before a new CDBM is performed.\n",
    		PARAM_DEFAULT_CDCLMAINTENANCEBOOST);
    printf("c    -cdclIRTERNARYLitMax    [uint|%d] "
    		"How many ternary clauses is in-processing allowed to learn for a single resolution variable at maximum.\n",
    		PARAM_DEFAULT_CDCLIRTERNARYLITMAX);
    printf("c    -cdclIRTERNARYMax       [uint|%d] "
    		"How many ternary clauses is in-processing allowed to learn in total for a single call to ternary resolution.\n",
    		PARAM_DEFAULT_CDCLIRTERNARYMAX);
    printf("c    -cdclIRNIVERMax         [uint|%d] "
    		"The maximum variable total occurrence for checking it with NIVER during in-processing.\n",
    		PARAM_DEFAULT_CDCLIRNIVERMAX);
    printf("c    -cdclIRGEMaxAONN        [uint|%d] "
    		"Maximum number of resolvents allowed to be added in GE during in-processing for AND/OR/NAND/NOR gates.\n",
    		PARAM_DEFAULT_CDCLIRGEMAXAONN);
    printf("c    -cdclIRGEMaxXOR         [uint|%d] "
    		"Maximum number of resolvents allowed to be added in GE during in-processing for XOR gates.\n",
    		PARAM_DEFAULT_CDCLIRGEMAXXOR);
    printf("c    -cdclIRStrMaxSize       [uint|%d] "
    		"Maximum clause size to use clause in IR strengthening.\n",
    		PARAM_DEFAULT_CDCLIRSTRMAXSIZE);
    printf("c    -cdclIRNHBRMin          [uint|%d] "
    		"Minimum number of implications a literal must have to be used for NHBR.\n",
    		PARAM_DEFAULT_CDCLIRNHBRMIN);
    printf("c    -cdclIRMinConfDistance  [float|%f] "
    		"This multiplied with the number of variables gives the minimum conflicts between two in-processings.\n",
    		PARAM_DEFAULT_CDCLIRMINCONFDISTANCE);
    printf("c    -cdclSelectVarRule      [uint|%d] "
    		"Determines what heuristic to use to pick the next variable to assign (SVR plug-in).\n",
    		PARAM_DEFAULT_CDCLSELECTVARRULE);
    cdcl_selectVarRules_printHelp();
    printf("c    -cdclSelectDirRule      [uint|%d] "
    		"Determines what heuristic to use to pick an assignment for the decision variable (SVR plug-in).\n",
    		PARAM_DEFAULT_CDCLSELECTDIRRULE);
    cdcl_selectDirRules_printHelp();
    printf("c    -cdclConflictAnalysisRule [uint|%d] "
    		"Determines what conflict analysis to perform in order to learn new clauses (CAR plug-in).\n",
    		PARAM_DEFAULT_CDCLCONFLICTANALYSISRULE);
    cdcl_conflictAnalysisRules_printHelp();
    printf("c    -cdclStrLearnedRule     [uint|%d] "
    		"Determines what strengthening of learned clauses to perform (SLR plug-in).\n",
    		PARAM_DEFAULT_CDCLSTRLEARNEDRULE);
    cdcl_strLearnedRules_printHelp();
    printf("c    -cdclStrOtherRule       [uint|%d] "
    		"Determines what strengthening of other with learned clauses to perform (SOR plug-in).\n",
    		PARAM_DEFAULT_CDCLSTROTHERRULE);
    cdcl_strOtherRules_printHelp();
    printf("c    -cdclComputeBJLRule     [uint|%d] "
    		"Determines what computation is to be performed for computing the back-jump level (CBJLR plug-in).\n",
    		PARAM_DEFAULT_CDCLCOMPUTEBJLRULE);
    cdcl_computeBJLRules_printHelp();
    printf("c    -cdclRestartRule        [uint|%d] "
    		"Determines what type of restarts to perform (RR plug-in).\n",
    		PARAM_DEFAULT_CDCLRESTARTRULE);
    cdcl_restartRules_printHelp();
    printf("c    -cdclMaintenanceRule    [uint|%d] "
    		"Determines what type of clause database maintenance to perform (MR plug-in).\n",
    		PARAM_DEFAULT_CDCLMAINTENANCERULE);
    cdcl_maintenanceRules_printHelp();
    printf("c    -cdclInprocessingRule   [uint|%d] "
    		"Determines what type of in-processing to perform (IR plug-in).\n",
    		PARAM_DEFAULT_CDCLINPROCESSINGRULE);
    cdcl_inprocessingRules_printHelp();
    printf("c    -cdclAbortRule          [uint|%d] "
    		"Determines what type of search abort rule to use (AR plug-in).\n",
    		PARAM_DEFAULT_CDCLABORTRULE);
    cdcl_abortRules_printHelp();
}

void params_printVersion(){
	printf("c Version information:\n");
	printf("c  DIMETHEUS: %d.%d ", VERSION_MA, VERSION_MI);
	//Check if we compile on a 32 bit system.
	#ifdef SYS32BIT
	//We are compiling for a 32-bit system.
	printf(" (32 bit)\n");
	#else
	//We are compiling for a 64-bit system
	printf(" (64 bit)\n");
	#endif
	printf("c    SVN revision (Head): %d\n", VERSION_RE);
	printf("c    SVN check in (Time): %s\n", VERSION_CI);
	printf("c  Module versions:\n");
	printf("c    NUM [MODULE FOR PHASE] [TYPE/TASK                      ] :: VERSION  :: MODULE NAME\n");
	printf("c    000 "); class_extern_printVersion(); printf("\n");
	printf("c    010 "); iteadapter_extern_printVersion(); printf("\n");
	printf("c    020 "); pre_extern_printVersion(); printf("\n");
	printf("c    030 "); in_extern_printVersion(); printf("\n");
	printf("c    040 "); mp_extern_printVersion(); printf("\n");
	printf("c    050 "); sls_extern_printVersion(); printf("\n");
	printf("c    060 "); cdcl_extern_printVersion(); printf("\n");
}

void params_resetAll(){
	//RESET ALL TO DEFAULTS
	//Main algorithm related.
	param_formula 					= NULL;
	param_seed 						= PARAM_DEFAULT_SEED;
	param_printAssignment			= PARAM_DEFAULT_PRINTASSIGNMENT;
	param_guide						= PARAM_DEFAULT_GUIDE;
	//Classification related.
	param_classifyStrategy			= PARAM_DEFAULT_CLASSIFYSTRATEGY;
	//Adaptation related.
	param_adaptAssumeRandom			= PARAM_DEFAULT_ADAPTASSUMERANDOM;
	param_adaptStrategy				= PARAM_DEFAULT_ADAPTSTRATEGY;
	param_adaptPrepStrategy			= PARAM_DEFAULT_ADAPTPREPSTRATEGY;
	param_adaptPrepStrategyParams	= PARAM_DEFAULT_ADAPTPREPSTRATEGYPARAMS;
	param_adaptInpStrategy			= PARAM_DEFAULT_ADAPTINPSTRATEGY;
	param_adaptInpStrategyParams	= PARAM_DEFAULT_ADAPTINPSTRATEGYPARAMS;
	param_adaptSearchStrategy		= PARAM_DEFAULT_ADAPTSEARCHSTRATEGY;
	param_adaptSearchStrategyParams	= PARAM_DEFAULT_ADAPTSEARCHSTRATEGYPARAMS;
	param_adaptMpUR					= PARAM_DEFAULT_ADAPTMPUR;
	param_adaptMpURParams			= PARAM_DEFAULT_ADAPTMPURPARAMS;
	param_adaptSlsPAFVR				= PARAM_DEFAULT_ADAPTSLSPAFVR;
	param_adaptSlsPAFVRParams		= PARAM_DEFAULT_ADAPTSLSPAFVRPARAMS;
	param_adaptSlsAI				= PARAM_DEFAULT_ADAPTSLSAI;
	param_adaptSlsAIParams			= PARAM_DEFAULT_ADAPTSLSAIPARAMS;
	param_adaptCdclSVR				= PARAM_DEFAULT_ADAPTCDCLSVR;
	param_adaptCdclSVRParams		= PARAM_DEFAULT_ADAPTCDCLSVRPARAMS;
	param_adaptCdclSVAI				= PARAM_DEFAULT_ADAPTCDCLSVAI;
	param_adaptCdclSVAIParams		= PARAM_DEFAULT_ADAPTCDCLSVAIPARAMS;
	param_adaptCdclSDR				= PARAM_DEFAULT_ADAPTCDCLSDR;
	param_adaptCdclSDRParams		= PARAM_DEFAULT_ADAPTCDCLSDRPARAMS;
	param_adaptCdclSDDI				= PARAM_DEFAULT_ADAPTCDCLSDDI;
	param_adaptCdclSDDIParams		= PARAM_DEFAULT_ADAPTCDCLSDDIPARAMS;
	param_adaptCdclCAR				= PARAM_DEFAULT_ADAPTCDCLCAR;
	param_adaptCdclCARParams		= PARAM_DEFAULT_ADAPTCDCLCARPARAMS;
	param_adaptCdclSLR				= PARAM_DEFAULT_ADAPTCDCLSLR;
	param_adaptCdclSLRParams		= PARAM_DEFAULT_ADAPTCDCLSLRPARAMS;
	param_adaptCdclSOR				= PARAM_DEFAULT_ADAPTCDCLSOR;
	param_adaptCdclSORParams		= PARAM_DEFAULT_ADAPTCDCLSORPARAMS;
	param_adaptCdclCBJLR			= PARAM_DEFAULT_ADAPTCDCLCBJLR;
	param_adaptCdclCBJLRParams		= PARAM_DEFAULT_ADAPTCDCLCBJLRPARAMS;
	param_adaptCdclRR				= PARAM_DEFAULT_ADAPTCDCLRR;
	param_adaptCdclRRParams			= PARAM_DEFAULT_ADAPTCDCLRRPARAMS;
	param_adaptCdclMR				= PARAM_DEFAULT_ADAPTCDCLMR;
	param_adaptCdclMRParams			= PARAM_DEFAULT_ADAPTCDCLMRPARAMS;
	param_adaptCdclIR				= PARAM_DEFAULT_ADAPTCDCLIR;
	param_adaptCdclIRParams			= PARAM_DEFAULT_ADAPTCDCLIRPARAMS;
	param_adaptCdclAR				= PARAM_DEFAULT_ADAPTCDCLAR;
	param_adaptCdclARParams			= PARAM_DEFAULT_ADAPTCDCLARPARAMS;
	//Preprocessor related.
	param_prepOutput				= NULL;
	param_prepReviveCls 			= PARAM_DEFAULT_PREPREVIVECLS;
	param_prepACCEMax 				= PARAM_DEFAULT_PREPACCEMAX;
	param_prepACCEMinClsSize		= PARAM_DEFAULT_PREPACCEMINCLSSIZE;
	param_prepACCESaturate			= PARAM_DEFAULT_PREPACCESATURATE;
	param_prepNIVERMax 				= PARAM_DEFAULT_PREPNIVERMAX;
	param_prepATEMin				= PARAM_DEFAULT_PREPATEMIN;
	param_prepGEMaxAONN				= PARAM_DEFAULT_PREPGEMAXAONN;
	param_prepGEMaxXOR				= PARAM_DEFAULT_PREPGEMAXXOR;
	param_prepTERNARYLitMax			= PARAM_DEFAULT_PREPTERNARYLITMAX;
	param_prepTERNARYMax			= PARAM_DEFAULT_PREPTERNARYMAX;
	param_prepNHBRMin				= PARAM_DEFAULT_PREPNHBRMIN;
	param_prepStrategy				= PARAM_DEFAULT_PREPSTRATEGY;
	//In-processor related.
	param_inpStrMaxSize				= PARAM_DEFAULT_INPSTRMAXSIZE;
	param_inpTernaryLitMax			= PARAM_DEFAULT_INPTERNARYLITMAX;
	param_inpTernaryMax				= PARAM_DEFAULT_INPTERNARYMAX;
	param_inpNiverMax				= PARAM_DEFAULT_INPNIVERMAX;
	param_inpGEMaxAONN				= PARAM_DEFAULT_INPGEMAXAONN;
	param_inpGEMaxXOR				= PARAM_DEFAULT_INPGEMAXXOR;
	param_inpNHBRMin				= PARAM_DEFAULT_INPNHBRMIN;
	param_inpStrategy				= PARAM_DEFAULT_INPSTRATEGY;
	//Search related.
	param_searchMIDBlockSize		= PARAM_DEFAULT_SEARCHMIDBLOCKSIZE;
	param_searchMinClsImpact		= PARAM_DEFAULT_SEARCHMINCLSIMPACT;
	param_searchImpactMaxFactor		= PARAM_DEFAULT_SEARCHIMPACTMAXFACTOR;
	param_searchStrategy			= PARAM_DEFAULT_SEARCHSTRATEGY;
	//MP
	param_mpMaxNumIterations		= PARAM_DEFAULT_MPMAXNUMITERATIONS;
	param_mpMaxConvergenceDiff		= PARAM_DEFAULT_MPMAXCONVERGENCEDIFF;
	param_mpMaxMagnetization		= PARAM_DEFAULT_MPMAXMAGNETIZATION;
	param_mpEpsilon					= PARAM_DEFAULT_MPEPSILON;
	param_mpRho						= PARAM_DEFAULT_MPRHO;
	param_mpSigma					= PARAM_DEFAULT_MPSIGMA;
	param_mpUpdateRule				= PARAM_DEFAULT_MPUPDATERULE;
	//SLS
	param_slsMaxFlipsFactor			= PARAM_DEFAULT_SLSMAXFLIPSFACTOR;
	param_slsMaxTries				= PARAM_DEFAULT_SLSMAXTRIES;
	param_slsNoise					= PARAM_DEFAULT_SLSNOISE;
	param_slsProbsatCB				= PARAM_DEFAULT_SLSPROBSATCB;
	param_slsProbsatCBShift			= PARAM_DEFAULT_SLSPROBSATCBSHIFT;
	param_slsPickAndFlipVarRule 	= PARAM_DEFAULT_SLSPICKANDFLIPVARRULE;
	param_slsAssInitRule 			= PARAM_DEFAULT_SLSASSINITRULE;
	//CDCL
	param_cdclOutput				= NULL;
	param_cdclRestartStagMaxFrac    = PARAM_DEFAULT_CDCLRESTARTSTAGMAXFRAC;
	param_cdclRestartInnerouterInit = PARAM_DEFAULT_CDCLRESTARTINNEROUTERINIT;
	param_cdclRestartInnerouterInc  = PARAM_DEFAULT_CDCLRESTARTINNEROUTERINC;
	param_cdclRestartLubyUnit		= PARAM_DEFAULT_CDCLRESTARTLUBYUNIT;
	param_cdclRestartVarAgiIncBump	= PARAM_DEFAULT_CDCLRESTARTVARAGIINCBUMP;
	param_cdclRestartMaxAgiFrac		= PARAM_DEFAULT_CDCLRESTARTMAXAGIFRAC;
	param_cdclRestartMaxAgiOutFrac	= PARAM_DEFAULT_CDCLRESTARTMAXAGIOUTFRAC;
	param_cdclSelectVarActIncBump	= PARAM_DEFAULT_CDCLSELECTVARACTINCBUMP;
	param_cdclSelectVarActInit		= PARAM_DEFAULT_CDCLSELECTVARACTINIT;
	param_cdclSelectVarRandProb		= PARAM_DEFAULT_CDCLSELECTVARRANDPROB;
	param_cdclSelectDirMinFlipDist  = PARAM_DEFAULT_CDCLSELECTDIRMINFLIPDIST;
	param_cdclSelectDirDirInit		= PARAM_DEFAULT_CDCLSELECTDIRDIRINIT;
	param_cdclMaintenanceMinDev		= PARAM_DEFAULT_CDCLMAINTENANCEMINDEV;
	param_cdclMaintenanceMaxAvg		= PARAM_DEFAULT_CDCLMAINTENANCEMAXAVG;
	param_cdclMaintenanceActIncBump	= PARAM_DEFAULT_CDCLMAINTENANCEACTINCBUMP;
	param_cdclMaintenanceInitial    = PARAM_DEFAULT_CDCLMAINTENANCEINITIAL;
	param_cdclMaintenanceIncrease   = PARAM_DEFAULT_CDCLMAINTENANCEINCREASE;
	param_cdclMaintenanceBase		= PARAM_DEFAULT_CDCLMAINTENANCEBASE;
	param_cdclMaintenanceBoost		= PARAM_DEFAULT_CDCLMAINTENANCEBOOST;
	param_cdclIRTERNARYLitMax		= PARAM_DEFAULT_CDCLIRTERNARYLITMAX;
	param_cdclIRTERNARYMax			= PARAM_DEFAULT_CDCLIRTERNARYMAX;
	param_cdclIRNIVERMax			= PARAM_DEFAULT_CDCLIRNIVERMAX;
	param_cdclIRGEMaxAONN			= PARAM_DEFAULT_CDCLIRGEMAXAONN;
	param_cdclIRGEMaxXOR			= PARAM_DEFAULT_CDCLIRGEMAXXOR;
	param_cdclIRStrMaxSize			= PARAM_DEFAULT_CDCLIRSTRMAXSIZE;
	param_cdclIRNHBRMin				= PARAM_DEFAULT_CDCLIRNHBRMIN;
	param_cdclIRMinConfDistance		= PARAM_DEFAULT_CDCLIRMINCONFDISTANCE;
	param_cdclSelectVarRule		 	= PARAM_DEFAULT_CDCLSELECTVARRULE;
	param_cdclSelectDirRule		 	= PARAM_DEFAULT_CDCLSELECTDIRRULE;
	param_cdclConflictAnalysisRule	= PARAM_DEFAULT_CDCLCONFLICTANALYSISRULE;
	param_cdclStrLearnedRule		= PARAM_DEFAULT_CDCLSTRLEARNEDRULE;
	param_cdclStrOtherRule			= PARAM_DEFAULT_CDCLSTROTHERRULE;
	param_cdclComputeBJLRule		= PARAM_DEFAULT_CDCLCOMPUTEBJLRULE;
	param_cdclRestartRule			= PARAM_DEFAULT_CDCLRESTARTRULE;
	param_cdclMaintenanceRule		= PARAM_DEFAULT_CDCLMAINTENANCERULE;
	param_cdclInprocessingRule		= PARAM_DEFAULT_CDCLINPROCESSINGRULE;
	param_cdclAbortRule		        = PARAM_DEFAULT_CDCLABORTRULE;

}

void params_readSpecial(int argc, char** argv){
	int32_t parameter=0;
	for (parameter=1; parameter<argc && main_returnCode == UNKNOWN; ++parameter){
		if ( !strcmp("h", argv[1]) || !strcmp("/h", argv[1]) || !strcmp("-h", argv[1])
				|| !strcmp("help", argv[1]) || !strcmp("-help", argv[1]) || !strcmp("--help", argv[1])
			){
			params_printHelp();
			main_returnCode = BADPARAM;
			return;
		}
		if (!strcmp("v", argv[1]) || !strcmp("/v", argv[1]) || !strcmp("-v", argv[1])
				|| !strcmp("version", argv[1]) || !strcmp("-version", argv[1]) || !strcmp("--version", argv[1])
			){
			params_printVersion();
			main_returnCode = BADPARAM;
			return;
		}
	}
}

void params_readAll(int argc, char** argv){
	int32_t parameter=0;
	#ifdef VERBOSE
	int32_t formulaParam = 0, prepOutputParam = 0, cdclOutputParam = 0;
	#endif

	printf("c READING PARAMETERS...\n");
	//READ FROM COMMAND LINE
	for (parameter=1; parameter<argc && main_returnCode == UNKNOWN; ++parameter){
	//Main algorithm related.
	if (!strcmp("-formula",argv[parameter])) 			{params_readFormulaFile(argc,argv,++parameter);
		#ifdef VERBOSE
		formulaParam = parameter-1;
		#endif
		continue;}
	if (!strcmp("-seed",argv[parameter])) {				params_readSeed(argc,argv,++parameter);continue;}
	if (!strcmp("-printAssignment",argv[parameter])) 	{params_readPrintAssignment(argc,argv,++parameter);continue;}
	if (!strcmp("-guide",argv[parameter])) 				{params_readGuide(argc,argv,++parameter);continue;}
	//Classification related.
	if (!strcmp("-classifyStrategy",argv[parameter])) 	{params_readClassifyStrategy(argc,argv,++parameter);continue;}
	//Adaptation related.
	if (!strcmp("-adaptAssumeRandom",argv[parameter])) 	{params_readAdaptAssumeRandom(argc,argv,++parameter);continue;}
	if (!strcmp("-adaptStrategy",argv[parameter])) 		{params_readAdaptStrategy(argc,argv,++parameter);continue;}
	if (!strcmp("-adaptPrepStrategy",argv[parameter])) 	{params_readAdaptPrepStrategy(argc,argv,++parameter);continue;}
	if (!strcmp("-adaptPrepStrategyParams",argv[parameter])) {params_readAdaptPrepStrategyParams(argc,argv,++parameter);continue;}
	if (!strcmp("-adaptInpStrategy",argv[parameter])) 	{params_readAdaptInpStrategy(argc,argv,++parameter);continue;}
	if (!strcmp("-adaptInpStrategyParams",argv[parameter])){params_readAdaptInpStrategyParams(argc,argv,++parameter);continue;}
	if (!strcmp("-adaptSearchStrategy",argv[parameter])){params_readAdaptSearchStrategy(argc,argv,++parameter);continue;}
	if (!strcmp("-adaptSearchStrategyParams",argv[parameter])){params_readAdaptSearchStrategyParams(argc,argv,++parameter);continue;}
	if (!strcmp("-adaptMpUR",argv[parameter])) 			{params_readAdaptMpUR(argc,argv,++parameter);continue;}
	if (!strcmp("-adaptMpURParams",argv[parameter]))	{params_readAdaptMpURParams(argc,argv,++parameter);continue;}
	if (!strcmp("-adaptSlsPAFVR",argv[parameter])) 		{params_readAdaptSlsPAFVR(argc,argv,++parameter);continue;}
	if (!strcmp("-adaptSlsPAFVRParams",argv[parameter])){params_readAdaptSlsPAFVRParams(argc,argv,++parameter);continue;}
	if (!strcmp("-adaptSlsAI",argv[parameter])) 		{params_readAdaptSlsAI(argc,argv,++parameter);continue;}
	if (!strcmp("-adaptSlsAIParams",argv[parameter]))	{params_readAdaptSlsAIParams(argc,argv,++parameter);continue;}
	if (!strcmp("-adaptCdclSVR",argv[parameter])) 		{params_readAdaptCdclSVR(argc,argv,++parameter);continue;}
	if (!strcmp("-adaptCdclSVRParams",argv[parameter]))	{params_readAdaptCdclSVRParams(argc,argv,++parameter);continue;}
	if (!strcmp("-adaptCdclSVAI",argv[parameter])) 		{params_readAdaptCdclSVAI(argc,argv,++parameter);continue;}
	if (!strcmp("-adaptCdclSVAIParams",argv[parameter])){params_readAdaptCdclSVAIParams(argc,argv,++parameter);continue;}
	if (!strcmp("-adaptCdclSDR",argv[parameter])) 		{params_readAdaptCdclSDR(argc,argv,++parameter);continue;}
	if (!strcmp("-adaptCdclSDRParams",argv[parameter]))	{params_readAdaptCdclSDRParams(argc,argv,++parameter);continue;}
	if (!strcmp("-adaptCdclSDDI",argv[parameter])) 		{params_readAdaptCdclSDDI(argc,argv,++parameter);continue;}
	if (!strcmp("-adaptCdclSDDIParams",argv[parameter])){params_readAdaptCdclSDDIParams(argc,argv,++parameter);continue;}
	if (!strcmp("-adaptCdclCAR",argv[parameter])) 		{params_readAdaptCdclCAR(argc,argv,++parameter);continue;}
	if (!strcmp("-adaptCdclCARParams",argv[parameter]))	{params_readAdaptCdclCARParams(argc,argv,++parameter);continue;}
	if (!strcmp("-adaptCdclSLR",argv[parameter])) 		{params_readAdaptCdclSLR(argc,argv,++parameter);continue;}
	if (!strcmp("-adaptCdclSLRParams",argv[parameter]))	{params_readAdaptCdclSLRParams(argc,argv,++parameter);continue;}
	if (!strcmp("-adaptCdclSOR",argv[parameter])) 		{params_readAdaptCdclSOR(argc,argv,++parameter);continue;}
	if (!strcmp("-adaptCdclSORParams",argv[parameter]))	{params_readAdaptCdclSORParams(argc,argv,++parameter);continue;}
	if (!strcmp("-adaptCdclCBJLR",argv[parameter])) 	{params_readAdaptCdclCBJLR(argc,argv,++parameter);continue;}
	if (!strcmp("-adaptCdclCBJLRParams",argv[parameter])){params_readAdaptCdclCBJLRParams(argc,argv,++parameter);continue;}
	if (!strcmp("-adaptCdclRR",argv[parameter])) 		{params_readAdaptCdclRR(argc,argv,++parameter);continue;}
	if (!strcmp("-adaptCdclRRParams",argv[parameter]))	{params_readAdaptCdclRRParams(argc,argv,++parameter);continue;}
	if (!strcmp("-adaptCdclMR",argv[parameter])) 		{params_readAdaptCdclMR(argc,argv,++parameter);continue;}
	if (!strcmp("-adaptCdclMRParams",argv[parameter]))	{params_readAdaptCdclMRParams(argc,argv,++parameter);continue;}
	if (!strcmp("-adaptCdclIR",argv[parameter])) 		{params_readAdaptCdclIR(argc,argv,++parameter);continue;}
	if (!strcmp("-adaptCdclIRParams",argv[parameter]))	{params_readAdaptCdclIRParams(argc,argv,++parameter);continue;}
	if (!strcmp("-adaptCdclAR",argv[parameter])) 		{params_readAdaptCdclAR(argc,argv,++parameter);continue;}
	if (!strcmp("-adaptCdclARParams",argv[parameter]))	{params_readAdaptCdclARParams(argc,argv,++parameter);continue;}
	//Preprocessor related.
	if (!strcmp("-prepOutput",argv[parameter])) 		{params_readPrepOutput(argc,argv,++parameter);
		#ifdef VERBOSE
		prepOutputParam = parameter-1;
		#endif
		continue;}
	if (!strcmp("-prepReviveCls",argv[parameter])) 		{params_readPrepReviveCls(argc,argv,++parameter);continue;}
	if (!strcmp("-prepACCEMax",argv[parameter])) 		{params_readPrepACCEMax(argc,argv,++parameter);continue;}
	if (!strcmp("-prepACCEMinClsSize",argv[parameter])) {params_readPrepACCEMinClsSize(argc,argv,++parameter);continue;}
	if (!strcmp("-prepACCESaturate",argv[parameter])) 	{params_readPrepACCESaturate(argc,argv,++parameter);continue;}
	if (!strcmp("-prepNIVERMax",argv[parameter])) 		{params_readPrepNIVERMax(argc,argv,++parameter);continue;}
	if (!strcmp("-prepATEMin",argv[parameter])) 		{params_readPrepATEMin(argc,argv,++parameter);continue;}
	if (!strcmp("-prepGEMaxAONN",argv[parameter])) 		{params_readPrepGEMaxAONN(argc,argv,++parameter);continue;}
	if (!strcmp("-prepGEMaxXOR",argv[parameter])) 		{params_readPrepGEMaxXOR(argc,argv,++parameter);continue;}
	if (!strcmp("-prepTERNARYLitMax",argv[parameter])) 	{params_readPrepTERNARYLitMax(argc,argv,++parameter);continue;}
	if (!strcmp("-prepTERNARYMax",argv[parameter])) 	{params_readPrepTERNARYMax(argc,argv,++parameter);continue;}
	if (!strcmp("-prepNHBRMin",argv[parameter])) 		{params_readPrepNHBRMin(argc,argv,++parameter);continue;}
	if (!strcmp("-prepStrategy",argv[parameter])) 		{params_readPrepStrategy(argc,argv,++parameter);continue;}
	//In-processor related.
	if (!strcmp("-inpStrMaxSize",argv[parameter])) 		{params_readInpStrMaxSize(argc,argv,++parameter);continue;}
	if (!strcmp("-inpTernaryLitMax",argv[parameter])) 	{params_readInpTernaryLitMax(argc,argv,++parameter);continue;}
	if (!strcmp("-inpTernaryMax",argv[parameter])) 		{params_readInpTernaryMax(argc,argv,++parameter);continue;}
	if (!strcmp("-inpNiverMax",argv[parameter])) 		{params_readInpNiverMax(argc,argv,++parameter);continue;}
	if (!strcmp("-inpGEMaxAONN",argv[parameter])) 		{params_readInpGEMaxAONN(argc,argv,++parameter);continue;}
	if (!strcmp("-inpGEMaxXOR",argv[parameter])) 		{params_readInpGEMaxXOR(argc,argv,++parameter);continue;}
	if (!strcmp("-inpNHBRMin",argv[parameter])) 		{params_readInpNHBRMin(argc,argv,++parameter);continue;}
	if (!strcmp("-inpStrategy",argv[parameter])) 		{params_readInpStrategy(argc,argv,++parameter);continue;}
	//Search related.
	if (!strcmp("-searchMIDBlockSize",argv[parameter]))	{params_readSearchMIDBlockSize(argc,argv,++parameter);continue;}
	if (!strcmp("-searchMinClsImpact",argv[parameter])) {params_readSearchMinClsImpact(argc,argv,++parameter);continue;}
	if (!strcmp("-searchImpactMaxFactor",argv[parameter])){params_readSearchImpactMaxFactor(argc,argv,++parameter);continue;}
	if (!strcmp("-searchStrategy",argv[parameter])) 	{params_readSearchStrategy(argc,argv,++parameter);continue;}
	//MP
	if (!strcmp("-mpMaxNumIterations",argv[parameter])) {params_readMpMaxNumIterations(argc,argv,++parameter);continue;}
	if (!strcmp("-mpMaxConvergenceDiff",argv[parameter])){params_readMpMaxConvergenceDiff(argc,argv,++parameter);continue;}
	if (!strcmp("-mpMaxMagnetization",argv[parameter])) {params_readMpMaxMagnetization(argc,argv,++parameter);continue;}
	if (!strcmp("-mpEpsilon",argv[parameter])) 			{params_readMpEpsilon(argc,argv,++parameter);continue;}
	if (!strcmp("-mpRho",argv[parameter])) 				{params_readMpRho(argc,argv,++parameter);continue;}
	if (!strcmp("-mpSigma",argv[parameter])) 			{params_readMpSigma(argc,argv,++parameter);continue;}
	if (!strcmp("-mpUpdateRule",argv[parameter])) 		{params_readMpUpdateRule(argc,argv,++parameter);continue;}
	//SLS
	if (!strcmp("-slsMaxFlipsFactor",argv[parameter]))	{params_readSlsMaxFlipsFactor(argc,argv,++parameter);continue;}
	if (!strcmp("-slsMaxTries",argv[parameter])) 		{params_readSlsMaxTries(argc,argv,++parameter);continue;}
	if (!strcmp("-slsNoise",argv[parameter])) 			{params_readSlsNoise(argc,argv,++parameter);continue;}
	if (!strcmp("-slsProbsatCB",argv[parameter])) 		{params_readSlsProbsatCB(argc,argv,++parameter);continue;}
	if (!strcmp("-slsProbsatCBShift",argv[parameter])) 	{params_readSlsProbsatCBShift(argc,argv,++parameter);continue;}
	if (!strcmp("-slsPickAndFlipVarRule",argv[parameter])){params_readSlsPickAndFlipVarRule(argc,argv,++parameter);continue;}
	if (!strcmp("-slsAssInitRule",argv[parameter]))		{params_readSlsAssInitRule(argc,argv,++parameter);continue;}
	//CDCL

	if (!strcmp("-cdclOutput",argv[parameter])) 		{params_readCdclOutput(argc,argv,++parameter);
		#ifdef VERBOSE
		cdclOutputParam = parameter-1;
		#endif
		continue;}
	if (!strcmp("-cdclRestartStagMaxFrac",argv[parameter])){params_readCdclRestartStagMaxFrac(argc,argv,++parameter);continue;}
	if (!strcmp("-cdclRestartInnerouterInit",argv[parameter])){params_readCdclRestartInnerouterInit(argc,argv,++parameter);continue;}
	if (!strcmp("-cdclRestartInnerouterInc",argv[parameter])){params_readCdclRestartInnerouterInc(argc,argv,++parameter);continue;}
	if (!strcmp("-cdclRestartLubyUnit",argv[parameter])){params_readCdclRestartLubyUnit(argc,argv,++parameter);continue;}
	if (!strcmp("-cdclRestartVarAgiIncBump",argv[parameter])){params_readCdclRestartVarAgiIncBump(argc,argv,++parameter);continue;}
	if (!strcmp("-cdclRestartMaxAgiFrac",argv[parameter])){params_readCdclRestartMaxAgiFrac(argc,argv,++parameter);continue;}
	if (!strcmp("-cdclRestartMaxAgiOutFrac",argv[parameter])){params_readCdclRestartMaxAgiOutFrac(argc,argv,++parameter);continue;}
	if (!strcmp("-cdclSelectVarActIncBump",argv[parameter])){params_readCdclSelectVarActIncBump(argc,argv,++parameter);continue;}
	if (!strcmp("-cdclSelectVarActInit",argv[parameter])){params_readCdclSelectVarActInit(argc,argv,++parameter);continue;}
	if (!strcmp("-cdclSelectVarRandProb",argv[parameter])){params_readCdclSelectVarRandProb(argc,argv,++parameter);continue;}
	if (!strcmp("-cdclSelectDirMinFlipDist",argv[parameter])){params_readCdclSelectDirMinFlipDist(argc,argv,++parameter);continue;}
	if (!strcmp("-cdclSelectDirDirInit",argv[parameter])){params_readCdclSelectDirDirInit(argc,argv,++parameter);continue;}
	if (!strcmp("-cdclMaintenanceMinDev",argv[parameter])){params_readCdclMaintenanceMinDev(argc,argv,++parameter);continue;}
	if (!strcmp("-cdclMaintenanceMaxAvg",argv[parameter])){params_readCdclMaintenanceMaxAvg(argc,argv,++parameter);continue;}
	if (!strcmp("-cdclMaintenanceActIncBump",argv[parameter])){params_readCdclMaintenanceActIncBump(argc,argv,++parameter);continue;}
	if (!strcmp("-cdclMaintenanceInitial",argv[parameter])){params_readCdclMaintenanceInitial(argc,argv,++parameter);continue;}
	if (!strcmp("-cdclMaintenanceIncrease",argv[parameter])){params_readCdclMaintenanceIncrease(argc,argv,++parameter);continue;}
	if (!strcmp("-cdclMaintenanceBase",argv[parameter])){params_readCdclMaintenanceBase(argc,argv,++parameter);continue;}
	if (!strcmp("-cdclMaintenanceBoost",argv[parameter])){params_readCdclMaintenanceBoost(argc,argv,++parameter);continue;}
	if (!strcmp("-cdclIRTERNARYLitMax",argv[parameter])){params_readCdclIRTERNARYLitMax(argc,argv,++parameter);continue;}
	if (!strcmp("-cdclIRTERNARYMax",argv[parameter]))	{params_readCdclIRTERNARYMax(argc,argv,++parameter);continue;}
	if (!strcmp("-cdclIRNIVERMax",argv[parameter]))		{params_readCdclIRNIVERMax(argc,argv,++parameter);continue;}
	if (!strcmp("-cdclIRGEMaxAONN",argv[parameter]))	{params_readCdclIRGEMaxAONN(argc,argv,++parameter);continue;}
	if (!strcmp("-cdclIRGEMaxXOR",argv[parameter]))		{params_readCdclIRGEMaxXOR(argc,argv,++parameter);continue;}
	if (!strcmp("-cdclIRStrMaxSize",argv[parameter]))	{params_readCdclIRStrMaxSize(argc,argv,++parameter);continue;}
	if (!strcmp("-cdclIRNHBRMin",argv[parameter]))		{params_readCdclIRNHBRMin(argc,argv,++parameter);continue;}
	if (!strcmp("-cdclIRMinConfDistance",argv[parameter])){params_readCdclIRMinConfDistance(argc,argv,++parameter);continue;}
	if (!strcmp("-cdclSelectVarRule",argv[parameter]))	{params_readCdclSelectVarRule(argc,argv,++parameter);continue;}
	if (!strcmp("-cdclSelectDirRule",argv[parameter]))	{params_readCdclSelectDirRule(argc,argv,++parameter);continue;}
	if (!strcmp("-cdclConflictAnalysisRule",argv[parameter])){params_readCdclConflictAnalysisRule(argc,argv,++parameter);continue;}
	if (!strcmp("-cdclStrLearnedRule",argv[parameter])) {params_readCdclStrLearnedRule(argc,argv,++parameter);continue;}
	if (!strcmp("-cdclStrOtherRule",argv[parameter])) 	{params_readCdclStrOtherRule(argc,argv,++parameter);continue;}
	if (!strcmp("-cdclComputeBJLRule",argv[parameter])) {params_readCdclComputeBJLRule(argc,argv,++parameter);continue;}
	if (!strcmp("-cdclRestartRule",argv[parameter])) 	{params_readCdclRestartRule(argc,argv,++parameter);continue;}
	if (!strcmp("-cdclMaintenanceRule",argv[parameter])){params_readCdclMaintenanceRule(argc,argv,++parameter);continue;}
	if (!strcmp("-cdclInprocessingRule",argv[parameter])){params_readCdclInprocessingRule(argc,argv,++parameter);continue;}
	if (!strcmp("-cdclAbortRule",argv[parameter]))		{params_readCdclAbortRule(argc,argv,++parameter);continue;}

	//Otherwise we read something we do not want. Call for error.
	printf("c ERROR. Parameter %s unrecognized.\n", argv[parameter]);
	main_returnCode = BADPARAM;
	break;
	}

	//CHECK RESULT
	//Check if we read all mandatory parameters.
	if (main_returnCode == UNKNOWN){
		if (param_formula == NULL){
			printf("c ERROR. The mandatory parameter -formula is missing. Call ./dimetheus -h for help.\n");
			main_returnCode = BADPARAM;
		}
	}
	//In case something went wrong, we output the parameter help.
	if (main_returnCode == BADPARAM) {
		printf("c Use ./dimetheus -h for help.\n");
		return;
	}

	#ifdef VERBOSE
	//PRINT PARAMETER SETTING.
	if (main_returnCode == UNKNOWN){
		printf("c   Parameter settings...\n");
		//Main algorithm related.
		printf("c     Main:\n");
		printf("c       -formula %s\n", argv[formulaParam+1]);
		printf("c       -seed %d\n", param_seed);
		printf("c       -printAssignment %d\n", param_printAssignment);
		printf("c       -guide %d\n", param_guide);
		//Classification related.
		printf("c     Classification:\n");
		printf("c       -classifyStrategy %d\n", param_classifyStrategy);
		//Classification related.
		printf("c     Adaptation:\n");
		printf("c       -adaptAssumeRandom %d\n", param_adaptAssumeRandom);
		printf("c       -adaptStrategy %d\n", param_adaptStrategy);
		printf("c       -adaptPrepStrategy %d\n", param_adaptPrepStrategy);
		printf("c       -adaptPrepStrategyParams %d\n", param_adaptPrepStrategyParams);
		printf("c       -adaptInpStrategy %d\n", param_adaptInpStrategy);
		printf("c       -adaptInpStrategyParams %d\n", param_adaptInpStrategyParams);
		printf("c       -adaptSearchStrategy %d\n", param_adaptSearchStrategy);
		printf("c       -adaptSearchStrategyParams %d\n", param_adaptSearchStrategyParams);
		printf("c       -adaptMpUR %d\n", param_adaptMpUR);
		printf("c       -adaptMpURParams %d\n", param_adaptMpURParams);
		printf("c       -adaptSlsPAFVR %d\n", param_adaptSlsPAFVR);
		printf("c       -adaptSlsPAFVRParams %d\n", param_adaptSlsPAFVRParams);
		printf("c       -adaptSlsAI %d\n", param_adaptSlsAI);
		printf("c       -adaptSlsAIParams %d\n", param_adaptSlsAIParams);
		printf("c       -adaptCdclSVR %d\n", param_adaptCdclSVR);
		printf("c       -adaptCdclSVRParams %d\n", param_adaptCdclSVRParams);
		printf("c       -adaptCdclSVAI %d\n", param_adaptCdclSVAI);
		printf("c       -adaptCdclSVAIParams %d\n", param_adaptCdclSVAIParams);
		printf("c       -adaptCdclSDR %d\n", param_adaptCdclSDR);
		printf("c       -adaptCdclSDRParams %d\n", param_adaptCdclSDRParams);
		printf("c       -adaptCdclSDDI %d\n", param_adaptCdclSDDI);
		printf("c       -adaptCdclSDDIParams %d\n", param_adaptCdclSDDIParams);
		printf("c       -adaptCdclCAR %d\n", param_adaptCdclCAR);
		printf("c       -adaptCdclCARParams %d\n", param_adaptCdclCARParams);
		printf("c       -adaptCdclSLR %d\n", param_adaptCdclSLR);
		printf("c       -adaptCdclSLRParams %d\n", param_adaptCdclSLRParams);
		printf("c       -adaptCdclSOR %d\n", param_adaptCdclSOR);
		printf("c       -adaptCdclSORParams %d\n", param_adaptCdclSORParams);
		printf("c       -adaptCdclCBJLR %d\n", param_adaptCdclCBJLR);
		printf("c       -adaptCdclCBJLRParams %d\n", param_adaptCdclCBJLRParams);
		printf("c       -adaptCdclRR %d\n", param_adaptCdclRR);
		printf("c       -adaptCdclRRParams %d\n", param_adaptCdclRRParams);
		printf("c       -adaptCdclMR %d\n", param_adaptCdclMR);
		printf("c       -adaptCdclMRParams %d\n", param_adaptCdclMRParams);
		printf("c       -adaptCdclIR %d\n", param_adaptCdclIR);
		printf("c       -adaptCdclIRParams %d\n", param_adaptCdclIRParams);
		printf("c       -adaptCdclAR %d\n", param_adaptCdclAR);
		printf("c       -adaptCdclARParams %d\n", param_adaptCdclARParams);
		//Preprocessor related.
		printf("c     Preprocessor:\n");
		if (param_prepOutput == NULL) {
			printf("c       -prepOutput (none)\n");
		} else {
			printf("c       -prepOutput %s\n", argv[prepOutputParam+1]);
		}
		printf("c       -prepReviveCls %d\n", param_prepReviveCls);
		printf("c       -prepACCEMax %d\n", param_prepACCEMax);
		printf("c       -prepACCEMinClsSize %d\n", param_prepACCEMinClsSize);
		printf("c       -prepACCESaturate %d\n", param_prepACCESaturate);
		printf("c       -prepNIVERMax %d\n", param_prepNIVERMax);
		printf("c       -prepATEMin %d\n", param_prepATEMin);
		printf("c       -prepGEMaxAONN %d\n", param_prepGEMaxAONN);
		printf("c       -prepGEMaxXOR %d\n", param_prepGEMaxXOR);
		printf("c       -prepTERNARYLitMax %d\n", param_prepTERNARYLitMax);
		printf("c       -prepTERNARYMax %d\n", param_prepTERNARYMax);
		printf("c       -prepNHBRMin %d\n", param_prepNHBRMin);
		printf("c       -prepStrategy %d\n", param_prepStrategy);
		//In-processor related.
		printf("c     In-processor:\n");
		printf("c       -inpStrMaxSize %d\n", param_inpStrMaxSize);
		printf("c       -inpTernaryLitMax %d\n", param_inpTernaryLitMax);
		printf("c       -inpTernaryMax %d\n", param_inpTernaryMax);
		printf("c       -inpNiverMax %d\n", param_inpNiverMax);
		printf("c       -inpGEMaxAONN %d\n", param_inpGEMaxAONN);
		printf("c       -inpGEMaxXOR %d\n", param_inpGEMaxXOR);
		printf("c       -inpNHBRMin %d\n", param_inpNHBRMin);
		printf("c       -inpStrategy %d\n", param_inpStrategy);
		//Search related.
		printf("c     Search:\n");
		printf("c       -searchMIDBlockSize %f\n", param_searchMIDBlockSize);
		printf("c       -searchMinClsImpact %f\n", param_searchMinClsImpact);
		printf("c       -searchImpactMaxFactor %f\n", param_searchImpactMaxFactor);
		printf("c       -searchStrategy %d\n", param_searchStrategy);
		//MP
		printf("c     MP:\n");
		printf("c       -mpMaxNumIterations %d\n", param_mpMaxNumIterations);
		printf("c       -mpMaxConvergenceDiff %f\n",param_mpMaxConvergenceDiff);
		printf("c       -mpMaxMagnetization %f\n", param_mpMaxMagnetization);
		printf("c       -mpEpsilon %.12f\n", param_mpEpsilon);
		printf("c       -mpRho %f\n", param_mpRho);
		printf("c       -mpSigma %f\n", param_mpSigma);
		printf("c       -mpUpdateRule %d\n", param_mpUpdateRule);
		//SLS
		printf("c     SLS:\n");
		printf("c       -slsMaxFlipsFactor %f\n", param_slsMaxFlipsFactor);
		printf("c       -slsMaxTries %d\n", param_slsMaxTries);
		printf("c       -slsNoise %f\n", param_slsNoise);
		printf("c       -slsProbsatCB %f\n", param_slsProbsatCB);
		printf("c       -slsProbsatCBShift %f\n", param_slsProbsatCBShift);
		printf("c       -slsPickAndFlipVarRule %d\n", param_slsPickAndFlipVarRule);
		printf("c       -slsAssInitRule %d\n", param_slsAssInitRule);
		//CDCL
		printf("c     CDCL:\n");
		if (param_cdclOutput == NULL) {
			printf("c       -cdclOutput (none)\n");
		} else {
			printf("c       -cdclOutput %s\n", argv[cdclOutputParam+1]);
		}
		printf("c       -cdclRestartStagMaxFrac %f\n", param_cdclRestartStagMaxFrac);
		printf("c       -cdclRestartInnerouterInit %d\n", param_cdclRestartInnerouterInit);
		printf("c       -cdclRestartInnerouterInc %f\n", param_cdclRestartInnerouterInc);
		printf("c       -cdclRestartLubyUnit %d\n", param_cdclRestartLubyUnit);
		printf("c       -cdclRestartVarAgiIncBump %f\n", param_cdclRestartVarAgiIncBump);
		printf("c       -cdclRestartMaxAgiFrac %f\n", param_cdclRestartMaxAgiFrac);
		printf("c       -cdclRestartMaxAgiOutFrac %f\n", param_cdclRestartMaxAgiOutFrac);
		printf("c       -cdclSelectVarActIncBump %f\n", param_cdclSelectVarActIncBump);
		printf("c       -cdclSelectVarActInit %d\n", param_cdclSelectVarActInit);
		printf("c       -cdclSelectVarRandProb %f\n", param_cdclSelectVarRandProb);
		printf("c       -cdclSelectDirDirInit %d\n", param_cdclSelectDirDirInit);
		printf("c       -cdclSelectDirMinFlipDist %d\n", param_cdclSelectDirMinFlipDist);
		printf("c       -cdclMaintenanceMinDev %f\n", param_cdclMaintenanceMinDev);
		printf("c       -cdclMaintenanceMaxAvg %f\n", param_cdclMaintenanceMaxAvg);
		printf("c       -cdclMaintenanceActIncBump %f\n", param_cdclMaintenanceActIncBump);
		printf("c       -cdclMaintenanceInitial %f\n", param_cdclMaintenanceInitial);
		printf("c       -cdclMaintenanceIncrease %f\n", param_cdclMaintenanceIncrease);
		printf("c       -cdclMaintenanceBase %d\n", param_cdclMaintenanceBase);
		printf("c       -cdclMaintenanceBoost %d\n", param_cdclMaintenanceBoost);
		printf("c       -cdclIRTERNARYLitMax %d\n", param_cdclIRTERNARYLitMax);
		printf("c       -cdclIRTERNARYMax %d\n", param_cdclIRTERNARYMax);
		printf("c       -cdclIRNIVERMax %d\n", param_cdclIRNIVERMax);
		printf("c       -cdclIRGEMaxAONN %d\n", param_cdclIRGEMaxAONN);
		printf("c       -cdclIRGEMaxXOR %d\n", param_cdclIRGEMaxXOR);
		printf("c       -cdclIRStrMaxSize %d\n", param_cdclIRStrMaxSize);
		printf("c       -cdclIRNHBRMin %d\n", param_cdclIRNHBRMin);
		printf("c       -cdclIRMinConfDistance %f\n", param_cdclIRMinConfDistance);
		printf("c       -cdclSelectVarRule %d\n", param_cdclSelectVarRule);
		printf("c       -cdclSelectDirRule %d\n", param_cdclSelectDirRule);
		printf("c       -cdclConflictAnalysisRule %d\n", param_cdclConflictAnalysisRule);
		printf("c       -cdclStrLearnedRule %d\n", param_cdclStrLearnedRule);
		printf("c       -cdclStrOtherRule %d\n", param_cdclStrOtherRule);
		printf("c       -cdclComputeBJLRule %d\n", param_cdclComputeBJLRule);
		printf("c       -cdclRestartRule %d\n", param_cdclRestartRule);
		printf("c       -cdclMaintenanceRule %d\n", param_cdclMaintenanceRule);
		printf("c       -cdclInprocessingRule %d\n", param_cdclInprocessingRule);
		printf("c       -cdclAbortRule %d\n", param_cdclAbortRule);
	}
	printf("c\n");
	#endif
}
