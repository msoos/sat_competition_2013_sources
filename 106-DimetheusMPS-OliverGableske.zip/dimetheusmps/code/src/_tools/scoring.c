/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#include "scoring.h"

#ifdef SCORING
void scoring_reset(){
	//Reset everything back.
	scoring_mp_score = 1.0;
	scoring_cdcl_score = 1.0;
	scoring_sls_score = 1.0;
}

void scoring_init(){
	//Initialize, once the formula specifics are known.
}

void scoring_dispose(){
	//Dispose everything.
}

void scoring_print(){
	float_ty totalScore = 1.0;
	float_ty numScores = 1.0;

	totalScore = totalScore / numScores;

	//Print the final scores.
	printf("c SCORES:\n");
	printf("c   MP score: %.8f\n", scoring_mp_score);
	printf("c   TOTAL SCORE: %.8f\n", totalScore);
	printf("c\n");
}
#endif
