/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#ifndef SLSVARIABLES_H_
#define SLSVARIABLES_H_


#define SET_SLS_VAR_ASSIGNMENT_TRUE( __var ) ( \
	sls_assignments[(( __var) >> 6ULL)] |= (1ULL << (__var & 63ULL)) \
)

#define SET_SLS_VAR_ASSIGNMENT_FALSE( __var ) ( \
	sls_assignments[(( __var) >> 6ULL)] &= ~(1ULL << (__var & 63ULL)) \
)

#define SET_SLS_VAR_ASSIGNMENT_FLIP( __var ) (\
		sls_assignments[(( __var) >> 6ULL)] ^= (1ULL << (__var & 63ULL))\
)

#define SET_SLS_LIT_ASSIGNMENT_FLIP( __theLit ) (\
		__theLit < 0 ? \
		(sls_assignments[((-__theLit) >> 6ULL)] ^= (1ULL << ((-__theLit) & 63ULL))) : \
		(sls_assignments[(( __theLit) >> 6ULL)] ^= (1ULL << (( __theLit) & 63ULL))) \
)

#define GET_SLS_LIT_ASSIGNMENT( __theLit ) ( \
	__theLit < 0 ? \
	(((sls_assignments[((-__theLit) >> 6ULL)]) >> ((-__theLit) & 63ULL) ) & 1ULL) : \
	(((sls_assignments[(( __theLit) >> 6ULL)]) >> (( __theLit) & 63ULL) ) & 1ULL) \
)

#define GET_SLS_VAR_ASSIGNMENT( __var ) ( \
	(((sls_assignments[(( __var) >> 6ULL)]) >> (( __var) & 63ULL) ) & 1ULL) \
)

#define IS_SLS_LIT_SAT( __theLit ) (\
		__theLit < 0 ? \
		(!((sls_assignments[((-__theLit) >> 6ULL)] >> ((-__theLit) & 63ULL)) & 1ULL)) : \
		( ((sls_assignments[(( __theLit) >> 6ULL)] >> (( __theLit) & 63ULL)) & 1ULL)) \
)

void sls_variables_prepareCall();
void sls_variables_prepareTry();

void sls_variables_reset();
void sls_variables_init();
void sls_variables_dispose();

#ifdef VERBOSE_SLS
void sls_variables_printAssignment();
#endif
#endif /* SLSVARIABLES_H_ */
