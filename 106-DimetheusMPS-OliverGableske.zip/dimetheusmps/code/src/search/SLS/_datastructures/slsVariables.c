/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#include "../sls.h"

void sls_variables_prepareCall(){

}

void sls_variables_prepareTry(){
	sls_assInitRule_ai();
}

void sls_variables_reset(){
	sls_assignments = NULL;
}

void sls_variables_init(){
	uint32_t i;
	sls_assignments = malloc(sizeof(uint64_t)*( (f.n_initial / 64U) +1U ));
	if (sls_assignments == NULL){
		printf("c ERROR. SLS was unable to allocate memory for the variables. Out of memory?\n");
		sls_returnCode = SLS_ERROR;
		#ifdef COLLECTSTATS
		++stats_sls_return_ERROR;
		#endif
		return;
	}
	//We reset the assignment to 64 variables in one go.
	for (i = 0; i <= f.n_initial / 64U; ++i){
		sls_assignments[i] = 0ULL;
	}
}

void sls_variables_dispose(){
	if (sls_assignments != NULL){
		free(sls_assignments);
	}
}

#ifdef VERBOSE_SLS
void sls_variables_printAssignment(){
	uint32_t i;
	printf("c ASSIGNMENTS (SLS)[ ");
	for (i = 0; i <= f.n_initial / 64U; ++i){
		PRINT_BITS_UINT64(sls_assignments[i]);printf(" ");
	}
	printf(" ]\n");
}
#endif
