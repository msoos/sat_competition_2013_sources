/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#ifndef SLSLITERALS_H_
#define SLSLITERALS_H_

#include "../sls.h"

typedef struct {
	slsClause **occs;		//The occurrences of this literal. Terminated with NULL.
	uint32_t numOccsUsed;	//The number of occurrences used in this clause.
	uint32_t numOccsAvail;	//The number of occurrences available in this clause.
	uint32_t brake;			//The brake score of a literal.
} slsLiteral;

#define SET_SLS_LIT_OCCS( __l, __o )			( sls_literals[__l].occs = __o )
#define SET_SLS_LIT_NUMOCCS_USED( __l, __v )	( sls_literals[__l].numOccsUsed = __v )
#define SET_SLS_LIT_NUMOCCS_AVAIL( __l, __a )	( sls_literals[__l].numOccsAvail = __a )
#define SET_SLS_LIT_BRAKE( __l, __b )			( sls_literals[__l].brake = __b )

#define SET_SLS_LIT_BRAKE_INC( __l )			( ++sls_literals[__l].brake )
#define SET_SLS_LIT_BRAKE_DEC( __l )			( --sls_literals[__l].brake )

#define GET_SLS_LIT_OCCS( __l )					( sls_literals[__l].occs )
#define GET_SLS_LIT_NUMOCCS_USED( __l )			( sls_literals[__l].numOccsUsed )
#define GET_SLS_LIT_NUMOCCS_AVAIL( __l )		( sls_literals[__l].numOccsAvail )
#define GET_SLS_LIT_BRAKE( __l )				( sls_literals[__l].brake )

#define ADD_SLS_LIT_OCC( __l, __c )	{ \
	if (sls_literals[__l].numOccsUsed == sls_literals[__l].numOccsAvail-1U) { \
		sls_literals[__l].numOccsAvail += BLOCKSIZE; \
		sls_literals[__l].occs = realloc(sls_literals[__l].occs, sizeof(slsClause*)*sls_literals[__l].numOccsAvail); \
	} \
	sls_literals[ __l ].occs[ sls_literals[__l].numOccsUsed++ ] = __c; \
	sls_literals[ __l ].occs[ sls_literals[__l].numOccsUsed ] = NULL; \
	if (sls_literals[__l].numOccsUsed > sls_litMaxOcc) sls_litMaxOcc = sls_literals[__l].numOccsUsed; \
}

void sls_literals_prepareCall();

void sls_literals_prepareTry();

void sls_literals_reset();
void sls_literals_init();
void sls_literals_dispose();

#endif /* SLSLITERALS_H_ */
