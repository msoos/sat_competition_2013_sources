/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#ifndef ASSINITRULES_H_
#define ASSINITRULES_H_

#include "../sls.h"

#define SLS_ASSINITRULE_MINVALUE 0
#define SLS_ASSINITRULE_MAXVALUE 1

#define SLS_ASSINITRULE_RANDOM 0	//Initialize starting assignment randomly.
#include "ai_random.h"

#define SLS_ASSINITRULE_PROVIDED 1	//Use the provided phases for initializing the SLS starting assignment.
#include "ai_provided.h"

static inline void sls_assInitRules_printHelp(){
	sls_assInitRule_random_printHelp();
	sls_assInitRule_provided_printHelp();
}

//Extern interface methods -- can be called by the one who initializes the component.
void (*sls_assInitRule_prepare)();	//This points to one of the initialization rules call preparation methods available.
void (*sls_assInitRule_ai)();		//This points to one of the initialization rules that are available.

void sls_extern_assInitRules_switch(int32_t);//Use to switch the initialization rule without re-initializing the SLS module.

//Interface Methods for initializing the component -- called by the one who wants to use the above methods.
void sls_assInitRules_resetPlugin();
void sls_assInitRules_initPlugin();
void sls_assInitRules_disposePlugin();

#endif /* ASSINITRULES_H_ */
