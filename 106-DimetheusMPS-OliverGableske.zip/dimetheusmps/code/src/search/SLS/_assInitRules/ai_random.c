/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#include "assInitRules.h"

void sls_assInitRule_random_printHelp(){
	printf("c      %-3d: RANDOM:\n", SLS_ASSINITRULE_RANDOM);
    printf("c           Behavior: Initialize the SLS starting assignment randomly.\n");
}

void sls_assInitRule_random_prepare(){
	#ifdef VERBOSE_SLS
	printf("c     SLS:     AI-Plug-in [%-3d: RANDOM]:\n", SLS_ASSINITRULE_RANDOM);
	#endif
}

void sls_assInitRule_random_ai(){
	//Initialize the variable assignments randomly.
	int32_t i;
	for (i = 0; i < f.n_vars_e_used; ++i){
		//We ignore all variables already assigned. They do not make it into the clauses anyway.
		if (!IS_VAR_UNASSIGNED(f.vars_e[i])) continue;
		if ((rand_random() & 1U) == 1U){
			SET_SLS_VAR_ASSIGNMENT_FALSE(f.vars_e[i]->id);
		} else {
			SET_SLS_VAR_ASSIGNMENT_TRUE(f.vars_e[i]->id);
		}
	}
}

