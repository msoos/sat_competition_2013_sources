/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#include "sls.h"

void sls_intern_prepareTry(){
	//Used to create a new random assignment.
	//Randomly assign the SLS assignment of the variables.
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	#endif
	#ifdef VERBOSE_SLS
	printf("c     SLS:     Preparing variables...\n");
	#endif
	sls_variables_prepareTry();
	#ifdef VERBOSE_SLS
	printf("c     SLS:     Preparing clauses...\n");
	#endif
	sls_clauses_prepareTry();
	#ifdef VERBOSE_SLS
	printf("c     SLS:     Preparing literals...\n");
	#endif
	sls_literals_prepareTry();
	#ifdef VERBOSE_SLS
	printf("c     SLS:   Preparing random number generator...\n");
	#endif
	rand_init();
	#ifdef VERBOSE_SLS
	printf("c     SLS:       ");rand_printConfig_inline();printf("\n");
	#endif

	#ifdef COLLECTSTATS
	stats_sls_time_initTry += (STATS_GET_CURRENT_TIME_IN_SEC() - time_start);
	#endif
}

void sls_extern_printVersion(){
	printf("[Search          ] [Local Search                   ] :: %3d.%-4d :: %s",
			SLS_VERSION_MA, SLS_VERSION_MI, SLS_VERSION_NAME);
}

void sls_extern_localSearch(uint32_t prepareAnew){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_sls_component_totalCalls;
	#endif
	uint64_t numTries = 0;
	sls_returnCode = SLS_UNKNOWN;

	if (prepareAnew){
		#ifdef VERBOSE_SLS
		printf("c     SLS: Preparing call...\n");
		printf("c     SLS:   Data-structures...\n");
		#endif
		//Prepare the snapshot view of the formula for the SLS module.
		sls_variables_prepareCall();
		sls_literals_prepareCall();
		sls_clauses_prepareCall();
		#ifdef VERBOSE_SLS
		printf("c     SLS:     Variables: %u, Clauses %u\n", sls_varNum, sls_clsUsed);
		printf("c     SLS:   Plug-ins...\n");
		#endif
		//Prepare the call to all plug-ins.
		sls_pickAndFlipVarRule_prepare();
		sls_assInitRule_prepare();

		//Prepare local parameters.
		sls_maxNumFlips = param_slsMaxFlipsFactor*f.n_initial;
		sls_maxNumTries = param_slsMaxTries;
		sls_numFlips = 0;
		#ifdef VERBOSE_SLS
		printf("c     SLS:   Local search configuration:\n");
		printf("c     SLS:     sls_maxNumFlips %u", (uint32_t)sls_maxNumFlips);
		if (sls_maxNumFlips == 0U){
			printf(" (unlimited)\n");
		} else {
			printf("\n");
		}
		printf("c     SLS:     sls_maxNumTries %u", (uint32_t)sls_maxNumTries);
		if (sls_maxNumTries == 0U){
			printf(" (unlimited)\n");
		} else {
			printf("\n");
		}
		#endif
	}

	#ifdef COLLECTSTATS
	stats_sls_time_init += (STATS_GET_CURRENT_TIME_IN_SEC() - time_start);
	#endif

	#ifdef VERBOSE_SLS
	printf("c     SLS: Performing search...\n");fflush(stdout);
	#endif
	do {
		//In each try, we call for the WalkSAT internal heuristic to perform a try.
		#ifdef VERBOSE_SLS
		printf("c     SLS:   Try %u...\n", (uint32_t)numTries);
		#endif
		sls_intern_prepareTry();
		#ifdef VERBOSE_SLS
		printf("c     SLS:     Flipping...\n");fflush(stdout);
		#endif
		#ifdef COLLECTSTATS
		float_ty time_start_flips = STATS_GET_CURRENT_TIME_IN_SEC();
		#endif
		sls_pickAndFlipVarRule_paf();
		#ifdef COLLECTSTATS
		stats_sls_time_flips += STATS_GET_CURRENT_TIME_IN_SEC() - time_start_flips;
		#endif
		if (sls_returnCode == SLS_SAT){
			//We found a solution. Time to stop.
			#ifdef VERBOSE_SLS
			printf("c     SLS:     The try succeeded.\n");
			#endif
			++numTries;	break;
		} else if (sls_returnCode == SLS_UNKNOWN){
			//We assume the failure of the try and get on with the next.
			#ifdef VERBOSE_SLS
			printf("c     SLS:     TRY FAILED.\n");
			#endif
			++numTries;
		} else {
			//We assume an error because the only return codes allowed are the above two.
			#ifdef VERBOSE_SLS
			printf("c     SLS:     An unexpected return code was encountered. We assume an error.\n");
			#endif
			++numTries;	break;
		}
	} while (numTries != sls_maxNumTries);

	#ifdef VERBOSE_SLS
	printf("c     SLS: Done flipping, %u flips in %u tries performed.\n", (uint32_t) sls_numFlips, (uint32_t) numTries);
	#endif

	#ifdef COLLECTSTATS
	if (sls_returnCode == SLS_SAT){
		++stats_sls_return_SAT;
	} else if (sls_returnCode == SLS_UNKNOWN){
		++stats_sls_return_UNKNOWN;
	} else {
		++stats_sls_return_ERROR;
	}
	stats_sls_ls_totalTries += numTries;
	stats_sls_time_total += (STATS_GET_CURRENT_TIME_IN_SEC() - time_start);
	#endif
}

void sls_resetModule(){
	#ifdef VERBOSE_SLS
	printf("c     SLS: Component reset... \n");
	#endif
	sls_returnCode 			= SLS_UNKNOWN;
	sls_numFlips			= 0;

	sls_clauses_reset();
	sls_literals_reset();
	sls_variables_reset();

	sls_pickAndFlipVarRules_resetPlugin();
	sls_assInitRules_resetPlugin();
}

void sls_initModule(){
	#ifdef VERBOSE_SLS
	printf("c     SLS: Component initialize... \n");
	#endif
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	#endif
	sls_returnCode 	= SLS_UNKNOWN;
	sls_numFlips 	= 0;

	sls_clauses_init();	if (sls_returnCode != SLS_UNKNOWN) return;
	sls_literals_init(); if (sls_returnCode != SLS_UNKNOWN) return;
	sls_variables_init(); if (sls_returnCode != SLS_UNKNOWN) return;

	sls_pickAndFlipVarRules_initPlugin(); if (sls_returnCode != SLS_UNKNOWN) return;
	sls_assInitRules_initPlugin(); if (sls_returnCode != SLS_UNKNOWN) return;

	#ifdef COLLECTSTATS
	stats_sls_time_init += (STATS_GET_CURRENT_TIME_IN_SEC() - time_start);
	stats_sls_time_total += (STATS_GET_CURRENT_TIME_IN_SEC() - time_start);
	#endif
}

void sls_disposeModule(){
	#ifdef VERBOSE_SLS
	printf("c     SLS: Component dispose... \n");
	#endif

	sls_clauses_dispose();
	sls_literals_dispose();
	sls_variables_dispose();

	sls_pickAndFlipVarRules_disposePlugin();
	sls_assInitRules_disposePlugin();
}
