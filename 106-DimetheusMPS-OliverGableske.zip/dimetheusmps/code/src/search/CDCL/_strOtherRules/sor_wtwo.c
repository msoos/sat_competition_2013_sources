/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#include "strOtherRules.h"

void cdcl_strOtherRule_wtwo_printHelp(){
	printf("c      %-3d: WTWO:\n", CDCL_STROTHERRULE_WTWO);
    printf("c           Behavior: Strengthens clauses using the WL2 literal for resolution.\n");
}

void cdcl_strOtherRule_wtwo_prepare(){
	#ifdef VERBOSE_CDCL
	printf("c     CDCL:     SOR-Plug-in [%-3d: WTWO]:\n", CDCL_STROTHERRULE_WTWO);
	#endif
}

uint32_t cdcl_strOtherRule_wtwo_str(){
	//We use the last learned clause and try to strengthen other clauses with it using watcher two for resolution.
	cdclClause *c = cdcl_cls_l[cdcl_cls_l_used - 1], *d;
	uint64_t sig, newSig;
	int32_t resLit, found, aLit, bLit, i;
	uint32_t numC, numD, resLitPos = 0, resPosD, restart = 1;


	//We strengthen with short clauses only.
	if (GET_CDCL_CLS_SIZE(c) < 2 || GET_CDCL_CLS_SIZE(c) > 3) return cdcl_targetBJLevel;

	while (restart){
		restart = 0;
		sig = 0ULL;

		resLit = GET_CDCL_CLS_W2(c);

		//First we create a signature of c that does not contain the signature bit for the literal we resolve on.
		if (GET_CDCL_CLS_SIZE(c) == 2){
			//Clause c is binary.
			if (GET_CDCL_CLS_LITNUM(c, 0) != resLit) {
				sig |= GET_CDCL_LIT_SIG(GET_CDCL_CLS_LITNUM(c, 0));
			} else {
				resLitPos = 0;
			}
			if (GET_CDCL_CLS_LITNUM(c, 1) != resLit) {
				sig |= GET_CDCL_LIT_SIG(GET_CDCL_CLS_LITNUM(c, 1));
			} else {
				resLitPos = 1;
			}
		} else {
			//Clause c is ternary.
			if (GET_CDCL_CLS_LITNUM(c, 0) != resLit) {
				sig |= GET_CDCL_LIT_SIG(GET_CDCL_CLS_LITNUM(c, 0));
			} else {
				resLitPos = 0;
			}
			if (GET_CDCL_CLS_LITNUM(c, 1) != resLit) {
				sig |= GET_CDCL_LIT_SIG(GET_CDCL_CLS_LITNUM(c, 1));
			} else {
				resLitPos = 1;
			}
			if (GET_CDCL_CLS_LITNUM(c, 2) != resLit) {
				sig |= GET_CDCL_LIT_SIG(GET_CDCL_CLS_LITNUM(c, 2));
			} else {
				resLitPos = 2;
			}
		}
		//Now the signature without the resolution literal has been created.

		//Walk through the occurrence list of the second watcher literal with opposite sign and check if any clause in here can
		//be strengthened by the learned clause.
		for (i = 0; i < GET_CDCL_LIT_NUMOCCS_USED(-resLit); ++i){
			d = GET_CDCL_LIT_OCCNUM(-resLit, i);
			//Fast check if strengthening is possible. We rule out d if it is too large.
			if (GET_CDCL_CLS_SIZE(d) > 3
					|| GET_CDCL_CLS_SIZE(c) > GET_CDCL_CLS_SIZE(d)
					|| (sig & ~GET_CDCL_CLS_SIG(d)) !=0ULL ) continue;

			//Retain the information at what position the resolving literal is in clause d.
			resPosD = GET_CDCL_LIT_OCCLITPOSNUM(-resLit, i);

			//The simple checks did not rule out clause d. We must check if all the literals from c if they are found in d.
			found = 0;
			for (numC = 0; numC < GET_CDCL_CLS_SIZE(c); ++numC){
				if (GET_CDCL_CLS_LITNUM(c,numC) == resLit) {
					continue;//We ignore the literal we resolve on.
				}
				found = 0;
				for (numD = 0; numD < GET_CDCL_CLS_SIZE(d); ++numD){
					if (GET_CDCL_CLS_LITNUM(c,numC) == -GET_CDCL_CLS_LITNUM(d,numD)){
						found = 0;//This resolution would end in a tautology.
						break;
					} else if (GET_CDCL_CLS_LITNUM(c,numC) == GET_CDCL_CLS_LITNUM(d,numD)){
						found = 1;//The literal from c, which is not resLit, has been found in d.
						break;
					}
				}
				if (!found){
					break;
				}
			}
			if (!found) continue;

			//A strengthening operation is possible between c and d.
			if (GET_CDCL_CLS_SIZE(c) == 3 && GET_CDCL_CLS_SIZE(d) == 3){
				//This operation will drop literal resLit from clause c (the newly learned clause) which is then binary. Since
				//the clause has not yet been added to any lists, we must not remove it from any lists.
				//We remove the literal at position resLitPos in c, because this is the literal that can be strengthened away.
				//We also update the clauses signature and size.
				#ifdef COLLECTSTATS
				if (GET_CDCL_CLS_SIZE(c) > STATS_CDCL_LEARNEDLENGTH_MAX){
					--stats_cdcl_learnedLength[STATS_CDCL_LEARNEDLENGTH_MAX+1];
				} else {
					--stats_cdcl_learnedLength[GET_CDCL_CLS_SIZE(c)];
				}
				#endif
				SET_CDCL_CLS_SIG(c, sig);
				SET_CDCL_CLS_SIZE_DEC(c);
				SET_CDCL_CLS_LITNUM(c, resLitPos, GET_CDCL_CLS_LITNUM(c, GET_CDCL_CLS_SIZE(c)));

				aLit = GET_CDCL_CLS_LITNUM(c, 0);
				bLit = GET_CDCL_CLS_LITNUM(c, 1);

				//We must now figure out what the new target level is that we must back-jump to. WL1 must be the literal that
				//has the higher decision level.
				if (GET_CDCL_VAR_DECLEVEL(abs(aLit)) < GET_CDCL_VAR_DECLEVEL(abs(bLit))){
					SET_CDCL_CLS_W1(c, bLit);
					SET_CDCL_CLS_REPLIT(c, bLit);
					SET_CDCL_CLS_W2(c, aLit);
					cdcl_targetBJLevel = GET_CDCL_VAR_DECLEVEL(abs(aLit));
				} else if (GET_CDCL_VAR_DECLEVEL(abs(aLit)) > GET_CDCL_VAR_DECLEVEL(abs(bLit))){
					SET_CDCL_CLS_W1(c, aLit);
					SET_CDCL_CLS_REPLIT(c, aLit);
					SET_CDCL_CLS_W2(c, bLit);
					cdcl_targetBJLevel = GET_CDCL_VAR_DECLEVEL(abs(bLit));
				}
				//We have successfully made the learned clause a binary clause. We try again with the binary.
				restart = 1;
				#ifdef COLLECTSTATS
				if (GET_CDCL_CLS_SIZE(c) > STATS_CDCL_LEARNEDLENGTH_MAX){
					++stats_cdcl_learnedLength[STATS_CDCL_LEARNEDLENGTH_MAX+1];
				} else {
					++stats_cdcl_learnedLength[GET_CDCL_CLS_SIZE(c)];
				}
				#endif
				break;
			} else if (GET_CDCL_CLS_SIZE(c) == 2 && GET_CDCL_CLS_SIZE(d) == 3){
				//This operation will drop literal -resLit from d, which then becomes a binary clause. Since clause d is already
				//part of the formula, we must remove it from the watcher and occurrence lists and add its implications.
				newSig = 0ULL;

				//First, we remove clause d from the watcher lists.
				aLit = GET_CDCL_CLS_W1(d);
				numD = GET_CDCL_CLS_WHEREW1(d);
				REM_CDCL_CLS_FROM_LIT_W1LIST(aLit, numD);
				aLit = GET_CDCL_CLS_W2(d);
				numD = GET_CDCL_CLS_WHEREW2(d);
				REM_CDCL_CLS_FROM_LIT_W2LIST(aLit, numD);

				//Second, we remove clause d from the occurrence lists.
				aLit = GET_CDCL_CLS_LITNUM(d, 0);
				numD = GET_CDCL_CLS_OCCPOSNUM(d, 0);
				if (aLit != -resLit) {
					newSig |= GET_CDCL_LIT_SIG(aLit);
				}
				REM_CDCL_LIT_OCC(aLit, numD);

				aLit = GET_CDCL_CLS_LITNUM(d, 1);
				numD = GET_CDCL_CLS_OCCPOSNUM(d, 1);
				if (aLit != -resLit){
					newSig |= GET_CDCL_LIT_SIG(aLit);
				}
				REM_CDCL_LIT_OCC(aLit, numD);

				aLit = GET_CDCL_CLS_LITNUM(d, 2);
				numD = GET_CDCL_CLS_OCCPOSNUM(d, 2);
				if (aLit != -resLit){
					newSig |= GET_CDCL_LIT_SIG(aLit);
				}
				REM_CDCL_LIT_OCC(aLit, numD);

				//We now decrease the size of clause d and override the position i with the last literal in the clause.
				SET_CDCL_CLS_SIZE_DEC(d);
				SET_CDCL_CLS_SIG(d, newSig);
				SET_CDCL_CLS_LITNUM(d, resPosD, GET_CDCL_CLS_LITNUM(d, GET_CDCL_CLS_SIZE(d)));

				//Afterwards, we must add the clause back to the formula -- since it is binary now, we add it to the implications
				//and to the occurrence lists of both of its literals.
				aLit = GET_CDCL_CLS_LITNUM(d,0);
				bLit = GET_CDCL_CLS_LITNUM(d,1);
				ADD_CDCL_CLS_TO_LIT_OCCS(d, aLit, 0);
				ADD_CDCL_CLS_TO_LIT_OCCS(d, bLit, 1);
				ADD_CDCL_LIT_IMPLICATIONS(d, aLit, bLit);
				//We must now check if the clause becomes empty or unit in the target decision level. If the clause is satisfied
				//at the target BJ level, then nothing must be done.
				aLit = GET_CDCL_CLS_LITNUM(d, 0);
				bLit = GET_CDCL_CLS_LITNUM(d, 1);
				SET_CDCL_CLS_REPLIT(d, aLit);
				SET_CDCL_CLS_W1(d, aLit);
				SET_CDCL_CLS_W2(d, bLit);

			} else if (GET_CDCL_CLS_SIZE(c) == 2 && GET_CDCL_CLS_SIZE(d) == 2){
				//In this case, we can remove from clause c the resLit and c will become unit. This is the best case that can
				//happen, because we can now back-jump to DL0.
				#ifdef COLLECTSTATS
				if (GET_CDCL_CLS_SIZE(c) > STATS_CDCL_LEARNEDLENGTH_MAX){
					--stats_cdcl_learnedLength[STATS_CDCL_LEARNEDLENGTH_MAX+1];
				} else {
					--stats_cdcl_learnedLength[GET_CDCL_CLS_SIZE(c)];
				}
				#endif
				if (GET_CDCL_CLS_LITNUM(c, 0) == resLit){
					//The first literal in the clause must be removed. The second literal is the unit.
					SET_CDCL_CLS_LITNUM(c, 0, GET_CDCL_CLS_LITNUM(c, 1));
					SET_CDCL_CLS_SIZE_DEC(c);
					SET_CDCL_CLS_W1(c, GET_CDCL_CLS_LITNUM(c,0));
					SET_CDCL_CLS_W2(c, 0);
					SET_CDCL_CLS_SIG(c, 0ULL);
				} else {
					//The second literal in the clause must be removed. The first literal is the unit.
					SET_CDCL_CLS_SIZE_DEC(c);
					SET_CDCL_CLS_W1(c, GET_CDCL_CLS_LITNUM(c,0));
					SET_CDCL_CLS_W2(c, 0);
					SET_CDCL_CLS_SIG(c, 0ULL);
				}
				//We can stop as we detected a failed literal in this "unit" clause now.
				#ifdef COLLECTSTATS
				if (GET_CDCL_CLS_SIZE(c) > STATS_CDCL_LEARNEDLENGTH_MAX){
					++stats_cdcl_learnedLength[STATS_CDCL_LEARNEDLENGTH_MAX+1];
				} else {
					++stats_cdcl_learnedLength[GET_CDCL_CLS_SIZE(c)];
				}
				#endif
				cdcl_targetBJLevel = 0;
				break;
			}
		}
	}
	return cdcl_targetBJLevel;
}



