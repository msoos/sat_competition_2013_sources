/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#include "../dimetheus.h"

void formula_reset(){
	main_litStamp = 1;
	f.att = NULL;
	f.vars = NULL;
	f.vars_e = NULL;
	f.vars_d = NULL;

	f.lits = NULL;

	f.clauses_eo = NULL;
	f.clauses_do = NULL;
	f.clauses_el = NULL;
	f.clauses_dl = NULL;
	f.clauses_rem = NULL;

	f.n_initial = 0;
	f.n_afterPrep = 0;
	f.n_vars_e_used = 0;
	f.n_vars_d_used = 0;

	f.m_initial = 0;

	f.m_eo_used = 0;
	f.m_eo_avail = 0;

	f.m_do_used = 0;
	f.m_do_avail = 0;

	f.m_el_used = 0;
	f.m_el_avail = 0;

	f.m_dl_used = 0;
	f.m_dl_avail = 0;

	f.m_rem_used = 0;
	f.m_rem_avail = 0;
}

void formula_loadHeader(){
	int32_t chr, chr2, pRead = 0;
	char txt[255];
	chr = '#';
	while (chr != 'p' && chr != EOF) {
		while ((chr = fgetc(param_formula)) == 'c') {
			while ((chr2 = fgetc(param_formula)) != EOF && chr2 != '\n');
		}
	}
	ungetc(chr, param_formula);

	if (fscanf(param_formula, "p %s %u %u", txt, &f.n_initial, &f.m_initial) != 3) {
		printf("c ERROR. Problem reading the p-line of the formula file.\n");
		main_returnCode = BADFORMULA;
		return;
	} else {
		pRead = 1;
		f.n_afterPrep = f.n_initial;
	}

	if (!pRead || strcmp("cnf", txt) != 0 ) {
		printf("c ERROR. Formula does not seem to be CNF. Is 'cnf' found in p-line?\n");
		printf("c ERROR. This solver can only read the DIMACS CNF INPUT FORMAT.\n");
		main_returnCode = BADFORMULA;
		return;
	}

	if (f.n_initial > VAR_OFFSET_MASK){
		printf("c ERROR. The p-line indicates a formula with more than %u variables.\n", VAR_OFFSET_MASK);
		printf("c ERROR. This solver can only solve formulas with less variables.\n");
		main_returnCode = BADFORMULA;
		return;
	}

	if (f.m_initial > CLS_OFFSET_MASK){
		printf("c ERROR. The p-line indicates a formula with more than %u clauses.\n", CLS_OFFSET_MASK);
		printf("c ERROR. This solver can only solve formulas with less clauses.\n");
		main_returnCode = BADFORMULA;
		return;
	}

	if (f.n_initial == 0 || f.m_initial == 0){
		printf("c Formula either has no variables or no clauses. Anyway, it is satisfiable by definition.\n");
		main_returnCode = SAT;
		return;
	}


	#ifdef VERBOSE
	printf("c   Formula header says: %u variables and %u clauses.\n", f.n_initial, f.m_initial);
	#endif
}

void formula_printAtt(){
	printf("%d ", f.att->isSet);
	printf("%d ", f.att->n);
	printf("%d ", f.att->m);
	printf("%f ", f.att->r);
	printf("%d ", f.att->initAss);
	printf("%d ", f.att->minClsSize);
	printf("%d ", f.att->maxClsSize);
}

void formula_init(){
	int32_t i;
	#ifdef VERBOSE
	printf("c   Allocating memory for clauses...\n");
	#endif

	//Allocate memory for the formula attributes.
	f.att = malloc(sizeof(formulaAttributes)*1);
	f.att->isSet = 0;
	f.att->n = 0;
	f.att->m = 0;
	f.att->r = ZERO;
	f.att->initAss = 0;
	f.att->minClsSize = 0;
	f.att->maxClsSize = 0;

	//Enabled original clauses. We give one extra address such that the array is not automatically increased when the last
	//original clause gets added to the array (see the end of method addOriginalClause).
	f.clauses_eo = malloc(sizeof(clause*)*(f.m_initial+1));
	for (i=0; i < (f.m_initial+1); ++i){
		f.clauses_eo[i] = NULL;
	}
	f.m_eo_avail = f.m_initial+1;

	//Disabled original clauses. We add one extra address field here as well.
	f.clauses_do = malloc(sizeof(clause*)*(f.m_initial+1));
	for (i=0; i < (f.m_initial+1); ++i){
		f.clauses_do[i] = NULL;
	}
	f.m_do_avail = f.m_initial+1;

	//Enabled learned clauses.
	f.clauses_el = malloc(sizeof(clause*)*BLOCKSIZE);
	for (i=0; i < BLOCKSIZE; ++i){
		f.clauses_el[i] = NULL;
	}
	f.m_el_avail = BLOCKSIZE;

	//Disabled learned clauses.
	f.clauses_dl = malloc(sizeof(clause*)*BLOCKSIZE);
	for (i=0; i < BLOCKSIZE; ++i){
		f.clauses_dl[i] = NULL;
	}
	f.m_dl_avail = BLOCKSIZE;

	f.clauses_rem = malloc(sizeof(remClause*)*BLOCKSIZE);
	for (i=0; i < BLOCKSIZE; ++i){
		f.clauses_rem[i] = NULL;
	}
	f.m_rem_avail = BLOCKSIZE;

	if (f.clauses_eo == NULL || f.clauses_do == NULL || f.clauses_el == NULL || f.clauses_dl == NULL || f.clauses_rem == NULL){
		#ifdef VERBOSE
		printf("c ERROR. Unable to allocate the memory for the clauses header data. Out of memory?\n");
		#endif
		main_returnCode = ERROR;
		return;
	}
}

void formula_dispose(){
	int32_t i;

	if (f.att != NULL){
		free(f.att);
		f.att = NULL;
	}

	if (f.clauses_eo != NULL){
		for (i = 0; i < f.m_eo_used; ++i){
			if (f.clauses_eo[i] != NULL){
				if (f.clauses_eo[i]->lits != NULL){
					free(f.clauses_eo[i]->lits);
					f.clauses_eo[i]->lits = NULL;
				}
				if (f.clauses_eo[i]->msgs != NULL){
					free(f.clauses_eo[i]->msgs);
					f.clauses_eo[i]->msgs = NULL;
				}
				if (f.clauses_eo[i]->occPos != NULL){
					free(f.clauses_eo[i]->occPos);
					f.clauses_eo[i]->occPos = NULL;
				}
				free(f.clauses_eo[i]);
			}
		}
		free(f.clauses_eo);
		f.clauses_eo = NULL;
	}

	if (f.clauses_do != NULL){
		for (i = 0; i < f.m_do_used; ++i){
			if (f.clauses_do[i] != NULL){
				if (f.clauses_do[i]->lits != NULL){
					free(f.clauses_do[i]->lits);
					f.clauses_do[i]->lits = NULL;
				}
				if (f.clauses_do[i]->msgs != NULL){
					free(f.clauses_do[i]->msgs);
					f.clauses_do[i]->msgs = NULL;
				}
				if (f.clauses_do[i]->occPos != NULL){
					free(f.clauses_do[i]->occPos);
					f.clauses_do[i]->occPos = NULL;
				}
				free(f.clauses_do[i]);
			}
		}
		free(f.clauses_do);
		f.clauses_do = NULL;
	}

	if (f.clauses_el != NULL){
		for (i = 0; i < f.m_el_used; ++i){
			if (f.clauses_el[i] != NULL){
				if (f.clauses_el[i]->lits != NULL){
					free(f.clauses_el[i]->lits);
					f.clauses_el[i]->lits = NULL;
				}
				if (f.clauses_el[i]->msgs != NULL){
					free(f.clauses_el[i]->msgs);
					f.clauses_el[i]->msgs = NULL;
				}
				if (f.clauses_el[i]->occPos != NULL){
					free(f.clauses_el[i]->occPos);
					f.clauses_el[i]->occPos = NULL;
				}
				free(f.clauses_el[i]);
			}
		}
		free(f.clauses_el);
		f.clauses_el = NULL;
	}

	if (f.clauses_dl != NULL){
		for (i = 0; i < f.m_dl_used; ++i){
			if (f.clauses_dl[i] != NULL){
				if (f.clauses_dl[i]->lits != NULL){
					free(f.clauses_dl[i]->lits);
					f.clauses_dl[i]->lits = NULL;
				}
				if (f.clauses_dl[i]->msgs != NULL){
					free(f.clauses_dl[i]->msgs);
					f.clauses_dl[i]->msgs = NULL;
				}
				if (f.clauses_dl[i]->occPos != NULL){
					free(f.clauses_dl[i]->occPos);
					f.clauses_dl[i]->occPos = NULL;
				}
				free(f.clauses_dl[i]);
			}
		}
		free(f.clauses_dl);
		f.clauses_dl = NULL;
	}

	if (f.clauses_rem != NULL){
		for (i = 0; i < f.m_rem_used; ++i){
			if (f.clauses_rem[i] != NULL){
				if (f.clauses_rem[i]->lits != NULL){
					free(f.clauses_rem[i]->lits);
					f.clauses_rem[i]->lits = NULL;
				}
				if (f.clauses_rem[i]->coveredLits != NULL){
					free(f.clauses_rem[i]->coveredLits);
					f.clauses_rem[i]->coveredLits = NULL;
				}
				free(f.clauses_rem[i]);
			}
		}
		free(f.clauses_rem);
		f.clauses_rem = NULL;
	}
}


#ifdef VERBOSE
void formula_printFormula(){
	printf("c LitStamp:%u\n",main_litStamp);
	printf("c Clause Pointers: %p %p %p %p\n",(void*)f.clauses_eo,(void*)f.clauses_do,(void*)f.clauses_el,(void*)f.clauses_dl);
	printf("c CLS count used I:%d EO:%d DO:%d EL:%d DL:%d\n",f.m_initial,f.m_eo_used,f.m_do_used,f.m_el_used,f.m_dl_used);
	printf("c CLS count avail I:%d EO:%d DO:%d EL:%d DL:%d\n",f.m_initial,f.m_eo_avail,f.m_do_avail,f.m_el_avail,f.m_dl_avail);
}
#endif
