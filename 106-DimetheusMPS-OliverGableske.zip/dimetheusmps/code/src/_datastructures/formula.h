/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#ifndef FORMULA_H_
#define FORMULA_H_

#include "../dimetheus.h"

typedef struct {			//The structure of the formula attributes computed for the original formula.
	uint32_t isSet;			//Tells us if the attributes have been computed.
	uint32_t n;				//Number of variables.
	uint32_t m;				//Number of clauses.
	float_ty r;				//Ratio of the formula.
	uint32_t initAss;		//How many assignments resulted from initial unit clauses?
	uint32_t minClsSize;	//How small was the smallest clause?
	uint32_t maxClsSize;	//How large was the largest clause?
} formulaAttributes;

//The following macros are used to access the current formula attributes.
#define MAIN_GET_FATT_ISSET() 			( f.att->isSet )
#define MAIN_GET_FATT_N()				( f.att->n )
#define MAIN_GET_FATT_M()				( f.att->m )
#define MAIN_GET_FATT_R()				( f.att->r )
#define MAIN_GET_FATT_INITASS()			( f.att->initAss )
#define MAIN_GET_FATT_MINCLSSIZE()		( f.att->minClsSize )
#define MAIN_GET_FATT_MAXCLSSIZE()		( f.att->maxClsSize )

#define MAIN_SET_FATT_ISSET( __d ) 		( f.att->isSet = __d )
#define MAIN_SET_FATT_N( __d )			( f.att->n = __d )
#define MAIN_SET_FATT_M( __d )			( f.att->m = __d )
#define MAIN_SET_FATT_R( __d )			( f.att->r = __d )
#define MAIN_SET_FATT_INITASS( __d )	( f.att->initAss = __d )
#define MAIN_SET_FATT_MINCLSSIZE( __d )	( f.att->minClsSize = __d )
#define MAIN_SET_FATT_MAXCLSSIZE( __d)	( f.att->maxClsSize = __d )

typedef struct {
	formulaAttributes* att;	//The pointer to the structure containing all the attributes of the original formula.
	variable* vars;			//An array of variables that are used in the formula.
	variable** vars_e;		//An array of pointers to the enabled variables.
	variable** vars_d;		//An array of pointers to the disabled variables.

	literal* lits;			//An array of the literals that are used in the formula.

	clause** clauses_eo; 	//An array of pointers to the enabled original clauses of the formula. ID is 00.
	clause** clauses_do; 	//An array of pointers to the disabled original clauses of the formula. ID is 01.
	clause** clauses_el;	//An array of pointers to the enabled learned clauses of the formula. ID is 10.
	clause** clauses_dl;	//An array of pointers to the disabled learned clauses of the formula. ID is 11.

	remClause** clauses_rem;//An array of pointers to the removed (NIVER/BLOCKED/COVERED) clauses.

	uint32_t n_initial;		//The number of initial variables in the formula.
	uint32_t n_afterPrep;	//The number of variables after prerocessing finished its work.
	uint32_t n_vars_e_used;	//The amount of address pointers used (number of variables) for the vars_e array.
	uint32_t n_vars_d_used;	//The amount of address pointers used (number of variables) for the vars_d array.

	uint32_t m_initial;		//The number of initial clauses in the formula, they are all original clauses of course.

	uint32_t m_eo_used;		//The amount of address pointers used (number of clauses) for the clauses_eo array.
	uint32_t m_eo_avail;	//The amount of address pointers available for the clauses_eo array.

	uint32_t m_do_used;		//The amount of address pointers used (number of clauses) for the clauses_do array.
	uint32_t m_do_avail;	//The amount of address pointers available for the clauses_do array.

	uint32_t m_el_used;		//The amount of address pointers used (number of clauses) for the clauses_el array.
	uint32_t m_el_avail;	//The amount of address pointers available for the clauses_el array.

	uint32_t m_dl_used;		//The amount of address pointers used (number of clauses) for the clauses_dl array.
	uint32_t m_dl_avail;	//The amount of address pointers available for the clauses_dl array.

	uint32_t m_rem_used;	//The amount of address pointers used (number of removed clauses) for the clauses_rem array.
	uint32_t m_rem_avail;	//The amount of address pointers available for the clauses_rem array.
} CNF;

void formula_reset();		//For resetting the formula data.
void formula_loadHeader();	//For loading the formula header from file (to initialize f.n and f.m).
void formula_init();		//For initializing the formula data-structure.
void formula_printAtt();	//For printing the attributes.
void formula_dispose();		//For disposing the formula data-structure.

#ifdef VERBOSE
void formula_printFormula();				//This will output all attributes of the formula.
#endif

#endif /* FORMULA_H_ */
