/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#ifndef GUIDES_H_
#define GUIDES_H_

#include "../dimetheus.h"

#define GUIDE_MINVALUE 0
#define GUIDE_MAXVALUE 5

#define GUIDE_MANUAL 0
#include "g_manual.h"

#define GUIDE_PREPONLY 1
#include "g_preponly.h"

#define GUIDE_CDCL 2
#include "g_cdcl.h"

#define GUIDE_SLS 3
#include "g_sls.h"

#define GUIDE_PMPCDCL 4
#include "g_pmpcdcl.h"

#define GUIDE_PMPSLS 5
#include "g_pmpsls.h"

#define GUIDE_TESTING 999
#include "g_testing.h"

static inline void main_guide_printHelp(){
	//Print the help to all the guides we have.
	main_guide_manual_printHelp();
    main_guide_preponly_printHelp();
    main_guide_cdcl_printHelp();
    main_guide_sls_printHelp();
    main_guide_pmpcdcl_printHelp();
    main_guide_pmpsls_printHelp();
    main_guide_testing_printHelp();
}

void (*main_guide_apply)(int, char**);

void main_guides_pointer_init();
void main_guides_printGuidanceError();

#endif /* GUIDES_H_ */
