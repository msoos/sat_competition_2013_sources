/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#include "guides.h"

void main_guides_pointer_init(){
	#ifdef VERBOSE
	printf("c   Setting pointer to... ");
	#endif

	if (param_guide == GUIDE_PREPONLY){
		#ifdef VERBOSE
		printf("PREPONLY\n");
		#endif
		main_guide_apply = &main_guide_preponly_apply;
	} else if (param_guide == GUIDE_CDCL){
		#ifdef VERBOSE
		printf("CDCL\n");
		#endif
		main_guide_apply = &main_guide_cdcl_apply;
	} else if (param_guide == GUIDE_SLS){
		#ifdef VERBOSE
		printf("SLS\n");
		#endif
		main_guide_apply = &main_guide_sls_apply;
	} else if (param_guide == GUIDE_PMPCDCL){
		#ifdef VERBOSE
		printf("PMPCDCL\n");
		#endif
		main_guide_apply = &main_guide_pmpcdcl_apply;
	} else if (param_guide == GUIDE_PMPSLS){
		#ifdef VERBOSE
		printf("PMPSLS\n");
		#endif
		main_guide_apply = &main_guide_pmpsls_apply;
	} else if (param_guide == GUIDE_TESTING){
		#ifdef VERBOSE
		printf("TESTING\n");
		#endif
		main_guide_apply = &main_guide_testing_apply;
	} else {
		#ifdef VERBOSE
		printf("MANUAL\n");
		#endif
		main_guide_apply = &main_guide_manual_apply;
	}
}

void main_guides_printGuidanceError(){
	printf("c ERROR. Parameter settings are in conflict with the guide selected.\n");
	printf("c ERROR. The selected guide prohibits the use of the parameters it enforces and requires other parameters\n");
	printf("c ERROR. to be set in a specific way (or left unprovided).\n");
	printf("c ERROR. See the help for details: ./dimetheus -h\n");
}
