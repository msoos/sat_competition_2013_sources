/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */


#include "guides.h"

void main_guide_cdcl_printHelp(){
	printf("c      %-3d: CDCL\n", GUIDE_CDCL);
    printf("c           Behavior: Perform conflict driven clause learning.\n");
    printf("c           Enforces: -adaptPrepStrategy [0 <1>], - adaptPrepStrategyParams [0 <1>],\n"
    	   "c                     -searchStrategy [%d], -adaptSearchStrategy [0], -adaptSearchStrategyParams [0 <1>]\n",
    								SEARCH_STRATEGY_CDCL);
}

void main_guide_cdcl_apply(int argc, char** argv){
	//This guide will enforce CDCL.

	int32_t parameter;

	//PARAMETERS TO CHECK
	//OTHER

	//PREP
	int32_t adaptPrepStrategyRead = -1,	adaptPrepStrategyParamsRead = -1;

	//INP

	//SEARCH
	int32_t searchStrategyRead = -1, adaptSearchStrategyRead = -1,	adaptSearchStrategyParamsRead = -1;

	//PRE

	//IN

	//MP

	//SLS

	//CDCL

	//READ PARAMETERS
	for (parameter=1; parameter<argc; ++parameter){
		//OTHER

		//PREP
		if (!strcmp("-adaptPrepStrategy",argv[parameter])){adaptPrepStrategyRead = param_adaptPrepStrategy;continue;}
		if (!strcmp("-adaptPrepStrategyParams",argv[parameter])){adaptPrepStrategyParamsRead = param_adaptPrepStrategyParams;continue;}

		//INP

		//SEARCH
		if (!strcmp("-searchStrategy",argv[parameter])){searchStrategyRead = param_searchStrategy;continue;}
		if (!strcmp("-adaptSearchStrategy",argv[parameter])){adaptSearchStrategyRead = param_adaptSearchStrategy;continue;}
		if (!strcmp("-adaptSearchStrategyParams",argv[parameter])){adaptSearchStrategyParamsRead = param_adaptSearchStrategyParams;continue;}

		//PRE

		//IN

		//MP

		//SLS

		//CDCL
	}

	//CHECK PARAMETERS
	//OTHER

	//PREP
	if (adaptPrepStrategyRead == -1) param_adaptPrepStrategy = 1;
	if (adaptPrepStrategyParamsRead == -1) param_adaptPrepStrategyParams = 1;

	//INP

	//SEARCH
	if (searchStrategyRead != -1 ){
		if (searchStrategyRead != SEARCH_STRATEGY_CDCL){main_returnCode = CONFLICTINGPARAMS;}
	} else {param_searchStrategy = SEARCH_STRATEGY_CDCL;}

	if (adaptSearchStrategyRead != -1 ){
		if (adaptSearchStrategyRead != 0){main_returnCode = CONFLICTINGPARAMS;}
	} else {param_adaptSearchStrategy = 0;}

	if (adaptSearchStrategyParamsRead == -1 ) param_adaptSearchStrategyParams = 1;

	//PRE

	//IN

	//MP

	//SLS

	//CDCL

	//CHECK
	if (main_returnCode == CONFLICTINGPARAMS){
		//The user made some parameter setting that is conflicting with this guide.
		main_guides_printGuidanceError();
	} else {
		//Otherwise, the user either did not provide the parameters or set them correctly.
		#ifdef VERBOSE_GUIDE
		printf("c   Guide %d [CDCL] successfully enforced.\n", GUIDE_CDCL);
		printf("c     -adaptPrepStrategy %d\n", param_adaptPrepStrategy);
		printf("c     -adaptPrepStrategyParams %d\n", param_adaptPrepStrategyParams);
		printf("c     -searchStrategy %d\n", param_searchStrategy);
		printf("c     -adaptSearchStrategy 0\n");
		printf("c     -adaptSearchStrategyParams %d\n", param_adaptSearchStrategyParams);
		#endif
	}
}
