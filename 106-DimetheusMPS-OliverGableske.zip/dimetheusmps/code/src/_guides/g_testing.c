/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#include "guides.h"

void main_guide_testing_printHelp(){
	printf("c      %-3d: TESTING\n", GUIDE_TESTING);
    printf("c           Behavior: A special testing guide used to ease the development. Do not use.\n");
    printf("c           Enforces: Subject to changes. Do not use.\n");
}

void main_guide_testing_apply(int argc, char** argv){
	//This is a testing guide that frequently changes. Do not use it.

	int32_t parameter;

	//PARAMETERS TO CHECK
	//OTHER

	//PREP

	//INP

	//SEARCH

	//PRE

	//IN

	//MP

	//SLS

	//CDCL

	//READ PARAMETERS
	for (parameter=1; parameter<argc; ++parameter){
		//OTHER

		//PREP

		//INP

		//SEARCH

		//PRE

		//IN

		//MP

		//SLS

		//CDCL
	}

	//CHECK PARAMETERS
	//OTHER

	//PREP

	//INP

	//SEARCH

	//PRE

	//IN

	//MP

	//SLS

	//CDCL

	//CHECK
	if (main_returnCode == CONFLICTINGPARAMS){
		//The user made some parameter setting that is conflicting with this guide.
		main_guides_printGuidanceError();
	} else {
		//Otherwise, the user either did not provide the parameters or set them correctly.
		#ifdef VERBOSE_GUIDE
		printf("c   Guide %d [TESTING] successfully enforced.\n", GUIDE_TESTING);
		#endif
	}
}
