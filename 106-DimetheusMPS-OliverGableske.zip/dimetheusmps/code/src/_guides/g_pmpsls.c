/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */


#include "guides.h"

void main_guide_pmpsls_printHelp(){
	printf("c      %-3d: PMPSLS\n", GUIDE_PMPSLS);
    printf("c           Behavior: Performs SLS-based MID using rho-sigma-PMP-i.\n");
    printf("c           Enforces: -adaptPrepStrategy [0 <1>], -adaptPrepStrategyParams [0 <1>],\n"
    	   "c                     -searchStrategy [%d], -adaptSearchStrategy [0], -adaptSearchStrategyParams [0 <1>],\n"
    	   "c                     -adaptAssumeRandom [0 <1>], -mpUpdateRule [%d], -adaptMpUR [0], -adaptMpURParams [0 <1>],\n"
    	   "c                     -slsAssInitRule [%d], -adaptSlsAI [0], -adaptSlsAIParams [0],\n"
    	   "c                     -adaptSlsPAFVR [0 <1>], -adaptSlsPAFVRParams [0 <1>], -slsMaxFlipsFactor [<0.0> ...]\n",
    	   	   	   	   	   	   	   SEARCH_STRATEGY_PMPSLS,  MP_UPDATERULE_L2I_RHOSIGMAPMP, SLS_ASSINITRULE_PROVIDED);

}

void main_guide_pmpsls_apply(int argc, char** argv){
	//This guide will enforce the rho-sigma PMP guided SLS. It enforces that MP is performed with the L2 heuristic and
	//it ensures that the SLS picks exactly the provided biases and phases for initializing its starting assignment.

	int32_t parameter;

	//PARAMETERS TO CHECK
	//OTHER
	int32_t adaptAssumeRandomRead = -1;

	//PREP
	int32_t adaptPrepStrategyRead = -1,	adaptPrepStrategyParamsRead = -1;

	//INP

	//SEARCH
	int32_t searchStrategyRead = -1, adaptSearchStrategyRead = -1,	adaptSearchStrategyParamsRead = -1;

	//PRE

	//IN

	//MP
	int32_t mpUpdateRuleRead = -1, adaptMpURRead = -1,	adaptMpURParamsRead = -1;

	//SLS
	int32_t slsAssInitRuleRead = -1, adaptSlsAIRead = -1, adaptSlsAIParamsRead = -1,
			adaptSlsPAFVRRead = -1, adaptSlsPAFVRParamsRead = -1, slsMaxFlipsFactorRead = -1;

	//CDCL

	//READ PARAMETERS
	for (parameter=1; parameter<argc; ++parameter){
		//OTHER
		if (!strcmp("-adaptAssumeRandom",argv[parameter])){adaptAssumeRandomRead = param_adaptAssumeRandom;continue;}

		//PREP
		if (!strcmp("-adaptPrepStrategy",argv[parameter])){adaptPrepStrategyRead = param_adaptPrepStrategy;continue;}
		if (!strcmp("-adaptPrepStrategyParams",argv[parameter])){adaptPrepStrategyParamsRead = param_adaptPrepStrategyParams;continue;}
		//INP

		//SEARCH
		if (!strcmp("-searchStrategy",argv[parameter])){searchStrategyRead = param_searchStrategy;continue;}
		if (!strcmp("-adaptSearchStrategy",argv[parameter])){adaptSearchStrategyRead = param_adaptSearchStrategy;continue;}
		if (!strcmp("-adaptSearchStrategyParams",argv[parameter])){adaptSearchStrategyParamsRead = param_adaptSearchStrategyParams;continue;}

		//PRE

		//IN

		//MP
		if (!strcmp("-mpUpdateRule",argv[parameter])){mpUpdateRuleRead = param_mpUpdateRule;continue;}
		if (!strcmp("-adaptMpUR",argv[parameter])){adaptMpURRead = param_adaptMpUR;continue;}
		if (!strcmp("-adaptMpURParams",argv[parameter])){adaptMpURParamsRead = param_adaptMpURParams;continue;}

		//SLS
		if (!strcmp("-slsAssInitRule",argv[parameter])){slsAssInitRuleRead = param_slsAssInitRule;continue;}
		if (!strcmp("-adaptSlsAI",argv[parameter])){adaptSlsAIRead = param_adaptSlsAI;continue;}
		if (!strcmp("-adaptSlsAIParams",argv[parameter])){adaptSlsAIParamsRead = param_adaptSlsAIParams;continue;}
		if (!strcmp("-adaptSlsPAFVR",argv[parameter])){adaptSlsPAFVRRead = param_adaptSlsPAFVR;continue;}
		if (!strcmp("-adaptSlsPAFVRParams",argv[parameter])){adaptSlsPAFVRParamsRead = param_adaptSlsPAFVRParams;continue;}
		if (!strcmp("-slsMaxFlipsFactor",argv[parameter])){slsMaxFlipsFactorRead = param_slsMaxFlipsFactor;continue;}
		//CDCL

	}


	//CHECK PARAMETERS
	//OTHER
	if (adaptAssumeRandomRead == -1) param_adaptAssumeRandom = 1;

	//PREP
	if (adaptPrepStrategyRead == -1) param_adaptPrepStrategy = 1;
	if (adaptPrepStrategyParamsRead == -1) param_adaptPrepStrategyParams = 1;

	//INP

	//SEARCH
	if (searchStrategyRead != -1 ){
		if (searchStrategyRead != SEARCH_STRATEGY_PMPSLS){main_returnCode = CONFLICTINGPARAMS;}
	} else {param_searchStrategy = SEARCH_STRATEGY_PMPSLS;}

	if (adaptSearchStrategyRead != -1 ){
		if (adaptSearchStrategyRead != 0){main_returnCode = CONFLICTINGPARAMS;}
	} else {param_adaptSearchStrategy = 0;}

	if (adaptSearchStrategyParamsRead == -1) param_adaptSearchStrategyParams = 1;

	//PRE

	//IN

	//MP
	if (mpUpdateRuleRead != -1 ){
		if (mpUpdateRuleRead != MP_UPDATERULE_L2I_RHOSIGMAPMP){main_returnCode = CONFLICTINGPARAMS;}
	} else {param_mpUpdateRule = MP_UPDATERULE_L2I_RHOSIGMAPMP;}

	if (adaptMpURRead != -1 ){
		if (adaptMpURRead != 0){main_returnCode = CONFLICTINGPARAMS;}
	} else {param_adaptMpUR = 0;}

	if (adaptMpURParamsRead == -1) param_adaptMpURParams = 1;

	//SLS
	if (slsAssInitRuleRead != -1 ){
		if (slsAssInitRuleRead != SLS_ASSINITRULE_PROVIDED){main_returnCode = CONFLICTINGPARAMS;}
	} else {param_slsAssInitRule = SLS_ASSINITRULE_PROVIDED;}

	if (adaptSlsAIRead != -1 ){
		if (adaptSlsAIRead != 0){main_returnCode = CONFLICTINGPARAMS;}
	} else {param_adaptSlsAI = 0;}

	if (adaptSlsAIParamsRead != -1 ){
		if (adaptSlsAIParamsRead != 0){main_returnCode = CONFLICTINGPARAMS;}
	} else {param_adaptSlsAIParams = 0;}

	if (adaptSlsPAFVRRead == -1) param_adaptSlsPAFVR = 1;
	if (adaptSlsPAFVRParamsRead == -1) param_adaptSlsPAFVRParams = 1;

	if (slsMaxFlipsFactorRead == -1) param_slsMaxFlipsFactor = ZERO;
	//CDCL

	//CHECK
	if (main_returnCode == CONFLICTINGPARAMS){
		//The user made some parameter setting that is conflicting with this guide.
		main_guides_printGuidanceError();
	} else {
		//Otherwise, the user either did not provide the parameters or set them correctly.
		#ifdef VERBOSE_GUIDE
		printf("c   Guide %d [PMPSLS] successfully enforced.\n", GUIDE_PMPSLS);
		printf("c     -adaptAssumeRandom %d\n", param_adaptAssumeRandom);
		printf("c     -adaptPrepStrategy %d\n", param_adaptPrepStrategy);
		printf("c     -adaptPrepStrategyParams %d\n", param_adaptPrepStrategyParams);
		printf("c     -searchStrategy %d\n", param_searchStrategy);
		printf("c     -adaptSearchStrategy 0\n");
		printf("c     -adaptSearchStrategyParams %d\n", param_adaptSearchStrategyParams);
		printf("c     -mpUpdateRule %d\n", param_mpUpdateRule);
		printf("c     -adaptMpUR 0\n");
		printf("c     -adaptMpURParams %d\n", param_adaptMpURParams);
		printf("c     -slsAssInitRule %d\n", param_slsAssInitRule);
		printf("c     -adaptSlsAI 0\n");
		printf("c     -adaptSlsAIParams 0\n");
		printf("c     -adaptSlsPAFVR %d\n", param_adaptSlsPAFVR);
		printf("c     -adaptSlsPAFVRParams %d\n", param_adaptSlsPAFVRParams);
		printf("c     -slsMaxFlipsFactor %f\n", param_slsMaxFlipsFactor);
		#endif
	}
}

