/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#include "guides.h"

void main_guide_pmpcdcl_printHelp(){
	printf("c      %-3d: PMPCDCL\n", GUIDE_PMPCDCL);
    printf("c           Behavior: Performs CDCL-based MID using rho-sigma-PMP-i.\n");
    printf("c           Enforces: -adaptPrepStrategy [0 <1>], -adaptPrepStrategyParams [0 <1>],\n"
    	   "c                     -adaptInpStrategy [0 <1>], -adaptInpStrategyParams [0 <1>],\n"
    	   "c                     -searchStrategy [%d], -adaptSearchStrategy [0], -adaptSearchStrategyParams [0 <1>],\n"
    	   "c                     -mpUpdateRule [%d], -adaptMpUR [0], -adaptMpURParams [0 <1>],\n"
    	   "c                     -cdclSelectVarRule [%d], -adaptCdclSVR [0], -adaptCdclSVRParams [0], -cdclSelectVarRandProb [0.0],\n"
    	   "c                     -cdclSelectVarActInit [%d], -adaptCdclSVAI [0], -adaptCdclSVAIParams [0],\n"
    	   "c                     -cdclSelectDirRule [%d], -adaptCdclSDR [0], -adaptCdclSDRParams [0],\n"
    	   "c                     -cdclSelectDirDirInit [%d], -adaptCdclSDDI [0], -adaptCdclSDDIParams [0],\n"
    	   "c                     -cdclAbortRule [%d], -adaptCdclAR [0], -adaptCdclARParams [0],\n"
    	   "c                     -cdclInprocessingRule [%d %d <%d> %d], -adaptCdclIR [0 <1>], -adaptCdclIRParams [0 <1>]\n",
    	   	   	   	   	   	   	   SEARCH_STRATEGY_PMPCDCL, MP_UPDATERULE_L2I_RHOSIGMAPMP, CDCL_SELECTVARRULE_RRVSIDS,
    	   	   	   	   	   	   	   CDCL_SELECTVARRULE_VARACTINIT_PROVIDED, CDCL_SELECTDIRRULE_PHASESAVING,
    	   	   	   	   	   	   	   CDCL_SELECTDIRRULE_DIRINIT_PROVIDED, CDCL_ABORTRULE_PMPCDCL, CDCL_INPROCESSINGRULE_NULL,
    	   	   	   	   	   	   	   CDCL_INPROCESSINGRULE_REDUCEONLY, CDCL_INPROCESSINGRULE_SIMPLE, CDCL_INPROCESSINGRULE_FULL);

}

void main_guide_pmpcdcl_apply(int argc, char** argv){
	//This guide will enforce the rho-sigma PMP guided CDCL. It enforces that MP is performed with the L2 heuristic and
	//it ensures that the CDCL picks exactly the provided biases and phases for initializing VSIDS.

	int32_t parameter;

	//PARAMETERS TO CHECK
	//OTHER

	//PREP
	int32_t adaptPrepStrategyRead = -1,	adaptPrepStrategyParamsRead = -1;

	//INP
	int32_t adaptInpStrategyRead = -1, adaptInpStrategyParamsRead = -1;

	//SEARCH
	int32_t searchStrategyRead = -1, adaptSearchStrategyRead = -1, adaptSearchStrategyParamsRead = -1;

	//PRE

	//IN

	//MP
	int32_t mpUpdateRuleRead = -1, adaptMpURRead = -1,	adaptMpURParamsRead = -1;

	//SLS

	//CDCL
	int32_t cdclSelectVarRuleRead = -1,	adaptCdclSVRRead = -1, adaptCdclSVRParamsRead = -1;
	float_ty cdclSelectVarRandProbRead = -1.0;

	int32_t	cdclSelectVarActInitRead = -1, adaptCdclSVAIRead = -1, adaptCdclSVAIParamsRead = -1;

	int32_t cdclSelectDirRuleRead = -1,	adaptCdclSDRRead = -1, adaptCdclSDRParamsRead = -1;
	int32_t cdclSelectDirDirInitRead = -1, adaptCdclSDDIRead = -1, adaptCdclSDDIParamsRead = -1;

	int32_t cdclAbortRuleRead = -1,	adaptCdclARRead = -1, adaptCdclARParamsRead = -1;

	int32_t cdclInprocessingRuleRead = -1, adaptCdclIRRead = -1, adaptCdclIRParamsRead = -1;

	//READ PARAMETERS
	for (parameter=1; parameter<argc; ++parameter){
		//OTHER

		//PREP
		if (!strcmp("-adaptPrepStrategy",argv[parameter])){adaptPrepStrategyRead = param_adaptPrepStrategy;continue;}
		if (!strcmp("-adaptPrepStrategyParams",argv[parameter])){adaptPrepStrategyParamsRead = param_adaptPrepStrategyParams;continue;}

		//INP
		if (!strcmp("-adaptInpStrategy",argv[parameter])){adaptInpStrategyRead = param_adaptInpStrategy;continue;}
		if (!strcmp("-adaptInpStrategyParams",argv[parameter])){adaptInpStrategyParamsRead = param_adaptInpStrategyParams;continue;}

		//SEARCH
		if (!strcmp("-searchStrategy",argv[parameter])){searchStrategyRead = param_searchStrategy;continue;}
		if (!strcmp("-adaptSearchStrategy",argv[parameter])){adaptSearchStrategyRead = param_adaptSearchStrategy;continue;}
		if (!strcmp("-adaptSearchStrategyParams",argv[parameter])){adaptSearchStrategyParamsRead = param_adaptSearchStrategyParams;continue;}

		//PRE

		//IN

		//MP
		if (!strcmp("-mpUpdateRule",argv[parameter])){mpUpdateRuleRead = param_mpUpdateRule;continue;}
		if (!strcmp("-adaptMpUR",argv[parameter])){adaptMpURRead = param_adaptMpUR;continue;}
		if (!strcmp("-adaptMpURParams",argv[parameter])){adaptMpURParamsRead = param_adaptMpURParams;continue;}

		//SLS

		//CDCL
		if (!strcmp("-cdclSelectVarRule",argv[parameter])){cdclSelectVarRuleRead = param_cdclSelectVarRule;continue;}
		if (!strcmp("-adaptCdclSVR",argv[parameter])){adaptCdclSVRRead = param_adaptCdclSVR;continue;}
		if (!strcmp("-adaptCdclSVRParams",argv[parameter])){adaptCdclSVRParamsRead = param_adaptCdclSVRParams;continue;}
		if (!strcmp("-cdclSelectVarRandProb",argv[parameter])){cdclSelectVarRandProbRead = param_cdclSelectVarRandProb;continue;}
		if (!strcmp("-cdclSelectVarActInit",argv[parameter])){cdclSelectVarActInitRead = param_cdclSelectVarActInit;continue;}
		if (!strcmp("-adaptCdclSVAI",argv[parameter])){adaptCdclSVAIRead = param_adaptCdclSVAI;continue;}
		if (!strcmp("-adaptCdclSVAIParams",argv[parameter])){adaptCdclSVAIParamsRead = param_adaptCdclSVAIParams;continue;}
		if (!strcmp("-cdclSelectDirRule",argv[parameter])){cdclSelectDirRuleRead = param_cdclSelectDirRule;continue;}
		if (!strcmp("-adaptCdclSDR",argv[parameter])){adaptCdclSDRRead = param_adaptCdclSDR;continue;}
		if (!strcmp("-adaptCdclSDRParams",argv[parameter])){adaptCdclSDRParamsRead = param_adaptCdclSDRParams;continue;}
		if (!strcmp("-cdclSelectDirDirInit",argv[parameter])){cdclSelectDirDirInitRead = param_cdclSelectDirDirInit;continue;}
		if (!strcmp("-adaptCdclSDDI",argv[parameter])){adaptCdclSDDIRead = param_adaptCdclSDDI;continue;}
		if (!strcmp("-adaptCdclSDDIParams",argv[parameter])){adaptCdclSDDIParamsRead = param_adaptCdclSDDIParams;continue;}
		if (!strcmp("-cdclAbortRule",argv[parameter])){cdclAbortRuleRead = param_cdclAbortRule;continue;}
		if (!strcmp("-adaptCdclAR",argv[parameter])){adaptCdclARRead = param_adaptCdclAR;continue;}
		if (!strcmp("-adaptCdclARParams",argv[parameter])){adaptCdclARParamsRead = param_adaptCdclARParams;continue;}
		if (!strcmp("-cdclInprocessingRule",argv[parameter])){cdclInprocessingRuleRead = param_cdclInprocessingRule;continue;}
		if (!strcmp("-adaptCdclIR",argv[parameter])){adaptCdclIRRead = param_adaptCdclIR;continue;}
		if (!strcmp("-adaptCdclIRParams",argv[parameter])){adaptCdclIRParamsRead = param_adaptCdclIRParams;continue;}
	}

	//CHECK PARAMETERS
	//OTHER

	//PREP
	if (adaptPrepStrategyRead == -1) param_adaptPrepStrategy = 1;
	if (adaptPrepStrategyParamsRead == -1) param_adaptPrepStrategyParams = 1;

	//INP
	if (adaptInpStrategyRead == -1) param_adaptInpStrategy = 1;
	if (adaptInpStrategyParamsRead == -1) param_adaptInpStrategyParams = 1;

	//SEARCH
	if (searchStrategyRead != -1 ){
		if (searchStrategyRead != SEARCH_STRATEGY_PMPCDCL){main_returnCode = CONFLICTINGPARAMS;}
	} else {param_searchStrategy = SEARCH_STRATEGY_PMPCDCL;}

	if (adaptSearchStrategyRead != -1 ){
		if (adaptSearchStrategyRead != 0){main_returnCode = CONFLICTINGPARAMS;}
	} else {param_adaptSearchStrategy = 0;}

	if (adaptSearchStrategyParamsRead == -1) param_adaptSearchStrategyParams = 1;

	//PRE

	//IN

	//MP
	if (mpUpdateRuleRead != -1 ){
		if (mpUpdateRuleRead != MP_UPDATERULE_L2I_RHOSIGMAPMP){main_returnCode = CONFLICTINGPARAMS;}
	} else {param_mpUpdateRule = MP_UPDATERULE_L2I_RHOSIGMAPMP;}

	if (adaptMpURRead != -1 ){
		if (adaptMpURRead != 0){main_returnCode = CONFLICTINGPARAMS;}
	} else {param_adaptMpUR = 0;}

	if (adaptMpURParamsRead == -1) param_adaptMpURParams = 1;

	//SLS

	//CDCL
	if (cdclSelectVarRuleRead != -1){
		if (cdclSelectVarRuleRead != CDCL_SELECTVARRULE_RRVSIDS
				&& cdclSelectVarRuleRead != CDCL_SELECTVARRULE_RVSIDS
				&& cdclSelectVarRuleRead != CDCL_SELECTVARRULE_VSIDS){main_returnCode = CONFLICTINGPARAMS;}
	} else {param_cdclSelectVarRule = CDCL_SELECTVARRULE_RRVSIDS;}

	if (adaptCdclSVRRead != -1 ){
		if (adaptCdclSVRRead != 0){main_returnCode = CONFLICTINGPARAMS;}
	} else {param_adaptCdclSVR = 0;}

	if (adaptCdclSVRParamsRead != -1 ){
		if (adaptCdclSVRParamsRead != 0){main_returnCode = CONFLICTINGPARAMS;}
	} else {param_adaptCdclSVRParams = 0;}

	if (cdclSelectVarRandProbRead != -1.0){
		if (cdclSelectVarRandProbRead != ZERO){main_returnCode = CONFLICTINGPARAMS;}
	} else {param_cdclSelectVarRandProb = ZERO;}

	if (cdclSelectVarActInitRead != -1 ){
		if (cdclSelectVarActInitRead != CDCL_SELECTVARRULE_VARACTINIT_PROVIDED){main_returnCode = CONFLICTINGPARAMS;}
	} else {param_cdclSelectVarActInit = CDCL_SELECTVARRULE_VARACTINIT_PROVIDED;}

	if (adaptCdclSVAIRead != -1 ){
		if (adaptCdclSVAIRead != 0){main_returnCode = CONFLICTINGPARAMS;}
	} else {param_adaptCdclSVAI = 0;}

	if (adaptCdclSVAIParamsRead != -1 ){
		if (adaptCdclSVAIParamsRead != 0){main_returnCode = CONFLICTINGPARAMS;}
	} else {param_adaptCdclSVAIParams = 0;}

	if (cdclSelectDirRuleRead != -1 ){
		if (cdclSelectDirRuleRead != CDCL_SELECTDIRRULE_PHASESAVING){main_returnCode = CONFLICTINGPARAMS;}
	} else {param_cdclSelectDirRule = CDCL_SELECTDIRRULE_PHASESAVING;}

	if (adaptCdclSDRRead != -1 ){
		if (adaptCdclSDRRead != 0){main_returnCode = CONFLICTINGPARAMS;}
	} else {param_adaptCdclSDR = 0;}

	if (adaptCdclSDRParamsRead != -1 ){
		if (adaptCdclSDRParamsRead != 0){main_returnCode = CONFLICTINGPARAMS;}
	} else {param_adaptCdclSDRParams = 0;}

	if (cdclSelectDirDirInitRead != -1 ){
		if (cdclSelectDirDirInitRead != CDCL_SELECTDIRRULE_DIRINIT_PROVIDED){main_returnCode = CONFLICTINGPARAMS;}
	} else {param_cdclSelectDirDirInit = CDCL_SELECTDIRRULE_DIRINIT_PROVIDED;}

	if (adaptCdclSDDIRead != -1 ){
		if (adaptCdclSDDIRead != 0){main_returnCode = CONFLICTINGPARAMS;}
	} else {param_adaptCdclSDDI = 0;}

	if (adaptCdclSDDIParamsRead != -1 ){
		if (adaptCdclSDDIParamsRead != 0){main_returnCode = CONFLICTINGPARAMS;}
	} else {param_adaptCdclSDDIParams = 0;}

	if (cdclAbortRuleRead != -1 ){
		if (cdclAbortRuleRead != CDCL_ABORTRULE_PMPCDCL){main_returnCode = CONFLICTINGPARAMS;}
	} else {param_cdclAbortRule = CDCL_ABORTRULE_PMPCDCL;}

	if (adaptCdclARRead != -1 ){
		if (adaptCdclARRead != 0){main_returnCode = CONFLICTINGPARAMS;}
	} else {param_adaptCdclAR = 0;}

	if (adaptCdclARParamsRead != -1 ){
		if (adaptCdclARParamsRead != 0){main_returnCode = CONFLICTINGPARAMS;}
	} else {param_adaptCdclARParams = 0;}

	if (cdclInprocessingRuleRead != -1){
		if (cdclInprocessingRuleRead != CDCL_INPROCESSINGRULE_NULL
				&& cdclInprocessingRuleRead != CDCL_INPROCESSINGRULE_REDUCEONLY
				&& cdclInprocessingRuleRead != CDCL_INPROCESSINGRULE_SIMPLE
				&& cdclInprocessingRuleRead != CDCL_INPROCESSINGRULE_FULL){main_returnCode = CONFLICTINGPARAMS;}
	} else {param_cdclInprocessingRule = CDCL_INPROCESSINGRULE_SIMPLE;}

	if (adaptCdclIRRead == -1) param_adaptCdclIR = 1;
	if (adaptCdclIRParamsRead == -1) param_adaptCdclIRParams = 1;

	//CHECK
	if (main_returnCode == CONFLICTINGPARAMS){
		//The user made some parameter setting that is conflicting with this guide.
		main_guides_printGuidanceError();
	} else {
		//Otherwise, the user either did not provide the parameters or set them correctly.
		#ifdef VERBOSE_GUIDE
		printf("c   Guide %d [PMPCDCL] successfully enforced.\n", GUIDE_PMPCDCL);
		printf("c     -adaptPrepStrategy %d\n", param_adaptPrepStrategy);
		printf("c     -adaptPrepStrategyParams %d\n", param_adaptPrepStrategyParams);

		printf("c     -adaptInpStrategy %d\n", param_adaptInpStrategy);
		printf("c     -adaptInpStrategyParams %d\n", param_adaptInpStrategyParams);

		printf("c     -searchStrategy %d\n", param_searchStrategy);
		printf("c     -adaptSearchStrategy 0\n");
		printf("c     -adaptSearchStrategyParams 0\n");

		printf("c     -mpUpdateRule %d\n", param_mpUpdateRule);
		printf("c     -adaptMpUR 0\n");
		printf("c     -adaptMpURParams %d\n", param_adaptMpURParams);

		printf("c     -cdclSelectVarRule %d\n", param_cdclSelectVarRule);
		printf("c     -adaptCdclSVR 0\n");
		printf("c     -adaptCdclSVRParams 0\n");
		printf("c     -cdclSelectVarRandProb %f\n", param_cdclSelectVarRandProb);
		printf("c     -cdclSelectVarActInit %d\n", param_cdclSelectVarActInit);
		printf("c     -adaptCdclSVAI 0\n");
		printf("c     -adaptCdclSVAIParams 0\n");

		printf("c     -cdclSelectDirRule %d\n", param_cdclSelectDirRule);
		printf("c     -adaptCdclSDR 0\n");
		printf("c     -adaptCdclSDRParams 0\n");
		printf("c     -cdclSelectDirDirInit %d\n", param_cdclSelectDirDirInit);
		printf("c     -adaptCdclSDDI 0\n");
		printf("c     -adaptCdclSDDIParams 0\n");

		printf("c     -cdclAbortRule %d\n", param_cdclAbortRule);
		printf("c     -adaptCdclAR 0\n");
		printf("c     -adaptCdclARParams 0\n");

		printf("c     -cdclInprocessingRule %d\n", param_cdclInprocessingRule);
		printf("c     -adaptInpStrategy %d\n", param_adaptInpStrategy);
		printf("c     -adaptInpStrategyParams %d\n", param_adaptInpStrategyParams);
		#endif
	}
}

