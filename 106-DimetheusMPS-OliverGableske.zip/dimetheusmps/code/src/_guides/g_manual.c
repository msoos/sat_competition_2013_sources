/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#include "guides.h"

void main_guide_manual_printHelp(){
	printf("c      %-3d: MANUAL\n", GUIDE_MANUAL);
    printf("c           Behavior: Allows you to set everything yourself.\n");
    printf("c           Enforces: Nothing.\n");
}

void main_guide_manual_apply(int argc, char** argv){
	//The manual guide is doing nothing for you -- you have to do all the parameter and strategy settings manually :-)
}
