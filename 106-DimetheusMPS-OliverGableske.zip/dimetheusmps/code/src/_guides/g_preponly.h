/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#ifndef G_PREPONLY_H_
#define G_PREPONLY_H_

void main_guide_preponly_printHelp();
void main_guide_preponly_apply(int, char**);

#endif /* G_PREPONLY_H_ */
