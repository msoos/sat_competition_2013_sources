/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#ifndef DEFINES_H_
#define DEFINES_H_

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <signal.h>
#include <time.h>

//#define COLLECTSTATS					//If you want to collect and output statistics gathered during execution (slow!).
//#define SCORING						//If you want the solver to provide a score in the end, scoring how "well" it went.
#define NEWSCHOOLRAND					//Use the new linear congruence random number generator instead of C build in one.
#define VERSION_MA 1					//The major version number.
#define VERSION_MI 700					//The minor version number.
#define VERSION_RE 852					//The revision number.
#define VERSION_CI "29. April 2013, 09:42 CET" //The date and time for the revision commit.

#define BLOCKSIZE 8						//A block is 32 integers in size. This is the initial size of dynamic arrays. MUST BE
										//1 OR A MULTIPLE OF 2! This is set to 1 for testing purposes.

//#define VERBOSE						//In case you want to see output of the global main component of the solver.

#define VERBOSE_GUIDE					//In case you want to see output during the guidance phase.
#define VERBOSE_CLASSIFY				//In case you want to see output during the classification phase.
#define VERBOSE_ADAPT					//In case you want to see output during the adaptation phase.
//#define VERBOSE_PREP					//In case you want to see output during the preprocessing phase.
//#define VERBOSE_SEARCH				//In case you want to see output during the search phase.
//#define VERBOSE_INP					//In case you want to see output during the in-processing phase.

//#define VERBOSE_IN					//In case you want to see the output of the IN module.
#define VERBOSE_CLASS					//In case you want to see the output of the CLASS module.
#define VERBOSE_ITEADAPTER				//In case you want to see the output of the ITEADAPTER module.
//#define VERBOSE_PRE					//In case you want to see the output of the PRE module.
//#define VERBOSE_MP					//In case you want to see the output of the MP module.
//#define VERBOSE_SLS					//In case you want to see the output of the SLS module.
//#define VERBOSE_CDCL					//In case you want to see the output of the CDCL module.

//RETURN CODES FOR PHASES.
//MAIN
#define UNKNOWN 0
#define SAT 10
#define UNSAT 20
#define ERROR 30
#define BADPARAM 37
#define BADFORMULA 38
#define CONFLICTINGPARAMS 39
#define SIGNAL 40

//CLASSIFY PHASE
#define CLASSIFY_UNKNOWN 0
#define CLASSIFY_ERROR 40

//ADAPT PHASE
#define ADAPT_UNKNOWN 0
#define ADAPT_ERROR 40

//PREPROCESSING PHASE
#define PREP_UNKNOWN 1
#define PREP_SAT 11
#define PREP_UNSAT 21
#define PREP_ERROR 31

//INPROCESSING PHASE
#define INP_UNKNOWN 2
#define INP_SAT 12
#define INP_UNSAT 22
#define INP_ERROR 32

//SEARCH PHASE
#define SEARCH_UNKNOWN 3
#define SEARCH_SAT 13
#define SEARCH_UNSAT 23
#define SEARCH_ERROR 33

//RETURN CODES FOR MODULES
//CLASS MODULE
#define CLASS_UNKNOWN 0
#define CLASS_ERROR 0

//ITEADAPTER MODULE
#define ITEADAPTER_UNKNOWN 0
#define ITEADAPTER_ERROR 0

//PRE MODULE
#define PRE_UNKNOWN 0
#define PRE_SAT 10
#define PRE_UNSAT 20
#define PRE_ERROR 40

//IN MODULE
#define IN_UNKNOWN 0
#define IN_SAT 10
#define IN_UNSAT 20
#define IN_ERROR 40

//MP MODULE
#define MP_UNKNOWN 0
#define MP_CONVERGED 10
#define MP_CONVERGED_PARAMAG 11
#define MP_CONVERGED_NONPARA 12
#define MP_UNCONVERGED 20
#define MP_ERROR 40

//SLS MODULE
#define SLS_UNKNOWN 0
#define SLS_SAT 10
#define SLS_ERROR 40

//CDCL MODULE
#define CDCL_UNKNOWN 0
#define CDCL_SAT 10
#define CDCL_UNSAT 20
#define CDCL_ERROR 40

#define DOUBLEMODE						//Enable this for maximum precision with floating points.
#ifdef DOUBLEMODE
typedef double float_ty;
#define VAR_MAX_ACTIVITY_VALUE 1e100
#define VAR_MAX_AGILITY_VALUE 1e100
#define CLS_MAX_ACTIVITY_VALUE 1e100
#define VQ_SCORE_FACTOR 1000000000.0
#define TWO 2.0
#define ONE 1.0
#define HALF 0.5
#define ZERO 0.0
#define LARGEFLOAT 100000000.0
#else
typedef float float_ty;
#define VAR_MAX_ACTIVITY_VALUE 2147483648.0f
#define VAR_MAX_AGILITY_VALUE 2147483648.0f
#define CLS_MAX_ACTIVITY_VALUE 2147483648.0f
#define VQ_SCORE_FACTOR 1000000000.0f
#define TWO 2.0f
#define ONE 1.0f
#define HALF 0.5f
#define ZERO 0.0f
#define LARGEFLOAT 100000000.0f
#endif

//Check if we compile on a 32 bit system.
#if !(defined __LP64__ || defined __LLP64__) || defined _WIN32 && !defined _WIN64
//We are compiling for a 32-bit system.
typedef int32_t addr_t;
#define SYS32BIT
#else
//We are compiling for a 64-bit system
typedef int64_t addr_t;
#define SYS64BIT
#endif

//Static global functions.
static inline uint32_t POPCOUNT_UINT64(uint64_t x){//Computes number of set bits in x. Knuth TAOCP Volume 4 F1A, page 11.
	x = x-( (x>>1) & 0x5555555555555555ull);
	x = (x & 0x3333333333333333ull) + ((x >> 2) & 0x3333333333333333ull);
	x = (x + (x >> 4)) & 0x0f0f0f0f0f0f0f0full;
	return (0x0101010101010101ull*x >> 56);
}

static inline void PRINT_BITS_UINT32(uint32_t x){
	int32_t counter;
	for (counter = 31; counter > -1; --counter){ \
		printf("%d", (int32_t)(( x >> counter ) & 1U));\
	} \
}

static inline void PRINT_BITS_UINT64(uint64_t x){
	int32_t counter;
	for (counter = 63; counter > -1; --counter){ \
		printf("%d", (int32_t)(( x >> counter ) & 1U));\
	} \
}

//Macro stuff.
//Rotating stuff.
#define ROTATE_32RIGHT_UINT64( __value ) ( (__value >> 32) | (__value << 32) )
#define ROTATE_16RIGHT_UINT32( __value ) ( (__value >> 16) | (__value << 16) )
#endif /* DEFINES_H_ */
