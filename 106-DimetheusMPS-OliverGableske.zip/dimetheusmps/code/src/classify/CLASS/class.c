/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#include "class.h"

void class_resetModule(){
	//Reset the CLASS module.
	#ifdef VERBOSE_CLASS
	printf("c     CLASS: Component reset...\n");
	#endif
	class_returnCode = CLASS_UNKNOWN;
}

void class_initModule(){
	//Initialize the CLASS component.
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	#endif
	#ifdef VERBOSE_CLASS
	printf("c     CLASS: Component init...\n");
	#endif
	class_returnCode = CLASS_UNKNOWN;

	#ifdef COLLECTSTATS
	stats_class_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void class_disposeModule(){
	//Dispose the CLASS component.
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	#endif
	#ifdef VERBOSE_CLASS
	printf("c     CLASS: Component dispose...\n");
	#endif

	class_returnCode = CLASS_UNKNOWN;

	#ifdef COLLECTSTATS
	stats_class_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void class_extern_printVersion(){
	printf("[Classification  ] [Classifier                     ] :: %3d.%-4d :: %s",
			CLASS_VERSION_MA, CLASS_VERSION_MI, CLASS_VERSION_NAME);
}

void class_extern_computeN(){
	//Computes the number of variables in the formula.
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	#endif

	MAIN_SET_FATT_N(f.n_initial);
	#ifdef VERBOSE_CLASS
	printf("N[%d] ", MAIN_GET_FATT_N());
	#endif

	#ifdef COLLECTSTATS
	++stats_class_component_totalCalls;
	stats_class_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void class_extern_computeM(){
	//Computes the number of clauses in the formula.
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	#endif

	MAIN_SET_FATT_M(f.m_initial);
	#ifdef VERBOSE_CLASS
	printf("M[%d] ", MAIN_GET_FATT_M());
	#endif

	#ifdef COLLECTSTATS
	++stats_class_component_totalCalls;
	stats_class_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void class_extern_computeR(){
	//Computes the formula clauses to variables ratio.
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	#endif

	float_ty r = ((float_ty)f.m_initial) / ((float_ty)f.n_initial);
	MAIN_SET_FATT_R(r);
	#ifdef VERBOSE_CLASS
	printf("R[%f] ", MAIN_GET_FATT_R());
	#endif

	#ifdef COLLECTSTATS
	++stats_class_component_totalCalls;
	stats_class_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void class_extern_computeInitAss(){
	//Computes how many assignments have been made because of initial unit clauses.
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	#endif

	uint32_t i, result = 0;
	for (i = 1; i < f.n_initial+1; ++i){
		if (!IS_VAR_UNASSIGNED((main_varData + i))){
			++result;
		}
	}

	MAIN_SET_FATT_INITASS(result);
	#ifdef VERBOSE_CLASS
	printf("INITASS[%d] ", MAIN_GET_FATT_INITASS());
	#endif

	#ifdef COLLECTSTATS
	++stats_class_component_totalCalls;
	stats_class_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void class_extern_computeMinMaxClsSize(){
	//Computes how many assignments have been made because of initial unit clauses.
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	#endif

	uint32_t i, min = UINT32_MAX, max = 0;
	clause *c;
	for (i = 0; i < f.m_eo_used; ++i){
		c = f.clauses_eo[i];
		if (GET_CLS_SIZE(c) < min) min = GET_CLS_SIZE(c);
		if (GET_CLS_SIZE(c) > max) max = GET_CLS_SIZE(c);
	}

	MAIN_SET_FATT_MINCLSSIZE(min);
	MAIN_SET_FATT_MAXCLSSIZE(max);
	#ifdef VERBOSE_CLASS
	printf("MINCLSSIZE[%d] MAXCLSSIZE[%d] ", MAIN_GET_FATT_MINCLSSIZE(), MAIN_GET_FATT_MAXCLSSIZE());
	#endif

	#ifdef COLLECTSTATS
	++stats_class_component_totalCalls;
	stats_class_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}
