/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#ifndef CLASS_H_
#define CLASS_H_

#include "../classify.h"

#define CLASS_VERSION_MA 0
#define CLASS_VERSION_MI 205
#define CLASS_VERSION_NAME "CLASS"

//Global variables and Macros of the CLASS module.
int32_t class_returnCode;					//The return code of the CLASS module.

//Methods exclusively accessible to the CLASS module (INTERN).

//Methods PROVIDED by the module.
void class_extern_printVersion();			//Prints the version of this module.
void class_extern_computeN();				//Computes the number of variables in the formula.
void class_extern_computeM();				//Computes the number of clauses in the formula.
void class_extern_computeR();				//Computes the formula clauses to variables ratio.
void class_extern_computeInitAss();			//Computes how many assignments have been made because of initial unit clauses.
void class_extern_computeMinMaxClsSize();	//Computes the minimum and maximum clause size.

//The following methods are used to initialize this module (called by the one who wants to use the external methods).
void class_resetModule();
void class_initModule();
void class_disposeModule();

#endif /* CLASS_H_ */
