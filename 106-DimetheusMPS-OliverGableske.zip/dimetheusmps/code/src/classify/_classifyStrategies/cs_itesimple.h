/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#ifndef CS_ITESIMPLE_H_
#define CS_ITESIMPLE_H_

#include "classifyStrategies.h"

void classify_strategy_itesimple_printHelp();			//Print the help.

void classify_strategy_itesimple_reset();
void classify_strategy_itesimple_init();
void classify_strategy_itesimple_dispose();

void classify_strategy_itesimple_execute();

#endif /* CS_ITESIMPLE_H_ */
