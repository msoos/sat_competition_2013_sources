/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */


#include "classifyStrategies.h"

void classify_strategy_itesimple_printHelp(){
	printf("c      %-3d: ITESIMPLE:\n", CLASSIFY_STRATEGY_ITESIMPLE);
    printf("c           Behavior: Computes simple formula attributes.\n");
}

void classify_strategy_itesimple_reset(){
	#ifdef VERBOSE_CLASSIFY
	printf("c   CLASSIFY: Strategy reset (ITESIMPLE)...\n");
	#endif

	class_resetModule();
}

void classify_strategy_itesimple_init(){
	#ifdef VERBOSE_CLASSIFY
	printf("c   CLASSIFY: Strategy init (ITESIMPLE)...\n");
	#endif

	class_initModule();
	if (class_returnCode != CLASS_UNKNOWN){
		classify_returnCode = CLASSIFY_ERROR;
		return;
	}
}

void classify_strategy_itesimple_dispose(){
	#ifdef VERBOSE_CLASSIFY
	printf("c   CLASSIFY: Strategy dispose (ITESIMPLE)...\n");
	#endif
	class_disposeModule();
}

void classify_strategy_itesimple_execute(){
	#ifdef VERBOSE_CLASSIFY
	printf("c   CLASSIFY: Strategy execute (ITESIMPLE)...\n");
	#endif

	#ifdef VERBOSE_CLASS
	printf("c     CLASS: ");
	uint32_t numMsg = 0;
	#endif

	class_extern_computeN();			 if (class_returnCode != CLASS_UNKNOWN) {classify_returnCode = CLASSIFY_ERROR; return;}
	#ifdef VERBOSE_CLASS
	if (++numMsg % 7 == 0) printf("\nc     CLASS: ");
	#endif

	class_extern_computeM(); 			if (class_returnCode != CLASS_UNKNOWN) {classify_returnCode = CLASSIFY_ERROR; return;}
	#ifdef VERBOSE_CLASS
	if (++numMsg % 7 == 0) printf("\nc     CLASS: ");
	#endif

	class_extern_computeR(); 			if (class_returnCode != CLASS_UNKNOWN) {classify_returnCode = CLASSIFY_ERROR; return;}
	#ifdef VERBOSE_CLASS
	if (++numMsg % 7 == 0) printf("\nc     CLASS: ");
	#endif

	class_extern_computeInitAss(); 		if (class_returnCode != CLASS_UNKNOWN) {classify_returnCode = CLASSIFY_ERROR; return;}
	#ifdef VERBOSE_CLASS
	if (++numMsg % 7 == 0) printf("\nc     CLASS: ");
	#endif

	class_extern_computeMinMaxClsSize();if (class_returnCode != CLASS_UNKNOWN) {classify_returnCode = CLASSIFY_ERROR; return;}
	#ifdef VERBOSE_CLASS
	if (++numMsg % 7 == 0) printf("\nc     CLASS: ");
	#endif

	MAIN_SET_FATT_ISSET(1);
	#ifdef VERBOSE_CLASS
	printf("\n");
	#endif
}

