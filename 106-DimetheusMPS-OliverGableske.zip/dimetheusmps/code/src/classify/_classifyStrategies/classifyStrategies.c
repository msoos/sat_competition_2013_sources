/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#include "classifyStrategies.h"

void classify_strategies_pointer_reset(){
	#ifdef VERBOSE_CLASSIFY
	printf("c   CLASSIFY: Resetting strategy pointers...\n");
	#endif
	classify_strategy_reset 			= &classify_strategy_null_reset;
	classify_strategy_init 				= &classify_strategy_null_init;
	classify_strategy_execute 			= &classify_strategy_null_execute;
	classify_strategy_dispose 			= &classify_strategy_null_dispose;
}

void classify_strategies_pointer_init(){
	#ifdef VERBOSE_CLASSIFY
	printf("c   CLASSIFY: Initializing strategy pointers...\n");
	#endif
	if (param_classifyStrategy == CLASSIFY_STRATEGY_TESTING){
		#ifdef VERBOSE_CLASSIFY
		printf("c   CLASSIFY: Classification strategy: %d, TESTING.\n", CLASSIFY_STRATEGY_TESTING);
		#endif
		classify_strategy_reset 			= &classify_strategy_testing_reset;
		classify_strategy_init 				= &classify_strategy_testing_init;
		classify_strategy_execute 			= &classify_strategy_testing_execute;
		classify_strategy_dispose 			= &classify_strategy_testing_dispose;
	} else if (param_classifyStrategy == CLASSIFY_STRATEGY_ITESIMPLE){
		#ifdef VERBOSE_CLASSIFY
		printf("c   CLASSIFY: Classification strategy: %d, ITESIMPLE.\n", CLASSIFY_STRATEGY_ITESIMPLE);
		#endif
		classify_strategy_reset 			= &classify_strategy_itesimple_reset;
		classify_strategy_init 				= &classify_strategy_itesimple_init;
		classify_strategy_execute 			= &classify_strategy_itesimple_execute;
		classify_strategy_dispose 			= &classify_strategy_itesimple_dispose;
	} else {
		#ifdef VERBOSE_CLASSIFY
		printf("c   CLASSIFY: Classification strategy: 0, NULL.\n");
		#endif
		classify_strategy_reset 			= &classify_strategy_null_reset;
		classify_strategy_init 				= &classify_strategy_null_init;
		classify_strategy_execute 			= &classify_strategy_null_execute;
		classify_strategy_dispose 			= &classify_strategy_null_dispose;
	}
}

void classify_strategies_pointer_dispose(){
	#ifdef VERBOSE_CLASSIFY
	printf("c   CLASSIFY: Disposing strategy pointers...\n");
	#endif
	classify_strategy_reset 			= &classify_strategy_null_reset;
	classify_strategy_init 				= &classify_strategy_null_init;
	classify_strategy_execute 			= &classify_strategy_null_execute;
	classify_strategy_dispose 			= &classify_strategy_null_dispose;
}

