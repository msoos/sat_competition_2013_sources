/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#ifndef CLASSIFY_H_
#define CLASSIFY_H_

#include "../dimetheus.h"
#include "_classifyStrategies/classifyStrategies.h"

//MODULES for the classification phase.
#include "CLASS/class.h"

//Global variables of the classification phase.
int32_t classify_returnCode;	//The return code of the classification phase.

//Methods provided exclusively to this phase (INTERN).

//Methods PROVIDED by this phase (EXTERN).
void classify_extern_classify();	//Executes the classification on the current formula.


//Methods to initialize this phase (are called by the one who wants to execute the above functions).
void classify_resetPhase();				//Reset the classification.
void classify_initPhase();				//For the classification.
void classify_disposePhase();			//For freeing all related memory.

#endif /* CLASSIFY_H_ */
