/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#ifndef CLASSIFY_C_
#define CLASSIFY_C_

#include "classify.h"

void classify_extern_classify(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_classify_component_totalCalls;
	#endif

	if (param_classifyStrategy != CLASSIFY_STRATEGY_NULL){
		#ifdef VERBOSE_CLASSIFY
		printf("c   CLASSIFY: CLASSIFICATION...\n");fflush(stdout);
		#endif

		classify_strategy_reset();
		classify_strategy_init();
		if (classify_returnCode == CLASSIFY_UNKNOWN){
			classify_strategy_execute();
		}
		classify_strategy_dispose();
		#ifdef VERBOSE_CLASSIFY
		printf("c   CLASSIFY: Done with classification.\n");fflush(stdout);
		#endif
	}

	if (classify_returnCode == CLASSIFY_UNKNOWN){
		#ifdef VERBOSE_CLASSIFY
		printf("c   CLASSIFY: ATTRIBUTES: ");formula_printAtt();printf("\n");
		#endif
	}

	#ifdef COLLECTSTATS
	stats_classify_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void classify_resetPhase(){
	#ifdef VERBOSE_CLASSIFY
	printf("c   CLASSIFY: RESET...\n");
	#endif
	//Reset the classification.
	classify_returnCode = CLASSIFY_UNKNOWN;
	classify_strategies_pointer_reset();
}

void classify_initPhase(){
	//Initialize the classification.
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	#endif

	#ifdef VERBOSE_CLASSIFY
	printf("c   CLASSIFY: INITIALIZE...\n");
	#endif
	classify_returnCode = CLASSIFY_UNKNOWN;
	classify_strategies_pointer_init();

	#ifdef COLLECTSTATS
	stats_classify_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void classify_disposePhase(){
	#ifdef VERBOSE_CLASSIFY
	printf("c   CLASSIFY: DISPOSE...\n");
	#endif
	//For freeing all classification related memory.

	classify_returnCode = CLASSIFY_UNKNOWN;
	classify_strategies_pointer_dispose();
}

#endif /* CLASSIFY_C_ */
