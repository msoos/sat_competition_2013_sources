/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 *
 *  The following disclaimer is stated only once, but is applicable for
 * 	all files contained in the BOSSLS project:
 *
 *  This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation, version 3. This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details. You should have received a copy of the GNU General Public License along with
 *  this program. If not, see <http://www.gnu.org/licenses/>.
 */

#include "dimetheus.h"

void main_handle_signal(int signal) {
    printf("c\nc SIGNAL %d RECEIVED.\nc DISPOSING ALL AND SHUTTING DOWN...\nc\n", signal);
    main_returnCode = SIGNAL;

	main_printResult();

	prep_strategy_dispose();
	search_strategy_dispose();
	inp_strategy_dispose();
	classify_strategy_dispose();
	adapt_strategy_dispose();

	prep_disposePhase();
	inp_disposePhase();
	search_disposePhase();
	classify_disposePhase();
	adapt_disposePhase();

	main_shutdown();
    fflush(stdout);
    exit(main_returnCode);
}

void main_resetAll(){
	printf("c RESET...\n");
	#ifdef COLLECTSTATS
	stats_reset();
	#endif
	#ifdef SCORING
	scoring_reset();
	#endif
	#ifdef VERBOSE
	printf("c   Enabled flags miscellaneous: VERBOSE ");
	#ifdef COLLECTSTATS
	printf("COLLECTSTATS ");
	#endif
	#ifdef SCORING
	printf("SCORING ");
	#endif
	#ifdef NEWSCHOOLRAND
	printf("NEWSCHOOLRAND ");
	#endif
	printf("\nc   Enabled phase flags: ");
	#ifdef VERBOSE_GUIDE
	printf("VERBOSE_GUIDE ");
	#endif
	#ifdef VERBOSE_CLASSIFY
	printf("VERBOSE_CLASSIFY ");
	#endif
	#ifdef VERBOSE_ADAPT
	printf("VERBOSE_ADAPT ");
	#endif
	#ifdef VERBOSE_PREP
	printf("VERBOSE_PREP ");
	#endif
	#ifdef VERBOSE_SEARCH
	printf("VERBOSE_SEARCH ");
	#endif
	#ifdef VERBOSE_INP
	printf("VERBOSE_INP ");
	#endif
	printf("\nc   Enabled module flags: ");
	#ifdef VERBOSE_CLASS
	printf("VERBOSE_CLASS ");
	#endif
	#ifdef VERBOSE_ITEADAPTER
	printf("VERBOSE_ITEADAPTER ");
	#endif
	#ifdef VERBOSE_PRE
	printf("VERBOSE_PRE ");
	#endif
	#ifdef VERBOSE_IN
	printf("VERBOSE_IN ");
	#endif
	#ifdef VERBOSE_MP
	printf("VERBOSE_MP ");
	#endif
	#ifdef VERBOSE_SLS
	printf("VERBOSE_SLS ");
	#endif
	#ifdef VERBOSE_CDCL
	printf("VERBOSE_CDCL ");
	#endif
	printf("\n");
	printf("c   Data structures memory size in bits:\n");
	printf("c     Size of address data-type:             %d\n", (int32_t) (8*sizeof(int32_t*)));
	printf("c     Size of long data-type:                %d\n", (int32_t) (8*sizeof(int64_t)));
	printf("c     Size of floating point data-type:      %d\n", (int32_t) (8*sizeof(float_ty)));
	printf("c     Size of clause data-type:              %d\n", (int32_t) (8*sizeof(clause)));
	printf("c     Size of removed clause data-type:      %d\n", (int32_t) (8*sizeof(remClause)));
	printf("c     Size of variable data-type:            %d\n", (int32_t) (8*sizeof(variable)));
	printf("c     Size of literal data-type:             %d\n", (int32_t) (8*sizeof(literal)));
	printf("c     Size of CNF data-type:                 %d\n", (int32_t) (8*sizeof(CNF)));
	printf("c   Limits/constants:\n");
	printf("c     Maximum number of variables supported: %u\n", VAR_OFFSET_MASK);
	printf("c     Maximum number of clauses supported:   %u\n", CLS_OFFSET_MASK);
	printf("c     RANDMAX = %u\n", RANDMAX);
	printf("c     OORANDMAX = 1.0/RANDMAX: %1.32f\n", OORANDMAX);
	printf("c   Signal handler and return code...\n");
	#endif
	signal(SIGTERM, &main_handle_signal);
	signal(SIGINT, &main_handle_signal);
	signal(SIGABRT, &main_handle_signal);
	//We reset the return-code of the solver, that represents the state we are currently in.
	main_returnCode = UNKNOWN;
	#ifdef VERBOSE
	printf("c   Parameters...\n");
	#endif
	params_resetAll();
	#ifdef VERBOSE
	printf("c   Random number generator...\n");
	#endif
	srand(param_seed);
	rand_reset();
	#ifdef VERBOSE
	printf("c   Data-structures...\n");
	#endif
	formula_reset();
	variables_reset();
	literals_reset();
	clauses_reset();
	main_simpleUP_reset();
	main_complexup_reset();
	main_decStack_reset();
	cQ_reset();
	cS_reset();
	lQ_reset();
	lS_reset();
	vQ_reset();
	vS_reset();
	#ifdef VERBOSE
	printf("c   Guide...\n");
	#endif
	main_guide_apply = &main_guide_manual_apply;
	#ifdef VERBOSE
	printf("c   Phases...\n");
	#endif
	classify_resetPhase();
	adapt_resetPhase();
	prep_resetPhase();
	search_resetPhase();
	inp_resetPhase();

	#ifdef VERBOSE
	printf("c\n");fflush(stdout);
	#endif
}

void main_printSolverHeader(){
	printf("c DIMETHEUS SAT Solver\n"
			"c   Version: %d.%d.%d\n"
			"c   Author:  Oliver Gableske (oliver@gableske.net)\n"
			"c   License: See license.txt for details -- contact the author if the file is missing\n"
			"c   Website: https://www.gableske.net/dimetheus\n"
			"c\n", VERSION_MA, VERSION_MI, VERSION_RE);
}

void main_startup(){
	printf("c STARTUP...\n");
	//INITIALIZE ALL MAIN ALGORITHM DATA-STRUCTURES.
	#ifdef VERBOSE
	printf("c   Random number generator...\n");
	#endif
	srand(param_seed);
	rand_init();
	#ifdef VERBOSE
	printf("c     ");rand_printConfig_inline();printf("\n");
	printf("c   Main algorithm data-structures...\n");
	#endif
	formula_loadHeader();	if (main_returnCode != UNKNOWN){ return; }
	#ifdef COLLECTSTATS
	stats_init();			if (main_returnCode != UNKNOWN){ return; }
	#endif
	#ifdef SCORING
	scoring_init();			if (main_returnCode != UNKNOWN){ return; }
	#endif
	formula_init();			if (main_returnCode != UNKNOWN){ return; }
	variables_init();		if (main_returnCode != UNKNOWN){ return; }
	literals_init();		if (main_returnCode != UNKNOWN){ return; }
	main_simpleUP_init();	if (main_returnCode != UNKNOWN){ return; }
	main_decStack_init();	if (main_returnCode != UNKNOWN){ return; }
	main_complexup_init();	if (main_returnCode != UNKNOWN){ return; }
	clauses_init();			if (main_returnCode != UNKNOWN){ return; }
	cQ_init();				if (main_returnCode != UNKNOWN){ return; }
	cS_init();				if (main_returnCode != UNKNOWN){ return; }
	lQ_init();				if (main_returnCode != UNKNOWN){ return; }
	lS_init();				if (main_returnCode != UNKNOWN){ return; }
	vQ_init();				if (main_returnCode != UNKNOWN){ return; }
	vS_init();				if (main_returnCode != UNKNOWN){ return; }

	#ifdef VERBOSE
	printf("c   Closing formula file...\n");
	#endif
	fclose(param_formula);

	#ifdef VERBOSE
	printf("c   Initial unit Propagation...\n");
	#endif
	clause* c = main_simpleUP_propagate_final();
	if (c != NULL){
		#ifdef VERBOSE
		printf("c     The initial unit propagation ran into a conflict in clause %p.\n", (void*)c);
		#endif
		main_returnCode = UNSAT;
	} else if (f.m_eo_used + f.m_el_used == 0){
		#ifdef VERBOSE
		printf("c     There are no further enabled clauses. We found a satisfying assignment.\n");
		#endif
		main_returnCode = SAT;
	} else {
		#ifdef VERBOSE
		printf("c     CNF has %d variables and %d clauses remaining.\n", f.n_vars_e_used, f.m_eo_used);
		#endif
	}
	if (main_returnCode != UNKNOWN) return;

	#ifdef VERBOSE
	printf("c   Resetting the fundamental variable activities and phases based on occurrences.\n");
	#endif
	variables_resetActivitiesAndPhases();

	#ifdef VERBOSE
	printf("c\n");fflush(stdout);
	#endif
}

void main_guide(int argc, char** argv){
	printf("c GUIDE...\n");
	main_guides_pointer_init();
	#ifdef VERBOSE
	printf("c   Applying guide...\n");
	#endif
	main_guide_apply(argc, argv);
	#ifdef VERBOSE
	printf("c\n");fflush(stdout);
	#endif
	#ifdef COLLECTSTATS
	stats_main_time_init = STATS_GET_CURRENT_TIME_IN_SEC();
	#endif
}

void main_classify(){
	printf("c CLASSIFY...\n");
	classify_initPhase();
	if (main_returnCode == UNKNOWN) {
		classify_extern_classify();
	}
	if (classify_returnCode == CLASSIFY_ERROR){
		main_returnCode = ERROR;
	} else if (classify_returnCode == CLASSIFY_UNKNOWN){
		main_returnCode = UNKNOWN;
	}
	classify_disposePhase();
	#ifdef VERBOSE
	printf("c\n");fflush(stdout);
	#endif
}

void main_adapt(){
	printf("c ADAPT...\n");
	adapt_initPhase();
	if (main_returnCode == UNKNOWN) {
		adapt_extern_adaptation();
	}
	if (adapt_returnCode == CLASSIFY_ERROR){
		main_returnCode = ERROR;
	} else if (adapt_returnCode == CLASSIFY_UNKNOWN){
		main_returnCode = UNKNOWN;
	}
	adapt_disposePhase();
	#ifdef VERBOSE
	printf("c\n");fflush(stdout);
	#endif
}

void main_preprocess(){
	printf("c PREPROCESS...\n");
	prep_initPhase();
	if (main_returnCode == UNKNOWN) {
		prep_extern_preprocessing();
	}
	if (prep_returnCode == PREP_ERROR){
		main_returnCode = ERROR;
	} else if (prep_returnCode == PREP_UNSAT){
		main_returnCode = UNSAT;
	} else if (prep_returnCode == PREP_SAT){
		main_returnCode = SAT;
	} else if (prep_returnCode == PREP_UNKNOWN){
		main_returnCode = UNKNOWN;
	}
	prep_disposePhase();
	#ifdef VERBOSE
	printf("c\n");fflush(stdout);
	#endif
}

void main_search(){
	printf("c SEARCH...\n");
	search_initPhase();
	if (param_searchStrategy != SEARCH_STRATEGY_NULL && main_returnCode == UNKNOWN) {
		search_extern_searching();
	}
	if (search_returnCode == SEARCH_ERROR){
		main_returnCode = ERROR;
	} else if (search_returnCode == SEARCH_UNSAT){
		main_returnCode = UNSAT;
	} else if (search_returnCode == SEARCH_SAT){
		main_returnCode = SAT;
	} else if (search_returnCode == SEARCH_UNKNOWN){
		main_returnCode = UNKNOWN;
	}
	search_disposePhase();
	#ifdef VERBOSE
	printf("c\n");fflush(stdout);
	#endif
}

int32_t main_verifyResultSAT(){
	int32_t i, j, isSat, lit;
	clause *c;
	remClause *rc;
	//This method will walk through all the original clauses (enabled and disabled ones) and check that it finds at least
	//one satisfied literal in all of them. It furthermore checks that all removed clauses are satisfied as well.
	for (i = 0; i < f.m_eo_used; ++i){
		c = f.clauses_eo[i];
		isSat = 0;
		for (j = 0; j < c->size; ++j){
			lit = c->lits[j];
			if (IS_LIT_SAT(lit)){
				++isSat;
				break;
			}
		}
		if (!isSat) {
			printf("c ERROR. Solution fails verification. Enabled clause %p is not satisfied.\n", (void*)c);
			#ifdef VERBOSE
			clauses_printClause(c);
			#endif
			main_returnCode = ERROR;
			return 0;
		}
	}

	for (i = 0; i < f.m_do_used; ++i){
		c = f.clauses_do[i];
		isSat = 0;
		for (j = 0; j < c->size; ++j){
			lit = c->lits[j];
			if (IS_LIT_SAT(lit)){
				++isSat;
				break;
			}
		}
		if (!isSat) {
			printf("c ERROR. Solution fails verification. Disabled clause %p is not satisfied.\n", (void*)c);
			#ifdef VERBOSE
			clauses_printClause(c);
			#endif
			main_returnCode = ERROR;
			return 0;
		}
	}

	for (i = 0; i < f.m_rem_used; ++i){
		rc = f.clauses_rem[i];
		isSat = 0;
		for (j = 0; j < rc->size; ++j){
			lit = rc->lits[j];
			if (IS_LIT_SAT(lit)){
				++isSat;
				break;
			}
		}
		if (!isSat) {
			printf("c ERROR. Solution fails verification. Removed clause %p is not satisfied.\n", (void*)rc);
			#ifdef VERBOSE
			clauses_printRemClause(rc);
			#endif
			main_returnCode = ERROR;
			return 0;
		}
	}

	#ifdef VERBOSE
	printf("c Solution verified.\n");
	#endif

	//Otherwise, all clauses seem to be satisfied.
	return 1;
}

void main_printAssignments(){
	//This method prints all the assignments of assigned variables.
	int32_t i;
	variable* v;
	printf("v ");
	for (i = 1; i <= f.n_initial; ++i){
		v = main_varData + i;
		if (IS_VAR_UNASSIGNED(v)){
			continue;
		} else {
			if (IS_VAR_TRUE(v)){
				printf("%d ", i);
			} else {
				printf("-%d ", i);
			}
		}
	}
	printf("0\n");
}

void main_printResult(){
	#ifdef SCORING
	scoring_print();
	#endif
	if (main_returnCode == ERROR
			|| main_returnCode == UNKNOWN
			|| main_returnCode == SIGNAL
			|| main_returnCode == CONFLICTINGPARAMS
			|| main_returnCode == BADPARAM
			|| main_returnCode == BADFORMULA){
		//There can be no useful result available.
		printf("s UNKNOWN\n");
	} else if (main_returnCode == UNSAT){
		//Unsatisfiable. No solution verification available for now.
		printf("s UNSATISFIABLE\n");
	} else if (main_returnCode == SAT){
		//We must assign all not yet assigned variables in order to get a complete assignment for the formula.
		variables_assignRemainingVars();
		//The preprocessor gets its turn to reconstruct a satisfying assignment from it, if necessary.
		prep_extern_reconstructSolution();
		if (main_returnCode == ERROR){
			printf("s UNKNOWN\n");
			return;
		}

		//Verify the result and output accordingly.
		if (main_verifyResultSAT()){
			printf("s SATISFIABLE\n");
			if (param_printAssignment){
				main_printAssignments();
			} else {
				printf("c SOLUTION OMITTED (-printAssignment 0 was used).\n");
			}

		} else {
			printf("s UNKNOWN\n");
			printf("c Solution would have been: ");main_printAssignments();
		}
	}
	printf("c\n");

	#ifdef COLLECTSTATS
	stats_print();
	#endif
}

void main_shutdown(){
	printf("c SHUTDOWN...\n");fflush(stdout);
	#ifdef COLLECTSTATS
	stats_dispose();
	#endif
	#ifdef SCORING
	scoring_dispose();
	#endif
	vS_dispose();
	vQ_dispose();
	lS_dispose();
	lQ_dispose();
	cS_dispose();
	cQ_dispose();
	main_simpleUP_dispose();
	main_complexup_dispose();
	main_decStack_dispose();
	variables_dispose();
	literals_dispose();
	clauses_dispose();
	formula_dispose();

	if (main_returnCode == ERROR
			|| main_returnCode == CONFLICTINGPARAMS
			|| main_returnCode == BADPARAM
			|| main_returnCode == BADFORMULA) {
		printf("c TERMINATING WITH ERRORS(%d).\n", main_returnCode);
	}
	if (main_returnCode == SIGNAL) {
		printf("c TERMINATING ON SIGNAL.\n");
	}

	#ifdef VERBOSE
	if (main_returnCode == SAT){
		printf("c TERMINATING WITH RESULT SAT.\n");
	} else if (main_returnCode == UNSAT){
		printf("c TERMINATING WITH RESULT UNSAT.\n");
	} else if (main_returnCode == UNKNOWN){
		printf("c TERMINATING WITH RESULT UNKNOWN.\n");
	}
	#endif
	printf("c ALL DONE.\n");
}

int32_t main(int argc, char** argv){
	main_printSolverHeader();
	params_readSpecial(argc,argv);
	if (main_returnCode == UNKNOWN) main_resetAll();
	if (main_returnCode == UNKNOWN) params_readAll(argc,argv);

	if (main_returnCode == UNKNOWN){
		main_startup();

		if (main_returnCode == UNKNOWN) main_guide(argc,argv);
		if (main_returnCode == UNKNOWN)	main_classify();
		if (main_returnCode == UNKNOWN)	main_adapt();
		if (main_returnCode == UNKNOWN)	main_preprocess();
		if (main_returnCode == UNKNOWN) main_search();

		main_printResult();
		main_shutdown();
	}

	return main_returnCode;
}
