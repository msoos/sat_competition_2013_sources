/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#ifndef PARAMETERS_H_
#define PARAMETERS_H_

#include "dimetheus.h"

//Main algorithm related.
FILE *param_formula;					//The file containing the formula in DIMACS CNF INPUT format.
void params_readFormulaFile(int,char**,int32_t);
int32_t param_seed;						//The seed for the random number generator.
#define PARAM_DEFAULT_SEED 101
void params_readSeed(int, char**, int32_t);
int32_t param_printAssignment;			//Set this to 0 if you do not want to output the satisfying assignment if one was found.
#define PARAM_DEFAULT_PRINTASSIGNMENT 1
void params_readPrintAssignment(int, char**, int32_t);
int32_t param_guide;					//This is the selector for one of the guides. Check guides/guides.h for values.
#define PARAM_DEFAULT_GUIDE 5
void params_readGuide(int, char**, int32_t);

//Classification related.
int32_t param_classifyStrategy;			//The classification strategy that is used.
#define PARAM_DEFAULT_CLASSIFYSTRATEGY 1
void params_readClassifyStrategy(int, char**, int32_t);

//Adaption related.
int32_t param_adaptAssumeRandom;		//Tells the adaptation strategy to assume a random instance no matter what.
#define PARAM_DEFAULT_ADAPTASSUMERANDOM 0
void params_readAdaptAssumeRandom(int, char**, int32_t);
int32_t param_adaptStrategy;			//The adaptation strategy that is used.
#define PARAM_DEFAULT_ADAPTSTRATEGY 1
void params_readAdaptStrategy(int, char**, int32_t);
int32_t param_adaptPrepStrategy;		//If adapting the preprocessing strategy is allowed.
#define PARAM_DEFAULT_ADAPTPREPSTRATEGY 0
void params_readAdaptPrepStrategy(int, char**, int32_t);
int32_t param_adaptPrepStrategyParams;	//If adapting the preprocessing strategy parameters is allowed.
#define PARAM_DEFAULT_ADAPTPREPSTRATEGYPARAMS 0
void params_readAdaptPrepStrategyParams(int, char**, int32_t);
int32_t param_adaptInpStrategy;		//If adapting the in-processing strategy is allowed.
#define PARAM_DEFAULT_ADAPTINPSTRATEGY 0
void params_readAdaptInpStrategy(int, char**, int32_t);
int32_t param_adaptInpStrategyParams;	//If adapting the in-processing strategy is allowed.
#define PARAM_DEFAULT_ADAPTINPSTRATEGYPARAMS 0
void params_readAdaptInpStrategyParams(int, char**, int32_t);
int32_t param_adaptSearchStrategy;		//If adapting the search strategy is allowed.
#define PARAM_DEFAULT_ADAPTSEARCHSTRATEGY 0
void params_readAdaptSearchStrategy(int, char**, int32_t);
int32_t param_adaptSearchStrategyParams;	//If adapting the search strategy parameters is allowed.
#define PARAM_DEFAULT_ADAPTSEARCHSTRATEGYPARAMS 0
void params_readAdaptSearchStrategyParams(int, char**, int32_t);
int32_t param_adaptMpUR;				//If adapting the MP UR is allowed.
#define PARAM_DEFAULT_ADAPTMPUR 0
void params_readAdaptMpUR(int, char**, int32_t);
int32_t param_adaptMpURParams;			//If adapting the MP UR parameters is allowed.
#define PARAM_DEFAULT_ADAPTMPURPARAMS 0
void params_readAdaptMpURParams(int, char**, int32_t);
int32_t param_adaptSlsPAFVR;			//If adapting the SLS PAFVR is allowed.
#define PARAM_DEFAULT_ADAPTSLSPAFVR 0
void params_readAdaptSlsPAFVR(int, char**, int32_t);
int32_t param_adaptSlsPAFVRParams;		//If adapting the SLS PAFVR parameters is allowed.
#define PARAM_DEFAULT_ADAPTSLSPAFVRPARAMS 0
void params_readAdaptSlsPAFVRParams(int, char**, int32_t);
int32_t param_adaptSlsAI;				//If adapting the SLS AI is allowed.
#define PARAM_DEFAULT_ADAPTSLSAI 0
void params_readAdaptSlsAI(int, char**, int32_t);
int32_t param_adaptSlsAIParams;			//If adapting the SLS AI parameters is allowed.
#define PARAM_DEFAULT_ADAPTSLSAIPARAMS 0
void params_readAdaptSlsAIParams(int, char**, int32_t);
int32_t param_adaptCdclSVR;				//If adapting the CDCL SVR is allowed.
#define PARAM_DEFAULT_ADAPTCDCLSVR 0
void params_readAdaptCdclSVR(int, char**, int32_t);
int32_t param_adaptCdclSVRParams;		//If adapting the CDCL SVR parameters is allowed.
#define PARAM_DEFAULT_ADAPTCDCLSVRPARAMS 0
void params_readAdaptCdclSVRParams(int, char**, int32_t);
int32_t param_adaptCdclSVAI;			//If adapting the CDCL SVAI is allowed.
#define PARAM_DEFAULT_ADAPTCDCLSVAI 0
void params_readAdaptCdclSVAI(int, char**, int32_t);
int32_t param_adaptCdclSVAIParams;		//If adapting the CDCL SVAI parameters is allowed.
#define PARAM_DEFAULT_ADAPTCDCLSVAIPARAMS 0
void params_readAdaptCdclSVAIParams(int, char**, int32_t);
int32_t param_adaptCdclSDR;				//If adapting the CDCL SDR is allowed.
#define PARAM_DEFAULT_ADAPTCDCLSDR 0
void params_readAdaptCdclSDR(int, char**, int32_t);
int32_t param_adaptCdclSDRParams;		//If adapting the CDCL SDR parameters is allowed.
#define PARAM_DEFAULT_ADAPTCDCLSDRPARAMS 0
void params_readAdaptCdclSDRParams(int, char**, int32_t);
int32_t param_adaptCdclSDDI;			//If adapting the CDCL SDDI is allowed.
#define PARAM_DEFAULT_ADAPTCDCLSDDI 0
void params_readAdaptCdclSDDI(int, char**, int32_t);
int32_t param_adaptCdclSDDIParams;		//If adapting the CDCL SDDI parameters is allowed.
#define PARAM_DEFAULT_ADAPTCDCLSDDIPARAMS 0
void params_readAdaptCdclSDDIParams(int, char**, int32_t);
int32_t param_adaptCdclCAR;				//If adapting the CDCL CAR is allowed.
#define PARAM_DEFAULT_ADAPTCDCLCAR 0
void params_readAdaptCdclCAR(int, char**, int32_t);
int32_t param_adaptCdclCARParams;		//If adapting the CDCL CAR parameters is allowed.
#define PARAM_DEFAULT_ADAPTCDCLCARPARAMS 0
void params_readAdaptCdclCARParams(int, char**, int32_t);
int32_t param_adaptCdclSLR;				//If adapting the CDCL SLR is allowed.
#define PARAM_DEFAULT_ADAPTCDCLSLR 0
void params_readAdaptCdclSLR(int, char**, int32_t);
int32_t param_adaptCdclSLRParams;		//If adapting the CDCL SLS parameters is allowed.
#define PARAM_DEFAULT_ADAPTCDCLSLRPARAMS 0
void params_readAdaptCdclSLRParams(int, char**, int32_t);
int32_t param_adaptCdclSOR;				//If adapting the CDCL SOR is allowed.
#define PARAM_DEFAULT_ADAPTCDCLSOR 0
void params_readAdaptCdclSOR(int, char**, int32_t);
int32_t param_adaptCdclSORParams;		//If adapting the CDCL SOR parameters is allowed.
#define PARAM_DEFAULT_ADAPTCDCLSORPARAMS 0
void params_readAdaptCdclSORParams(int, char**, int32_t);
int32_t param_adaptCdclCBJLR;			//If adapting the CDCL CBJLR is allowed.
#define PARAM_DEFAULT_ADAPTCDCLCBJLR 0
void params_readAdaptCdclCBJLR(int, char**, int32_t);
int32_t param_adaptCdclCBJLRParams;		//If adapting the CDCL CBJLR parameters is allowed.
#define PARAM_DEFAULT_ADAPTCDCLCBJLRPARAMS 0
void params_readAdaptCdclCBJLRParams(int, char**, int32_t);
int32_t param_adaptCdclRR;				//If adapting the CDCL RR is allowed.
#define PARAM_DEFAULT_ADAPTCDCLRR 0
void params_readAdaptCdclRR(int, char**, int32_t);
int32_t param_adaptCdclRRParams;		//If adapting the CDCL RR parameters is allowed.
#define PARAM_DEFAULT_ADAPTCDCLRRPARAMS 0
void params_readAdaptCdclRRParams(int, char**, int32_t);
int32_t param_adaptCdclMRParams;		//If adapting the CDCL MR is allowed.
#define PARAM_DEFAULT_ADAPTCDCLMRPARAMS 0
void params_readAdaptCdclMRParams(int, char**, int32_t);
int32_t param_adaptCdclMR;				//If adapting the CDCL MR parameters is allowed.
#define PARAM_DEFAULT_ADAPTCDCLMR 0
void params_readAdaptCdclMR(int, char**, int32_t);
int32_t param_adaptCdclIR;				//If adapting the CDCL IR is allowed.
#define PARAM_DEFAULT_ADAPTCDCLIR 0
void params_readAdaptCdclIR(int, char**, int32_t);
int32_t param_adaptCdclIRParams;		//If adapting the CDCL IR parameters is allowed.
#define PARAM_DEFAULT_ADAPTCDCLIRPARAMS 0
void params_readAdaptCdclIRParams(int, char**, int32_t);
int32_t param_adaptCdclAR;				//If adapting the CDCL AR is allowed.
#define PARAM_DEFAULT_ADAPTCDCLAR 0
void params_readAdaptCdclAR(int, char**, int32_t);
int32_t param_adaptCdclARParams;		//If adapting the CDCL AR parameters is allowed.
#define PARAM_DEFAULT_ADAPTCDCLARPARAMS 0
void params_readAdaptCdclARParams(int, char**, int32_t);

//Preprocessor related.
FILE *param_prepOutput;					//The file containing the formula in DIMACS CNF INPUT format after preprocessing.
void params_readPrepOutput(int, char**, int32_t);
int32_t param_prepReviveCls;			//Bring back some of the removed clauses if the preprocessor terminates with UNKNOWN.
#define PARAM_DEFAULT_PREPREVIVECLS 1
void params_readPrepReviveCls(int, char**, int32_t);
int32_t param_prepACCEMax;				//Maximum literal occurrences allowed for the literal to be added to ACCE queue.
#define PARAM_DEFAULT_PREPACCEMAX 20
void params_readPrepACCEMax(int, char**, int32_t);
int32_t param_prepACCEMinClsSize;		//Minimum clause size for clauses to be checked by ACCE.
#define PARAM_DEFAULT_PREPACCEMINCLSSIZE 3
void params_readPrepACCEMinClsSize(int, char**, int32_t);
int32_t param_prepACCESaturate;			//Tells us if ACCE is to be performed until saturation.
#define PARAM_DEFAULT_PREPACCESATURATE 0
void params_readPrepACCESaturate(int, char**, int32_t);
int32_t param_prepNIVERMax;				//Maximum literal occurrences allowed for the variable to be added to NIVER queue.
#define PARAM_DEFAULT_PREPNIVERMAX 25
void params_readPrepNIVERMax(int, char**, int32_t);
int32_t param_prepATEMin;				//Minimum size of a clause that is to be checked by separate ATE.
#define PARAM_DEFAULT_PREPATEMIN 3
void params_readPrepATEMin(int, char**, int32_t);
int32_t param_prepGEMaxAONN;			//Maximum number of resolvents allowed when extracting an AND/OR/NAND/NOR gate in GE.
#define PARAM_DEFAULT_PREPGEMAXAONN 8
void params_readPrepGEMaxAONN(int, char**, int32_t);
int32_t param_prepGEMaxXOR;				//Maximum number of resolvents allowed to be added when extracting an XOR gate in GE.
#define PARAM_DEFAULT_PREPGEMAXXOR 10000
void params_readPrepGEMaxXOR(int, char**, int32_t);
int32_t param_prepTERNARYLitMax;		//Maximum number of resolvents for a literal in TERNARY resolution.
#define PARAM_DEFAULT_PREPTERNARYLITMAX 1000
void params_readPrepTERNARYLitMax(int, char**, int32_t);
int32_t param_prepTERNARYMax;			//Maximum number of resolvents total in a run of TERNARY resolution.
#define PARAM_DEFAULT_PREPTERNARYMAX 5000
void params_readPrepTERNARYMax(int, char**, int32_t);
int32_t param_prepNHBRMin;				//Minimum number of implications for a literal to be used in NHBR.
#define PARAM_DEFAULT_PREPNHBRMIN 10
void params_readPrepNHBRMin(int, char**, int32_t);
int32_t param_prepStrategy;				//The preprocessing strategy that is used.
#define PARAM_DEFAULT_PREPSTRATEGY 2
void params_readPrepStrategy(int, char**, int32_t);

//In-processor related.
int32_t param_inpStrMaxSize;			//The maximum size of a clause we do strengthening with.
#define PARAM_DEFAULT_INPSTRMAXSIZE 4
void params_readInpStrMaxSize(int, char**, int32_t);
int32_t param_inpTernaryLitMax;			//The maximum number of ternary clauses that can be learned with one literal.
#define PARAM_DEFAULT_INPTERNARYLITMAX 100
void params_readInpTernaryLitMax(int, char**, int32_t);
int32_t param_inpTernaryMax;			//The maximum number of ternary clauses that can be learned in total.
#define PARAM_DEFAULT_INPTERNARYMAX 1000
void params_readInpTernaryMax(int, char**, int32_t);
int32_t param_inpNiverMax;				//The maximum literal occurrence to check a variable with NIVER.
#define PARAM_DEFAULT_INPNIVERMAX 25
void params_readInpNiverMax(int, char**, int32_t);
int32_t param_inpGEMaxAONN;				//The maximum number of resolvents allowed when removing AND/OR/NAND/NOR gates in GE.
#define PARAM_DEFAULT_INPGEMAXAONN 8
void params_readInpGEMaxAONN(int, char**, int32_t);
int32_t param_inpGEMaxXOR;				//The maximum number of resolvents allowed when removing XOR gates in GE.
#define PARAM_DEFAULT_INPGEMAXXOR 10000
void params_readInpGEMaxXOR(int, char**, int32_t);
int32_t param_inpNHBRMin;				//The minimum number of implications a literal must have to be used in NHBR.
#define PARAM_DEFAULT_INPNHBRMIN 10
void params_readInpNHBRMin(int, char**, int32_t);
int32_t param_inpStrategy;				//The in-processing strategy that is used.
#define PARAM_DEFAULT_INPSTRATEGY 2
void params_readInpStrategy(int, char**, int32_t);

//Search related.
float_ty param_searchMIDBlockSize;		//The fraction of new variables we want to assign when doing MID.
#define PARAM_DEFAULT_SEARCHMIDBLOCKSIZE 0.05
void params_readSearchMIDBlockSize(int, char**, int32_t);
float_ty param_searchMinClsImpact;		//The minimum MP impact a learned clause must have such that it is retained.
#define PARAM_DEFAULT_SEARCHMINCLSIMPACT 0.333
void params_readSearchMinClsImpact(int, char**, int32_t);
float_ty param_searchImpactMaxFactor;	//The maximum impact of learned things before we disable MP until a new unit is learned.
#define PARAM_DEFAULT_SEARCHIMPACTMAXFACTOR 0.03
void params_readSearchImpactMaxFactor(int, char**, int32_t);
int32_t param_searchStrategy;			//The search strategy that is used.
#define PARAM_DEFAULT_SEARCHSTRATEGY 1
void params_readSearchStrategy(int, char**, int32_t);

//MP
int32_t param_mpMaxNumIterations;		//Maximum number of iterations in message passing before non-convergence is claimed.
#define PARAM_DEFAULT_MPMAXNUMITERATIONS 1000
void params_readMpMaxNumIterations(int, char**, int32_t);
float_ty param_mpMaxConvergenceDiff;	//Maximum allowed difference in any message update before convergence is claimed.
#define PARAM_DEFAULT_MPMAXCONVERGENCEDIFF 0.01
void params_readMpMaxConvergenceDiff(int, char**, int32_t);
float_ty param_mpMaxMagnetization;		//Maximum allowed magnetization to assume a paramagnetic state.
#define PARAM_DEFAULT_MPMAXMAGNETIZATION 0.01
void params_readMpMaxMagnetization(int, char**, int32_t);
float_ty param_mpEpsilon;				//The smallest allowed value before we take it as zero.
#define PARAM_DEFAULT_MPEPSILON 0.0000001
void params_readMpEpsilon(int, char**, int32_t);
float_ty param_mpRho;					//Controls the interpolation of BP (rho=0) and SP (rho=1).
#define PARAM_DEFAULT_MPRHO 0.98
void params_readMpRho(int, char**, int32_t);
float_ty param_mpSigma;					//Controls the interpolation of non-EM (sigma=0) and full-EM (sigma=1).
#define PARAM_DEFAULT_MPSIGMA 0.001
void params_readMpSigma(int, char**, int32_t);
int32_t param_mpUpdateRule;				//Determines what update rule to use in the next call to MP.
#define PARAM_DEFAULT_MPUPDATERULE 8
void params_readMpUpdateRule(int, char**, int32_t);

//SLS
float_ty param_slsMaxFlipsFactor;		//This multiplied with the number of variables determines the maximum flip number.
#define PARAM_DEFAULT_SLSMAXFLIPSFACTOR 100000.0f
void params_readSlsMaxFlipsFactor(int, char**, int32_t);
int32_t param_slsMaxTries;				//The maximum number of tries for the flip rule. Set zero for unlimited.
#define PARAM_DEFAULT_SLSMAXTRIES 0
void params_readSlsMaxTries(int, char**, int32_t);
float_ty param_slsNoise;				//A noise value that can be used in many occasions or pick variable rules.
#define PARAM_DEFAULT_SLSNOISE 0.5866f
void params_readSlsNoise(int, char**, int32_t);
float_ty param_slsProbsatCB;			//The brake base for the ProbSAT score computation.
#define PARAM_DEFAULT_SLSPROBSATCB 2.16f
void params_readSlsProbsatCB(int, char**, int32_t);
float_ty param_slsProbsatCBShift;		//The shift value for the brake values for the ProbSAT score computation.
#define PARAM_DEFAULT_SLSPROBSATCBSHIFT 1.0f
void params_readSlsProbsatCBShift(int, char**, int32_t);
int32_t param_slsPickAndFlipVarRule;	//Determines what variable picking and flipping implementation to use.
#define PARAM_DEFAULT_SLSPICKANDFLIPVARRULE 1
void params_readSlsPickAndFlipVarRule(int, char**, int32_t);
int32_t param_slsAssInitRule;			//Determines how to initialize the SLS starting assignment.
#define PARAM_DEFAULT_SLSASSINITRULE 0
void params_readSlsAssInitRule(int, char**, int32_t);

//CDCL
FILE *param_cdclOutput;					//The file containing the CDCL formula in DIMACS CNF INPUT format.
void params_readCdclOutput(int, char**, int32_t);
float_ty param_cdclRestartStagMaxFrac;	//The maximum stagnation fraction allowed for doing a restart.
#define PARAM_DEFAULT_CDCLRESTARTSTAGMAXFRAC 0.1
void params_readCdclRestartStagMaxFrac(int, char**, int32_t);
int32_t param_cdclRestartInnerouterInit;	//This is the base value for the inner/outer restart series.
#define PARAM_DEFAULT_CDCLRESTARTINNEROUTERINIT 100
void params_readCdclRestartInnerouterInit(int, char**, int32_t);
float_ty param_cdclRestartInnerouterInc;	//This is the increase factor for inner/outer restarts.
#define PARAM_DEFAULT_CDCLRESTARTINNEROUTERINC 1.1
void params_readCdclRestartInnerouterInc(int, char**, int32_t);
int32_t param_cdclRestartLubyUnit;		//This is the base value for the Luby restart series.
#define PARAM_DEFAULT_CDCLRESTARTLUBYUNIT 10
void params_readCdclRestartLubyUnit(int, char**, int32_t);
float_ty param_cdclRestartVarAgiIncBump;		//This is the value that bumps the variable agility increase.
#define PARAM_DEFAULT_CDCLRESTARTVARAGIINCBUMP 1.00010001
void params_readCdclRestartVarAgiIncBump(int, char**, int32_t);
float_ty param_cdclRestartMaxAgiFrac;		//The fraction of variables with high agility allowed when doing a restart.
#define PARAM_DEFAULT_CDCLRESTARTMAXAGIFRAC 0.20
void params_readCdclRestartMaxAgiFrac(int, char**, int32_t);
float_ty param_cdclRestartMaxAgiOutFrac;	//The fraction of variables with high agility allowed when doing an outer restart.
#define PARAM_DEFAULT_CDCLRESTARTMAXAGIOUTFRAC 0.25
void params_readCdclRestartMaxAgiOutFrac(int, char**, int32_t);
float_ty param_cdclSelectVarActIncBump;		//This is the value that bumps the variable activities increase.
#define PARAM_DEFAULT_CDCLSELECTVARACTINCBUMP 1.05
void params_readCdclSelectVarActIncBump(int, char**, int32_t);
int32_t param_cdclSelectVarActInit;		//Determines how the SVR plug-in initializes the variable activities.
#define PARAM_DEFAULT_CDCLSELECTVARACTINIT 1
void params_readCdclSelectVarActInit(int, char**, int32_t);
float_ty param_cdclSelectVarRandProb;	//Determines the probability of SVR plug-in to pick a random variable.
#define PARAM_DEFAULT_CDCLSELECTVARRANDPROB 0.001
void params_readCdclSelectVarRandProb(int, char**, int32_t);
int32_t param_cdclSelectDirMinFlipDist;	//Minimum decision distance for flipping a DL1 decision.
#define PARAM_DEFAULT_CDCLSELECTDIRMINFLIPDIST 1024
void params_readCdclSelectDirMinFlipDist(int, char**, int32_t);
int32_t param_cdclSelectDirDirInit;		//Determines how the SDR plug-in initializes the variable directions.
#define PARAM_DEFAULT_CDCLSELECTDIRDIRINIT 4
void params_readCdclSelectDirDirInit(int, char**, int32_t);
float_ty param_cdclMaintenanceMinDev;  //If scaled LBD standard deviation is below this value, we pick INACTIVITY instead.
#define PARAM_DEFAULT_CDCLMAINTENANCEMINDEV 0.10
void params_readCdclMaintenanceMinDev(int, char**, int32_t);
float_ty param_cdclMaintenanceMaxAvg;  //If scaled LBD average is above this value, we pick INACTIVITY instead.
#define PARAM_DEFAULT_CDCLMAINTENANCEMAXAVG 12.0
void params_readCdclMaintenanceMaxAvg(int, char**, int32_t);
float_ty param_cdclMaintenanceActIncBump;	//This is the value that bumps the clause activities increase.
#define PARAM_DEFAULT_CDCLMAINTENANCEACTINCBUMP 1.001
void params_readCdclMaintenanceActIncBump(int, char**, int32_t);
float_ty param_cdclMaintenanceInitial;  //This is the fraction of initial clauses that we want to learn before CDBM in INACTIVITY.
#define PARAM_DEFAULT_CDCLMAINTENANCEINITIAL 1.3
void params_readCdclMaintenanceInitial(int, char**, int32_t);
float_ty param_cdclMaintenanceIncrease;  //This bumps the number of learned clauses before we do the next CDBM in INACTIVITY.
#define PARAM_DEFAULT_CDCLMAINTENANCEINCREASE 1.1
void params_readCdclMaintenanceIncrease(int, char**, int32_t);
int32_t param_cdclMaintenanceBase;  //This is LBD-scheme number of clauses that we want to learn before CDBM.
#define PARAM_DEFAULT_CDCLMAINTENANCEBASE 20000
void params_readCdclMaintenanceBase(int, char**, int32_t);
int32_t param_cdclMaintenanceBoost;  //This bumps the number of learned clauses before we do the next CDBM in LBD.
#define PARAM_DEFAULT_CDCLMAINTENANCEBOOST 20000
void params_readCdclMaintenanceBoost(int, char**, int32_t);
int32_t param_cdclIRTERNARYLitMax;		//Maximum number of resolvents for a literal in TERNARY resolution.
#define PARAM_DEFAULT_CDCLIRTERNARYLITMAX 500
void params_readCdclIRTERNARYLitMax(int, char**, int32_t);
int32_t param_cdclIRTERNARYMax;			//Maximum number of resolvents total in a run of TERNARY resolution.
#define PARAM_DEFAULT_CDCLIRTERNARYMAX 1000
void params_readCdclIRTERNARYMax(int, char**, int32_t);
int32_t param_cdclIRNIVERMax;			//Maximum number of occurrences to check a variable with NIVER.
#define PARAM_DEFAULT_CDCLIRNIVERMAX 25
void params_readCdclIRNIVERMax(int, char**, int32_t);
int32_t param_cdclIRGEMaxAONN;			//Maximum number of new resolvents when removing an AND/OR/NAND/NOR gate in IR GE.
#define PARAM_DEFAULT_CDCLIRGEMAXAONN 8
void params_readCdclIRGEMaxAONN(int, char**, int32_t);
int32_t param_cdclIRGEMaxXOR;			//Maximum number of new resolvents when removing an XOR gate in IR GE.
#define PARAM_DEFAULT_CDCLIRGEMAXXOR 10000
void params_readCdclIRGEMaxXOR(int, char**, int32_t);
int32_t param_cdclIRStrMaxSize;			//Maximum clause size to use clause in strengthening.
#define PARAM_DEFAULT_CDCLIRSTRMAXSIZE 4
void params_readCdclIRStrMaxSize(int, char**, int32_t);
int32_t param_cdclIRNHBRMin;			//Minimum number of implications a literal must have to be used for NHBR.
#define PARAM_DEFAULT_CDCLIRNHBRMIN 10
void params_readCdclIRNHBRMin(int, char**, int32_t);
float_ty param_cdclIRMinConfDistance;	//This times the number of remaining variables gives the minimum conflict distance.
#define PARAM_DEFAULT_CDCLIRMINCONFDISTANCE 0.0
void params_readCdclIRMinConfDistance(int, char**, int32_t);
int32_t param_cdclSelectVarRule;		//Determines what variable selection implementation to use.
#define PARAM_DEFAULT_CDCLSELECTVARRULE 3
void params_readCdclSelectVarRule(int, char**, int32_t);
int32_t param_cdclSelectDirRule;		//Determines what variable direction selection implementation to use.
#define PARAM_DEFAULT_CDCLSELECTDIRRULE 3
void params_readCdclSelectDirRule(int, char**, int32_t);
int32_t param_cdclConflictAnalysisRule;	//Determines what conflict analysis implementation to use.
#define PARAM_DEFAULT_CDCLCONFLICTANALYSISRULE 1
void params_readCdclConflictAnalysisRule(int, char**, int32_t);
int32_t param_cdclStrLearnedRule;		//Determines what strengthen learned clauses implementation to use.
#define PARAM_DEFAULT_CDCLSTRLEARNEDRULE 5
void params_readCdclStrLearnedRule(int, char**, int32_t);
int32_t param_cdclStrOtherRule;			//Determines what strengthen other clauses implementation to use.
#define PARAM_DEFAULT_CDCLSTROTHERRULE 1
void params_readCdclStrOtherRule(int, char**, int32_t);
int32_t param_cdclComputeBJLRule;		//Determines what back-jump level computation implementation to use.
#define PARAM_DEFAULT_CDCLCOMPUTEBJLRULE 0
void params_readCdclComputeBJLRule(int, char**, int32_t);
int32_t param_cdclRestartRule;			//Determines what restart implementation to use.
#define PARAM_DEFAULT_CDCLRESTARTRULE 3
void params_readCdclRestartRule(int, char**, int32_t);
int32_t param_cdclMaintenanceRule;		//Determines what clause database maintenance implementation to use.
#define PARAM_DEFAULT_CDCLMAINTENANCERULE 4
void params_readCdclMaintenanceRule(int, char**, int32_t);
int32_t param_cdclInprocessingRule;		//Determines what in-processing implementation to use.
#define PARAM_DEFAULT_CDCLINPROCESSINGRULE 2
void params_readCdclInprocessingRule(int, char**, int32_t);
int32_t param_cdclAbortRule;		 //Determines what abort rule implementation to use.
#define PARAM_DEFAULT_CDCLABORTRULE 0
void params_readCdclAbortRule(int, char**, int32_t);

//Handling methods for reading the parameters and checking them.
uint32_t params_isBaseParam(char*);
void params_readUnsignedInteger(int, char**, int32_t , unsigned int*);
void params_readFloat(int, char**, int32_t, float*);
void params_readDouble(int, char**, int32_t, double*);
void params_printHelp();
void params_printVersion();
void params_resetAll();
void params_readSpecial(int, char**);
void params_readAll(int, char**);

#endif /* PARAMETERS_H_ */
