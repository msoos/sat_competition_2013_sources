/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#ifndef AS_ITERANDOM_H_
#define AS_ITERANDOM_H_

#include "adaptStrategies.h"

void adapt_strategy_iterandom_printHelp();	//Print the help.

void adapt_strategy_iterandom_reset();
void adapt_strategy_iterandom_init();
void adapt_strategy_iterandom_dispose();

void adapt_strategy_iterandom_execute();

#endif /* AS_ITERANDOM_H_ */
