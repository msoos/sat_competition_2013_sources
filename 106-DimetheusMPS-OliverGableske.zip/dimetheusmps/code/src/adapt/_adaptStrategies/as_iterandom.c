/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#include "adaptStrategies.h"

void adapt_strategy_iterandom_printHelp(){
	printf("c      %-3d: ITERANDOM:\n", ADAPT_STRATEGY_ITERANDOM);
    printf("c           Behavior: Uses the formula attributes to distinguish between random and non-random formulas.\n");
    printf("c           Adaption: Solver type; results in either SLS-based MID (random) or CDCL-based MID (non-random).\n");
}

void adapt_strategy_iterandom_reset(){
	#ifdef VERBOSE_ADAPT
	printf("c   ADAPT: Strategy reset (ITERANDOM)...\n");
	#endif

}

void adapt_strategy_iterandom_init(){
	#ifdef VERBOSE_ADAPT
	printf("c   ADAPT: Strategy init (ITERANDOM)...\n");
	#endif

}

void adapt_strategy_iterandom_dispose(){
	#ifdef VERBOSE_ADAPT
	printf("c   ADAPT: Strategy dispose (ITERANDOM)...\n");
	#endif

}

void adapt_strategy_iterandom_execute(){
	#ifdef VERBOSE_ADAPT
	printf("c   ADAPT: Strategy execute (ITERANDOM)...\n");
	#endif
	if (!MAIN_GET_FATT_ISSET()){
		#ifdef VERBOSE_ADAPT
		printf("c   ADAPT: Adaptation not possible, since the formula attributes have not been computed.\n");
		#endif
		return;
	}

	//Grab the formula attributes and determine if the instance is random or not.
	uint32_t isRandom = 0;
	uint32_t k = MAIN_GET_FATT_MAXCLSSIZE();
	uint32_t n = MAIN_GET_FATT_N();
	float_ty r = MAIN_GET_FATT_R();

	if (param_adaptAssumeRandom || MAIN_GET_FATT_MINCLSSIZE() == MAIN_GET_FATT_MAXCLSSIZE()){
		//We simply assume that the instance is random if its minimum and maximum clause sizes match.
		++isRandom;
	}

	if (isRandom){
		#ifdef VERBOSE_ADAPT
		printf("c   ADAPT: Strategy (ITERANDOM) identified the formula to be random.\n");
		#endif
		//We adapt everything for a random formula.
		//STRATEGIES
		if (param_adaptPrepStrategy) iteadapter_extern_prepStrategy_random(k, n, r);
		if (param_adaptPrepStrategyParams) iteadapter_extern_prepStrategyParams_random(k, n, r);
		if (param_adaptInpStrategy) iteadapter_extern_inpStrategy_random(k, n, r);
		if (param_adaptInpStrategyParams) iteadapter_extern_inpStrategyParams_random(k, n, r);
		if (param_adaptSearchStrategy) iteadapter_extern_searchStrategy_random(k, n, r);
		if (param_adaptSearchStrategyParams) iteadapter_extern_searchStrategyParams_random(k, n, r);

		//MODULES
		//PRE
		//Nothing to adapt yet.

		//IN
		//Nothing to adapt yet.

		//MP
		if (param_adaptMpUR) 			iteadapter_extern_mpUR_random(k, n, r);
		if (param_adaptMpURParams) 		iteadapter_extern_mpURParams_random(k, n, r);

		//SLS
		if (param_adaptSlsPAFVR)		iteadapter_extern_slsPAFVR_random(k, n, r);
		if (param_adaptSlsPAFVRParams)	iteadapter_extern_slsPAFVRParams_random(k, n, r);
		if (param_adaptSlsAI)			iteadapter_extern_slsAI_random(k, n, r);
		if (param_adaptSlsAIParams)		iteadapter_extern_slsAIParams_random(k, n, r);

		//CDCL
		if (param_adaptCdclSVR)			iteadapter_extern_cdclSVR_random(k, n, r);
		if (param_adaptCdclSVRParams)	iteadapter_extern_cdclSVRParams_random(k, n, r);
		if (param_adaptCdclSVAI)		iteadapter_extern_cdclSVAI_random(k, n, r);
		if (param_adaptCdclSVAIParams)	iteadapter_extern_cdclSVAIParams_random(k, n, r);
		if (param_adaptCdclSDR)			iteadapter_extern_cdclSDR_random(k, n, r);
		if (param_adaptCdclSDRParams)	iteadapter_extern_cdclSDRParams_random(k, n, r);
		if (param_adaptCdclSDDI)		iteadapter_extern_cdclSDDI_random(k, n, r);
		if (param_adaptCdclSDDIParams)	iteadapter_extern_cdclSDDIParams_random(k, n, r);
		if (param_adaptCdclCAR)			iteadapter_extern_cdclCAR_random(k, n, r);
		if (param_adaptCdclCARParams)	iteadapter_extern_cdclCARParams_random(k, n, r);
		if (param_adaptCdclSLR)			iteadapter_extern_cdclSLR_random(k, n, r);
		if (param_adaptCdclSLRParams)	iteadapter_extern_cdclSLRParams_random(k, n, r);
		if (param_adaptCdclSOR)			iteadapter_extern_cdclSOR_random(k, n, r);
		if (param_adaptCdclSORParams)	iteadapter_extern_cdclSORParams_random(k, n, r);
		if (param_adaptCdclCBJLR)		iteadapter_extern_cdclCBJLR_random(k, n, r);
		if (param_adaptCdclCBJLRParams)	iteadapter_extern_cdclCBJLRParams_random(k, n, r);
		if (param_adaptCdclRR)			iteadapter_extern_cdclRR_random(k, n, r);
		if (param_adaptCdclRRParams)	iteadapter_extern_cdclRRParams_random(k, n, r);
		if (param_adaptCdclMR)			iteadapter_extern_cdclMR_random(k, n, r);
		if (param_adaptCdclMRParams)	iteadapter_extern_cdclMRParams_random(k, n, r);
		if (param_adaptCdclIR)			iteadapter_extern_cdclIR_random(k, n, r);
		if (param_adaptCdclIRParams)	iteadapter_extern_cdclIRParams_random(k, n, r);
		if (param_adaptCdclAR)			iteadapter_extern_cdclAR_random(k, n, r);
		if (param_adaptCdclARParams)	iteadapter_extern_cdclARParams_random(k, n, r);
	} else {
		#ifdef VERBOSE_ADAPT
		printf("c   ADAPT: Strategy (ITERANDOM) identified the formula to be non-random.\n");
		#endif
		//We adapt everything for a non-random formula.
		//STRATEGIES
		if (param_adaptPrepStrategy) iteadapter_extern_prepStrategy_nonrandom();
		if (param_adaptPrepStrategyParams) iteadapter_extern_prepStrategyParams_nonrandom();
		if (param_adaptInpStrategy) iteadapter_extern_inpStrategy_nonrandom();
		if (param_adaptInpStrategyParams) iteadapter_extern_inpStrategyParams_nonrandom();
		if (param_adaptSearchStrategy) iteadapter_extern_searchStrategy_nonrandom();
		if (param_adaptSearchStrategyParams) iteadapter_extern_searchStrategyParams_nonrandom();

		//MODULES
		//PRE
		//Nothing to adapt yet.

		//IN
		//Nothing to adapt yet.

		//MP
		if (param_adaptMpUR) iteadapter_extern_mpUR_nonrandom();
		if (param_adaptMpURParams) iteadapter_extern_mpURParams_nonrandom();

		//SLS
		if (param_adaptSlsPAFVR)		iteadapter_extern_slsPAFVR_nonrandom();
		if (param_adaptSlsPAFVRParams)	iteadapter_extern_slsPAFVRParams_nonrandom();
		if (param_adaptSlsAI)			iteadapter_extern_slsAI_nonrandom();
		if (param_adaptSlsAIParams)		iteadapter_extern_slsAIParams_nonrandom();

		//CDCL
		if (param_adaptCdclSVR)			iteadapter_extern_cdclSVR_nonrandom();
		if (param_adaptCdclSVRParams)	iteadapter_extern_cdclSVRParams_nonrandom();
		if (param_adaptCdclSVAI)		iteadapter_extern_cdclSVAI_nonrandom();
		if (param_adaptCdclSVAIParams)	iteadapter_extern_cdclSVAIParams_nonrandom();
		if (param_adaptCdclSDR)			iteadapter_extern_cdclSDR_nonrandom();
		if (param_adaptCdclSDRParams)	iteadapter_extern_cdclSDRParams_nonrandom();
		if (param_adaptCdclSDDI)		iteadapter_extern_cdclSDDI_nonrandom();
		if (param_adaptCdclSDDIParams)	iteadapter_extern_cdclSDDIParams_nonrandom();
		if (param_adaptCdclCAR)			iteadapter_extern_cdclCAR_nonrandom();
		if (param_adaptCdclCARParams)	iteadapter_extern_cdclCARParams_nonrandom();
		if (param_adaptCdclSLR)			iteadapter_extern_cdclSLR_nonrandom();
		if (param_adaptCdclSLRParams)	iteadapter_extern_cdclSLRParams_nonrandom();
		if (param_adaptCdclSOR)			iteadapter_extern_cdclSOR_nonrandom();
		if (param_adaptCdclSORParams)	iteadapter_extern_cdclSORParams_nonrandom();
		if (param_adaptCdclCBJLR)		iteadapter_extern_cdclCBJLR_nonrandom();
		if (param_adaptCdclCBJLRParams)	iteadapter_extern_cdclCBJLRParams_nonrandom();
		if (param_adaptCdclRR)			iteadapter_extern_cdclRR_nonrandom();
		if (param_adaptCdclRRParams)	iteadapter_extern_cdclRRParams_nonrandom();
		if (param_adaptCdclMR)			iteadapter_extern_cdclMR_nonrandom();
		if (param_adaptCdclMRParams)	iteadapter_extern_cdclMRParams_nonrandom();
		if (param_adaptCdclIR)			iteadapter_extern_cdclIR_nonrandom();
		if (param_adaptCdclIRParams)	iteadapter_extern_cdclIRParams_nonrandom();
		if (param_adaptCdclAR)			iteadapter_extern_cdclAR_nonrandom();
		if (param_adaptCdclARParams)	iteadapter_extern_cdclARParams_nonrandom();
	}



}
