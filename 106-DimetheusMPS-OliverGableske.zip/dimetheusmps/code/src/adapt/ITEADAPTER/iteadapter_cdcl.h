/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#ifndef ITEADAPTER_CDCL_H_
#define ITEADAPTER_CDCL_H_

#include "iteadapter.h"

void iteadapter_extern_cdclSVR_random(uint32_t,uint32_t,float_ty);
void iteadapter_extern_cdclSVR_nonrandom();
void iteadapter_extern_cdclSVRParams_random(uint32_t,uint32_t,float_ty);
void iteadapter_extern_cdclSVRParams_nonrandom();

void iteadapter_extern_cdclSVAI_random(uint32_t,uint32_t,float_ty);
void iteadapter_extern_cdclSVAI_nonrandom();
void iteadapter_extern_cdclSVAIParams_random(uint32_t,uint32_t,float_ty);
void iteadapter_extern_cdclSVAIParams_nonrandom();

void iteadapter_extern_cdclSDR_random(uint32_t,uint32_t,float_ty);
void iteadapter_extern_cdclSDR_nonrandom();
void iteadapter_extern_cdclSDRParams_random(uint32_t,uint32_t,float_ty);
void iteadapter_extern_cdclSDRParams_nonrandom();

void iteadapter_extern_cdclSDDI_random(uint32_t,uint32_t,float_ty);
void iteadapter_extern_cdclSDDI_nonrandom();
void iteadapter_extern_cdclSDDIParams_random(uint32_t,uint32_t,float_ty);
void iteadapter_extern_cdclSDDIParams_nonrandom();

void iteadapter_extern_cdclCAR_random(uint32_t,uint32_t,float_ty);
void iteadapter_extern_cdclCAR_nonrandom();
void iteadapter_extern_cdclCARParams_random(uint32_t,uint32_t,float_ty);
void iteadapter_extern_cdclCARParams_nonrandom();

void iteadapter_extern_cdclSLR_random(uint32_t,uint32_t,float_ty);
void iteadapter_extern_cdclSLR_nonrandom();
void iteadapter_extern_cdclSLRParams_random(uint32_t,uint32_t,float_ty);
void iteadapter_extern_cdclSLRParams_nonrandom();

void iteadapter_extern_cdclSOR_random(uint32_t,uint32_t,float_ty);
void iteadapter_extern_cdclSOR_nonrandom();
void iteadapter_extern_cdclSORParams_random(uint32_t,uint32_t,float_ty);
void iteadapter_extern_cdclSORParams_nonrandom();

void iteadapter_extern_cdclCBJLR_random(uint32_t,uint32_t,float_ty);
void iteadapter_extern_cdclCBJLR_nonrandom();
void iteadapter_extern_cdclCBJLRParams_random(uint32_t,uint32_t,float_ty);
void iteadapter_extern_cdclCBJLRParams_nonrandom();

void iteadapter_extern_cdclRR_random(uint32_t,uint32_t,float_ty);
void iteadapter_extern_cdclRR_nonrandom();
void iteadapter_extern_cdclRRParams_random(uint32_t,uint32_t,float_ty);
void iteadapter_extern_cdclRRParams_nonrandom();

void iteadapter_extern_cdclMR_random(uint32_t,uint32_t,float_ty);
void iteadapter_extern_cdclMR_nonrandom();
void iteadapter_extern_cdclMRParams_random(uint32_t,uint32_t,float_ty);
void iteadapter_extern_cdclMRParams_nonrandom();

void iteadapter_extern_cdclIR_random(uint32_t,uint32_t,float_ty);
void iteadapter_extern_cdclIR_nonrandom();
void iteadapter_extern_cdclIRParams_random(uint32_t,uint32_t,float_ty);
void iteadapter_extern_cdclIRParams_nonrandom();

void iteadapter_extern_cdclAR_random(uint32_t,uint32_t,float_ty);
void iteadapter_extern_cdclAR_nonrandom();
void iteadapter_extern_cdclARParams_random(uint32_t,uint32_t,float_ty);
void iteadapter_extern_cdclARParams_nonrandom();

#endif /* ITEADAPTER_CDCL_H_ */
