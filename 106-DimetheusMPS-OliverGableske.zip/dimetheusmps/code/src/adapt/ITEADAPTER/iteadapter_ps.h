/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#ifndef ITEADAPTER_PS_H_
#define ITEADAPTER_PS_H_

#include "iteadapter.h"

void iteadapter_extern_prepStrategy_random(uint32_t,uint32_t,float_ty);
void iteadapter_extern_prepStrategyParams_random(uint32_t,uint32_t,float_ty);

void iteadapter_extern_prepStrategy_nonrandom();
void iteadapter_extern_prepStrategyParams_nonrandom();

#endif /* ITEADAPTER_PS_H_ */
