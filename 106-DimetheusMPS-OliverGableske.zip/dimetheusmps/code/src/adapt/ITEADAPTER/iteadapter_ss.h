/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#ifndef ITEADAPTER_SS_H_
#define ITEADAPTER_SS_H_

#include "iteadapter.h"

//RANDOM 3SAT TABLE FOR SEARCHMIDBLOCKSIZE ===================================================================================
#define ITEADAPTER_PMP_BLOCKSIZE_3SAT_TLINE(__tLine, __nVars) {\
	if (__nVars <= 1000){\
		__tLine = 0;\
	} else if (__nVars <= 6000){\
		__tLine = 1;\
	} else if (__nVars <= 10000){\
		__tLine = 2;\
	} else if (__nVars <= 20000){\
		__tLine = 3;\
	} else if (__nVars <= 25000){\
		__tLine = 4;\
	} else if (__nVars <= 30000){\
		__tLine = 5;\
	} else if (__nVars <= 40000){\
		__tLine = 6;\
	} else if (__nVars <= 50000){\
		__tLine = 7;\
	} else if (__nVars <= 75000){\
		__tLine = 8;\
	} else {\
		__tLine = 9;\
	}\
}

#define ITEADAPTER_PMP_BLOCKSIZE_3SAT_TROW(__tRow, __rRatio) {\
	if (__rRatio <= 4.200){\
		__tRow = 0;\
	} else if (__rRatio <= 4.208){\
		__tRow = 1;\
	} else if (__rRatio <= 4.215){\
		__tRow = 2;\
	} else if (__rRatio <= 4.223){\
		__tRow = 3;\
	} else if (__rRatio <= 4.230){\
		__tRow = 4;\
	} else if (__rRatio <= 4.237){\
		__tRow = 5;\
	} else if (__rRatio <= 4.245){\
		__tRow = 6;\
	} else if (__rRatio <= 4.252){\
		__tRow = 7;\
	} else if (__rRatio <= 4.260){\
		__tRow = 8;\
	} else {\
		__tRow = 9;\
	}\
}

static const float_ty iteadapter_pmp_blocksize_3SAT[10][10] = {
/*           R4200   R4208   R4215   R4223   R4230   R4237   R4245   R4252   R4260   R4267   */
/*   N1000*/{0.99893,0.65903,0.98966,0.72269,0.62022,0.94826,0.94826,0.94826,0.94826,0.94826},
/*   N6000*/{0.80809,0.62812,0.51584,0.71815,0.71584,0.10718,0.00130,0.00139,0.00100,0.00010},
/*  N10000*/{0.06854,0.04237,0.02200,0.02200,0.01044,0.01044,0.00130,0.00139,0.00100,0.00010},
/*  N20000*/{0.03304,0.02089,0.01333,0.00770,0.00893,0.00665,0.00130,0.00139,0.00100,0.00010},
/*  N25000*/{0.04500,0.04298,0.02852,0.01560,0.00769,0.00824,0.00130,0.00139,0.00100,0.00010},
/*  N30000*/{0.03383,0.03383,0.02628,0.00947,0.00664,0.00724,0.00130,0.00139,0.00100,0.00010},
/*  N40000*/{0.05155,0.04080,0.02703,0.01341,0.00790,0.00249,0.00130,0.00139,0.00100,0.00010},
/*  N50000*/{0.04610,0.04569,0.02697,0.02037,0.00531,0.00157,0.00349,0.00139,0.00100,0.00010},
/*  N75000*/{0.05157,0.04329,0.03288,0.02615,0.00893,0.00733,0.00549,0.00239,0.00150,0.00050},
/* N100000*/{0.06632,0.04651,0.03860,0.02104,0.01741,0.01038,0.00850,0.00300,0.00200,0.00010},
};
#define ITEADAPTER_PMP_BLOCKSIZE_3SAT_GETVALUE(__tLine, __tRow) ( iteadapter_pmp_blocksize_3SAT[__tLine][__tRow] )

//RANDOM 4SAT TABLE FOR SEARCHMIDBLOCKSIZE ===================================================================================
#define ITEADAPTER_PMP_BLOCKSIZE_4SAT_TLINE(__tLine, __nVars) {\
	if (__nVars <= 1000){\
		__tLine = 0;\
	} else if (__nVars <= 5000){\
		__tLine = 1;\
	} else if (__nVars <= 10000){\
		__tLine = 2;\
	} else if (__nVars <= 15000){\
		__tLine = 3;\
	} else if (__nVars <= 20000){\
		__tLine = 4;\
	} else {\
		__tLine = 5;\
	}\
}

#define ITEADAPTER_PMP_BLOCKSIZE_4SAT_TROW(__tRow, __rRatio) {\
	if (__rRatio <= 9.000){\
		__tRow = 0;\
	} else if (__rRatio <= 9.121){\
		__tRow = 1;\
	} else if (__rRatio <= 9.223){\
		__tRow = 2;\
	} else if (__rRatio <= 9.324){\
		__tRow = 3;\
	} else if (__rRatio <= 9.425){\
		__tRow = 4;\
	} else if (__rRatio <= 9.526){\
		__tRow = 5;\
	} else if (__rRatio <= 9.627){\
		__tRow = 6;\
	} else if (__rRatio <= 9.729){\
		__tRow = 7;\
	} else if (__rRatio <= 9.830){\
		__tRow = 8;\
	}  else {\
		__tRow = 9;\
	}\
}

static const float_ty iteadapter_pmp_blocksize_4SAT[6][10] = {
/*         R9000   R9121   R9223   R9324   R9425   R9526   R9627   R9729   R9830   R9931   */
/* N1000*/{0.69835,0.87384,0.80844,0.79998,0.76617,0.58217,0.58217,0.68485,0.68485,0.68485},
/* N5000*/{0.98069,0.57924,0.57920,0.08931,0.07789,0.04080,0.02048,0.00547,0.00500,0.00250},
/*N10000*/{0.34175,0.33112,0.33112,0.09433,0.07650,0.05978,0.03125,0.01550,0.00500,0.00300},
/*N15000*/{0.32882,0.32882,0.31957,0.09367,0.08461,0.06015,0.03248,0.01600,0.00600,0.00400},
/*N20000*/{0.34809,0.31528,0.13172,0.10185,0.08213,0.05916,0.03721,0.01500,0.00750,0.00350},
/*N25000*/{0.32733,0.32733,0.11636,0.11636,0.09071,0.05748,0.03409,0.01500,0.00750,0.00350},
};
#define ITEADAPTER_PMP_BLOCKSIZE_4SAT_GETVALUE(__tLine, __tRow) ( iteadapter_pmp_blocksize_4SAT[__tLine][__tRow] )

//RANDOM 5SAT TABLE FOR SEARCHMIDBLOCKSIZE ===================================================================================
#define ITEADAPTER_PMP_BLOCKSIZE_5SAT_TLINE(__tLine, __nVars) {\
	if (__nVars <= 300){\
		__tLine = 0;\
	} else if (__nVars <= 440){\
		__tLine = 1;\
	} else if (__nVars <= 720){\
		__tLine = 2;\
	} else if (__nVars <= 1000){\
		__tLine = 3;\
	} else if (__nVars <= 1280){\
		__tLine = 4;\
	} else {\
		__tLine = 5;\
	}\
}

#define ITEADAPTER_PMP_BLOCKSIZE_5SAT_TROW(__tRow, __rRatio) {\
	if (__rRatio <= 20.000){\
		__tRow = 0;\
	} else if (__rRatio <= 20.155){\
		__tRow = 1;\
	} else if (__rRatio <= 20.275){\
		__tRow = 2;\
	} else if (__rRatio <= 20.395){\
		__tRow = 3;\
	} else if (__rRatio <= 20.516){\
		__tRow = 4;\
	} else if (__rRatio <= 20.636){\
		__tRow = 5;\
	} else if (__rRatio <= 20.756){\
		__tRow = 6;\
	} else if (__rRatio <= 20.876){\
		__tRow = 7;\
	} else if (__rRatio <= 20.997){\
		__tRow = 8;\
	}  else {\
		__tRow = 9;\
	}\
}

static const float_ty iteadapter_pmp_blocksize_5SAT[6][10] = {
/*         R20000  R20155  R20275  R20395  R20516  R20636  R20756  R20876  R20997  R21117   */
/*  N300*/{0.02035,0.02991,0.02991,0.02991,0.02991,0.02991,0.02991,0.02991,0.02991,0.02991},
/*  N440*/{0.02118,0.00895,0.00895,0.00895,0.00895,0.00895,0.00895,0.00895,0.00895,0.00895},
/*  N720*/{0.00131,0.00511,0.00250,0.00250,0.00250,0.00250,0.00250,0.00250,0.00250,0.00250},
/* N1000*/{0.00131,0.01157,0.01157,0.00500,0.00100,0.00100,0.00100,0.00100,0.00100,0.00100},
/* N1280*/{0.01023,0.01230,0.02549,0.00367,0.00100,0.00100,0.00100,0.00100,0.00100,0.00100},
/* N1600*/{0.00834,0.00834,0.00367,0.00367,0.00100,0.00100,0.00100,0.00100,0.00100,0.00100},
};
#define ITEADAPTER_PMP_BLOCKSIZE_5SAT_GETVALUE(__tLine, __tRow) ( iteadapter_pmp_blocksize_5SAT[__tLine][__tRow] )

//RANDOM 6SAT TABLE FOR SEARCHMIDBLOCKSIZE ===================================================================================
#define ITEADAPTER_PMP_BLOCKSIZE_6SAT_TLINE(__tLine, __nVars) {\
	if (__nVars <= 200){\
		__tLine = 0;\
	} else if (__nVars <= 240){\
		__tLine = 1;\
	} else if (__nVars <= 280){\
		__tLine = 2;\
	} else if (__nVars <= 300){\
		__tLine = 3;\
	} else if (__nVars <= 340){\
		__tLine = 4;\
	} else {\
		__tLine = 5;\
	}\
}

#define ITEADAPTER_PMP_BLOCKSIZE_6SAT_TROW(__tRow, __rRatio) {\
	if (__rRatio <= 40.000){\
		__tRow = 0;\
	} else if (__rRatio <= 40.674){\
		__tRow = 1;\
	} else if (__rRatio <= 41.011){\
		__tRow = 2;\
	} else if (__rRatio <= 41.348){\
		__tRow = 3;\
	} else if (__rRatio <= 41.685){\
		__tRow = 4;\
	} else if (__rRatio <= 42.022){\
		__tRow = 5;\
	} else if (__rRatio <= 42.359){\
		__tRow = 6;\
	} else if (__rRatio <= 42.696){\
		__tRow = 7;\
	} else if (__rRatio <= 43.033){\
		__tRow = 8;\
	}  else {\
		__tRow = 9;\
	}\
}

static const float_ty iteadapter_pmp_blocksize_6SAT[6][10] = {
/*        R40000  R40674  R41011  R41348  R41685  R42022  R42359  R42696  R43033  R43370   */
/* N200*/{0.00945,0.00500,0.00400,0.00300,0.00000,0.00000,0.00000,0.00000,0.00000,0.00000},
/* N240*/{0.00855,0.00500,0.00100,0.00000,0.00000,0.00000,0.00000,0.00000,0.00000,0.00000},
/* N280*/{0.00164,0.00100,0.00100,0.00000,0.00000,0.00000,0.00000,0.00000,0.00000,0.00000},
/* N300*/{0.00481,0.00100,0.00100,0.00000,0.00000,0.00000,0.00000,0.00000,0.00000,0.00000},
/* N340*/{0.00898,0.00100,0.01000,0.00000,0.00000,0.00000,0.00000,0.00000,0.00000,0.00000},
/* N400*/{0.01537,0.02722,0.00201,0.00100,0.00000,0.00000,0.00000,0.00000,0.00000,0.00000},
};
#define ITEADAPTER_PMP_BLOCKSIZE_6SAT_GETVALUE(__tLine, __tRow) ( iteadapter_pmp_blocksize_6SAT[__tLine][__tRow] )

//RANDOM 7SAT TABLE FOR SEARCHMIDBLOCKSIZE ===================================================================================
#define ITEADAPTER_PMP_BLOCKSIZE_7SAT_TLINE(__tLine, __nVars) {\
	if (__nVars <= 100){\
		__tLine = 0;\
	} else if (__nVars <= 120){\
		__tLine = 1;\
	} else if (__nVars <= 140){\
		__tLine = 2;\
	} else if (__nVars <= 160){\
		__tLine = 3;\
	} else if (__nVars <= 180){\
		__tLine = 4;\
	} else {\
		__tLine = 5;\
	}\
}

#define ITEADAPTER_PMP_BLOCKSIZE_7SAT_TROW(__tRow, __rRatio) {\
	if (__rRatio <= 85.000){\
		__tRow = 0;\
	} else if (__rRatio <= 85.558){\
		__tRow = 1;\
	} else if (__rRatio <= 85.837){\
		__tRow = 2;\
	} else if (__rRatio <= 86.116){\
		__tRow = 3;\
	} else if (__rRatio <= 86.395){\
		__tRow = 4;\
	} else if (__rRatio <= 86.674){\
		__tRow = 5;\
	} else if (__rRatio <= 86.953){\
		__tRow = 6;\
	} else if (__rRatio <= 87.232){\
		__tRow = 7;\
	} else if (__rRatio <= 87.511){\
		__tRow = 8;\
	}  else {\
		__tRow = 9;\
	}\
}

static const float_ty iteadapter_pmp_blocksize_7SAT[6][10] = {
/*        R85000  R85558  R85837  R86116  R86395  R86674  R86953  R87232  R87511  R87790   */
/* N100*/{0.09437,0.09437,0.09437,0.09437,0.09437,0.09437,0.09437,0.09437,0.09437,0.09437},
/* N120*/{0.09437,0.09437,0.09437,0.09437,0.09437,0.09437,0.09437,0.09437,0.09437,0.09437},
/* N140*/{0.09437,0.09437,0.09437,0.09437,0.09437,0.09437,0.09437,0.09437,0.09437,0.09437},
/* N160*/{0.09437,0.09437,0.09437,0.09437,0.09437,0.09437,0.09437,0.09437,0.09437,0.09437},
/* N180*/{0.09437,0.09437,0.09437,0.09437,0.09437,0.09437,0.09437,0.09437,0.09437,0.09437},
/* N200*/{0.09437,0.09437,0.09437,0.09437,0.09437,0.09437,0.09437,0.09437,0.09437,0.09437},
};
#define ITEADAPTER_PMP_BLOCKSIZE_7SAT_GETVALUE(__tLine, __tRow) ( iteadapter_pmp_blocksize_7SAT[__tLine][__tRow] )

void iteadapter_extern_searchStrategy_random(uint32_t,uint32_t,float_ty);
void iteadapter_extern_searchStrategyParams_random(uint32_t,uint32_t,float_ty);

void iteadapter_extern_searchStrategy_nonrandom();
void iteadapter_extern_searchStrategyParams_nonrandom();

#endif /* ITEADAPTER_SS_H_ */
