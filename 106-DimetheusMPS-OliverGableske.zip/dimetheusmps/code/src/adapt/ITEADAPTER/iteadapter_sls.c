/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#include "iteadapter_sls.h"

void iteadapter_extern_slsPAFVR_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	//We adapt the pick and flip variable rule according to the type of instance we have.
	if (k < 4U){
		//We assume its a 3-SAT instance. In this case, it seems that ProbSAT with polynomial brake only is best.
		param_slsPickAndFlipVarRule = SLS_PICKANDFLIPVARRULE_PROBSATPB;
	} else {
		//We assume its a k > 3 instance. In this case, it seems that ProbSAT with exponential brake only is best.
		param_slsPickAndFlipVarRule = SLS_PICKANDFLIPVARRULE_PROBSATEB;
	}
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: RANDOM   : SLS -slsPickAndFlipVarRule %d\n", param_slsPickAndFlipVarRule);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_slsPAFVRParams_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	//The ProbSAT break adaptation.
	if (k <= 3){
		param_slsProbsatCB = 2.165;
	} else if (k == 4){
		param_slsProbsatCB = 2.85;
	} else if (k == 5){
		param_slsProbsatCB = 3.7;
	} else if (k == 6){
		param_slsProbsatCB = 5.1;
	} else {
		param_slsProbsatCB = 5.4;
	}

	//The WalkSAT noise adaptation.
	if (k <= 3){
		if (r <= 3.0){
			param_slsNoise = (-7.617f+14.588f*r)/100.0f;
		} else if (r < 3.85){
			param_slsNoise = (-2.5858+12.347f*r)/100.0f;
		} else if (r <= 4.2){
			param_slsNoise = (-77.53f+31.970f*r)/100.0f;
		} else {
			param_slsNoise = 0.70f;
		}
	} else if (k == 4){
		param_slsNoise = 0.4f;
	} else if (k == 5){
		param_slsNoise = 0.25f;
	} else if (k == 6){
		param_slsNoise = 0.175f;
	} else if (k == 7){
		param_slsNoise = 0.1f;
	}

	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: RANDOM   : SLS -slsProbsatCB %f, -slsNoise %f\n", param_slsProbsatCB, param_slsNoise);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_slsPAFVR_nonrandom(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	//In case the formula is non-random, we currently have no clever rules. It seems, however, that ProbSAT with exponential
	//break seems to work best.
	param_slsPickAndFlipVarRule = SLS_PICKANDFLIPVARRULE_PROBSATEB;
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: NONRANDOM: SLS -slsPickAndFlipVarRule %d\n", param_slsPickAndFlipVarRule);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_slsPAFVRParams_nonrandom(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	//The ProbSAT break adaptation. We have no clue besides using the 7-SAT settings.
	param_slsProbsatCB = 5.4;

	//The WalkSAT noise adaptation. We have no clue besides using the 7-SAT settings.
	param_slsNoise = 0.1;

	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: NONRANDOM: SLS -slsProbsatCB %f, -slsNoise %f\n", param_slsProbsatCB, param_slsNoise);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}


void iteadapter_extern_slsAI_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	//If we are allowed to adapt, we pick the provided values in the hope that they are better than the random ones.
	param_slsAssInitRule = SLS_ASSINITRULE_PROVIDED;
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: RANDOM   : SLS -slsAssInitRule %d\n", param_slsAssInitRule);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_slsAIParams_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	//There is nothing we can currently adapt.
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_slsAI_nonrandom(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	//If we are allowed to adapt, we pick the provided values in the hope that they are better than the random ones.
	param_slsAssInitRule = SLS_ASSINITRULE_PROVIDED;
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: NONRANDOM: SLS -slsAssInitRule %d\n", param_slsAssInitRule);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_slsAIParams_nonrandom(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	//There is nothing we can currently adapt.
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}
