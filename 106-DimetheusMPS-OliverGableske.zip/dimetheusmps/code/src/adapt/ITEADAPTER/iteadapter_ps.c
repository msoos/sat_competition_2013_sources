/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#include "iteadapter_ps.h"

void iteadapter_extern_prepStrategy_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	param_prepStrategy = PREP_STRATEGY_RAND;
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: RANDOM   : PREP -prepStrategy %d\n", param_prepStrategy);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_prepStrategyParams_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif

	//Currently, there are no parameters to be adapted in any of the preprocessing strategies. ITE AS IN SS ARE MISSING.

	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_prepStrategy_nonrandom(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	param_prepStrategy = PREP_STRATEGY_STRONG;
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: NONRANDOM: PREP -prepStrategy %d\n", param_prepStrategy);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_prepStrategyParams_nonrandom(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif

	//Currently, there are no parameters to be adapted in any of the preprocessing strategies. ITE AS IN SS ARE MISSING.

	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}
