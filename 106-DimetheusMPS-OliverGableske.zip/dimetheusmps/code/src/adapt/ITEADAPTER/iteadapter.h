/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#ifndef ITEADAPTER_H_
#define ITEADAPTER_H_

#include "../adapt.h"

#define ITEADAPTER_VERSION_MA 0
#define ITEADAPTER_VERSION_MI 215
#define ITEADAPTER_VERSION_NAME "ITEADAPTER"

//Global variables and Macros of the ITEADAPTER module.
int32_t iteadapter_returnCode;				//The return code of the ITEADAPTER module.

//Methods exclusively accessible to the ITEADAPTER module (INTERN).

//Methods PROVIDED by the module.
void iteadapter_extern_printVersion();		//Prints the version of this module.

//STRATEGY PARAMETERS
#include "iteadapter_ps.h"
#include "iteadapter_is.h"
#include "iteadapter_ss.h"

//PRE ADAPTION
#include "iteadapter_pre.h"

//IN ADAPTION
#include "iteadapter_in.h"

//MP ADAPTION
#include "iteadapter_mp.h"

//SLS ADAPTION
#include "iteadapter_sls.h"

//CDCL ADAPTION
#include "iteadapter_cdcl.h"

//The following methods are used to initialize this module (called by the one who wants to use the external methods).
void iteadapter_resetModule();
void iteadapter_initModule();
void iteadapter_disposeModule();

#endif /* ITEADAPTER_H_ */
