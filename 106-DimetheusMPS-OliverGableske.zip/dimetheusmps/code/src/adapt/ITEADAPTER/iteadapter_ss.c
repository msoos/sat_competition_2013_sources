/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#include "iteadapter_ss.h"

void iteadapter_extern_searchStrategy_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	param_searchStrategy = SEARCH_STRATEGY_PMPSLS;
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: RANDOM   : SEARCH -searchStrategy %d\n", param_searchStrategy);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_intern_searchStrategyParams_NULL_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: RANDOM   : SEARCH NULL (none)\n");
	#endif
}

void iteadapter_intern_searchStrategyParams_CDCL_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: RANDOM   : SEARCH CDCL (none)\n");
	#endif
}

void iteadapter_intern_searchStrategyParams_SLS_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: RANDOM   : SEARCH SLS (none)\n");
	#endif
}

void iteadapter_intern_searchStrategyParams_PMPSLS_random(uint32_t k, uint32_t n, float_ty r){
	//Fall-back parameters.
	param_searchMIDBlockSize = 0.05;

	//The table line and row will be used to pick a parameter setting.
	uint32_t tLine = 0, tRow = 0;
	//Grab the table line and row numbers for the specific attributes, and assign the block size value.
	if (k <= 3){
		//RANDOM 3-SAT and below.
		//Grab the table line number.
		ITEADAPTER_PMP_BLOCKSIZE_3SAT_TLINE(tLine, n);
		//Grab the table row number.
		ITEADAPTER_PMP_BLOCKSIZE_3SAT_TROW(tRow, r);
		//Assign rho.
		param_searchMIDBlockSize = ITEADAPTER_PMP_BLOCKSIZE_3SAT_GETVALUE(tLine, tRow);
	} else if (k == 4){
		//RANDOM 4-SAT.
		//Grab the table line number.
		ITEADAPTER_PMP_BLOCKSIZE_4SAT_TLINE(tLine, n);
		//Grab the table row number.
		ITEADAPTER_PMP_BLOCKSIZE_4SAT_TROW(tRow, r);
		//Assign rho.
		param_searchMIDBlockSize = ITEADAPTER_PMP_BLOCKSIZE_4SAT_GETVALUE(tLine, tRow);
	} else if (k == 5){
		//RANDOM 5-SAT.
		//Grab the table line number.
		ITEADAPTER_PMP_BLOCKSIZE_5SAT_TLINE(tLine, n);
		//Grab the table row number.
		ITEADAPTER_PMP_BLOCKSIZE_5SAT_TROW(tRow, r);
		//Assign rho.
		param_searchMIDBlockSize = ITEADAPTER_PMP_BLOCKSIZE_5SAT_GETVALUE(tLine, tRow);
	} else if (k == 6){
		//RANDOM 6-SAT.
		//Grab the table line number.
		ITEADAPTER_PMP_BLOCKSIZE_6SAT_TLINE(tLine, n);
		//Grab the table row number.
		ITEADAPTER_PMP_BLOCKSIZE_6SAT_TROW(tRow, r);
		//Assign rho.
		param_searchMIDBlockSize = ITEADAPTER_PMP_BLOCKSIZE_6SAT_GETVALUE(tLine, tRow);
	} else {
		//RANDOM 7-SAT and above.
		//Grab the table line number.
		ITEADAPTER_PMP_BLOCKSIZE_7SAT_TLINE(tLine, n);
		//Grab the table row number.
		ITEADAPTER_PMP_BLOCKSIZE_7SAT_TROW(tRow, r);
		//Assign rho.
		param_searchMIDBlockSize = ITEADAPTER_PMP_BLOCKSIZE_7SAT_GETVALUE(tLine, tRow);
	}

	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: RANDOM   : SEARCH PMPSLS -searchMIDBlockSize %f (%d-SAT table, line %d, row %d)\n",
			param_searchMIDBlockSize, k, tLine, tRow);
	#endif

	//TODO: Check if an interpolation is possible.

	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: RANDOM   : SEARCH PMPSLS -searchMIDBlockSize %f\n", param_searchMIDBlockSize);
	#endif

}

void iteadapter_intern_searchStrategyParams_PMPCDCL_random(uint32_t k, uint32_t n, float_ty r){
	//Fall-back parameters.
	param_searchMIDBlockSize = 0.05;

	//The table line and row will be used to pick a parameter setting.
	uint32_t tLine = 0, tRow = 0;
	//Grab the table line and row numbers for the specific attributes, and assign the block size value.
	if (k <= 3){
		//RANDOM 3-SAT and below.
		//Grab the table line number.
		ITEADAPTER_PMP_BLOCKSIZE_3SAT_TLINE(tLine, n);
		//Grab the table row number.
		ITEADAPTER_PMP_BLOCKSIZE_3SAT_TROW(tRow, r);
		//Assign rho.
		param_searchMIDBlockSize = ITEADAPTER_PMP_BLOCKSIZE_3SAT_GETVALUE(tLine, tRow);
	} else if (k == 4){
		//RANDOM 4-SAT.
		//Grab the table line number.
		ITEADAPTER_PMP_BLOCKSIZE_4SAT_TLINE(tLine, n);
		//Grab the table row number.
		ITEADAPTER_PMP_BLOCKSIZE_4SAT_TROW(tRow, r);
		//Assign rho.
		param_searchMIDBlockSize = ITEADAPTER_PMP_BLOCKSIZE_4SAT_GETVALUE(tLine, tRow);
	} else if (k == 5){
		//RANDOM 5-SAT.
		//Grab the table line number.
		ITEADAPTER_PMP_BLOCKSIZE_5SAT_TLINE(tLine, n);
		//Grab the table row number.
		ITEADAPTER_PMP_BLOCKSIZE_5SAT_TROW(tRow, r);
		//Assign rho.
		param_searchMIDBlockSize = ITEADAPTER_PMP_BLOCKSIZE_5SAT_GETVALUE(tLine, tRow);
	} else if (k == 6){
		//RANDOM 6-SAT.
		//Grab the table line number.
		ITEADAPTER_PMP_BLOCKSIZE_6SAT_TLINE(tLine, n);
		//Grab the table row number.
		ITEADAPTER_PMP_BLOCKSIZE_6SAT_TROW(tRow, r);
		//Assign rho.
		param_searchMIDBlockSize = ITEADAPTER_PMP_BLOCKSIZE_6SAT_GETVALUE(tLine, tRow);
	} else {
		//RANDOM 7-SAT and above.
		//Grab the table line number.
		ITEADAPTER_PMP_BLOCKSIZE_7SAT_TLINE(tLine, n);
		//Grab the table row number.
		ITEADAPTER_PMP_BLOCKSIZE_7SAT_TROW(tRow, r);
		//Assign rho.
		param_searchMIDBlockSize = ITEADAPTER_PMP_BLOCKSIZE_7SAT_GETVALUE(tLine, tRow);
	}

	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: RANDOM   : SEARCH PMPCDCL -searchMIDBlockSize %f (%d-SAT, line %d, row %d)\n",
			param_searchMIDBlockSize, k, tLine, tRow);
	#endif

	//TODO: Check if an interpolation is possible.

	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: RANDOM   : SEARCH PMPCDCL -searchMIDBlockSize %f\n", param_searchMIDBlockSize);
	#endif
}

void iteadapter_intern_searchStrategyParams_TESTING_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: RANDOM   : SEARCH TESTING (none)\n");
	#endif
}

void iteadapter_extern_searchStrategyParams_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif

	if (param_searchStrategy == SEARCH_STRATEGY_NULL){
		iteadapter_intern_searchStrategyParams_NULL_random(k, n, r);
	} else if (param_searchStrategy == SEARCH_STRATEGY_CDCL){
		iteadapter_intern_searchStrategyParams_CDCL_random(k, n, r);
	} else if (param_searchStrategy == SEARCH_STRATEGY_SLS){
		iteadapter_intern_searchStrategyParams_SLS_random(k, n, r);
	} else if (param_searchStrategy == SEARCH_STRATEGY_PMPSLS){
		iteadapter_intern_searchStrategyParams_PMPSLS_random(k, n, r);
	} else if (param_searchStrategy == SEARCH_STRATEGY_PMPCDCL){
		iteadapter_intern_searchStrategyParams_PMPCDCL_random(k, n, r);
	} else if (param_searchStrategy == SEARCH_STRATEGY_TESTING){
		iteadapter_intern_searchStrategyParams_TESTING_random(k, n, r);
	}

	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_searchStrategy_nonrandom(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	param_searchStrategy = SEARCH_STRATEGY_PMPCDCL;
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: NONRANDOM: SEARCH -searchStrategy %d\n", param_searchStrategy);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_intern_searchStrategyParams_NULL_nonrandom(){
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: NONRANDOM: SEARCH NULL (none)\n");
	#endif
}

void iteadapter_intern_searchStrategyParams_CDCL_nonrandom(){
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: NONRANDOM: SEARCH CDCL (none)\n");
	#endif
}

void iteadapter_intern_searchStrategyParams_SLS_nonrandom(){
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: NONRANDOM: SEARCH SLS (none)\n");
	#endif
}

void iteadapter_intern_searchStrategyParams_PMPSLS_nonrandom(){
	//Fall-back parameters.
	param_searchMIDBlockSize = 0.05;
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: NONRANDOM: SEARCH PMPSLS -searchMIDBlockSize %f\n", param_searchMIDBlockSize);
	#endif
}

void iteadapter_intern_searchStrategyParams_PMPCDCL_nonrandom(){
	//Fall-back parameters.
	param_searchMIDBlockSize = 0.05;
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: NONRANDOM: SEARCH PMPCDCL -searchMIDBlockSize %f\n", param_searchMIDBlockSize);
	#endif
}

void iteadapter_intern_searchStrategyParams_TESTING_nonrandom(){
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: NONRANDOM: SEARCH TESTING (none)\n");
	#endif
}

void iteadapter_extern_searchStrategyParams_nonrandom(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif

	if (param_searchStrategy == SEARCH_STRATEGY_NULL){
		iteadapter_intern_searchStrategyParams_NULL_nonrandom();
	} else if (param_searchStrategy == SEARCH_STRATEGY_CDCL){
		iteadapter_intern_searchStrategyParams_CDCL_nonrandom();
	} else if (param_searchStrategy == SEARCH_STRATEGY_SLS){
		iteadapter_intern_searchStrategyParams_SLS_nonrandom();
	} else if (param_searchStrategy == SEARCH_STRATEGY_PMPSLS){
		iteadapter_intern_searchStrategyParams_PMPSLS_nonrandom();
	} else if (param_searchStrategy == SEARCH_STRATEGY_PMPCDCL){
		iteadapter_intern_searchStrategyParams_PMPCDCL_nonrandom();
	} else if (param_searchStrategy == SEARCH_STRATEGY_TESTING){
		iteadapter_intern_searchStrategyParams_TESTING_nonrandom();
	}

	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}
