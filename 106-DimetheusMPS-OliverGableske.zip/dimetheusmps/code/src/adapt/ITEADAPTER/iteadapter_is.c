/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */


#include "iteadapter_is.h"

void iteadapter_extern_inpStrategy_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	param_inpStrategy = INP_STRATEGY_RAND;
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: RANDOM   : INP -inpStrategy %d\n", param_inpStrategy);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_inpStrategyParams_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif

	//Currently, there are no parameters to be adapted in any of the in-processing strategies. ITE AS IN SS ARE MISSING.

	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_inpStrategy_nonrandom(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	param_inpStrategy = INP_STRATEGY_SIMPLE;
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: NONRANDOM: INP -inpStrategy %d\n", param_inpStrategy);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_inpStrategyParams_nonrandom(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif

	//Currently, there are no parameters to be adapted in any of the in-processing strategies. ITE AS IN SS ARE MISSING.

	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

