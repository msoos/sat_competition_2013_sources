/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#include "iteadapter_mp.h"

void iteadapter_extern_mpUR_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	param_mpUpdateRule = MP_UPDATERULE_L2I_RHOSIGMAPMP;
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: RANDOM   : MP -mpUpdateRule %d\n", param_mpUpdateRule);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_mpURParams_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	//Fall-back parameters.
	param_mpRho = 0.995;
	param_mpSigma = 0.0;

	//The table line and row will be used to pick a parameter setting.
	uint32_t tLine = 0, tRow = 0;

	//Grab the table line and row numbers for the specific attributes, and assign the rho value.
	if (k <= 3){
		//RANDOM 3-SAT and below.
		//Grab the table line number.
		ITEADAPTER_MP_RHO_3SAT_TLINE(tLine, n);
		//Grab the table row number.
		ITEADAPTER_MP_RHO_3SAT_TROW(tRow, r);
		//Assign rho.
		param_mpRho = ITEADAPTER_MP_RHO_3SAT_GETVALUE(tLine, tRow);
	} else if (k == 4){
		//RANDOM 4-SAT
		//Grab the table line number.
		ITEADAPTER_MP_RHO_4SAT_TLINE(tLine, n);
		//Grab the table row number.
		ITEADAPTER_MP_RHO_4SAT_TROW(tRow, r);
		//Assign rho.
		param_mpRho = ITEADAPTER_MP_RHO_4SAT_GETVALUE(tLine, tRow);
	} else if (k == 5){
		//RANDOM 5-SAT
		//Grab the table line number.
		ITEADAPTER_MP_RHO_5SAT_TLINE(tLine, n);
		//Grab the table row number.
		ITEADAPTER_MP_RHO_5SAT_TROW(tRow, r);
		//Assign rho.
		param_mpRho = ITEADAPTER_MP_RHO_5SAT_GETVALUE(tLine, tRow);
	} else if (k == 6){
		//RANDOM 6-SAT
		//Grab the table line number.
		ITEADAPTER_MP_RHO_6SAT_TLINE(tLine, n);
		//Grab the table row number.
		ITEADAPTER_MP_RHO_6SAT_TROW(tRow, r);
		//Assign rho.
		param_mpRho = ITEADAPTER_MP_RHO_6SAT_GETVALUE(tLine, tRow);
	} else {
		//RANDOM 7-SAT and above.
		//Grab the table line number.
		ITEADAPTER_MP_RHO_7SAT_TLINE(tLine, n);
		//Grab the table row number.
		ITEADAPTER_MP_RHO_7SAT_TROW(tRow, r);
		//Assign rho.
		param_mpRho = ITEADAPTER_MP_RHO_7SAT_GETVALUE(tLine, tRow);
	}

	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: RANDOM   : MP -mpRho %f (%d-SAT table, line %d, row %d)\n",
			param_mpRho, k, tLine, tRow);
	#endif

	//TODO: Check if an interpolation is possible.

	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: RANDOM   : MP -mpRho %f, -mpSigma %f\n", param_mpRho, param_mpSigma);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_mpUR_nonrandom(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	param_mpUpdateRule = MP_UPDATERULE_L2I_RHOSIGMAPMP;
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: NONRANDOM: MP -mpUpdateRule %d\n", param_mpUpdateRule);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_mpURParams_nonrandom(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	//Fall-back parameters.
	param_mpRho = 1.0;
	param_mpSigma = 1.0;
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: NONRANDOM: MP -mpRho %f, -mpSigma %f\n", param_mpRho, param_mpSigma);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}
