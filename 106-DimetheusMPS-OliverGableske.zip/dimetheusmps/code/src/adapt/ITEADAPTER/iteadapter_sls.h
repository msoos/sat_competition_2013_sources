/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#ifndef ITEADAPTER_SLS_H_
#define ITEADAPTER_SLS_H_

#include "iteadapter.h"

void iteadapter_extern_slsPAFVR_random(uint32_t,uint32_t,float_ty);
void iteadapter_extern_slsPAFVR_nonrandom();
void iteadapter_extern_slsPAFVRParams_random(uint32_t,uint32_t,float_ty);
void iteadapter_extern_slsPAFVRParams_nonrandom();

void iteadapter_extern_slsAI_random(uint32_t,uint32_t,float_ty);
void iteadapter_extern_slsAI_nonrandom();
void iteadapter_extern_slsAIParams_random(uint32_t,uint32_t,float_ty);
void iteadapter_extern_slsAIParams_nonrandom();

#endif /* ITEADAPTER_SLS_H_ */
