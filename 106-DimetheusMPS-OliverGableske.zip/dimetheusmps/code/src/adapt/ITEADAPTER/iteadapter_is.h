/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#ifndef ITEADAPTER_IS_H_
#define ITEADAPTER_IS_H_

#include "iteadapter.h"

void iteadapter_extern_inpStrategy_random(uint32_t,uint32_t,float_ty);
void iteadapter_extern_inpStrategyParams_random(uint32_t,uint32_t,float_ty);

void iteadapter_extern_inpStrategy_nonrandom();
void iteadapter_extern_inpStrategyParams_nonrandom();

#endif /* ITEADAPTER_IS_H_ */
