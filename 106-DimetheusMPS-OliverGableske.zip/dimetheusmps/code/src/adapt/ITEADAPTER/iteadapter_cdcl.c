/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#include "iteadapter_cdcl.h"

void iteadapter_extern_cdclSVR_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	param_cdclSelectVarRule = CDCL_SELECTVARRULE_RRVSIDS;
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: RANDOM   : CDCL -cdclSelectVarRule %d\n", param_cdclSelectVarRule);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclSVR_nonrandom(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	param_cdclSelectVarRule = CDCL_SELECTVARRULE_RRVSIDS;
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: NONRANDOM: CDCL -cdclSelectVarRule %d\n", param_cdclSelectVarRule);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclSVRParams_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	//Nothing to tune yet.
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclSVRParams_nonrandom(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	//Nothing to tune yet.
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclSVAI_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	param_cdclSelectVarActInit = CDCL_SELECTVARRULE_VARACTINIT_JERESLOWWANG;
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: RANDOM   : CDCL -cdclSelectVarActInit %d\n", param_cdclSelectVarActInit);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclSVAI_nonrandom(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	param_cdclSelectVarActInit = CDCL_SELECTVARRULE_VARACTINIT_JERESLOWWANG;
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: NONRANDOM: CDCL -cdclSelectVarActInit %d\n", param_cdclSelectVarActInit);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclSVAIParams_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	//Nothing to tune yet.
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclSVAIParams_nonrandom(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	//Nothing to tune yet.
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclSDR_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	param_cdclSelectDirRule = CDCL_SELECTDIRRULE_PHASESAVING;
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: RANDOM   : CDCL -cdclSelectDirRule %d\n", param_cdclSelectDirRule);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclSDR_nonrandom(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	param_cdclSelectDirRule = CDCL_SELECTDIRRULE_PHASESAVING;
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: NONRANDOM: CDCL -cdclSelectDirRule %d\n", param_cdclSelectVarActInit);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclSDRParams_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	//Nothing to tune yet.
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclSDRParams_nonrandom(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	//Nothing to tune yet.
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclSDDI_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	param_cdclSelectDirDirInit = CDCL_SELECTDIRRULE_DIRINIT_JERESLOWWANG;
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: RANDOM   : CDCL -cdclSelectDirDirInit %d\n", param_cdclSelectDirDirInit);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclSDDI_nonrandom(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	param_cdclSelectDirDirInit = CDCL_SELECTDIRRULE_DIRINIT_JERESLOWWANG;
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: NONRANDOM: CDCL -cdclSelectDirDirInit %d\n", param_cdclSelectDirDirInit);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclSDDIParams_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	//Nothing to tune yet.
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclSDDIParams_nonrandom(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	//Nothing to tune yet.
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclCAR_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	param_cdclConflictAnalysisRule = CDCL_CONFLICTANALYSISRULE_FIRSTUIP;
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: RANDOM   : CDCL -cdclConflictAnalysisRule %d\n", param_cdclConflictAnalysisRule);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclCAR_nonrandom(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	param_cdclConflictAnalysisRule = CDCL_CONFLICTANALYSISRULE_FIRSTUIP;
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: NONRANDOM: CDCL -cdclConflictAnalysisRule %d\n", param_cdclConflictAnalysisRule);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclCARParams_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	//Nothing to tune yet.
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclCARParams_nonrandom(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	//Nothing to tune yet.
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclSLR_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	param_cdclStrLearnedRule = CDCL_STRLEARNEDRULE_LOCALREC;
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: RANDOM   : CDCL -cdclStrLearnedRule %d\n", param_cdclStrLearnedRule);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclSLR_nonrandom(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	param_cdclStrLearnedRule = CDCL_STRLEARNEDRULE_LOCALREC;
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: NONRANDOM: CDCL -cdclStrLearnedRule %d\n", param_cdclStrLearnedRule);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclSLRParams_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	//Nothing to tune yet.
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclSLRParams_nonrandom(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	//Nothing to tune yet.
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclSOR_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	param_cdclStrOtherRule = CDCL_STROTHERRULE_WTWO;
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: RANDOM   : CDCL -cdclStrOtherRule %d\n", param_cdclStrOtherRule);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclSOR_nonrandom(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	param_cdclStrOtherRule = CDCL_STROTHERRULE_WTWO;
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: NONRANDOM: CDCL -cdclStrOtherRule %d\n", param_cdclStrOtherRule);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclSORParams_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	//Nothing to tune yet.
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclSORParams_nonrandom(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	//Nothing to tune yet.
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclCBJLR_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	param_cdclComputeBJLRule = CDCL_COMPUTEBJLRULE_FIRSTASSERT;
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: RANDOM   : CDCL -cdclComputeBJLRule %d\n", param_cdclComputeBJLRule);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclCBJLR_nonrandom(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	param_cdclComputeBJLRule = CDCL_COMPUTEBJLRULE_FIRSTASSERT;
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: NONRANDOM: CDCL -cdclComputeBJLRule %d\n", param_cdclComputeBJLRule);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclCBJLRParams_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	//Nothing to tune yet.
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclCBJLRParams_nonrandom(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	//Nothing to tune yet.
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclRR_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	param_cdclRestartRule = CDCL_RESTARTRULE_LUBYSTAG;
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: RANDOM   : CDCL -cdclRestartRule %d\n", param_cdclRestartRule);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclRR_nonrandom(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	param_cdclRestartRule = CDCL_RESTARTRULE_LUBYSTAG;
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: NONRANDOM: CDCL -cdclRestartRule %d\n", param_cdclRestartRule);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclRRParams_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	//Nothing to tune yet.
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclRRParams_nonrandom(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	//Nothing to tune yet.
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclMR_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	param_cdclMaintenanceRule = CDCL_MAINTENANCERULE_LBDINACTLUBY;
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: RANDOM   : CDCL -cdclMaintenanceRule %d\n", param_cdclMaintenanceRule);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclMR_nonrandom(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	param_cdclMaintenanceRule = CDCL_MAINTENANCERULE_LBDINACTLUBY;
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: NONRANDOM: CDCL -cdclMaintenanceRule %d\n", param_cdclMaintenanceRule);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclMRParams_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	//Nothing to tune yet.
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclMRParams_nonrandom(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	//Nothing to tune yet.
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclIR_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	param_cdclInprocessingRule = CDCL_INPROCESSINGRULE_SIMPLE;
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: RANDOM   : CDCL -cdclInprocessingRule %d\n", param_cdclInprocessingRule);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclIR_nonrandom(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	param_cdclInprocessingRule = CDCL_INPROCESSINGRULE_SIMPLE;
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: NONRANDOM: CDCL -cdclInprocessingRule %d\n", param_cdclInprocessingRule);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclIRParams_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	//Nothing to tune yet.
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclIRParams_nonrandom(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	//Nothing to tune yet.
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclAR_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	param_cdclAbortRule = CDCL_ABORTRULE_NULL;
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: RANDOM   : CDCL -cdclAbortRule %d\n", param_cdclAbortRule);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclAR_nonrandom(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	param_cdclAbortRule = CDCL_ABORTRULE_NULL;
	#ifdef VERBOSE_ITEADAPTER
	printf("c     ITEADAPTER: NONRANDOM: CDCL -cdclAbortRule %d\n", param_cdclAbortRule);
	#endif
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclARParams_random(uint32_t k, uint32_t n, float_ty r){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	//Nothing to tune yet.
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void iteadapter_extern_cdclARParams_nonrandom(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_iteadapter_component_totalCalls;
	#endif
	//Nothing to tune yet.
	#ifdef COLLECTSTATS
	stats_iteadapter_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}
