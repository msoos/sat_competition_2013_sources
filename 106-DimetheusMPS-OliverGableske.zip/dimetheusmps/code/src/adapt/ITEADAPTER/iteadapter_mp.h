/*	DIMETHEUS SAT SOLVER
 * 	Author:		Olive__rRatioGableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#ifndef ITEADAPTER_MP_H_
#define ITEADAPTER_MP_H_

#include "iteadapter.h"

//RANDOM 3SAT TABLE FOR RHO ==================================================================================================
#define ITEADAPTER_MP_RHO_3SAT_TLINE(__tLine, __nVars) {\
	if (__nVars <= 1000){\
		__tLine = 0;\
	} else if (__nVars <= 6000){\
		__tLine = 1;\
	} else if (__nVars <= 10000){\
		__tLine = 2;\
	} else if (__nVars <= 20000){\
		__tLine = 3;\
	} else if (__nVars <= 25000){\
		__tLine = 4;\
	} else if (__nVars <= 30000){\
		__tLine = 5;\
	} else if (__nVars <= 40000){\
		__tLine = 6;\
	} else if (__nVars <= 50000){\
		__tLine = 7;\
	} else if (__nVars <= 75000){\
		__tLine = 8;\
	} else {\
		__tLine = 9;\
	}\
}

#define ITEADAPTER_MP_RHO_3SAT_TROW(__tRow, __rRatio) {\
	if (__rRatio <= 4.200){\
		__tRow = 0;\
	} else if (__rRatio <= 4.208){\
		__tRow = 1;\
	} else if (__rRatio <= 4.215){\
		__tRow = 2;\
	} else if (__rRatio <= 4.223){\
		__tRow = 3;\
	} else if (__rRatio <= 4.230){\
		__tRow = 4;\
	} else if (__rRatio <= 4.237){\
		__tRow = 5;\
	} else if (__rRatio <= 4.245){\
		__tRow = 6;\
	} else if (__rRatio <= 4.252){\
		__tRow = 7;\
	} else if (__rRatio <= 4.260){\
		__tRow = 8;\
	} else {\
		__tRow = 9;\
	}\
}

static const float_ty iteadapter_mp_rho_3SAT[10][10] = {
/*           R4200   R4208   R4215   R4223   R4230   R4237   R4245   R4252   R4260   R4267   */
/*   N1000*/{0.97665,0.92761,0.98502,0.98927,0.96232,0.98487,0.99500,0.99900,0.99990,1.00000},
/*   N6000*/{0.92955,0.95430,0.90257,0.89927,0.96156,0.96447,0.98000,0.99500,0.99900,1.00000},
/*  N10000*/{0.99451,0.99999,0.99919,0.99919,0.99640,0.99640,0.98000,0.99500,0.99900,1.00000},
/*  N20000*/{0.99414,0.99634,0.99268,0.99442,0.99830,0.99186,0.99500,0.99900,0.99950,1.00000},
/*  N25000*/{0.99300,0.99473,0.99257,0.99258,0.99191,1.00000,0.99500,0.99900,0.99950,1.00000},
/*  N30000*/{0.99448,0.99323,0.99457,0.99723,0.99772,0.99749,0.99800,0.99900,0.99950,1.00000},
/*  N40000*/{0.99343,0.99505,0.99470,0.99723,0.99303,0.99776,0.99543,0.99817,0.99900,1.00000},
/*  N50000*/{0.99244,0.99611,0.99185,0.99572,0.99559,0.99865,0.99719,0.99817,0.99900,1.00000},
/*  N75000*/{0.99167,0.99582,0.99716,0.99723,0.99493,0.99507,0.99719,0.99817,0.99900,1.00000},
/* N100000*/{0.99531,0.99665,0.99700,0.99584,0.99765,0.99849,0.99800,0.99817,0.99900,1.00000},
};
#define ITEADAPTER_MP_RHO_3SAT_GETVALUE(__tLine, __tRow) ( iteadapter_mp_rho_3SAT[__tLine][__tRow] )

//RANDOM 4SAT TABLE FOR RHO ==================================================================================================
#define ITEADAPTER_MP_RHO_4SAT_TLINE(__tLine, __nVars) {\
	if (__nVars <= 1000){\
		__tLine = 0;\
	} else if (__nVars <= 5000){\
		__tLine = 1;\
	} else if (__nVars <= 10000){\
		__tLine = 2;\
	} else if (__nVars <= 15000){\
		__tLine = 3;\
	} else if (__nVars <= 20000){\
		__tLine = 4;\
	} else {\
		__tLine = 5;\
	}\
}

#define ITEADAPTER_MP_RHO_4SAT_TROW(__tRow, __rRatio) {\
	if (__rRatio <= 9.000){\
		__tRow = 0;\
	} else if (__rRatio <= 9.121){\
		__tRow = 1;\
	} else if (__rRatio <= 9.223){\
		__tRow = 2;\
	} else if (__rRatio <= 9.324){\
		__tRow = 3;\
	} else if (__rRatio <= 9.425){\
		__tRow = 4;\
	} else if (__rRatio <= 9.526){\
		__tRow = 5;\
	} else if (__rRatio <= 9.627){\
		__tRow = 6;\
	} else if (__rRatio <= 9.729){\
		__tRow = 7;\
	} else if (__rRatio <= 9.830){\
		__tRow = 8;\
	}  else {\
		__tRow = 9;\
	}\
}

static const float_ty iteadapter_mp_rho_4SAT[6][10] = {
/*         R9000   R9121   R9223   R9324   R9425   R9526   R9627   R9729   R9830   R9931   */
/* N1000*/{0.95266,0.94954,0.80824,0.80824,0.80626,0.94406,0.94406,0.84824,0.99900,1.00000},
/* N5000*/{0.95739,0.80419,0.84190,0.98806,0.98967,0.99880,0.99750,0.95786,0.98000,1.00000},
/*N10000*/{0.96280,0.98181,0.98181,0.97740,0.99880,0.99970,0.99785,0.99980,0.99990,1.00000},
/*N15000*/{0.97726,0.97726,0.99368,0.99409,0.98765,0.98962,1.00000,1.00000,1.00000,1.00000},
/*N20000*/{0.98116,1.00000,1.00000,0.99913,0.99650,1.00000,0.99898,1.00000,1.00000,1.00000},
/*N25000*/{0.99145,0.99145,0.99145,0.99145,0.99954,0.99847,0.99553,0.99750,0.99900,1.00000},
};
#define ITEADAPTER_MP_RHO_4SAT_GETVALUE(__tLine, __tRow) ( iteadapter_mp_rho_4SAT[__tLine][__tRow] )

//RANDOM 5SAT TABLE FOR RHO ==================================================================================================
#define ITEADAPTER_MP_RHO_5SAT_TLINE(__tLine, __nVars) {\
	if (__nVars <= 300){\
		__tLine = 0;\
	} else if (__nVars <= 440){\
		__tLine = 1;\
	} else if (__nVars <= 720){\
		__tLine = 2;\
	} else if (__nVars <= 1000){\
		__tLine = 3;\
	} else if (__nVars <= 1280){\
		__tLine = 4;\
	} else {\
		__tLine = 5;\
	}\
}

#define ITEADAPTER_MP_RHO_5SAT_TROW(__tRow, __rRatio) {\
	if (__rRatio <= 20.000){\
		__tRow = 0;\
	} else if (__rRatio <= 20.155){\
		__tRow = 1;\
	} else if (__rRatio <= 20.275){\
		__tRow = 2;\
	} else if (__rRatio <= 20.395){\
		__tRow = 3;\
	} else if (__rRatio <= 20.516){\
		__tRow = 4;\
	} else if (__rRatio <= 20.636){\
		__tRow = 5;\
	} else if (__rRatio <= 20.756){\
		__tRow = 6;\
	} else if (__rRatio <= 20.876){\
		__tRow = 7;\
	} else if (__rRatio <= 20.997){\
		__tRow = 8;\
	}  else {\
		__tRow = 9;\
	}\
}

static const float_ty iteadapter_mp_rho_5SAT[6][10] = {
/*         R20000  R20155  R20275  R20395  R20516  R20636  R20756  R20876  R20997  R21117   */
/*  N300*/{0.07376,0.44735,0.67000,0.75000,0.85000,0.90000,0.99000,0.99900,1.00000,1.00000},
/*  N440*/{0.96780,0.83213,0.87000,0.90000,0.99000,0.99900,1.00000,1.00000,1.00000,1.00000},
/*  N720*/{0.88513,0.75957,0.85000,0.90000,0.99000,0.99900,1.00000,1.00000,1.00000,1.00000},
/* N1000*/{0.88513,0.93475,0.95000,0.99000,0.99900,1.00000,1.00000,1.00000,1.00000,1.00000},
/* N1280*/{0.91108,0.91108,0.55830,0.78000,0.89000,0.95000,0.99900,1.00000,1.00000,1.00000},
/* N1600*/{0.94910,0.80626,0.85662,0.85662,0.90000,0.99000,0.99900,1.00000,1.00000,1.00000},
};
#define ITEADAPTER_MP_RHO_5SAT_GETVALUE(__tLine, __tRow) ( iteadapter_mp_rho_5SAT[__tLine][__tRow] )

//RANDOM 6SAT TABLE FOR RHO ==================================================================================================
#define ITEADAPTER_MP_RHO_6SAT_TLINE(__tLine, __nVars) {\
	if (__nVars <= 200){\
		__tLine = 0;\
	} else if (__nVars <= 240){\
		__tLine = 1;\
	} else if (__nVars <= 280){\
		__tLine = 2;\
	} else if (__nVars <= 300){\
		__tLine = 3;\
	} else if (__nVars <= 340){\
		__tLine = 4;\
	} else {\
		__tLine = 5;\
	}\
}

#define ITEADAPTER_MP_RHO_6SAT_TROW(__tRow, __rRatio) {\
	if (__rRatio <= 40.000){\
		__tRow = 0;\
	} else if (__rRatio <= 40.674){\
		__tRow = 1;\
	} else if (__rRatio <= 41.011){\
		__tRow = 2;\
	} else if (__rRatio <= 41.348){\
		__tRow = 3;\
	} else if (__rRatio <= 41.685){\
		__tRow = 4;\
	} else if (__rRatio <= 42.022){\
		__tRow = 5;\
	} else if (__rRatio <= 42.359){\
		__tRow = 6;\
	} else if (__rRatio <= 42.696){\
		__tRow = 7;\
	} else if (__rRatio <= 43.033){\
		__tRow = 8;\
	}  else {\
		__tRow = 9;\
	}\
}

static const float_ty iteadapter_mp_rho_6SAT[6][10] = {
/*        R40000  R40674  R41011  R41348  R41685  R42022  R42359  R42696  R43033  R43370   */
/* N200*/{0.28682,0.58682,0.78000,0.89555,0.99000,0.99900,0.99990,1.00000,1.00000,1.00000},
/* N240*/{0.50137,0.78000,0.89555,0.99000,0.99900,0.99990,1.00000,1.00000,1.00000,1.00000},
/* N280*/{0.95435,0.99990,0.99990,0.99990,0.99990,0.99990,1.00000,1.00000,1.00000,1.00000},
/* N300*/{0.83545,0.99990,0.99990,0.99990,0.99990,0.99990,1.00000,1.00000,1.00000,1.00000},
/* N340*/{0.90514,0.96772,0.81247,0.99990,0.99990,0.99990,1.00000,1.00000,1.00000,1.00000},
/* N400*/{0.95000,0.56100,0.41729,0.99990,0.99990,0.99990,1.00000,1.00000,1.00000,1.00000},
};
#define ITEADAPTER_MP_RHO_6SAT_GETVALUE(__tLine, __tRow) ( iteadapter_mp_rho_6SAT[__tLine][__tRow] )

//RANDOM 7SAT TABLE FOR RHO ==================================================================================================
#define ITEADAPTER_MP_RHO_7SAT_TLINE(__tLine, __nVars) {\
	if (__nVars <= 100){\
		__tLine = 0;\
	} else if (__nVars <= 120){\
		__tLine = 1;\
	} else if (__nVars <= 140){\
		__tLine = 2;\
	} else if (__nVars <= 160){\
		__tLine = 3;\
	} else if (__nVars <= 180){\
		__tLine = 4;\
	} else {\
		__tLine = 5;\
	}\
}

#define ITEADAPTER_MP_RHO_7SAT_TROW(__tRow, __rRatio) {\
	if (__rRatio <= 85.000){\
		__tRow = 0;\
	} else if (__rRatio <= 85.558){\
		__tRow = 1;\
	} else if (__rRatio <= 85.837){\
		__tRow = 2;\
	} else if (__rRatio <= 86.116){\
		__tRow = 3;\
	} else if (__rRatio <= 86.395){\
		__tRow = 4;\
	} else if (__rRatio <= 86.674){\
		__tRow = 5;\
	} else if (__rRatio <= 86.953){\
		__tRow = 6;\
	} else if (__rRatio <= 87.232){\
		__tRow = 7;\
	} else if (__rRatio <= 87.511){\
		__tRow = 8;\
	}  else {\
		__tRow = 9;\
	}\
}

static const float_ty iteadapter_mp_rho_7SAT[6][10] = {
/*        R85000  R85558  R85837  R86116  R86395  R86674  R86953  R87232  R87511  R87790   */
/* N100*/{0.26779,0.26779,0.26779,0.26779,0.26779,0.26779,0.26779,0.26779,0.26779,0.26779},
/* N120*/{0.26779,0.26779,0.26779,0.26779,0.26779,0.26779,0.26779,0.26779,0.26779,0.26779},
/* N140*/{0.26779,0.26779,0.26779,0.26779,0.26779,0.26779,0.26779,0.26779,0.26779,0.26779},
/* N160*/{0.26779,0.26779,0.26779,0.26779,0.26779,0.26779,0.26779,0.26779,0.26779,0.26779},
/* N180*/{0.26779,0.26779,0.26779,0.26779,0.26779,0.26779,0.26779,0.26779,0.26779,0.26779},
/* N200*/{0.26779,0.26779,0.26779,0.26779,0.26779,0.26779,0.26779,0.26779,0.26779,0.26779},
};
#define ITEADAPTER_MP_RHO_7SAT_GETVALUE(__tLine, __tRow) ( iteadapter_mp_rho_7SAT[__tLine][__tRow] )

void iteadapter_extern_mpUR_random(uint32_t,uint32_t,float_ty);
void iteadapter_extern_mpUR_nonrandom();
void iteadapter_extern_mpURParams_random(uint32_t,uint32_t,float_ty);
void iteadapter_extern_mpURParams_nonrandom();

#endif /* ITEADAPTER_MP_H_ */
