/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#ifndef ITEADAPTER_PRE_H_
#define ITEADAPTER_PRE_H_

#include "iteadapter.h"

//Currently, nothing in PRE is being adapted.

#endif /* ITEADAPTER_PRE_H_ */
