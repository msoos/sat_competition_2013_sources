/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#ifndef ITEADAPTER_IN_H_
#define ITEADAPTER_IN_H_

#include "iteadapter.h"

//Currently, nothing in IN is adapted.

#endif /* ITEADAPTER_IN_H_ */
