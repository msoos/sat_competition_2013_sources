/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#ifndef DIMETHEUS_H_
#define DIMETHEUS_H_

#include "defines.h"

#include "params.h"

#include "_datastructures/clauses.h"
#include "_datastructures/variables.h"
#include "_datastructures/literals.h"
#include "_datastructures/formula.h"

CNF f;							//The formula we are currently working with.
variable* main_varData;			//The variable data array. Variable 42 is main_varData + 42.
literal* main_litData;			//The literal data array. Literal -42 is main_litData - 42.
int32_t main_returnCode;		//The return value of the solver. See defines.h for the values.
uint32_t main_litStamp;			//The stamp that is currently used for standard literal stamps.
uint32_t main_upStamp;			//The stamp that is currently used for unit propagation.

//Tool includes.
#include "_tools/tools.h"

//Guide includes.
#include "_guides/guides.h"

//Component includes.
#include "classify/classify.h"
#include "adapt/adapt.h"
#include "prep/prep.h"
#include "search/search.h"

void main_handle_signal(int);	//This is the signal handler. If the solver receives a signal it will terminate, no matter what.
void main_printSolverHeader();	//This prints the name and version number of the solver.
void main_resetAll();			//Resets all components and data-structures. Basically, everything is NULL then.
void main_startup();			//This starts up the solver.
void main_guide(int, char**);	//This will set the guide to use and apply it.
void main_classify();			//This will perform the classification phase.
void main_adapt();				//This will perform the adaptation phase.
void main_preprocess();			//This will perform the preprocessing phase.
void main_search();				//This will initialize searching phase.
int32_t main_verifyResultSAT();	//This method is used if the result is SATISFIABLE. It returns 0 (fails) or 1 (solution OK).
void main_printAssignments();	//This prints the assignment currently assigned to all the variables. DIMACS conform.
void main_printResult();		//Prints the result line and calls for printing the assignment, if necessary.
void main_shutdown();			//This shuts down the solver, and frees all necessary stuff.

int32_t main(int,char**);
#endif /* DIMETHEUS_H_ */
