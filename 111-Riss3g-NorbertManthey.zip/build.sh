#!/bin/sh
rm -rf binary
mkdir binary
cd code/riss3g;
make rissRS
cp riss3g ../../binary/
make clean
make simp
cp riss3g ../../binary/riss3gSimp
cd ../..
cp riss3g.sh riss3g-cert.sh binary
