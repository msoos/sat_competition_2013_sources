#!/bin/bash

echo "*** Creating a folder \"binary\"..."
mkdir binary

echo "*** Copying the run script..."
cd code
cp runShatterGlucose.sh ../binary

echo "*** Copying the removeTseitins script..."
cp removeTseitins.sh ../binary

echo "*** Compiling cnfdedup and copying the executable..."
cd cnfdedup
make
cp cnfdedup ../../binary

echo "*** Compiling saucy and shatter and copying the executables..."
cd ../saucy-3.0
make
cp saucy ../../binary
cp shatter ../../binary

echo "*** Compiling glucose and copying the executable..."
cd ../glucose-2.2/simp
make -r
cp glucose ../../../binary

echo "*** Browsing back to the parent folder..."
cd ../../../
