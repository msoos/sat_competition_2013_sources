#!/bin/bash

cd code/cnfdedup
make clean

cd ../saucy-3.0
make clean

cd ../glucose-2.2/simp
make clean

cd ../../../
rm -r binary

cd code