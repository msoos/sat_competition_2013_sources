===========================
Contents of this submission
===========================

The submission archive contains the files
* build.sh
* license.txt
* readme.txt
and the folder
* code
	which in turn contains the files
	* clean.sh
	* removeTseitins.sh
	* runShatterGlucose.sh
	and the source folders
	* glucose-2.2
	* saucy-3.0


==============
How to install
==============

Assuming the file "build.sh" and the folder "code" have the same parent folder, simply run "build.sh" from that folder. More info about which commands "build.sh" executes, is available as print statements in "build.sh".


==========
How to run
==========

After installation, the folder "binary" contains the script "runShatterGlucose.sh". Given a DIMACS cnf file and a folder to store temporary files, this script calls all the necessary preprocessors, the actual SAT-solver, returns the outcome (UNSAT or SAT + DIMACS certificate) to stdout. More info is available in "runShatterGlucose.sh".

To call: ./runShatterGlucose.sh <cnf-file> <temporary files folder>
e.g.:    ./runShatterGlucose.sh ~/Desktop/cnf_files/fpga10_9_sat.cnf /tmp

================
How to uninstall
================

Run code/clean.sh from the location of the folder "code".


===================
Solvers and Authors
===================

cnfdedup - Jo Devriendt
Saucy 3.0 - Paul T. Darga, Mark Liffiton, Hadi Katebi
Shatter - Originally Fadi A. Aloul, rewritten by Paul T. Darga
Glucose 2.2 - Gilles Audemard, Laurent Simon

