#!/bin/bash
export FM=$PWD/code/SatELite/ForMani

if [ ! -e binary ]; then
mkdir binary
fi

cd code/SatELite/SatELite
make r
cp SatELite_release ../../../binary/

cd ../../glucose/core
make rs
cp glucose_static ../../../binary/glucan_static
 
