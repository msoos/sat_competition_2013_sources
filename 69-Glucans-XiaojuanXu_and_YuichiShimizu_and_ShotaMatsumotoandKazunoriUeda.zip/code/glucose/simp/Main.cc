/*****************************************************************************************[Main.cc]
Copyright (c) 2003-2006, Niklas Een, Niklas Sorensson
Copyright (c) 2007,      Niklas Sorensson

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/

#include <errno.h>

#include <signal.h>
#include <zlib.h>
#include <sys/resource.h>

#include "utils/System.h"
#include "utils/ParseUtils.h"
#include "utils/Options.h"
#include "core/Dimacs.h"
#include "simp/SimpSolver.h"
#include "simp/SimpSolverG.h"

#include "core/PMinisat.h"
#include "core/ParallelCore.h"
#include "core/ParallelPool.h"

using namespace Minisat;

//=================================================================================================


template <class Solver>
void printStats(Solver& solver)
{
    double cpu_time = cpuTime();
    double mem_used = memUsedPeak();
    printf("c restarts              : %"PRIu64"\n", solver.starts);
/*    printf("c nb ReduceDB           : %lld\n", solver.nbReduceDB);
    printf("c nb removed Clauses    : %lld\n",solver.nbRemovedClauses);
    printf("c nb learnts DL2        : %lld\n", solver.nbDL2);
    printf("c nb learnts size 2     : %lld\n", solver.nbBin);
    printf("c nb learnts size 1     : %lld\n", solver.nbUn);*/

    printf("c conflicts             : %-12"PRIu64"   (%.0f /sec)\n", solver.conflicts   , solver.conflicts   /cpu_time);
    printf("c decisions             : %-12"PRIu64"   (%4.2f %% random) (%.0f /sec)\n", solver.decisions, (float)solver.rnd_decisions*100 / (float)solver.decisions, solver.decisions   /cpu_time);
    printf("c propagations          : %-12"PRIu64"   (%.0f /sec)\n", solver.propagations, solver.propagations/cpu_time);
    printf("c conflict literals     : %-12"PRIu64"   (%4.2f %% deleted)\n", solver.tot_literals, (solver.max_literals - solver.tot_literals)*100 / (double)solver.max_literals);
    //printf("c nb reduced Clauses    : %lld\n",solver.nbReducedClauses);

    if (mem_used != 0) printf("Memory used           : %.2f MB\n", mem_used);
    printf("c CPU time              : %g s\n", cpu_time);
}


DimacsCache dimacs_cache;
int nof_threads;
int nof_glueminisat;
pthread_mutex_t result_out_lock = PTHREAD_MUTEX_INITIALIZER;

SimpSolver** solver;
SimpSolverG** gsolver;

static FILE* assign_res;
static double initial_time;
static double file_parsed_time;
static double initial_dtime;
static double file_parsed_dtime;
static double end_dtime;

static IntOption    opt_glueminisat("MAIN", "nof-glueminisat","number of glueminisat threads.\n", 0, IntRange(0, INT32_MAX));

// Terminate by notifying the solver and back out gracefully. This is mainly to have a test-case
// for this feature of the Solver as it may take longer than an immediate call to '_exit()'.
static void SIGINT_interrupt(int signum) { solver[0]->interrupt(); }

// Note that '_exit()' rather than 'exit()' has to be used. The reason is that 'exit()' calls
// destructors and may cause deadlocks if a malloc/free function happens to be running (these
// functions are guarded by locks for multithreaded use).
static void SIGINT_exit(int signum) {
    printf("\n"); printf("*** INTERRUPTED ***\n");
    if (solver[0]->verbosity > 0){
        printStats(*solver[0]);
        printf("\n"); printf("*** INTERRUPTED ***\n"); }
    _exit(1); }

//=================================================================================================
// Main:
void *new_thread(void *args){
	//try {
		argdata* temp = (argdata*)args;
		int rank = temp->rank; int size = temp->size;
		//printf("%d: Start\n",rank);fflush(stdout);
		SimpSolver& S = *(solver[rank]);
		S.myrank 			= rank;
		S.mysize 			= size;
		S.random_seed		-= rank + 2;
		//S.random_var_freq = 0.001 * rank;
		if (rank == 1) {
			//S.ccmin_mode = 1;
			S.phase_saving = 1;
		}else if (rank == 2){
	    	S.contrasat = false;
		}else if (rank == 3){
	    	S.cirminisat = false;
	    }else if(rank == size - 1){
			S.phase_saving = 0;
	    }else{

	    	S.contrasat = false;
	    	S.cirminisat = false;
	    }

		S.start_time = get_dtime();
		if(rank != 0){
			if(S.verbosity > 0)
				printf("c %d: start read from cache\n",rank);
			parse_DIMACS_cache(S);
		}
		S.after_parse = get_dtime();
		if(S.verbosity > 0)
			printf("c %d: simplifing\n",rank);
        S.eliminate(true);
		if (!S.okay()){
			pthread_mutex_lock(&result_out_lock);
			if (assign_res != NULL) fprintf(assign_res, "UNSAT\n"), fclose(assign_res);
			if (S.verbosity > 0){
				printf("===============================================================================\n");
				printf("Solved by unit propagation\n");
				printStats(S);
				end_dtime = get_dtime();
				printf("c Wall time              : %g s\n", end_dtime - initial_dtime);
				printf("\n"); }
			printf("s UNSATISFIABLE\n");
			fflush(stdout);
			//write_stats_tofile(S, l_False);
			for(int i = 0; i < nof_threads; i++)
			    pthread_mutex_lock(&(dimacs_cache.lock[i]));
			_exit(20);
		}

		//pthread_barrier_wait( &solve_barrier );
		vec<Lit> dummy;
		if(S.verbosity > 0)
			printf("c %d: solving\n",rank);
		lbool ret = S.solveLimited(dummy);
		if (S.verbosity > 0){
			printStats(S);
			end_dtime = get_dtime();
			printf("c Wall time              : %g s\n", end_dtime - initial_dtime);
			printf("\n");
		}
		printf("s ");
		printf(ret == l_True ? "SATISFIABLE\n" : ret == l_False ? "UNSATISFIABLE\n" : "INDETERMINATE\n");

		if (ret == l_True){
		printf("v ");
		for (int i = 0; i < S.nVars(); i++)
			if (S.model[i] != l_Undef)
				printf("%s%s%d", (i==0)?"":" ", (S.model[i]==l_True)?"":"-", i+1);
		}
		fflush(stdout);

		//write_stats_tofile(S, ret);
		for(int i = 0; i < nof_threads; i++)
		    pthread_mutex_lock(&(dimacs_cache.lock[i]));
		if (assign_res != NULL){
			if (ret == l_True){
				fprintf(assign_res, "SAT\n");
				for (int i = 0; i < S.nVars(); i++)
					if (S.model[i] != l_Undef)
						fprintf(assign_res, "%s%s%d", (i==0)?"":" ", (S.model[i]==l_True)?"":"-", i+1);
				fprintf(assign_res, " 0\n");
			}else if (ret == l_False)
				fprintf(assign_res, "UNSAT\n");
			else
				fprintf(assign_res, "INDET\n");
			fclose(assign_res);
		}

		#ifdef NDEBUG
			//exit(ret == l_True ? 10 : ret == l_False ? 20 : 0);     // (faster than "return", which will invoke the destructor for 'Solver')
			_exit(ret == l_True ? 10 : ret == l_False ? 20 : 0);     // (faster than "return", which will invoke the destructor for 'Solver')
		#else
			pthread_exit(NULL);
			return NULL;
		#endif
		/*} catch (OutOfMemoryException&){
			printf("===============================================================================\n");
			printf("INDETERMINATE\n");
			exit(0);
		}*/
	return NULL;
}

void *new_threadg(void *args){
	//try {
		argdata* temp = (argdata*)args;
		int rank = temp->rank; int size = temp->size;
		//printf("%d: Start\n",rank);fflush(stdout);
		SimpSolverG& S = *(gsolver[ (nof_glueminisat + rank) - nof_threads]);

		S.myrank = rank;
		S.mysize = size;
		S.random_seed		-= rank + 2;
		//S.random_var_freq = 0.001 * rank;
		if (rank-nof_glueminisat == 1) {
			//S.ccmin_mode = 1;
			S.phase_saving = 1;
		}else if (rank-nof_glueminisat == 2){
			//S.ccmin_mode = 1;
		}else if (rank-nof_glueminisat == 3){
			//S.phase_saving = 0;
	    }else{
	    	S.contrasat = false;
	    	S.cirminisat = false;
	    }

		S.start_time = get_dtime();
		if(rank != 0){
			if(S.verbosity > 0)
				printf("c %d: start read from cache\n",rank);
			parse_DIMACS_cache(S);
		}
		S.after_parse = get_dtime();

		if(S.verbosity > 0)
			printf("c %d: simplifing\n",rank);
		S.eliminate(true);

		if (!S.okay()){
			pthread_mutex_lock(&result_out_lock);
			if (assign_res != NULL) fprintf(assign_res, "UNSAT\n"), fclose(assign_res);
			if (S.verbosity > 0){
				printf("c ===============================================================================\n");
				printf("c Solved by unit propagation\n");
				printStats(S);
				end_dtime = get_dtime();
				printf("c Wall time              : %g s\n", end_dtime - initial_dtime);
				printf("\n"); }
			printf("s UNSATISFIABLE\n");
			fflush(stdout);
			//write_stats_tofile(S, l_False);
			for(int i = 0; i < nof_threads; i++)
			    pthread_mutex_lock(&(dimacs_cache.lock[i]));
			_exit(20);
		}

		//pthread_barrier_wait( &solve_barrier );
		vec<Lit> dummy;
		if(S.verbosity > 0)
			printf("c %d: solving\n",rank);
		lbool ret = S.solveLimited(dummy);
		if (S.verbosity > 0){
			printStats(S);
			end_dtime = get_dtime();
			printf("c Wall time              : %g s\n", end_dtime - initial_dtime);
			printf("\n");
		}
		printf("s ");
		printf(ret == l_True ? "SATISFIABLE\n" : ret == l_False ? "UNSATISFIABLE\n" : "INDETERMINATE\n");
		if (ret == l_True){
		printf("v ");
		for (int i = 0; i < S.nVars(); i++)
			if (S.model[i] != l_Undef)
				printf("%s%s%d", (i==0)?"":" ", (S.model[i]==l_True)?"":"-", i+1);
		}
		fflush(stdout);

		//write_stats_tofile(S, ret);
		for(int i = 0; i < nof_threads; i++)
		    pthread_mutex_lock(&(dimacs_cache.lock[i]));
		if (assign_res != NULL){
			if (ret == l_True){
				fprintf(assign_res, "SAT\n");
				for (int i = 0; i < S.nVars(); i++)
					if (S.model[i] != l_Undef)
						fprintf(assign_res, "%s%s%d", (i==0)?"":" ", (S.model[i]==l_True)?"":"-", i+1);
				fprintf(assign_res, " 0\n");
			}else if (ret == l_False)
				fprintf(assign_res, "UNSAT\n");
			else
				fprintf(assign_res, "INDET\n");
			fclose(assign_res);
		}

		#ifdef NDEBUG
			//exit(ret == l_True ? 10 : ret == l_False ? 20 : 0);     // (faster than "return", which will invoke the destructor for 'Solver')
			_exit(ret == l_True ? 10 : ret == l_False ? 20 : 0);     // (faster than "return", which will invoke the destructor for 'Solver')
		#else
			pthread_exit(NULL);
			return NULL;
		#endif
		/*} catch (OutOfMemoryException&){
			printf("===============================================================================\n");
			printf("INDETERMINATE\n");
			exit(0);
		}*/
	return NULL;
}

template <class Solver>
void main_init(Solver& S, int argc, char** argv){

    if (S.verbosity > 0)
      {
    	printf("\n%s , %d, %d, \n",argv[1], nof_threads, S.exchange_limit), fflush (stdout);
	FILE* csvfp = fopen(get_result_filename().c_str(), "ab+");
	fprintf(csvfp, "\n%s, %d,", argv[1], nof_threads); fflush(csvfp);
	fclose(csvfp);
	leave_stamp("1");
      }
    gzFile in = (argc == 1) ? gzdopen(0, "rb") : gzopen(argv[1], "rb");
    if (in == NULL)
        printf("ERROR! Could not open file: %s\n", argc == 1 ? "<stdin>" : argv[1]), exit(1);

    if (S.verbosity > 0){
        printf("c ============================[ Problem Statistics ]=============================\n");
        printf("c |                                                                             |\n"); }

    dimacs_cache.first_input = true;
    parse_DIMACS(in, S); dimacs_cache.used = 1;
    dimacs_cache.first_input = false;
    gzclose(in);
	assign_res = (argc >= 3) ? fopen(argv[2], "wb") : NULL;

    if (S.verbosity > 0){
        printf("c |  Number of variables:  %12d                                         |\n", S.nVars());
        printf("c |  Number of clauses:    %12d                                         |\n", S.nClauses()); }

	file_parsed_time = cpuTime();
	file_parsed_dtime = get_dtime();

	if (S.verbosity > 0){
		printf("c |  File Parse time:           %12.2f s(WCT:%12.2f s)\n", file_parsed_time - initial_time, file_parsed_dtime - initial_dtime);
		printf("c |\n");
	    if (S.verbosity >= 1){
	        printf("c ============================[ Search Statistics ]==============================\n");
	        printf("c | Conflicts |          ORIGINAL         |          LEARNT          | Progress |\n");
	        printf("c |           |    Vars  Clauses Literals |    Limit  Clauses Lit/Cl |          |\n");
	        printf("c ===============================================================================\n");
	    }
	}
}


//=================================================================================================
// Main:

int main(int argc, char** argv)
{
    //try {
        setUsageHelp("USAGE: %s [options] <input-file> <result-output-file>\n\n  where input may be either in plain or gzipped DIMACS.\n");
        // printf("This is MiniSat 2.0 beta\n");
        
#if defined(__linux__)
        fpu_control_t oldcw, newcw;
        _FPU_GETCW(oldcw); newcw = (oldcw & ~_FPU_EXTENDED) | _FPU_DOUBLE; _FPU_SETCW(newcw);
        printf("c WARNING: for repeatability, setting FPU to use double precision\n");
#endif
        // Extra options:
        //
        IntOption    verb   ("MAIN", "verb",   "Verbosity level (0=silent, 1=some, 2=more).", 0, IntRange(0, 2));
        BoolOption   pre    ("MAIN", "pre",    "Completely turn on/off any preprocessing.", true);
        StringOption dimacs ("MAIN", "dimacs", "If given, stop after preprocessing and write the result to this file.");
        IntOption    cpu_lim("MAIN", "cpu-lim","Limit on CPU time allowed in seconds.\n", INT32_MAX, IntRange(0, INT32_MAX));
        IntOption    mem_lim("MAIN", "mem-lim","Limit on memory usage in megabytes.\n", INT32_MAX, IntRange(0, INT32_MAX));
        IntOption    opt_threads("MAIN", "nof-threads","number of threads.\n", 1, IntRange(0, INT32_MAX));

        parseOptions(argc, argv, true);
        nof_threads = (int32_t)opt_threads;
        nof_glueminisat = (int32_t)opt_glueminisat;

        SimpSolver s[nof_threads - nof_glueminisat]; solver = new SimpSolver*[nof_threads - nof_glueminisat];
        SimpSolverG gs[nof_glueminisat]; gsolver = new SimpSolverG*[nof_glueminisat];
        for(int i = 0; i < nof_threads - nof_glueminisat; i++)
        	solver[i] = &s[i];
        for(int i = 0; i < nof_glueminisat; i++)
        	gsolver[i] = &gs[i];

        initial_time = cpuTime();
        initial_dtime = get_dtime();

        for(int i = 0; i < nof_threads - nof_glueminisat; i++){
        	s[i].verbosity = verb;
        	if (!pre) s[i].eliminate(true);
        }
        for(int i = 0; i < nof_glueminisat; i++){
        	gs[i].verbosity = verb;
        	if (!pre) gs[i].eliminate(true);
        }
        
        // Use signal handlers that forcibly quit until the solver will be able to respond to
        // interrupts:
        //signal(SIGINT, SIGINT_exit);
        //signal(SIGXCPU,SIGINT_exit);

        // Set limit on CPU-time:
        if (cpu_lim != INT32_MAX){
            rlimit rl;
            getrlimit(RLIMIT_CPU, &rl);
            if (rl.rlim_max == RLIM_INFINITY || (rlim_t)cpu_lim < rl.rlim_max){
                rl.rlim_cur = cpu_lim;
                if (setrlimit(RLIMIT_CPU, &rl) == -1)
                    printf("WARNING! Could not set resource limit: CPU-time.\n");
            } }

        // Set limit on virtual memory:
        if (mem_lim != INT32_MAX){
            rlim_t new_mem_lim = (rlim_t)mem_lim * 1024*1024;
            rlimit rl;
            getrlimit(RLIMIT_AS, &rl);
            if (rl.rlim_max == RLIM_INFINITY || new_mem_lim < rl.rlim_max){
                rl.rlim_cur = new_mem_lim;
                if (setrlimit(RLIMIT_AS, &rl) == -1)
                    printf("WARNING! Could not set resource limit: Virtual memory.\n");
            } }
        
        if (argc == 1)
            printf("Reading from standard input... Use '--help' for help.\n");

        gzFile in = (argc == 1) ? gzdopen(0, "rb") : gzopen(argv[1], "rb");
        if (in == NULL)
            printf("ERROR! Could not open file: %s\n", argc == 1 ? "<stdin>" : argv[1]), exit(1);
        

        if(nof_threads == nof_glueminisat)
        	main_init(gs[0], argc, argv);
        else
        	main_init(s[0], argc, argv);

        dimacs_cache.lock = new pthread_mutex_t[nof_threads];
        for(int i = 0; i < nof_threads; i++){
        	pthread_mutex_init(&(dimacs_cache.lock[i]), NULL);
        }

	    pthread_t threads[nof_threads];
	    ParallelPool::pool = new ParallelPool[nof_threads];

		argdata args[nof_threads];
		for(int i = 0; i < nof_threads - nof_glueminisat; i++) {
			args[i].rank = i; args[i].size = nof_threads;
			pthread_create(&(threads[i]), NULL, new_thread, (void *)&args[i]);
		}
		for(int i = nof_threads - nof_glueminisat; i < nof_threads; i++) {
			args[i].rank = i; args[i].size = nof_threads;
			pthread_create(&(threads[i]), NULL, new_threadg, (void *)&args[i]);
		}

		for (int i = 0; i < nof_threads; i++)
			pthread_join(threads[i], NULL);

#ifdef NDEBUG
        _exit(-1);     // (faster than "return", which will invoke the destructor for 'Solver')
#else
        return (0);
#endif
    /*} catch (OutOfMemoryException&){
        printf("===============================================================================\n");
        printf("INDETERMINATE\n");
        exit(0);
    }*/
}
