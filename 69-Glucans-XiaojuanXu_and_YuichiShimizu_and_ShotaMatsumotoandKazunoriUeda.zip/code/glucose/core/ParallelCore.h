/*
 * ParallelCore.h
 *
 *  Created on: 2012/01/30
 *      Author: xxj
 */

#ifndef PARALLELCORE_H_
#define PARALLELCORE_H_

#include "core/Solver.h"
#include "ParallelPool.h"

using namespace Minisat;

template <class Solver>
void write_stats_tofile(Solver& S, lbool ret){
	FILE* csvfp = fopen(get_result_filename().c_str(), "ab+");
	fprintf(csvfp, ret == l_True ? "SATISFIABLE," : ret == l_False ? "UNSATISFIABLE," : "INDETERMINATE,");
	fprintf(csvfp, "%d,%f,",S.myrank, get_dtime() - S.start_time);
	fprintf(csvfp, "%"PRIu64",%"PRIu64",", S.starts, S.conflicts);
	fprintf(csvfp, "%"PRIu64",%"PRIu64",", S.decisions, S.rnd_decisions);
	fprintf(csvfp, "%"PRIu64",", S.propagations);
	fprintf(csvfp, "%"PRIu64",%"PRIu64",", S.tot_literals, S.max_literals);
	fprintf(csvfp, "%2f,", S.comm_time);
	fprintf(csvfp, "%2f,", S.wait_time);
	fprintf(csvfp, "%2f,", S.prop_time);
	fprintf(csvfp, "%2f,", S.after_parse - S.start_time);
	fprintf(csvfp, "%"PRIu64",", S.comm_num);
	fprintf(csvfp, "%"PRIu64",", S.recv_lemma_num);
	fprintf(csvfp, "%"PRIu64",", S.recv_lemma_size);
	fprintf(csvfp, "%"PRIu64",", S.recv_ulit);
	fprintf(csvfp, "%"PRIu64",", S.sent_learnts);
	fprintf(csvfp, "%"PRIu64",", S.sent_literals);
	fprintf(csvfp, "%"PRIu64",", S.sent_ulit);
	fprintf(csvfp, "%d,", S.exchange_limit);
	double mem_used = memUsedPeak();
	if (mem_used != 0) fprintf(csvfp, "%.2f MB,", mem_used);
	fflush(csvfp); fclose(csvfp);
	leave_stamp("0");
}

#endif /* PARALLELCORE_H_ */
