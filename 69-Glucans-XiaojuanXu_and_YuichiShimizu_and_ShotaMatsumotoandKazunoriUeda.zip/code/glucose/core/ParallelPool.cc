/* ParallelPool.cc

Glucans -- Copyright (c) 2012, 2013 Xiaojuan Xu, Yuichi Shimizu, Shota Matsumoto, Kazunori Ueda
                                    Waseda Univ. Tokyo, Japan

Glucans sources are based on Glucose (see below Glucose copyrights). Permissions and copyrights of
Glucans are exactly the same as Glucose on which it is based on. (see below).

--------

Glucose -- Copyright (c) 2009,2011, Gilles Audemard, Laurent Simon
				CRIL - Univ. Artois, France
				LRI  - Univ. Paris Sud, France
 
Glucose sources are based on MiniSat (see below MiniSat copyrights). Permissions and copyrights of
Glucose are exactly the same as Minisat on which it is based on. (see below).

--------

MiniSat -- Copyright (c) 2003-2006, Niklas Een, Niklas Sorensson
           Copyright (c) 2007-2010  Niklas Sorensson

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

#include <stdio.h>
#include "core/ParallelPool.h"

namespace Minisat {

ParallelPool* ParallelPool::pool = NULL;

ParallelPool::ParallelPool() {
	head 		= NULL;							//the initial state should be empty
	tail 		= NULL;							//the initial state should be empty
	pthread_mutex_init(&lock, NULL);
}

ParallelPool::~ParallelPool() {

}

//Add Data
void ParallelPool::MakeList(PoolData** newone, int size, PoolElement*& partial_head, PoolElement*& partial_tail){
	assert (size > 0);
	PoolElement* local_elem 	= new PoolElement(newone[0]);
	partial_head 	= local_elem;
	partial_tail 	= local_elem;
	for(int i = 1; i < size; i++){
		assert (newone[i]->clause.size() > 0);
		local_elem = new PoolElement(newone[i]);
		partial_tail->next = local_elem;
		partial_tail = local_elem;
	}
	assert(local_elem != NULL);
	assert(partial_head != NULL);
	assert(partial_tail != NULL);
}

//Add List
void ParallelPool::AddList(PoolElement* partial_head, PoolElement* partial_tail){
	pthread_mutex_lock(&lock);
	if(head == NULL){
		assert(tail == NULL);
		head = partial_head;
		tail = partial_tail;
	}else if(tail != partial_tail){
		assert(head != NULL);
		tail->next = partial_head;
		tail = partial_tail;
	}
	pthread_mutex_unlock(&lock);
}

//Read Data
PoolElement* ParallelPool::ReadOne(){
	PoolElement* elem = NULL;
	pthread_mutex_lock(&lock);
	if(head != NULL){
		//Garbage.push(head);
		elem = head;
		head = head->next;
	}
	if(head == NULL) tail = NULL;
	pthread_mutex_unlock(&lock);
	return elem;
}

void ParallelPool::ReadFinalize(){
	for(int i = 0; i < Garbage.size(); i++){
		Garbage[i]->GC();
		delete(Garbage[i]);
	}
	Garbage.clear();
}

} /* namespace Minisat */
