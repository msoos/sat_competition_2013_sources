/*
PMinisat.h

Glucans -- Copyright (c) 2012, 2013 Xiaojuan Xu, Yuichi Shimizu, Shota Matsumoto, Kazunori Ueda
                                    Waseda Univ. Tokyo, Japan

Glucans sources are based on Glucose (see below Glucose copyrights). Permissions and copyrights of
Glucans are exactly the same as Glucose on which it is based on. (see below).

--------

Glucose -- Copyright (c) 2009,2011, Gilles Audemard, Laurent Simon
				CRIL - Univ. Artois, France
				LRI  - Univ. Paris Sud, France
 
Glucose sources are based on MiniSat (see below MiniSat copyrights). Permissions and copyrights of
Glucose are exactly the same as Minisat on which it is based on. (see below).

--------

MiniSat -- Copyright (c) 2003-2006, Niklas Een, Niklas Sorensson
           Copyright (c) 2007-2010  Niklas Sorensson

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
#ifndef PMinisat_h
#define PMinisat_h

#include <fstream>
#include <iostream>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <time.h>
#include <unistd.h>
#include <vector>

#include "core/Solver.h"

#define MAX_LEMMA_LIMIT 20

using namespace Minisat;
using namespace std;

//cnf cache
typedef struct {
	pthread_mutex_t* lock;
	pthread_mutex_t usedlock;
	bool first_input;
	int used;
	vector< vector<int> >* db;
}DimacsCache;

// pthread arg
typedef struct {
	int rank;
    int size;
}argdata;

extern DimacsCache dimacs_cache;
extern pthread_mutex_t result_out_lock;
//extern pthread_barrier_t solve_barrier;
extern int nof_threads;

//extern void Global_varBumpActivity(int var);
/*inline*/

//time
inline double get_dtime(void){
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return ((double)(tv.tv_sec) + (double)(tv.tv_usec) * 0.001 * 0.001);
}

//results
inline void leave_stamp(const char* stamp){
	FILE* stampfp = fopen("c-sat.stamp", "w");
	fprintf(stampfp, stamp);
	fflush(stampfp); fclose(stampfp);
}
inline string get_result_filename(){
	string resultfile = "result.csv";
	ifstream fconf; fconf.open("result.cfg");
	if (fconf){
		getline(fconf, resultfile);
	}
	return resultfile;
}

#endif
