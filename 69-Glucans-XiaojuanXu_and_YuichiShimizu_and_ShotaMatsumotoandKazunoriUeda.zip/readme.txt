Name of this solver : Glucans

Version : strict

Authors : Xiaojuan Xu, Yuichi Shimizu, Shota Matsumoto and Kazunori Ueda (Waseda Univ. Tokyo, Japan)

For compiling : ./build.sh

For running : ./glucan_static INSTANCE -mem-lim=15000  -tmpdir=TEMPDIR -contrasat -nof-threads=8 -se-lim=120 -strictlbd -keep-lbd=2 -sendmore
