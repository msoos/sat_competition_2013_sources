#!/bin/bash

echo "*** Creating a folder \"binary\"..."
mkdir binary

echo "*** Copying the run script..."
cd code
cp runBreakIDGlucose.sh ../binary

echo "*** Copying the removeTseitins script..."
cp removeTseitins.sh ../binary

echo "*** Compiling cnfdedup and copying the executable..."
cd cnfdedup
make
cp cnfdedup ../../binary

echo "*** Compiling BreakID and copying the executable..."
cd ../BreakID
make
cp BreakID ../../binary

echo "*** Compiling saucy and copying the executable..."
cd ../saucy-3.0
make
cp saucy ../../binary

echo "*** Compiling glucose and copying the executable..."
cd ../glucose-2.2/simp
make -r
cp glucose ../../../binary

echo "*** Browsing back to the parent folder..."
cd ../../../
