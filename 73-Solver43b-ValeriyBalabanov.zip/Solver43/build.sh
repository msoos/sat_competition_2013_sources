#!/bin/bash
mkdir binary

cd code/core
gmake rs
cp Solver43_static ../../binary

make clean