Solver43, version "b" (with variable cleaning)

For static compiling: 
./build.sh


For running: 
./solver43_static BENCHNAME