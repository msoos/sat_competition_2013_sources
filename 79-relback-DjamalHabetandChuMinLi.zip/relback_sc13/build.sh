#!/bin/bash
export FM=$PWD/code/SatELite/ForMani

mkdir binary

mv relback.sh binary/ 

cd code/SatELite/SatELite
make r
cp SatELite_release ../../../binary

cd ../../relback/core
make rs
cp relback_static ../../../binary
 
