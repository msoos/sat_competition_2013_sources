#!/bin/bash

mkdir binary

cd code

make

cp CCAnr ../binary/CCAnr

