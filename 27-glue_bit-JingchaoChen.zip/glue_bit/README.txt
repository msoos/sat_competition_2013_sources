glue_bit  is developed by Jingchao Chen, Donghua University, China, 2013

For compiling : 
   ./build.sh


For running
cd binary
glue_bit.sh BENCHNAME TEMPDIR

