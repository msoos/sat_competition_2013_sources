#!/bin/bash

mkdir -p binary
cd code

export FM=$PWD/sources/SatELite/ForMani

cp glue_bit.sh ../binary/glue_bit.sh

cd sources/SatELite/SatELite
make r
cp SatELite_release ../../../../binary

cd ../../glue_bit/core
make rs
cp glue_bit_static ../../../../binary
 
