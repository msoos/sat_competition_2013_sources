#!/bin/bash
export FM=$PWD/sources/SatElite/ForMani
rm -rf glue_bit_static 
rm -rf SatELite_release

cd sources/SatElite/SatELite
make clean 

cd ../../glue_bit/core
make clean 

find . -name 'depend.mak' -delete 
