cd code/simp
make
cp minisat ../../binary
make clean
