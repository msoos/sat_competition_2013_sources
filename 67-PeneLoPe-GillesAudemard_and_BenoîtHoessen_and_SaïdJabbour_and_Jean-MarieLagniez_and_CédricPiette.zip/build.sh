make -C code CONF=Release SHARED=-static penelope SatELite
mkdir binary
cp code/penelope code/SatELite_release code/configuration.ini code/solver.sh ./binary/
