It is complied by g++ with -m32 -O2 -static options.
complie CCA2013 as
gcc code/CCA2013.c -O2 -static -o binary/CCA2013

It is submitted to SAT Challenge 2013.
run CCA2013 as
binary/CCA2013 <instance file> <random seed>



/************************************=== CCA2013 ===***************************************         
** CCA2013 is a local search solver for the Boolean Satisfiability (SAT) problem.
** We have referred to CCASat, but we write our codes ourselves, and we
** have fixed some bugs in the original source codes.
** CCA2013 is implemented by Chengqian Li, 
** when he was in Department of Computer Science, Sun Yat-sen University,
** and this solver exploits the strategies of both Chengqian Li and Yi Fan,
** who is from Institute of Integrated and Intelligent Systems, Griffith University.   
** Email: 498727460@qq.com
*****************************************************************************************/


/************************************=== Acknowledgement ===*************************************
** We thank Prof. Yongmei Liu for introducing us into such an
** exciting and competitive domain. We also thank Prof. Kaile Su
** and Dr. Shaowei Cai for sharing their state-of-the-art strategies
** with us. This work was supported by the Natural Science
** Foundation of China under Grant No. 61073053.
************************************************************************************************/
