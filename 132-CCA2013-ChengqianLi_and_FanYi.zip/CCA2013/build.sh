gcc code/CCA2013.c -O2 -static -o binary/CCA2013
