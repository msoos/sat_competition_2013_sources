#!/bin/bash

mkdir binary

cp code/RSeq.sh binary/
cp code/RSeqSattime.sh binary/

cd code/sattime2013 
icc sattime2013bis.c -O3 -static -o sattime
  
mv sattime ../../binary

cd ../relback/core
make clean
make rs
cp relback_static ../../../binary


 
