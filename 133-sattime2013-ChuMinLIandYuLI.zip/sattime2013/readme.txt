This is the SLS SAT solver sattime2013 submitted to the satcompetition
2013, by Chu Min LI and Yu LI.
To build the executable, type build.sh or 
icc sattime2013.c -O3 -static -o sattime2013 in the code subdirectory

to call the solver, type

sattime2013 INSTANCE -seed SEED -nbsol 1
