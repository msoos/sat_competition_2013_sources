#!/bin/sh
    
 mkdir binary
 cd code
 icc sattime2013.c -O3 -static -o sattime2013
 mv sattime2013 ../binary


