minisat_bit_u  is a hack version of Minisat, 
 developed by Jingchao Chen, Donghua University, China, 2013
minisat_bit_u emits a proof in DRUP format for the certified UNSAT tracks, 
 
================================================================================
DIRECTORY OVERVIEW:

mtl/            Mini Template Library
utils/          Generic helper code (I/O, Parsing, CPU-time, etc)
core/           A core version of the solver
simp/           An extended solver with simplification capabilities
README
LICENSE

================================================================================

For compiling : 
   ./build.sh

================================================================================

For running 
binary/minisat_bit_u BENCHNAME 

