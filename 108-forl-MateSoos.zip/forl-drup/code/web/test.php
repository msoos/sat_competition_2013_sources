<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8">
    <title>Cryptominisat</title>

    <link rel="stylesheet" type="text/css" href="jquery.jqplot.css" />
    <script type="text/javascript" src="jquery/jquery.min.js"></script>
    <script type="text/javascript" src="dygraphs/dygraph-dev.js"></script>
    <script type="text/javascript" src="highcharts/js/highcharts.js"></script>
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/prototype/1.6.1/prototype.js"></script>
    <script type="text/javascript" src="scriptaculous-js-1.9.0/src/scriptaculous.js"></script>
    <script type="text/javascript" src="dragdrop/js/portal.js"></script>
    <style>
        @import url(//fonts.googleapis.com/css?family=Yanone+Kaffeesatz:400,700);
        @import url(style.css);
    </style>
    <style type="text/css">
    div.other{
        border:1px solid black;
    }*/
    </style>
</head>
<body>

<script type="text/javascript">
<?
$runID = 1472309933;
$runID2 = 3962017339;
error_reporting(E_ALL);
error_reporting(E_STRICT);
//error_reporting(E_STRICT);

$username="presenter";
$password="presenter";
$database="cryptoms";

mysql_connect(localhost, $username, $password);
@mysql_select_db($database) or die( "Unable to select database");

function getMaxSize($runID, $runID2)
{
    $query="
    SELECT max(size) as mymax FROM clauseSizeDistrib
    where (runID = $runID or  runID = $runID2)
    and num > 10";
    $result=mysql_query($query);

    if (!$result) {
        die('Invalid query: ' . mysql_error());
    }
    return mysql_result($result, 0, "mymax");
}

function getMaxConfl($runID, $runID2)
{
    $query="
    SELECT max(conflicts) as mymax FROM clauseSizeDistrib
    where (runID = $runID or  runID = $runID2)
    and num > 0";
    $result=mysql_query($query);

    if (!$result) {
        die('Invalid query: ' . mysql_error());
    }
    return mysql_result($result, 0, "mymax");
}

$maxSize = getMaxSize($runID, $runID2) - 1; //Because no use for size 0
echo "var maxSize = $maxSize;\n";
$maxConfl = getMaxConfl($runID, $runID2);
echo "var maxConfl = $maxConfl;\n";
$statPer = 1000;
echo "var statPer = $statPer;\n";


function fillClauseDistrib($num, $runID, $maxConfl, $maxSize, $statPer)
{
    echo "clauseDistrib.push([]);";
    for($i = $statPer; $i <= $maxConfl; $i += $statPer) {
        echo "tmp = [";

        $query = "
        SELECT num FROM clauseSizeDistrib
        where runID = $runID
        and conflicts = $i
        and size <= $maxSize
        and size > 0
        order by conflicts,size";
        $result=mysql_query($query);
        if (!$result) {
            die('Invalid query: ' . mysql_error());
        }
        $nrows=mysql_numrows($result);

        $i2=0;
        while ($i2 < $nrows) {
            $numberOfCl = mysql_result($result, $i2, "num");
            echo $numberOfCl;

            $i2++;
            if ($i2 < $nrows)
                echo ",";
        }
        echo "];";
        echo "clauseDistrib[$num].push(tmp);\n";
    }
}

echo "var clauseDistrib = [];\n";
fillClauseDistrib(0, $runID, $maxConfl, $maxSize, $statPer);
fillClauseDistrib(1, $runID2, $maxConfl, $maxSize, $statPer);
?>
</script>


<table id="plot-table-a">
    <tr>
    <td><div id="drawingPad0" class="myPlotData other"></div></td>
    <td><div class="draghandle">mylabel</div></td>
    </tr>
</table>

<table id="plot-table-a">
    <tr>
    <td><div id="drawingPad1" class="myPlotData other"></div></td>
    <td><div class="draghandle">mylabel</div></td>
    </tr>
</table>


<script type="text/javascript">
    var xhtmlNS = "http://www.w3.org/1999/xhtml";
    var svgNS = "http://www.w3.org/2000/svg";
    var xlinkNS ="http://www.w3.org/1999/xlink";

    function makeRect(x1, x2, y1, y2, relHeight){
        num = relHeight*255.0;
        //document.write("<p>" + num+ "</p>");

        type = "fill:rgb(" + Math.floor(num) + "," + Math.floor(num) + "," + Math.floor(num) + ");";
        type += "stroke-width:0;stroke:rgb(" + Math.floor(num) + "," + Math.floor(num) + "," + Math.floor(num) + ");";
        //document.write("<p>" + type+ "</p>");
        var vRect = document.createElementNS(svgNS, "svg:rect");
        vRect.setAttributeNS( null, "x", new String( x1  ) + "px");
        vRect.setAttributeNS( null, "y", new String( y1  ) + "px");
        vRect.setAttributeNS( null, "width", new String( x2-x1  ) + "px");
        vRect.setAttributeNS( null, "height", new String( y2-y1  ) + "px");
        vRect.setAttributeNS( null, "style", type);

        return vRect;
    }

    function drawPattern(data, num){
        var vSVGElem = document.createElementNS(svgNS, "svg:svg");

        var vPad = document.getElementById( "drawingPad" + num);
        var width = 420;//vPad.style.width; // removes the "px" at the end
        var height = 100;vPad.style.height;
        var i;

        var vAX = new Array();
        num = maxConfl/statPer;
        for(i = 0; i < num; i++) {
            vAX.push(i*(width/num));
        }
        vAX.push(width);

        var vAY = new Array();
        for(i = maxSize; i >= 0; i--) {
            vAY.push(i*(height/maxSize));
        }
        vAY.push(0);

        var vRect = makeRect(0, width, 0, height, 0);
        vSVGElem.appendChild( vRect );

        for( i = 0 ; i < data.length ; i ++ ){
            maxHeight = 0;
            for(i2 = 0; i2 < data[i].length; i2++) {
                maxHeight = Math.max(maxHeight, data[i][i2]);
            }
            //maxHeight = Math.log(maxHeight);

            xStart = vAX[i];
            xEnd = vAX[i+1];

            for(i2 = 0; i2 < data[i].length; i2++) {
                yStart = vAY[i2+1];
                yEnd = vAY[i2];

                if (data[i][i2] != 0) {
                    //relHeight = Math.log(data[i][i2])/maxHeight;
                    relHeight = data[i][i2]/maxHeight;
                } else {
                    relHeight  = 0;
                }

                var vRect = makeRect(xStart, xEnd, yStart, yEnd, relHeight);
                vSVGElem.appendChild( vRect );
            }
        }

        vPad.appendChild(vSVGElem)
    }
    drawPattern(clauseDistrib[0], 0);
    drawPattern(clauseDistrib[1], 1);
</script>

</body>
</html>

