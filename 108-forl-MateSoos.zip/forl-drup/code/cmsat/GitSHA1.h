const char* get_git_version();

