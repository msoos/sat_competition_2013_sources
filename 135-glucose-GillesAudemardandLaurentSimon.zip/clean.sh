rm -rf binary
cd code/glucose2.3/core
make clean
cd ../simp
make clean

