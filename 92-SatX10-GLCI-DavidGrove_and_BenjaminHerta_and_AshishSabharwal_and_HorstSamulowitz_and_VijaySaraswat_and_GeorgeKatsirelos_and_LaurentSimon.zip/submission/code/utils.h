// -----------------------------------------------------------------
// Licensed Materials - Property of IBM
//
// SatX10
//
// (C) Copyright IBM Corporation 2012.  All Rights Reserved.
//
// Authors: Bard Bloom, David Grove, Benjamin Herta,
//          Vijay Sarawat, Ashish Sabharwal, Horst Samulowitz
// -----------------------------------------------------------------

#ifndef SatX10_utils_h
#define SatX10_utils_h


// I/O related headers
#include <iostream>
#include <fstream>
#include <iomanip>
#include <sstream>

using std::cout;
using std::cerr;
using std::endl;
using std::ostream;
using std::ifstream;
using std::setw;
using std::stringstream;


// Assert
#include <cassert>


// Exception handling
using std::exception;


// Limits
#include <limits>

static const int        limits_int_min        = std::numeric_limits<int>::min();
static const int        limits_int_max        = std::numeric_limits<int>::max();
static const unsigned   limits_unsigned_min   = std::numeric_limits<unsigned>::min();
static const unsigned   limits_unsigned_max   = std::numeric_limits<unsigned>::max();
static const double     limits_double_min     = std::numeric_limits<double>::min();
static const double     limits_double_max     = std::numeric_limits<double>::max();


// STL classes
#include <vector>
#include <set>
#include <algorithm>

using std::vector;
using std::set;
using std::pair;
using std::string;


// STL classes: special considerations for hash_map
#ifdef _MSC_VER
#include <hash_map>
using stdext::hash_map;
using stdext::hash_compare;
// define hash_map for string to template type T as type hashMapStrT_t
struct less_string {
    bool operator()(const string & s1, const string & s2) const {
        return strcmp(s1.c_str(), s2.c_str()) < 0;
    }
};
template <typename T>
struct hashMapStrT {
    typedef hash_map<const string, T, hash_compare<string, less_string> >   type;
};
#else
#include <ext/hash_map>
#include <cstring>
using __gnu_cxx::hash_map;
using __gnu_cxx::hash;
// define hash_map for string to type T as type hashMapStrT_t
struct eq_string {
    bool operator()(const string & s1, const string & s2) const {
        return strcmp(s1.c_str(), s2.c_str()) == 0;
    }
};
namespace __gnu_cxx {
    template<> struct hash<string> {
        size_t operator()(string _s) const {return __stl_hash_string(_s.c_str());}
    };
}
template <typename T>
struct hashMapStrT {
    typedef hash_map<const string, T, hash<string>, eq_string>   type;
};
#endif

// examples of hash maps for various types "T"
typedef hashMapStrT<char>::type   hashMapStrChar_t;
typedef hashMapStrT<int>::type    hashMapStrInt_t;
typedef hashMapStrT<double>::type hashMapStrDouble_t;


// convert an int to an std::string  (don't know of any other, more direct way, unfortunately)
inline string intToString(const int a) {
    stringstream ss;
    ss << a;
    return ss.str();
}

// convert a vector<int> to an std::string using 'sep' as the separator
// (don't know of any other, more direct way, unfortunately)
inline string intVectorToString(const vector<int> & v, const int sep = 0) {
    stringstream ss;
    for (unsigned i=0; i<v.size()-1; i++)
        ss << v[i] << sep;
    ss << v.back();
    return ss.str();
}

// split a string into a vector of string based on a delimiter;
// output in 'elems'
inline void split(const string & s, const char delim, vector<string> & elems) {
    stringstream ss(s);
    string item;
    elems.clear();
    while (std::getline(ss, item, delim))
        elems.push_back(item);
}
// return the output
inline vector<string> split(const string & s, const char delim) {
    vector<string> elems;
    split(s, delim, elems);
    return elems;
}


#endif   // SatX10_utils_h
