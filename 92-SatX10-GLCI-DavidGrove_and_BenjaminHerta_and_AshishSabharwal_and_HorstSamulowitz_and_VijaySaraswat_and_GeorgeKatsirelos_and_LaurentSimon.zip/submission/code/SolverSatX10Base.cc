// -----------------------------------------------------------------
// Licensed Materials - Property of IBM
//
// SatX10
//
// (C) Copyright IBM Corporation 2012.  All Rights Reserved.
//
// Authors: Bard Bloom, David Grove, Benjamin Herta,
//          Vijay Sarawat, Ashish Sabharwal, Horst Samulowitz
// -----------------------------------------------------------------


#include "SolverSatX10Base.h"
#include <cassert>


// define the static int object
const int    ClauseWithInfo::sep  =  0;


bool ClauseWithInfo::createFromSerializedObject(vector<int> & serialVec, unsigned & pos,
                                                const int currentPlaceID, const bool discardIDs)
{
    bool discardClause = false;
    // clear fields (from possible prior use)
    clause.clear();
    placeIDs.clear();
    otherInfo.clear();

    // first parse a clause
    assert(pos < serialVec.size());
    assert(serialVec[pos] != sep);  // clause must have non-zero length
    while (serialVec[pos] != sep)
        clause.push_back(serialVec[pos++]);
    // skip the separator
    pos++;

    // now parse the place IDs; if the ID of this place appears in the list, this
    // place has already seen (and even sent) this clause -- simply discard the clause;
    // otherwise, push it to the incoming buffer -- but discard IDs (except the latest
    // sender) if x10_hubLevel is zero as non-hubs do not forward clauses received from
    // other places
    while (serialVec[pos] != sep) {
        const int ID = serialVec[pos] - 1;        // IDs are shifted by -1 when deserializing
        pos++;                                    // advance cursor to the next position
        if (ID == currentPlaceID) {
            discardClause = true;
            while (serialVec[pos] != sep) pos++;  // discard the remaining IDs
        }
        else {
            if (!discardIDs)
                placeIDs.push_back(ID);               // this must be a hub solver; store all IDs
            else if (serialVec[pos] == sep)
                placeIDs.push_back(ID);               // this must be a leaf solver; retain only the latest ID
        }
    }
    // skip the separator
    pos++;

    // now parse any additional info that may have been provided
    while (serialVec[pos] != sep)
        otherInfo.push_back(serialVec[pos++]);
    // skip the separator
    pos++;

    // return discardClause
    return discardClause;
}


bool SolverSatX10Base::x10_checkOutgoingCandidateLen_AdjustMaxLenShared(const unsigned clauseLen) {
    const bool retvalue = (clauseLen <= x10_maxLenSharedClauses);
    if (x10_isSharingCutoffDynamic()) {
        // adjust x10_maxLenSharedClauses so that the ratio of outgoing clauses and
        // number of conflicts encountered by the solver stays roughly constant (e.g., 5%)
        // NOTE: HARDWIRED bounds on adjustment: min=1, max=128
        static unsigned nCalls = 0;
        ++nCalls;
        if (nCalls % 1000 == 0) {   // worry about adjustment only one in a 1000 calls
            const double currentRatio = x10_nTotalOutgoingClauses / (double) x10_nConflicts();
            const double targetRatio  = x10_ratioSharedToLearnt;
            if (x10_maxLenSharedClauses < 128 && currentRatio < (targetRatio / 1.001)) {
                x10_maxLenSharedClauses += 1;   // increase max length
#ifdef DEBUG
                std::cout << "maxlenshared Increased to " << x10_maxLenSharedClauses
                          << ", current ratio is " << currentRatio << std::endl;
#endif
            }
            else if (x10_maxLenSharedClauses > 1 && currentRatio > (targetRatio * 1.001)) {
                x10_maxLenSharedClauses -= 1;   // decrease max length
#ifdef DEBUG
                std::cout << "maxlenshared Decreased to " << x10_maxLenSharedClauses
                          << ", current ratio is " << currentRatio << std::endl;
#endif
            }
        }
    }
    if (retvalue == true)
        ++x10_nTotalOutgoingClauses;
    return retvalue;
}

