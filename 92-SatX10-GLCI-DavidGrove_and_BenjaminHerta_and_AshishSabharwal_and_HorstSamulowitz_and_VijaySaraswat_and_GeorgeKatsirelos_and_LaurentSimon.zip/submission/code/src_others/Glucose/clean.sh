#!/bin/bash
export FM=$PWD/sources/SatELite/ForMani
rm -rf glucose_static 
rm -rf SatELite_release

cd ./sources/SatELite/SatELite
make clean 

cd ../../glucose/core
make clean 

find . -name 'depend.mak' -delete 
