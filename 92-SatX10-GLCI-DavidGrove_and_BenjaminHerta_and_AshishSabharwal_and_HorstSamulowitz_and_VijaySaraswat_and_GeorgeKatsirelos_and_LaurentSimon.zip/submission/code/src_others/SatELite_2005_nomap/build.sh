export FM=$PWD/ForMani

cd SatELite
make realclean
make r
mv SatELite_release ../SatELite_2005_nomap
cd ..

echo
echo 'BUILD DONE!'
echo
