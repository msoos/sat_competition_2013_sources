// -----------------------------------------------------------------
// Licensed Materials - Property of IBM
//
// SatX10
//
// (C) Copyright IBM Corporation 2012.  All Rights Reserved.
//
// Authors: Bard Bloom, David Grove, Benjamin Herta,
//          Vijay Sarawat, Ashish Sabharwal, Horst Samulowitz
// -----------------------------------------------------------------


#ifndef Solver_Callback_h
#define Solver_Callback_h


// these are the callback functions that will be available to the SAT solver
class SolverX10Callback {
public:
    // methods that inheriting Callback classes must support;
    // currently being implemented in PolySat__Solver
    virtual int  x10_getRestart(void) const = 0;
    virtual void x10_step (void) const = 0;
    virtual void x10_processOutgoingClauses (const bool bProcessImmediately) = 0;
};

#endif
