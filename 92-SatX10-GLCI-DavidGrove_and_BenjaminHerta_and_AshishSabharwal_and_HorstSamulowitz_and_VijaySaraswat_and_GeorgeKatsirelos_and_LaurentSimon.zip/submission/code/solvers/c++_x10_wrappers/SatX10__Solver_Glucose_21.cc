// -----------------------------------------------------------------
// Licensed Materials - Property of IBM
//
// SatX10
//
// (C) Copyright IBM Corporation 2012.  All Rights Reserved.
//
// Authors: Bard Bloom, David Grove, Benjamin Herta,
//          Vijay Sarawat, Ashish Sabharwal, Horst Samulowitz
// -----------------------------------------------------------------

#include "x10/array/Array.h"
#include "x10/lang/String.h"

#include "SatX10__Solver_Glucose_21.h"


RTT_CC_DECLS1(SatX10__Solver_Glucose_21, "SatX10.Solver_Glucose_21", x10aux::RuntimeType::class_kind, SatX10__Solver)


