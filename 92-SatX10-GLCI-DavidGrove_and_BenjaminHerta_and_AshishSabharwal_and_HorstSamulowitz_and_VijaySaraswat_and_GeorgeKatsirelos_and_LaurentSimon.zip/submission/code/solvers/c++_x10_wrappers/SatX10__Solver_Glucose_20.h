// -----------------------------------------------------------------
// Licensed Materials - Property of IBM
//
// SatX10
//
// (C) Copyright IBM Corporation 2012.  All Rights Reserved.
//
// Authors: Bard Bloom, David Grove, Benjamin Herta,
//          Vijay Sarawat, Ashish Sabharwal, Horst Samulowitz
// -----------------------------------------------------------------


#ifndef SatX10__Solver_Glucose_20_h
#define SatX10__Solver_Glucose_20_h

#include "../../SatX10__Solver.h"

#include "../c++/glucose_20/sources/glucose/core/Solver.h"
#include "../c++/glucose_20/sources/glucose/utils/Options.h"


// Native c++ code for the x10 class Solver_Glucose_20
// Creates a solver object, parses commandline options, and reads CNF input file
class SatX10__Solver_Glucose_20 : public SatX10__Solver {
public:
    RTT_H_DECLS_CLASS

    // constructor
    SatX10__Solver_Glucose_20 (
            x10_int placeID,
            x10_boolean isHub,
            x10::lang::String* instanceName,
            x10_int maxlen,
            x10_int outgoingClausesBufferSize,
            x10::array::Array<x10::lang::String* >* arguments) :
                SatX10__Solver(instanceName->c_str(), maxlen) {

        // first parse command-line options; to do this, convert arguments into the usual argc, argv format
        int argc = arguments->FMGL(raw)->length() + 1;
        char** argv = convertX10StringArrayToCStyleArgvWithOffset(arguments);
        Glucose_20::parseOptions(argc, argv);
        // should normally have freed up the memory for argv here, but not worth the effort

        // now create the solver object
        solver = new Glucose_20::Solver(instanceName->c_str(), placeID, isHub, this, maxlen, outgoingClausesBufferSize);

        // parse CNF file
        solver->x10_parseDIMACS(instanceName->c_str());

        // print instance information if this is place 0
        if (placeID == 0)
            printInstanceInfo();
    }

    // destructor
    virtual ~SatX10__Solver_Glucose_20() { }

    // _make for X10
    static SatX10__Solver_Glucose_20* _make(
            x10_int placeID,
            x10_boolean isHub,
            x10::lang::String* s,
            x10_int maxlen,
            x10_int outgoingClausesBufferSize,
            x10::array::Array<x10::lang::String* >* arguments) {

        SatX10__Solver_Glucose_20* self =
            new (x10aux::alloc<SatX10__Solver_Glucose_20>()) SatX10__Solver_Glucose_20(placeID, isHub, s, maxlen, outgoingClausesBufferSize, arguments);

        return self;
    }
};


#endif
