// -----------------------------------------------------------------
// Licensed Materials - Property of IBM
//
// SatX10
//
// (C) Copyright IBM Corporation 2012.  All Rights Reserved.
//
// Authors: Bard Bloom, David Grove, Benjamin Herta,
//          Vijay Sarawat, Ashish Sabharwal, Horst Samulowitz
// -----------------------------------------------------------------


#ifndef Solver_X10_Base_h
#define Solver_X10_Base_h

#include <iostream>
#include <vector>
#include <string>
using std::vector;
using std::string;

#include "SolverX10Callback.h"


// a simple struct that is stored in incoming and outgoing clause buffers
class ClauseWithInfo {
public:
    vector<int>    clause;    // a clause
    vector<int>    placeIDs;  // associated X10 place IDs capturing which places have sent
                              //   this clause to others; for non-hubs, just store the last sender
    vector<int>    otherInfo; // arbitrary additional info; NOTE: CRITICAL THAT sep IS NOT USED AS INFO!!

    // a method to convert the contents of this struct into a single vector<int>
    inline void serializeAndAppendTo(vector<int> & resultVec);

    // a method to create contents of this object from a serialized vector<int> starting
    //   as index 'pos'; as a side effect, it ADVANCES pos enough to the position of the
    //   next clause in serialVec; thus, calling this method repeatedly will read off all
    //   clauses one by one
    // Return value: whether current place ID appears in the list of place IDs, in
    //   which case remaining place IDs should be discarded
    bool createFromSerializedObject(vector<int> & serialVec, unsigned & pos,
                                    const int currentPlaceID, const bool discardIDs);

protected:
    static const int    sep;   // the separator used when serializing ClauseWithInfo objects into vector<int>
};


// The base class that every SAT "Solver" class must inherit from.
// Serves three purposes:
//   A. Makes available to each solver various x10 related objects such
//      as place ID, max length of clauses to share, pointer to a callback
//      object, clause buffers, etc.
//   B. Lists several pure virtual methods that each inheriting solver is
//      expected to implement in order to interact with SatX10.x10
//   C. Provide a number of additional controls for SatX10.x10
//
class SolverSatX10Base {
protected:
    // default values of key parameters
	static const int    default_x10_maxLenSharedClauses       = 1;     // default length of clauses to share
	static const int    default_x10_outgoingClausesBufferSize = 100;   // default maximum number of outgoing clauses to keep in buffer before sharing
	static const int    default_x10_maxLenPassThrough         = 2;     // default length of incoming clauses to pass through as outgoing
	static const int    default_x10_messageProcessingInterval = 100;   // default number of decisions after which to process incoming messages
	static const double default_x10_ratioSharedToLearnt       = 0.05;  // default ratio between number of clauses shared and learnt
	static const bool   default_x10_useDuplDetectionLongCls   = false; // default for whether or not to use duplicate detection in long incoming clauses

    // objects that this base class keeps track of and makes available
    // to all inheriting solvers (e.g., place ID, callback, etc.)
    const string              x10_instanceName;           // name of the CNF instance being solved
    const int                 x10_placeID;                // the ID of the X10 place that is running this solver
    const int                 x10_hubLevel;               // a weak Hub, a strong Hub, or a Leaf in the SatX10 topology
    SolverX10Callback * const x10_callback;               // the 'callback' through which this solver interacts with X10
    int                       x10_maxLenSharedClauses;    // maximum length of clauses to share with others
    const int                 x10_outgoingClausesBufferSize; // the maximum number of outgoing clauses to keep in buffer before sharing

    const int                 x10_maxLenPassThrough;      // maximum length of incoming clause to pass through as outgoing
    const int                 x10_messageProcessingInterval; // after how many decisions to call step() / probe() to incorporate incoming messages
    const double              x10_ratioSharedToLearnt;    // desired ratio between number of clauses shared vs. learnt
    const bool                x10_useDuplDetectionLongCls;// use duplicate detection before passing through incoming clauses

    bool                      x10_useDynSharingCutoff;    // use dynamically adjusting shared clause max length
    int                       x10_nTotalOutgoingClauses;  // number of outgoing clauses ever buffered to be sent

    vector<ClauseWithInfo>    x10_incomingClauses;        // all collected incoming clauses along with additional info
    vector<ClauseWithInfo>    x10_outgoingClauses;        // all clauses to be sent to other solvers along with additional info

    int  x10_whenMessagesWereProcessed;      // to keep track of the last time incoming messages were processed
    bool x10_killed;                         // whether a kill signal has been received from X10
    bool x10_conflictingUnitFound;           // a flag to indicate whether addExternalClause found a conflicting unit

    // methods that inheriting SAT solvers must support:
    // process and incorporate all clauses in the incoming clauses vector
    virtual void x10_processIncomingClauses(void) = 0;

public:
    // constructors
    SolverSatX10Base(
            const string &  _instanceName,
            const int       _placeID,
            const int       _hubLevel,
            SolverX10Callback * const _cb = NULL,
            const int       _maxLenSharedClauses = default_x10_maxLenSharedClauses,   // see note below
            const int       _outgoingClausesBufferSize = default_x10_outgoingClausesBufferSize,
            const int       _maxLenPassThrough = default_x10_maxLenPassThrough,
            const int       _messageProcessingInterval = default_x10_messageProcessingInterval,
            const double    _ratioSharedToLearnt = default_x10_ratioSharedToLearnt,
            const bool      _useDuplDetectionLongCls = default_x10_useDuplDetectionLongCls) :
        x10_instanceName(_instanceName),
        x10_placeID(_placeID),
        x10_hubLevel(_hubLevel),
        x10_callback(_cb),
        x10_maxLenSharedClauses(_maxLenSharedClauses),
        x10_outgoingClausesBufferSize(_outgoingClausesBufferSize),
        x10_maxLenPassThrough(_maxLenPassThrough),
        x10_messageProcessingInterval(_messageProcessingInterval),
        x10_ratioSharedToLearnt(_ratioSharedToLearnt),
        x10_useDuplDetectionLongCls(_useDuplDetectionLongCls),
        x10_useDynSharingCutoff(_maxLenSharedClauses < 0),
        x10_nTotalOutgoingClauses(0),
        x10_whenMessagesWereProcessed(0),
        x10_killed(false),
        x10_conflictingUnitFound(false)
    {
        if (x10_maxLenSharedClauses < 0)   // note: negative number indicates that we should use dynamic adjustment to the value
            x10_maxLenSharedClauses = -x10_maxLenSharedClauses;
    }


    // methods that inheriting SAT solvers must support
    virtual void   x10_parseDIMACS(const char * filename) = 0;
    virtual int    x10_nVars(void) const = 0;
    virtual int    x10_nClauses(void) const = 0;
    virtual double x10_nConflicts(void) const = 0;
    virtual int    x10_solve(void) = 0; // return values: 0: unsolved, 1: satisfiable; -1: unsatisfiable
    virtual void   x10_printSolution(void) = 0;
    virtual void   x10_printStats(void) = 0;

    // additional controls for SatX10.x10 or for inheriting solvers
    int    x10_getPlaceID                   (void) const { return x10_placeID; }
    int    x10_getHubLevel                  (void) const { return x10_hubLevel; }
    int    x10_getMaxLenSharedClauses       (void) const { return x10_maxLenSharedClauses; }
    int    x10_getOutgoingClausesBufferSize (void) const { return x10_outgoingClausesBufferSize; }
    int    x10_getMaxLenPassThrough         (void) const { return x10_maxLenPassThrough; }
    double x10_getRatioSharedToLearnt       (void) const { return x10_ratioSharedToLearnt; }
    bool   x10_usingDuplDetectionLongCls    (void) const { return x10_useDuplDetectionLongCls; }
    bool   x10_isSharingCutoffDynamic       (void) const { return x10_useDynSharingCutoff; }
    bool   x10_wasKilled                    (void) const { return x10_killed; }

    int    x10_getNumOutgoingClauses        (void) const { return x10_outgoingClauses.size(); }
    ClauseWithInfo & x10_getOutgoingClause  (const int i){ return x10_outgoingClauses[i]; }
    void   x10_clearOutgoingClauses         (void)       { x10_outgoingClauses.clear(); }

    void   x10_kill (void) {
        x10_killed = true;
    }

    // buffer clause and return its position in the incoming clauses vector
    int    x10_bufferIncomingClause(const ClauseWithInfo & clauseWithInfo) {
        x10_incomingClauses.push_back(clauseWithInfo);
        return x10_incomingClauses.size() - 1;
    }

    // buffer clause and return its position in the outgoing clauses vector
    inline int    x10_bufferOutgoingClause(const ClauseWithInfo & clauseWithInfo);

    // buffer clause and return its position in the outgoing clauses vector
    inline int    x10_bufferOutgoingClause(const vector<int> & vecClause);

    // buffer clause and return its position in the outgoing clauses vector
    inline int    x10_bufferOutgoingClause(const vector<int> & vecClause, const int oneOtherInfo);

    // buffer clause and return its position in the outgoing clauses vector
    inline int    x10_bufferOutgoingClause(const vector<int> & vecClause, const vector<int> & otherInfo);

    // test candidate clause against current maxlen of shared clauses AND
    // adjust this maxlen if necessary
    bool   x10_checkOutgoingCandidateLen_AdjustMaxLenShared(const unsigned clauseLen);
};


///////////////////////////////
// INLINE METHODS
///////////////////////////////

void ClauseWithInfo::serializeAndAppendTo(vector<int> & resultVec) {
    resultVec.insert(resultVec.end(), clause.begin(), clause.end());
    resultVec.push_back(sep);
    for (unsigned j=0 ; j<placeIDs.size() ; j++)
    	resultVec.push_back(placeIDs[j] + 1);  // place IDs are shifted by +1 when serializing
    resultVec.push_back(sep);
    resultVec.insert(resultVec.end(), otherInfo.begin(), otherInfo.end());
    resultVec.push_back(sep);
}


// buffer clause and return its position in the outgoing clauses vector
int SolverSatX10Base::x10_bufferOutgoingClause(const ClauseWithInfo & clauseWithInfo) {
    x10_outgoingClauses.push_back(clauseWithInfo);
    x10_outgoingClauses.back().placeIDs.push_back(x10_placeID);  // append the ID of this place
    return x10_outgoingClauses.size() - 1;
}


// buffer clause and return its position in the outgoing clauses vector
int SolverSatX10Base::x10_bufferOutgoingClause(const vector<int> & vecClause) {
    ClauseWithInfo clauseWithInfo;
    clauseWithInfo.clause = vecClause;
    clauseWithInfo.placeIDs.push_back(x10_placeID);     // use the ID of this place
    x10_outgoingClauses.push_back(clauseWithInfo);
    return x10_outgoingClauses.size() - 1;
}


// buffer clause and return its position in the outgoing clauses vector
int SolverSatX10Base::x10_bufferOutgoingClause(const vector<int> & vecClause, const int oneOtherInfo) {
    ClauseWithInfo clauseWithInfo;
    clauseWithInfo.clause = vecClause;
    clauseWithInfo.placeIDs.push_back(x10_placeID);     // use the ID of this place
    clauseWithInfo.otherInfo.push_back(oneOtherInfo);
    x10_outgoingClauses.push_back(clauseWithInfo);
    return x10_outgoingClauses.size() - 1;
}


// buffer clause and return its position in the outgoing clauses vector
int SolverSatX10Base::x10_bufferOutgoingClause(const vector<int> & vecClause, const vector<int> & otherInfo) {
    ClauseWithInfo clauseWithInfo;
    clauseWithInfo.clause = vecClause;
    clauseWithInfo.placeIDs.push_back(x10_placeID);     // use the ID of this place
    clauseWithInfo.otherInfo = otherInfo;
    x10_outgoingClauses.push_back(clauseWithInfo);
    return x10_outgoingClauses.size() - 1;
}


#endif
