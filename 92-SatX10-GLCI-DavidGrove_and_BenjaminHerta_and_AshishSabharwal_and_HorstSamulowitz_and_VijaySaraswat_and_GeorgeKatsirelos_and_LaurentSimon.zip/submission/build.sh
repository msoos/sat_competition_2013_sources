#!/bin/sh
ROOT=$PWD


# Compile Glucose
cd $ROOT/code/src_others/Glucose
./clean.sh
./build.sh
cp glucose_static $ROOT/code/pySatX10/.

# Compile Satelite
cd $ROOT/code/src_others/SatELite_2005_nomap
./clean.sh
./build.sh
cp SatELite_2005_nomap $ROOT/code/pySatX10/.

# Compile SatX10
cd $ROOT/code
make clean-all
make
cp SatX10 $ROOT/code/pySatX10/.

cd $ROOT
mkdir binary
cd binary
mkdir WORKING-DIR
cp $ROOT/code/pySatX10/* .



