#!/bin/sh
ROOT=$PWD

# Clean Glucose
cd $ROOT/code/src_others/Glucose
./clean.sh

# Clean Satelite
cd $ROOT/code/src_others/SatELite_2005_nomap
./clean.sh

# Clean SatX10
cd $ROOT/code
make clean-all
cd pySatX10
rm glucose_static
rm SatELite_2005_nomap
rm SatX10

# Remove 'binary' folder
cd $ROOT
/bin/rm -fr binary

