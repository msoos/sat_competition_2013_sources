#ifndef _BOUNDEDQUEUE_HEADER
#define _BOUNDEDQUEUE_HEADER

#include <cstdlib>
#include <algorithm>
#include <iostream>
#include <cassert>

using namespace std;

template<typename T>
class BoundedQueue
{
private:
	T* _memory;
	size_t _last;
	size_t _size;
	T _sum;
	size_t _capacity;

public:
	BoundedQueue(size_t capacity)
		: _last(0), _size(0), _sum(0), _capacity(capacity)
	{
		_memory=static_cast<T*>(malloc(sizeof(T)*capacity));
	}

	~BoundedQueue()
	{
		if(_memory!=NULL){
			delete[] _memory;
		}
	}

	size_t size() const
	{
		return _size;
	}

	size_t capacity() const
	{
		return _capacity;
	}

	T sum() const
	{
		return _sum;
	}

	bool is_full()
	{
		return _size==_capacity;
	}

	void push(T value)
	{
		if(_size==_capacity){
			_sum-=_memory[_last];
		}
		_sum+=value;
		_memory[_last++]=value;
		if(_last==_capacity){
			_last=0;
		}
		_size=min(_size+1, _capacity);
	}

	void clear()
	{
		_last=0;
		_size=0;
		_sum=0;
	}

	void dump(ostream& out)
	{
		size_t head=(_last+_capacity-_size)%_capacity;
		for(size_t i=0; i<_size; i++){
			out<<_memory[(head+i)%_capacity]<<" ";
		}
		out<<endl;
	}
};

#endif
