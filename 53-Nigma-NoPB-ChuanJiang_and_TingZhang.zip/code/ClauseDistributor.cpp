#include <algorithm>

#include "ClauseDistributor.h"

ClauseDistributor::ClauseDistributor(size_t var_size)
	: _mark(0), _marks(var_size+1, 0)
{
}

//
// Return TRUE if the clause distribution results in less clauses
//
bool ClauseDistributor::resolve(Variable var, const vector<ClausePtr>& poss, const vector<ClausePtr>& negs)
{
	clear();

	if(poss.size()>=OCCUR_UPPER && negs.size()>=OCCUR_UPPER){
		return false;
	}

	size_t upper=poss.size()+negs.size();
	const vector<ClausePtr>& occurs1=(poss.size()<negs.size() ? poss : negs);
	const vector<ClausePtr>& occurs2=(poss.size()<negs.size() ? negs : poss);
	vector<Literal> resolvent;

	for(vector<ClausePtr>::const_iterator itr1=occurs1.begin(); itr1!=occurs1.end(); itr1++){
		Clause& clause1=ClausePool::get(*itr1);
		if(clause1.is_deleted()){
			upper--;
			continue;
		}

		resolvent.clear();
		_mark++;

		for(Clause::iterator sitr1=clause1.begin(); sitr1!=clause1.end(); sitr1++){
			if(sitr1->var()!=var){
				resolvent.push_back(*sitr1);
				_marks[sitr1->var()]=_mark;
			}
		}

		bool is_tautology=false;
		size_t resolvent_left_size=resolvent.size();

		for(vector<ClausePtr>::const_iterator itr2=occurs2.begin(); itr2!=occurs2.end(); itr2++){
			Clause& clause2=ClausePool::get(*itr2);
			if(clause2.is_deleted()){
				upper--;
				continue;
			}

			is_tautology=false;

			for(Clause::iterator sitr2=clause2.begin(); sitr2!=clause2.end() && !is_tautology; sitr2++){
				if(_marks[sitr2->var()]==_mark){
					for(size_t i=0; i<resolvent_left_size; i++){
						if(*sitr2==resolvent[i]){
							// Duplicate literals
							// Do nothing
							break;
						}
						else if(*sitr2==-resolvent[i]){
							// Tautology
							is_tautology=true;
							break;
						}
					}
				}
				else if(sitr2->var()!=var){
					resolvent.push_back(*sitr2);
				}
			}

			if(!is_tautology){
				std::copy(resolvent.begin(), resolvent.end(), back_inserter(_resolvents));
				_delimiters.push_back(_resolvents.size());
				if(_delimiters.size()>=upper){
					// Clause distribution results in more clauses
					return false;
				}
			}

			resolvent.resize(resolvent_left_size);
		}
	}

	return true;
}

void ClauseDistributor::clear()
{
	_resolvents.clear();
	_delimiters.clear();
}

ClauseDistributor::iterator::iterator(const ClauseDistributor& distributor)
	: _distributor(distributor), _index(0)
{
}

void ClauseDistributor::iterator::get(vector<Literal>& clause)
{
	clause.clear();
	if(_index>=_distributor._delimiters.size()){
		return;
	}

	size_t begin=(_index==0 ? 0 : _distributor._delimiters[_index-1]);
	size_t end=_distributor._delimiters[_index];
	std::copy(_distributor._resolvents.begin()+begin, _distributor._resolvents.begin()+end, back_inserter(clause));
}
