#include <fstream>
#include <cstring>
#include <string>

#include "DimacsParser.h"

void DimacsParser::parse_cnf(Solver& solver, const char* file_name)
{
	ifstream in;
	in.open(file_name);
	if (!in.is_open())
	{
		cout << "Cannot open the file " << file_name << "!" << endl;
		exit(1);
	}

	char* linebuffer=new char[MAX_LINE_LENGTH];
	char* literalbuffer=new char[MAX_LITERAL_LENGTH];
	int var_size;
	int line_size;
	int flag;
	vector<int> clause;

	while (in.getline(linebuffer, MAX_LINE_LENGTH))
	{
		if (linebuffer[0] == 'c')
		{
			continue;
		}
		else if (linebuffer[0] == 'p')
		{
			flag = sscanf(linebuffer, "p cnf %d %d", &var_size, &line_size);
			if (flag != 2)
			{
				cout << "Fail to parse variable number and line number!"
						<< endl;
				exit(2);
			}
			solver.set_variable_size(var_size);
		}
		else
		{
			char* lineptr = linebuffer;
			char* literalptr = literalbuffer;
			int lit;

			while (*lineptr != '\0')
			{
				literalptr = literalbuffer;
				while (*lineptr && isspace(*lineptr))
				{
					lineptr++;
				}
				while (*lineptr && !isspace(*lineptr))
				{
					*(literalptr++) = *(lineptr++); // copy Literal
				}
				*literalptr = '\0'; // terminate Literal

				if (strlen(literalbuffer) > 0)
				{
					lit = atoi(literalbuffer);

					if (lit != 0)
					{
						clause.push_back(lit);
					}
					else if (!clause.empty())
					{
						solver.add_clause(clause);
						clause.clear();
					}
				}
			}
		}
	}

	in.close();

	delete[] linebuffer;
	delete[] literalbuffer;
}
