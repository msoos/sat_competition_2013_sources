Solver: MIPSAT
Authors: Sergio Núñez, Daniel Borrajo and Carlos Linares López

-----------
Libraries needed
-----------
You will need the following libraries to compile the sources:
* libz
* mono (and compiler mcs)
* GNU make
* Boost (with program-options)
* g++ and gcc (multilib)


-----------------
Building the source
-----------------
./build.sh


-----------------
Usage
-----------------
./binary/solve BENCHNAME