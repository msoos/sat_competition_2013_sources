#!/bin/bash

BIN=${PWD}/binary
CODE=${PWD}/code

# Important, set MROOT environment variable!
export MROOT=${CODE}

mkdir -p ${BIN}

# Build GlucoRed including simplifier
cd ${CODE}/simp
make r
mv glucored-simp_release ${BIN}
if [ ! -e ${BIN}/glucored-simp_release ]; then exit 1; fi

# Build GlucoRed-multi
cd ${CODE}/glucored-multi
make r
mv glucored-multi_release ${BIN}
if [ ! -e ${BIN}/glucored-multi_release ]; then exit 1; fi

# Build GlucoRed+March
cd ${CODE}/glucored+march
make r
mv glucored+march_release ${BIN}
if [ ! -e ${BIN}/glucored+march_release ]; then exit 1; fi

# Build MARCH
cd ${CODE}/march_rw
make
mv march_rw ${BIN}
if [ ! -e ${BIN}/march_rw ]; then exit 1; fi

