#!/bin/bash

mkdir -p binary
cd code
make
cp vflipnum  ../binary/vflipnum
 
