  ======================================================
  SLS SAT Solver from Donghua University
  ======================================================
  vflipnum is a SLS SAT Solver based on the framework of Sparrow2011,
        Developed by Jingchao Chen and Yuyang Huang 
  ------------------------------------------------------
  .....e-mail chen-jc [@] dhu.edu.cn
  ------------------------------------------------------

For compiling vflipnum: 
   ./build.sh

===================
USAGE:

vflipnum BENCHNAME RANDOMSEED



