/*
 vflipnum --- Copyright (c) 2013, Jingchao Chen and Yuyang Huang, Donghua University, China   

 vflipnum is a SLS SAT Solver obtained by modifying Sparrow . Permissions and copyrights of
 vflipnum are exactly the same as Sparrow.

*/

#include "s_ubcsat.h"

char *filename;

#ifdef __cplusplus 
namespace ubcsat {
#endif


int VFNsatmain(int argc, char *argv[]) {
  
  InitSeed();

  SetupUBCSAT();

  AddAlgorithms();
 
  AddParameters();
 
  AddReports();
  AddDataTriggers();
  AddReportTriggers();

  AddLocal();

 //printf("c iCutoff=%I64d iNumRuns=%d \n",iCutoff,iNumRuns);
// printf("c iCutoff=%d iNumRuns=%d \n",(int)iCutoff,iNumRuns);

 // printf("c iSeed=%d \n",iSeed);
  
  ParseAllParameters(argc,argv);

  //printf("c iCutoff=%I64u iNumRuns=%d \n",iCutoff,iNumRuns);
 // printf("c iSeed=%d \n",iSeed);

  ActivateAlgorithmTriggers();
  ActivateReportTriggers();

  RunProcedures(PostParameters);
  RunProcedures(ReadInInstance);
  RunProcedures(PostRead);

  printf("c iSeed=%d \n",iSeed);
  RandomSeed(iSeed);

  RunProcedures(CreateData);
  RunProcedures(CreateStateInfo);
 

  iRun = 0;
  iNumSolutionsFound = 0;
  bTerminateAllRuns = 0;

  RunProcedures(PreStart);

  StartTotalClock();
  while ((iRun < iNumRuns) && (! bTerminateAllRuns)) {

    iRun++;

    iStep = 0;
    bSolutionFound = 0;
    bTerminateRun = 0;
    bRestart = 1;
    RunProcedures(PreRun);
    StartRunClock();
    while ((iStep < iCutoff) && (! bSolutionFound) && (! bTerminateRun)) {

      iStep++;
      iFlipCandidate = 0;

      RunProcedures(PreStep);
      RunProcedures(CheckRestart);

      if (bRestart) {
        RunProcedures(PreInit);
        RunProcedures(InitData);
        RunProcedures(InitStateInfo);
        RunProcedures(PostInit);
        bRestart = 0;
      } 
	  else {
        RunProcedures(ChooseCandidate);
        RunProcedures(PreFlip);
        RunProcedures(FlipCandidate);
        RunProcedures(UpdateStateInfo);
        RunProcedures(PostFlip);
      }
      
      RunProcedures(PostStep);

      RunProcedures(StepCalculations);

      RunProcedures(CheckTerminate);
    }

    StopRunClock();

    RunProcedures(RunCalculations);
    
    RunProcedures(PostRun);

    if (bSolutionFound) {
      iNumSolutionsFound++;
      if (iNumSolutionsFound == iFind) {
        bTerminateAllRuns = 1;
      }
    }
  }

  StopTotalClock();

  RunProcedures(FinalCalculations);

  RunProcedures(FinalReports);

  CleanExit();

  return(0);
  
}

char randomseed[10]="123"; 
//char *randomseed="10"; 
char *myargv[100];
int myargc = 0;

int VFNmain(int argc, char *argv[]) {

  printf("c This is vflipnum, April 2013\n");

  if (argc < 2) {
     printf("c USAGE: %s filename.cnf [seed]\n",argv[0]);
     exit(0);
  }

  //myargv[myargc++] = argv[0];
  myargv[myargc++] = (char *)"3";

  myargv[myargc++] = (char *)"-i";
  myargv[myargc++] = argv[1];
  filename = argv[1];

  printf("c  filename = %s \n",filename);  
 // myargv[myargc++] = fileName;
 // filename =fileName;

  myargv[myargc++] = (char *) "-seed";
  if(argc >= 3)  myargv[myargc++] = argv[2];
  else           myargv[myargc++] = randomseed;

  myargv[myargc++] = (char *)"-q";

  myargv[myargc++] = (char *) "-r";
  myargv[myargc++] = (char *) "satcomp";

  myargv[myargc++] = (char *)"-cutoff";
  myargv[myargc++] = (char *)"max";

  myargv[myargc++] = (char *)"-alg";
  myargv[myargc++] = (char *)"vflipnum";   //"sparrow";

  myargv[myargc++] = (char *)"-v";
  myargv[myargc++] = (char *)"sat13";

  return(VFNsatmain(myargc,myargv));
}

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus

int main(int argc, char *argv[]) {
  return(ubcsat::VFNmain(argc,argv));
}

#else

int main(int argc, char *argv[]) {
  return(VFNmain(argc,argv));
}

#endif
