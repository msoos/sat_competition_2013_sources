
#include "s_ubcsat.h"

#ifdef __cplusplus 
namespace ubcsat {
#endif

const char sVersion[] = " vflipnum April 2013 ";

#ifdef __cplusplus

}
#endif
