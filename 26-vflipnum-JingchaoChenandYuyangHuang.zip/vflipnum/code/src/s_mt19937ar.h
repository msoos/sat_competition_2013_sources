#ifndef MT19937AR_H
#define MT19937AR_H

#ifdef _MSC_VER
#include "stdint.h"
#else
#include <stdint.h>
#endif //_MSC_VER

#ifdef __cplusplus 
namespace mersenne {
#endif

extern uint32_t genrand_int32();
extern void init_genrand(uint32_t s);

#ifdef __cplusplus 
}
#endif
#endif
