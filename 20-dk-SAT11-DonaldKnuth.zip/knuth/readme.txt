Compile: run ./build.sh

Usage: run the solver (in binary/) with proof logging:
./dk-unsat.sh INSTANCE TMPFILE

Without proof logging:
./dk-run.sh INSTANCE 

With INSTANCE referring to the input formula and TMPFILE 
referring to a temporary file to store the proof in the 
BDRUP format.
