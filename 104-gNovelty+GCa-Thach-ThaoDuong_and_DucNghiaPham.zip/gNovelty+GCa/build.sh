mkdir binary
rm binary/gNovelty+GCa
cd code
make clean
make
cd ..
cp code/gNovelty+GCa binary/
