#ifndef MAIN_C
#define MAIN_C

#include "basic.h"
#include "normal.h"
#include "huge.h"
#include "lscore.h"
#include "selectmethod.h"

void local_search()
{
	int flipvar;
	for (step = 0; step<max_flips; step++)
	{
	
		if(unsat_stack_fill_pointer==0) return;
		
		flipvar = pick_var();
		flip(flipvar);
		time_stamp[flipvar] = step;
	}
}

int main(int argc, char* argv[])
{
	int     seed;
	unsigned long long tries;

	if(argc!=3)
	{
		printf("c Usage: ./FrwCB2013 <instance> <seed>\n");
		return -1;
	}
	
	times(&start);
	
	if (build_instance(argv[1])==0)
	{
		myfree();
		printf("c Invalid filename: %s\n", argv[1]);
		return -1;
	}
    
    select_prob_and_method();
    mymalloc();
    print_information(argv[1], argv[2]);
    
    sscanf(argv[2],"%d",&seed);
	
	srand(seed);

	for (tries = 1; tries <= max_tries; tries++) 
	{
		 init();
		 local_search();
		 if (unsat_stack_fill_pointer==0)  break;
	}


	times(&stop);
	double comp_time = (double)(stop.tms_utime - start.tms_utime +stop.tms_stime - start.tms_stime) / sysconf(_SC_CLK_TCK);

     //print out information about the solution.
	if(unsat_stack_fill_pointer==0){
		if(verify_sol()==1)
		{
			//printf("%d sat %llu %llu %lf\n",seed,tries,step,comp_time);
			 //printf("c solution found!\n");
			 //printf("c tries = %llu\n", tries); 
			 //printf("c searchSteps = %llu\n", step); 
			 //printf("c solveTime = %lf\n",comp_time);
			 printf("s SATISFIABLE\n");
			 print_solution();
			 printf("c verifying solution success!\n");
			 //printf("c instance = %s\n", argv[1]);
			 //printf("c seed = %d\n", seed);
			 printf("c tries = %llu (each complete try equals to %llu steps)\n", tries, max_flips); 
			 printf("c searchSteps = %llu + %llu * %llu\n", step, tries-1, max_flips); 
			 printf("c solveTime = %lf\n",comp_time);
		 }
		 else printf("s UNKNOWN\n");
	 }
	 else printf("s UNKNOWN\n");
	
	myfree();
	
	return 0;
}

#endif
