#ifndef LSCORE_H
#define LSCORE_H

#include "basic.h"

void init_lscore()
{
	int 		v,c;
	int			i,j;
	
	//init unsat_stack
	unsat_stack_fill_pointer = 0;

	//init solution
	for (v = 1; v <= num_vars; v++) {

		if(rand()%2==1) cur_soln[v] = 1;
		else cur_soln[v] = 0;

		time_stamp[v] = 0;
		conf_times[v] = 1;
	}

	/* figure out sat_count, and init unsat_stack */
	for (c=0; c<num_clauses; ++c) 
	{
		sat_count[c] = 0;
		
		for(j=0; j<clause_lit_count[c]; ++j)
		{
			if (cur_soln[clause_lit[c][j].var_num] == clause_lit[c][j].sense)
			{
				sat_count[c]++;
				sat_var[c] = clause_lit[c][j].var_num;	
			}
		}

		if (sat_count[c] == 0) 
			unsat(c);
	}
	
	int lit_count;
	for (v=1; v<=num_vars; v++) 
	{
		bscore[v] = mscore[v] = score_2[v] = 0;
		
		lit_count = var_lit_count[v];
		
		for(i=0; i<lit_count; ++i)
		{
			c = var_lit[v][i].clause_num;
			if (sat_count[c]==0) mscore[v]++;
			else if(sat_count[c]==1 && var_lit[v][i].sense==cur_soln[v])
				bscore[v]++;
		}
	}
	
	int flag;
	for (c=0; c<num_clauses; ++c) 
	{
		if (sat_count[c]==1)
		{
			for(j=0;j<clause_lit_count[c];++j)
			{
				v=clause_lit[c][j].var_num;
				if(v!=sat_var[c])score_2[v]++;
			}
		}
		else if(sat_count[c]==2)
		{
			flag=0;
			for(j=0;j<clause_lit_count[c];++j)
			{
				v=clause_lit[c][j].var_num;
				if(clause_lit[c][j].sense == cur_soln[v])
				{
					score_2[v]--;
					if(flag==0){sat_var[c] = v; flag=1;}
					else	{sat_var2[c] = v; break;}
				}
			}
		
		}
	}
	
	//setting for the virtual var 0
	time_stamp[0]=0;
	conf_times[0]=0;
	bscore[0]=0;
	mscore[0]=0;
	score_2[0]=0;
}

void flip_lscore(int flipvar)
{
	int v,c;
	int index;
	struct lit* clause_c;
	struct lit* p;
	struct lit* q;
	int* var_neighbor_ptr;
	int flag;

	cur_soln[flipvar] = 1 - cur_soln[flipvar];
	
	//update related clauses and neighbor vars
	for(q=var_lit[flipvar]; (c=q->clause_num)!=-1; q++)
	{
		clause_c = clause_lit[c];
		if(cur_soln[flipvar] == q->sense)
		{
			++sat_count[c];
			
			if(sat_count[c] == 3)
			{
				score_2[sat_var[c]]++;
				score_2[sat_var2[c]]++;
			}
			
			else if (sat_count[c] == 2) //sat_count from 1 to 2
			{
				bscore[sat_var[c]] --;
				
				sat_var2[c]=flipvar;

				for(p=clause_c; (v=p->var_num)!=0; p++)
					score_2[v]--;
				score_2[flipvar]--;
			}
			else if (sat_count[c] == 1) // sat_count from 0 to 1
			{
				sat_var[c] = flipvar;//record the only true lit's var
				bscore[flipvar]++;
				
				for(p=clause_c; (v=p->var_num)!=0; p++)
				{
					mscore[v] --;
					conf_times[v]++;
					score_2[v]++;
				}
				score_2[flipvar]--;

				sat(c);
			}
		}
		else // cur_soln[flipvar] != cur_lit.sense
		{
			--sat_count[c];
			if(sat_count[c]==2)
			{
				flag = 0;
				
				for(p=clause_c; (v=p->var_num)!=0; p++)
				{
					if(p->sense == cur_soln[v])
					{
						score_2[v]--;
						
						if(flag==0){sat_var[c]=v; flag=1;}
						else {sat_var2[c]=v; break;}
					}
				}
			}
			else if (sat_count[c] == 1) //sat_count from 2 to 1
			{
				score_2[flipvar]++;
				for(p=clause_c; (v=p->var_num)!=0; p++)
					score_2[v]++;
				if(sat_var[c]==flipvar)
					sat_var[c]=sat_var2[c];
				bscore[sat_var[c]]++;
			}
			else if (sat_count[c] == 0) //sat_count from 1 to 0
			{
				for(p=clause_c; (v=p->var_num)!=0; p++)
				{
					mscore[v] ++;
					score_2[v]--;
					conf_times[v]++;
				}
				bscore[flipvar]--;
				score_2[sat_var[c]]++;
				unsat(c);
			}//end else if
			
		}//end else
	}

	//update information of flipvar
	conf_times[flipvar] = 0;
}

int pick_var_lscore()
{
	int             i,c,v,ci;
	int             best_var,best_score;
	int		v_score;
	int		most_conf_var;
	struct lit 		*p,*q;
	
	c = unsat_stack[rand()%unsat_stack_fill_pointer];
	
	p=clause_lit[c];
	for(;(best_var=p->var_num)!=0; p++)
	{
		if(conf_times[best_var]!=0)
			break;
	}
	best_score = mscore[best_var]-bscore[best_var];
	for(p++; (v=p->var_num)!=0; p++)
	{
		if(conf_times[v]==0)
			continue;
		v_score = mscore[v]-bscore[v];
		if(v_score>best_score)
		{
			best_var = v;
			best_score = v_score;
		}
		else if(v_score<best_score)
			continue;
		else if(score_2[v]>score_2[best_var])
			best_var = v;
		else if(score_2[v]<score_2[best_var])
			continue;
		else if(conf_times[v]>conf_times[best_var])
			best_var = v;
		else if(conf_times[v]<conf_times[best_var])
			continue;
		else if(time_stamp[v]<time_stamp[best_var])
			best_var = v;
	}
	
	if(best_score>0)
		return best_var;
		
	if(rand()%MY_RAND_MAX_INT<prob)
	{
		p=clause_lit[c];
		best_var = p->var_num;
		for(p++; (v=p->var_num)!=0; p++)
		{
			if(bscore[v]<bscore[best_var])
				best_var = v;
			else if(bscore[v]>bscore[best_var])
				continue;
			else if(mscore[v]+score_2[v]>mscore[best_var]+score_2[best_var])
				best_var = v;
			else if(mscore[v]+score_2[v]<mscore[best_var]+score_2[best_var])
				continue;
			else if(conf_times[v]>conf_times[best_var])
				best_var = v;
			else if(conf_times[v]<conf_times[best_var])
				continue;
			else if(time_stamp[v]<time_stamp[best_var])
				best_var = v;
		}
		return best_var;
	}
	
	
	p=clause_lit[c];
	most_conf_var = p->var_num;
	for(p++; (v=p->var_num)!=0; p++)
	{
		if(conf_times[v]>conf_times[most_conf_var])
			most_conf_var = v;
		else if(conf_times[v]<conf_times[most_conf_var])
			continue;
		else if(time_stamp[v]<time_stamp[most_conf_var])
			most_conf_var = v;
		
	}
	
	return most_conf_var;
	
}


#endif
