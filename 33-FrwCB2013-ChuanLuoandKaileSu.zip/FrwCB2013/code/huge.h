#ifndef HUGE_H
#define HUGE_H

#include "basic.h"

void init_huge()
{
	int 		v,c;
	int			j;
	
	//init unsat_stack
	unsat_stack_fill_pointer = 0;

	//init solution
	for (v = 1; v <= num_vars; v++) {

		if(rand()%2==1) cur_soln[v] = 1;
		else cur_soln[v] = 0;

		time_stamp[v] = 0;
		conf_times[v] = 1;
	}

	/* figure out sat_count, and init unsat_stack */
	for (c=0; c<num_clauses; ++c) 
	{
		sat_count[c] = 0;
		
		for(j=0; j<clause_lit_count[c]; ++j)
		{
			if (cur_soln[clause_lit[c][j].var_num] == clause_lit[c][j].sense)
				sat_count[c]++;	
		}

		if (sat_count[c] == 0) 
			unsat(c);
	}
	
	//setting for the virtual var 0
	time_stamp[0]=0;
	conf_times[0]=0;
	bscore[0]=0;
	mscore[0]=0;
}

 
//flip a var, and do the neccessary updating
void flip_huge(int flipvar)
{
	int v,c;
	struct lit* clause_c;
	struct lit* p;
	struct lit* q;

	cur_soln[flipvar] = 1 - cur_soln[flipvar];
	
	//update related clauses and neighbor vars
	for(q=var_lit[flipvar]; (c=q->clause_num)!=-1; q++)
	{
		clause_c = clause_lit[c];
		if(cur_soln[flipvar] == q->sense)
		{
			++sat_count[c];
			
			if (sat_count[c] == 1) // sat_count from 0 to 1
			{	
				for(p=clause_c; (v=p->var_num)!=0; p++)
					conf_times[v]++;
				sat(c);
			}
		}
		else // cur_soln[flipvar] != cur_lit.sense
		{
			--sat_count[c];
			if (sat_count[c] == 0) //sat_count from 1 to 0
			{
				for(p=clause_c; (v=p->var_num)!=0; p++)
					conf_times[v]++;
				unsat(c);
			}//end else if
			
		}//end else
	}

	//update information of flipvar
	conf_times[flipvar] = 0;
}

int pick_var_huge()
{
	int             c,v,ci;
	int             best_var,best_score;
	int		v_score;
	int		most_conf_var;
	struct lit 		*p,*q;
	
	c = unsat_stack[rand()%unsat_stack_fill_pointer];
	
	p=clause_lit[c];
	for(;(v=p->var_num)!=0; p++)
	{
		bscore[v]=mscore[v]=0;
		for(q = var_lit[v]; (ci=q->clause_num)!=-1; q++)
		{
			if (sat_count[ci]==1 && q->sense==cur_soln[v]) bscore[v]++;
			else if(sat_count[ci]==0) mscore[v]++;
		}
	}

	best_var=0;
	p=clause_lit[c];
	for(;(best_var=p->var_num)!=0; p++)
	{
		if(conf_times[best_var]!=0)
			break;
	}
	best_score = mscore[best_var]-bscore[best_var];
	for(p++; (v=p->var_num)!=0; p++)
	{
		if(conf_times[v]==0)
			continue;
		v_score = mscore[v]-bscore[v];
		if(v_score>best_score)
		{
			best_var = v;
			best_score = v_score;
		}
		else if(v_score<best_score)
			continue;
		else if(conf_times[v]>conf_times[best_var])
			best_var = v;
		else if(conf_times[v]<conf_times[best_var])
			continue;
		else if(time_stamp[v]<time_stamp[best_var])
			best_var = v;
	}
	
	if(best_var!=0 && best_score>0)
		return best_var;
		
	if(rand()%MY_RAND_MAX_INT<prob)
	{
		p=clause_lit[c];
		best_var = p->var_num;
		for(p++; (v=p->var_num)!=0; p++)
		{
			if(bscore[v]<bscore[best_var])
				best_var = v;
			else if(bscore[v]>bscore[best_var])
				continue;
			else if(conf_times[v]>conf_times[best_var])
				best_var = v;
			else if(conf_times[v]<conf_times[best_var])
				continue;
			else if(time_stamp[v]<time_stamp[best_var])
				best_var = v;
		}
		return best_var;
	}
	
	
	p=clause_lit[c];
	most_conf_var = p->var_num;
	for(p++; (v=p->var_num)!=0; p++)
	{
		if(conf_times[v]>conf_times[most_conf_var])
			most_conf_var = v;
		else if(conf_times[v]<conf_times[most_conf_var])
			continue;
		else if(time_stamp[v]<time_stamp[most_conf_var])
			most_conf_var = v;
		
	}
	
	return most_conf_var;
	
}


#endif
