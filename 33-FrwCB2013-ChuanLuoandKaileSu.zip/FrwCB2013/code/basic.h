#ifndef BASIC_H
#define BASIC_H

#include <stdio.h>
#include <stdlib.h>
#include <sys/times.h> //these two h files are for linux
#include <unistd.h>

#define pop(stack) stack[--stack ## _fill_pointer]
#define push(item, stack) stack[stack ## _fill_pointer++] = item

#define LINE_LENGTH 10240

// Define a data structure for a literal in the SAT problem.
struct lit 
{
	int clause_num;		//clause num, begin with 0
	int var_num;		//variable num, begin with 1
	int sense;			//is 1 for true literals, 0 for false literals.
};

enum SOLVEMODE {NORMAL, HUGE, LSCORE};
enum SOLVEMODE method_mode;


/*parameters of the instance*/
int num_vars;		//var index from 1 to num_vars
int num_clauses;		//clause index from 0 to num_clauses-1
int max_clause_len;
int min_clause_len;
int num_clause_redundent;

/* literal arrays */				
struct lit** var_lit=NULL;				//var_lit[i][j] means the j'th literal of var i.
int* var_lit_count=NULL;			//amount of literals of each var
struct lit** clause_lit=NULL;			//clause_lit[i][j] means the j'th literal of clause i.
int* clause_lit_count=NULL; 			// amount of literals in each clause				
			
/* Information about the variables. */
int* bscore=NULL;
int* mscore=NULL;
int* score_2=NULL;				
unsigned long long*	time_stamp=NULL;
unsigned long long*	conf_times=NULL;

/* Information about the clauses */					
int* sat_count=NULL;			
int* sat_var=NULL;
int* sat_var2=NULL;			

//unsat clauses stack
int* unsat_stack=NULL;		//store the unsat clause number
int unsat_stack_fill_pointer;
int* index_in_unsat_stack=NULL; //which position is a clause in the unsat_stack


/* Information about solution */
int* cur_soln=NULL;	//the current solution, with 1's for True variables, and 0's for False variables

//cutoff steps
const unsigned long long max_tries = 9223372036854775806ll;
const unsigned long long max_flips = 9223372036854775806ll;

unsigned long long step;
struct tms start, stop;

const int MY_RAND_MAX_INT = 10000000;
const int prob_for_3SAT1  = 600*10000;  //random 3-SAT (r<4.26)
const int prob_for_3SAT2  = 630*10000;  //random 3-SAT (r>=4.26)
const int prob_for_4SAT1  = 650*10000;  //random 4-SAT (r<9.63)
const int prob_for_4SAT2  = 700*10000;  //random 4-SAT (r>=9.63)
const int prob_for_5SAT1  = 530*10000;  //random 5-SAT (r<20.2)
const int prob_for_5SAT2  = 600*10000;  //random 5-SAT (r>=20.2)
const int prob_for_6SAT1  = 670*10000;  //random 6-SAT (r<43.0)
const int prob_for_6SAT2  = 690*10000;  //random 6-SAT (r>=43.0)
const int prob_for_7SAT1  = 730*10000;  //random 7-SAT (r<86.0)
const int prob_for_7SAT2  = 780*10000;  //random 7-SAT (r>=86.0)
const int prob_for_others = 950*10000;  //not random SAT

int prob = 600*10000; //default

void mymalloc()
{
	int malloc_v = num_vars+10;
	int malloc_c = num_clauses+10;
	
	while(bscore==NULL) bscore = (int*) malloc(sizeof(int)*malloc_v);
	while(mscore==NULL) mscore = (int*) malloc(sizeof(int)*malloc_v);
	while(time_stamp==NULL) time_stamp = (unsigned long long*) malloc(sizeof(unsigned long long)*malloc_v);
	while(conf_times==NULL) conf_times = (unsigned long long*) malloc(sizeof(unsigned long long)*malloc_v);
	
	while(sat_count==NULL) sat_count = (int*) malloc(sizeof(int)*malloc_c);
	while(sat_var==NULL) sat_var = (int*) malloc(sizeof(int)*malloc_c);
	
	while(unsat_stack==NULL) unsat_stack = (int*) malloc(sizeof(int)*malloc_c);
	while(index_in_unsat_stack==NULL) index_in_unsat_stack = (int*) malloc(sizeof(int)*malloc_c);
	
	while(cur_soln==NULL) cur_soln = (int*) malloc(sizeof(int)*malloc_v);
	
	if(method_mode==LSCORE)
	{
		while(score_2==NULL) score_2 = (int*) malloc(sizeof(int)*malloc_v);
		while(sat_var2==NULL) sat_var2 = (int*) malloc(sizeof(int)*malloc_c);
	}
}

void myfree()
{
	int i;
	for(i=0; i<num_clauses; i++)
		free(clause_lit[i]);
	for(i=1; i<=num_vars; i++)
		free(var_lit[i]);
	
	if(var_lit!=NULL) free(var_lit);
	if(var_lit_count!=NULL) free(var_lit_count);
	if(clause_lit!=NULL) free(clause_lit);
	if(clause_lit_count!=NULL) free(clause_lit_count);
	
	if(bscore!=NULL) free(bscore);
	if(mscore!=NULL) free(mscore);
	if(time_stamp!=NULL) free(time_stamp);
	if(conf_times!=NULL) free(conf_times);
	
	if(sat_count!=NULL) free(sat_count);
	if(sat_var!=NULL) free(sat_var);
	
	if(unsat_stack!=NULL) free(unsat_stack);
	if(index_in_unsat_stack!=NULL) free(index_in_unsat_stack);
	
	if(cur_soln!=NULL) free(cur_soln);
	
	if(method_mode==LSCORE)
	{
		if(score_2!=NULL) free(score_2);
		if(sat_var2!=NULL) free(sat_var2);
	}
}

inline void unsat(int clause)
{
	index_in_unsat_stack[clause] = unsat_stack_fill_pointer;
	push(clause,unsat_stack);
}


inline void sat(int clause)
{
	int index,last_unsat_clause;

	//since the clause is satisfied, its position can be reused to store the last_unsat_clause
	last_unsat_clause = pop(unsat_stack);
	index = index_in_unsat_stack[clause];
	unsat_stack[index] = last_unsat_clause;
	index_in_unsat_stack[last_unsat_clause] = index;
}

void print_solution()
{
	int i;
    printf("v ");
    for (i=1; i<=num_vars; i++) {
		if(cur_soln[i]==0) printf("-");
		printf("%d",i);
		if(i%10==0) printf("\nv ");
		else	printf(" ");
    }
    printf("0\n");
}

int verify_sol()
{
	int c,j,flag;
	for (c = 0; c<num_clauses; ++c) 
	{
		flag = 0;
		for(j=0; j<clause_lit_count[c]; ++j)
			if (cur_soln[clause_lit[c][j].var_num] == clause_lit[c][j].sense) {flag = 1; break;}

		if(flag ==0){//output the clause unsatisfied by the solution
			printf("c clause %d is not satisfied\n",c);
			for(j=0; j<clause_lit_count[c]; ++j)
			{
				if(clause_lit[c][j].sense==0)printf("-");
				printf("%d ",clause_lit[c][j].var_num);
			}
			printf("\n");
			for(j=0; j<clause_lit_count[c]; ++j)
				printf("%d ",cur_soln[clause_lit[c][j].var_num]);
			printf("\n");
			return 0;
		}
	}
	return 1;
}

int build_instance(char *filename)
{
	char            line[LINE_LENGTH];
	char            tempstr[10];
	int             cur_lit;
	int             i,v,c,p;
	int 			lit_redundent,clause_redundent;
	int				tmp;
	char			*tmp_str;
	int				*temp_lit;
	char			ch;
	
	FILE *fp = fopen(filename, "r");
	if(fp==NULL)
		return 0;

	/*** build problem data structures of the instance ***/
	while((ch=fgetc(fp))!='p')
	{
		while(ch!='\n')
		{
			ch = fgetc(fp);
		}
	}
	tmp_str = fgets(line,LINE_LENGTH,fp);
	sscanf(line, "%s %d %d", tempstr, &num_vars, &num_clauses);
	
	temp_lit = (int*) malloc(sizeof(int)*(num_vars+10));
	while(var_lit==NULL) var_lit = (struct lit**) malloc(sizeof(struct lit*)*(num_vars+10));
	while(var_lit_count==NULL) var_lit_count = (int*) malloc(sizeof(int)*(num_vars+10));
	while(clause_lit==NULL) clause_lit = (struct lit**) malloc(sizeof(struct lit*)*(num_clauses+10));
	while(clause_lit_count==NULL) clause_lit_count = (int*) malloc(sizeof(int)*(num_clauses+10));
	
	for (c = 0; c < num_clauses; c++) 
		clause_lit_count[c] = 0;
	for (v=1; v<=num_vars; ++v)
		var_lit_count[v] = 0;
		
	max_clause_len = -1;
	min_clause_len = num_vars+1;
	num_clause_redundent = 0;
		
	//Now, read the clauses, one at a time.
	for (c = 0; c < num_clauses; ) 
	{
		clause_redundent=0;
		
		tmp = fscanf(fp,"%d",&cur_lit);
		while (cur_lit != 0) { 
		
			lit_redundent=0;
			for(p=0; p<clause_lit_count[c]; p++)
			{
				if(cur_lit==temp_lit[p]){
					//cout<<"literal "<<cur_lit<<" redundent in clause "<<c<<endl;
					lit_redundent=1;
					break;
				}
				else if(cur_lit==-temp_lit[p]){
					clause_redundent=1;
					break;
				}
			}
			
			if(lit_redundent==0)
			{
		
				temp_lit[clause_lit_count[c]] = cur_lit;
				clause_lit_count[c]++;
			}
		
			tmp = fscanf(fp,"%d",&cur_lit);
		}
		
		if(clause_redundent==0)
		{
			clause_lit[c] = (struct lit*) malloc((clause_lit_count[c]+1)*sizeof(struct lit));
		
			for(i=0; i<clause_lit_count[c]; ++i)
			{
				clause_lit[c][i].clause_num = c;
				clause_lit[c][i].var_num = abs(temp_lit[i]);
				if (temp_lit[i] > 0) clause_lit[c][i].sense = 1;
					else clause_lit[c][i].sense = 0;
			
				var_lit_count[clause_lit[c][i].var_num]++;
			}
			clause_lit[c][clause_lit_count[c]].var_num=0;
			clause_lit[c][clause_lit_count[c]].clause_num=-1;
			
			max_clause_len = max_clause_len>clause_lit_count[c]?max_clause_len:clause_lit_count[c];
			min_clause_len = min_clause_len<clause_lit_count[c]?min_clause_len:clause_lit_count[c];
			
			c++;
		}
		else 
		{
			num_clauses--;
			clause_lit_count[c] = 0;
			num_clause_redundent++;
		}
	}
	fclose(fp);
	
	//creat var literal arrays
	for (v=1; v<=num_vars; ++v)
	{
		var_lit[v] = (struct lit*) malloc((var_lit_count[v]+1)*sizeof(struct lit));
		var_lit[v][var_lit_count[v]].var_num = 0;
		var_lit[v][var_lit_count[v]].clause_num=-1;
		var_lit_count[v] = 0;	//reset to 0, for build up the array
	}
	//scan all clauses to build up var literal arrays
	for (c = 0; c < num_clauses; ++c) 
	{
		for(i=0; i<clause_lit_count[c]; ++i)
		{
			v = clause_lit[c][i].var_num;
			var_lit[v][var_lit_count[v]] = clause_lit[c][i];
			++var_lit_count[v];
		}
	}
	
	free(temp_lit);
	
	return 1;
		
}

#endif
