#ifndef NORMAL_H
#define NORMAL_H

#include "basic.h"

void init_normal()
{
	int 		v,c;
	int			i,j;
	
	//init unsat_stack
	unsat_stack_fill_pointer = 0;

	//init solution
	for (v = 1; v <= num_vars; v++) {

		if(rand()%2==1) cur_soln[v] = 1;
		else cur_soln[v] = 0;
		
		time_stamp[v] = 0;
		conf_times[v] = 1;
	}

	/* figure out sat_count, and init unsat_stack */
	for (c=0; c<num_clauses; ++c) 
	{
		sat_count[c] = 0;
		
		for(j=0; j<clause_lit_count[c]; ++j)
		{
			if (cur_soln[clause_lit[c][j].var_num] == clause_lit[c][j].sense)
			{
				sat_count[c]++;
				sat_var[c] = clause_lit[c][j].var_num;	
			}
		}

		if (sat_count[c] == 0) 
			unsat(c);
	}

	/*figure out var dscore*/
	int lit_count;
	for (v=1; v<=num_vars; v++) 
	{
		bscore[v] = mscore[v] = 0;
		
		lit_count = var_lit_count[v];
		
		for(i=0; i<lit_count; ++i)
		{
			c = var_lit[v][i].clause_num;
			if (sat_count[c]==0) mscore[v]++;
			else if (sat_count[c]==1 && var_lit[v][i].sense==cur_soln[v]) bscore[v]++;
		}
	}
	
	//setting for the virtual var 0
	time_stamp[0]=0;
	conf_times[0]=0;
	bscore[0]=0;
	mscore[0]=0;
}

 
//flip a var, and do the neccessary updating
void flip_normal(int flipvar)
{
	int v,c;
	struct lit* clause_c;
	struct lit* p;
	struct lit* q;

	cur_soln[flipvar] = 1 - cur_soln[flipvar];
	
	//update related clauses and neighbor vars
	for(q=var_lit[flipvar]; (c=q->clause_num)!=-1; q++)
	{
		clause_c = clause_lit[c];
		if(cur_soln[flipvar] == q->sense)
		{
			++sat_count[c];
			
			if (sat_count[c] == 2) //sat_count from 1 to 2
				bscore[sat_var[c]] --;
			else if (sat_count[c] == 1) // sat_count from 0 to 1
			{
				sat_var[c] = flipvar;//record the only true lit's var
				bscore[flipvar]++;
				
				for(p=clause_c; (v=p->var_num)!=0; p++)
				{
					mscore[v] --;
					conf_times[v]++;
				}

				sat(c);
			}
		}
		else // cur_soln[flipvar] != cur_lit.sense
		{
			--sat_count[c];
			if (sat_count[c] == 1) //sat_count from 2 to 1
			{
				for(p=clause_c; (v=p->var_num)!=0; p++)
				{
					if(p->sense == cur_soln[v] )
					{
						bscore[v] ++;
						sat_var[c] = v;
						break;
					}
				}
			}
			else if (sat_count[c] == 0) //sat_count from 1 to 0
			{
				for(p=clause_c; (v=p->var_num)!=0; p++)
				{
					mscore[v] ++;
					conf_times[v]++;
				}
				bscore[flipvar]--;
				unsat(c);
			}//end else if
			
		}//end else
	}

	//update information of flipvar
	conf_times[flipvar] = 0;
}

//pick a var to be flip
int pick_var_normal()
{
	int             c,v;
	int             best_var,best_score;
	int		v_score;
	int		most_conf_var;
	struct lit 		*p;
	
	c = unsat_stack[rand()%unsat_stack_fill_pointer];

	best_var=0;
	p=clause_lit[c];
	for(;(best_var=p->var_num)!=0; p++)
	{
		if(conf_times[best_var]!=0)
			break;
	}
	best_score = mscore[best_var]-bscore[best_var];
	for(p++; (v=p->var_num)!=0; p++)
	{
		if(conf_times[v]==0)
			continue;
		v_score = mscore[v]-bscore[v];
		if(v_score>best_score)
		{
			best_var = v;
			best_score = v_score;
		}
		else if(v_score<best_score)
			continue;
		else if(conf_times[v]>conf_times[best_var])
			best_var = v;
		else if(conf_times[v]<conf_times[best_var])
			continue;
		else if(time_stamp[v]<time_stamp[best_var])
			best_var = v;
	}
	
	if(best_var!=0 && best_score>0)
		return best_var;
		
	if(rand()%MY_RAND_MAX_INT<prob)
	{
		p=clause_lit[c];
		best_var = p->var_num;
		for(p++; (v=p->var_num)!=0; p++)
		{
			if(bscore[v]<bscore[best_var])
				best_var = v;
			else if(bscore[v]>bscore[best_var])
				continue;
			else if(conf_times[v]>conf_times[best_var])
				best_var = v;
			else if(conf_times[v]<conf_times[best_var])
				continue;
			else if(time_stamp[v]<time_stamp[best_var])
				best_var = v;
		}
		return best_var;
	}
	
	
	p=clause_lit[c];
	most_conf_var = p->var_num;
	for(p++; (v=p->var_num)!=0; p++)
	{
		if(conf_times[v]>conf_times[most_conf_var])
			most_conf_var = v;
		else if(conf_times[v]<conf_times[most_conf_var])
			continue;
		else if(time_stamp[v]<time_stamp[most_conf_var])
			most_conf_var = v;
		
	}
	
	return most_conf_var;
	
}


#endif
