#ifndef SELECTMETHOD_H
#define SELECTMETHOD_H

#include "basic.h"
#include "normal.h"
#include "huge.h"
#include "lscore.h"

void (*init)();
void (*flip)(int);
int (*pick_var)();

void select_prob_and_method()
{
	double r = ((double)num_clauses)/num_vars;
	
	if(max_clause_len == min_clause_len)
	{
		if(max_clause_len<=3)
		{
			if(num_vars>20000)
			{
				init = init_huge;
				flip = flip_huge;
				pick_var = pick_var_huge;
				method_mode = HUGE;
			}
			else
			{
				init = init_normal;
				flip = flip_normal;
				pick_var = pick_var_normal;
				method_mode = NORMAL;
			}
			if(r<4.26)
				prob = prob_for_3SAT1;
			else prob = prob_for_3SAT2;
		}
		else if(max_clause_len<=4)
		{
			init = init_normal;
			flip = flip_normal;
			pick_var = pick_var_normal;
			method_mode = NORMAL;
			if(r<9.63)
				prob = prob_for_4SAT1;
			else prob = prob_for_4SAT2;
		}
		else if(max_clause_len<=5)
		{
			init = init_lscore;
			flip = flip_lscore;
			pick_var = pick_var_lscore;
			method_mode = LSCORE;
			if(r<20.2)
				prob = prob_for_5SAT1;
			else prob = prob_for_5SAT2;
		}
		else if(max_clause_len<=6)
		{
			init = init_lscore;
			flip = flip_lscore;
			pick_var = pick_var_lscore;
			method_mode = LSCORE;
			if(r<43.0)
				prob = prob_for_6SAT1;
			else prob = prob_for_6SAT2;
		}
		else 
		{
			init = init_lscore;
			flip = flip_lscore;
			pick_var = pick_var_lscore;
			method_mode = LSCORE;
			if(r<86.0)
				prob = prob_for_7SAT1;
			else prob = prob_for_7SAT2;
		}
	}
	else if(max_clause_len == 3 && (min_clause_len == 2 || min_clause_len == 1))
	{
		if(num_vars>20000)
		{
			init = init_huge;
			flip = flip_huge;
			pick_var = pick_var_huge;
			method_mode = HUGE;
		}
		else
		{
			init = init_normal;
			flip = flip_normal;
			pick_var = pick_var_normal;
			method_mode = NORMAL;
		}
		prob = prob_for_3SAT1;
	}
	else 
	{
		init = init_normal;
		flip = flip_normal;
		pick_var = pick_var_normal;
		method_mode = NORMAL;
		prob = prob_for_others;
	}
}

void print_information(char* instance, char* seed)
{
	printf("c This is the FrwCB2013 solver, Version: SC2013_20130427\n");
	printf("c Author: Chuan Luo, chuanluosaber@gmail.com\n");
	printf("c instance = %s\n", instance);
	printf("c seed = %s\n", seed);
	printf("c num_vars = %d\nc num_clauses = %d\nc num_clause_redundent = %d\nc ratio = %lf\n", num_vars, num_clauses, num_clause_redundent, ((double)num_clauses)/num_vars);
    printf("c max_clause_len = %d\nc min_clause_len = %d\nc prob = %lf\n", max_clause_len, min_clause_len, (double)prob/MY_RAND_MAX_INT);
    if(method_mode == NORMAL)
    	printf("c Method Mode: normal\n");
    else if(method_mode == HUGE)
    	printf("c Method Mode: huge\n");
    else printf("c Method Mode: lscore\n");
}


#endif
