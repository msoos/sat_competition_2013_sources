#!/bin/bash

mkdir binary
gcc -O3 -static -m64 code/main.c -o binary/FrwCB2013
rm -f *~
rm -f code/*~
rm -f binary/*~
