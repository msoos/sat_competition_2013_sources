This is the SAT solver FrwCB2013 (Focused Random Walk with Configuration Checking and Break Minimum, Version: SC2013_20130427). 
FrwCB2013 should be complied by gcc with -O3 -static -m64 options under 64-bit GNU/Linux operating system.
FrwCB2013 is a 64-bit binary.

Please compile FrwCB2013 as
  sh build.sh
and then the executable binary (FrwCB2013) will be in the directory ./binary

Please run FrwCB2013 in directory ./binary as
  ./FrwCB2013 <instance> <seed>

Author:
  Chuan Luo
  	School of EECS, Peking University, Beijing, China
  	chuanluosaber@gmail.com
