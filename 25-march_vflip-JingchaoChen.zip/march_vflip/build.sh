#!/bin/bash

mkdir -p binary
cd code
make 
cp march_vflip  ../binary/march_vflip
 
