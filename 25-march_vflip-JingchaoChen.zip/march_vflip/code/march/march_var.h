#ifndef __MARCH_VAR_H__
#define __MARCH_VAR_H__
/*
        --------------------------------------------------------------------------------------------------------------
        ------------------------------------------------[ variables ]-------------------------------------------------
        --------------------------------------------------------------------------------------------------------------
*/

#ifdef GLOBAL_AUTARKY
int *clause_reduction;
int *clause_red_depth;
int *clause_SAT_flag;
int **big_to_binary, *btb_size, *big_global_table;
#endif

#ifdef PARALLEL
int para_depth;
int para_bin;
#endif

float *hiRank, *clause_weight, *hiSum;
int kSAT_flag;
int dist_acc_flag; 

// used for big clauses and resolvent_look
int *literal_list, **clause_list, *clause_length, **clause_set, *clause_database, *big_occ;
int nrofbigclauses;

#ifdef LONG_LOOK
int ll_conflicts;
#endif
#ifdef DISTRIBUTION
int target_rights, current_rights;
#ifdef CUT_OFF
int *bins;
#endif
#endif

int jump_depth;

int percent;
float *Rank;
int Rank_trigger;
float *diff, *_diff, *diff_tmp, *_diff_tmp, **diff_depth, *diff_table;
int initial_freevars;

double percentage_forced;

#ifdef PLOT
  double sum_plot;
  int count_plot;
#endif

int *dpll_fixstackp, *end_fixstackp;

int64 dl_possibility_counter, dl_actual_counter;

int *TernaryImpReduction;

int tree_elements;

/* doublelook statistics */

float DL_trigger, DL_trigger_sum;
int64 doublelook_count, doublelook_failed;

int bin_sat, bin_unsat;
int non_tautological_equivalences;

/* solver AND lookahead AND pre-selection */

int **TernaryImp, *TernaryImpSize, *tmpTernaryImpSize;
int *lookaheadArray, lookaheadArrayLength;
int *bImp_satisfied;
int *bImp_start;

double *lengthWeight;

int *freevarsArray;

int *preBieq, preBieqSize;

/* statistics */
int nrofvars, nrofclauses, nrofceq, nroforigvars;
int original_nrofvars, original_nrofclauses;
int freevars, depth;

int **Ceq, **Veq, **VeqLUT, *CeqValues, *CeqSizes, *CeqSizes2, *CeqSizesNA;
int *CeqStamps;									//KAN BETER char* CeqFlag WORDEN
int *CeqDepends, *VeqDepends;
int *VeqLength;
int *CeqSizes1, *CeqValues1;
int *eq_found;

/* data structure */
tstamp current_node_stamp;
tstamp *timeAssignments, *node_stamps;
int **Cv, *Clength, **BinaryImp, *BinaryImpLength;

/* various stacks */
int *rstack, *rstackp, rstackSize;
int *look_fixstack, *look_fixstackp, look_fixstackSize;
int *look_resstack, *look_resstackp, look_resstackSize;
int *subsumestack,  *subsumestackp,  subsumestackSize;
int *bieqstack,  *bieqstackp,  bieqstackSize;
int *impstack,   *impstackp,   impstackSize;

/* lookahead */
int *forced_literal_array, forced_literals;
tstamp currentTimeStamp;
int iterCounter;

struct treeNode *treeArray;

/* accounting */
int nodeCount;
int lookAheadCount;
int unitResolveCount;
int necessary_assignments;
int lookDead, mainDead;

int efcount;
int *org_size;

struct record {
    int branch_literal;
    int nrofforced;
    int forced_offset;
    int child[2];
    int UNSAT_flag;
};

unsigned int current_record;
struct record *records;

int nrgiven;
int minpos;
int lastCTS;

int complement_value;
int impgiven;

int node_stamp, tree_stamp, changed;

struct assignment {
    int *incoming;
    int incoming_size;
    int nr_incoming;
    int tree_size;
    int parent;
    int varnr;
};

struct assignment *assignment_array;

#endif
