/*
 march_vflip April 2013
 Copyright (c) 2013, Jingchao Chen, Donghua University,China.  All rights reserved.
*/

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include "D_Constants.h"
#include <signal.h>
#include "PPS_struct.h"
#include "MersenneTwister.h"

namespace ubcsat {
	int VFNmain(char * Filename);
}

extern int eCutoff;
extern int eSeed;

extern int **Cv, *Clength;
void initCNFdatastruct(int numCls, int numVar);

void load_march_solve();
int mix_march_solve(int * & solution);

MTRand mtrand(100);

void release_pps (PPS *pps);
void release_free_pps (PPS * & pps);
void release_occCls(PPS *pps);
void free_mem(int * & ptr);

void verify_output(int *solution);
void check(int sol[],Stack<int> *clause);
void readSATProblem(char *CNFfile, PPS * & pps);

/*
 * A signal handling function.
 * For handling user interuption (Ctrl+c).
 * Print out execution stats and exit.
 *
 */
void SIGINT_handler(int signum) 
{
  printf("c \n");
  printf("c \n");
  printf("c INTERRUPTED \n");
  printf("c Time used: %fs\n",get_cpu_time());
  exit(0); 
}

/*
 * A signal handling function. 
 * For handling segmentation fault.
 * 
 * Print out indicator message and exit.
 */
void SIGSEGV_handler(int signum) 
{
  printf("c \n");
  printf("c \n");
  printf("c SEGMENTATION FAULT \n");
  printf("c \ns UNKNOWN\n");
  printf("c \n");
  exit(0); 
}

//time measuring function
double nowtime() 
{
#ifdef _MSC_VER
#include <ctime>
    return (double)clock() / CLOCKS_PER_SEC;
#else
  struct rusage u;
  if (getrusage (RUSAGE_SELF, &u)) return 0;
  double res = u.ru_utime.tv_sec + 1e-6 * u.ru_utime.tv_usec;
  res += u.ru_stime.tv_sec + 1e-6 * u.ru_stime.tv_usec;
  return res;
#endif
}

char *FileName;

int load_SAT(char *CNFfile,int * &solution);
double starttime;
int main(int  argc, char *argv[])
{
   signal(SIGINT,SIGINT_handler);
   signal(SIGSEGV,SIGSEGV_handler);
   srand(INIT_RANDOM_SEED);

   if (argc<2) {
       printf("c Using format: march_vflip CNF_file\n");
       exit(0);
//        FileName=filename;
   }
   else FileName=argv[1];
   printf("c march_vflip by Jingchao Chen,  April 2013\n");
   printf("c input CNF file=%s \n",FileName);

   starttime=nowtime();
   mtrand.seed(10);
   eSeed=123;
   int trys=3;
   for(int i=0; i<trys; i++){
          eCutoff=70000000;
  	 // if(i==0) eCutoff=3*eCutoff; 
          ubcsat::VFNmain(FileName);
	  eSeed++;
   }

   load_march_solve();
   	int *march_solution=0;
	int result=mix_march_solve(march_solution); //0: unkown, 1:SAT, -1: UNSAT
    printf("c \nc  Running time=%f \n", nowtime()-starttime);
 	if(result>0) {
		verify_output(march_solution);
        exit(10);
    }
    if(result<0) {
		printf("c \ns UNSATISFIABLE\n"); 
        exit(20);
    }

    eCutoff=100000000;
  	while(1){
		  ubcsat::VFNmain(FileName);
		  eSeed++;
    }
  	printf("c \ns UNKNOWN\n");
	exit(0);
    return result;
}


void load_march_solve()
{   
	PPS *pps;

    readSATProblem(FileName, pps);

	int numCls=pps->numClause;
	int *pcls=pps->clause->begin();
    int *pend=pps->clause->end();

	initCNFdatastruct(numCls, pps->numVar);
	numCls=0;
   	
  	while(pcls < pend){
         int len=*pcls;
	     int mark=len & MARKBIT;
		 len=len>>FLAGBIT;
		 int *litp=pcls+1;
         pcls+=len;
		 if(mark!=CNF_CLS) continue;
	     len--;
		 Cv[numCls ] = (int*) malloc( sizeof( int ) * len);
   	   	 Clength[numCls] =len;
		 int n=0;
 	     for (; litp<pcls; litp++) Cv[numCls ][n++]=*litp;
		 numCls++;
	}
	delete pps->clause;
}


/* 
 * Prints the current solution 
 */
void print_solution(int sol[],int numVar)
{   
    printf("v ");
//    if(numVar>100) numVar=100;
    //FILE *fp=fopen("solution.txt","w+t");
    for(int i=1; i<=numVar; i++) if(sol[i]) printf("%d ", sol[i]);
    //for(int i=1; i<=numVar; i++) if(sol[i]) fprintf(fp,"%d ", sol[i]);
    printf("\nv 0\n");
    printf("c \nc  Running time=%f \n", nowtime()-starttime);
    //fprintf(fp," 0 \n");
	//fclose(fp);
}

void verify_output(int *solution)
{    PPS *s_pps;
     readSATProblem(FileName,s_pps);
	 for(int i=1; i<=s_pps->numVar; i++){ //bug cube-11-h14 2012/1/1
		 if(solution[i]==0) {
			 printf(" u[%d]=0 ",i);
             solution[i]=i;
		 }
	 }
     check(solution,s_pps->clause);
     printf("c \ns SATISFIABLE\n");
	 print_solution(solution,s_pps->numVar);
	 release_pps (s_pps);
}

void readSATProblem(char *CNFfile, PPS * & pps)
{
    int i,lastc,nextc,lit;

    FILE *fp=fopen(CNFfile,"r");
    if(fp==NULL) {
	   printf("c Cann't open file %s \n", CNFfile);
	   exit(1);
    }
    while ((lastc = fgetc(fp)) == 'c'){
	    while ((nextc = fgetc(fp)) != EOF && nextc != '\n');
    }
    ungetc(lastc,fp);
	int numatom,numClauses;
    if (fscanf(fp,"p cnf %i %i",&numatom,&numClauses) != 2) {
	     printf("c Bad input file \n");
	     exit(1);
    }

	pps=(struct PPS *) calloc (1, sizeof (PPS));
	pps->numClause=numClauses;
	pps->numVar=numatom;
    
	pps->clause=new Stack<int>; 
    Stack<int> * clsSAT=pps->clause;
	for(i = 0;i < numClauses;i++){
	    int clsbegin=clsSAT->nowpos();
		clsSAT->push(0);
        do {
		  if (fscanf(fp,"%i ",&lit) != 1) {
		        printf("c wrong CNF proposition \n");
		        exit(0);
		   }
	       if(lit != 0) {
         		clsSAT->push(lit);
				if(ABS(lit)>numatom){
                      printf("c ERROR - incorrect problem format or extraneous characters\n");
	                  exit(0);
				}
			}

		} while(lit != 0);
        int len =clsSAT->nowpos()-clsbegin;
		(*clsSAT)[clsbegin]=(len<<FLAGBIT) | CNF_CLS;
	}
 	fclose(fp);
}	

void check(int sol[],Stack<int> *clause)
{
     int len,sum,i,vi;

	 int *pcls=clause->begin();
	 int *pend=clause->end();
	 i=0;
  
	 while(pcls < pend){
             len=*pcls;
	     // int mark=len & MARKBIT;
	     len=len>>FLAGBIT;
	     int *lits=pcls+1;
    	     pcls+=len;
             sum=0; i++;
	     for (; lits<pcls; lits++){
		   vi=*lits;
       	           int xi= vi < 0 ? -vi : vi; 
                   if(sol) {
			   if(sol[xi]==vi) sum+=1;
		   }
	     }
	     if(sum==0 && sol) {
        	  printf ("c ERROR i=%d \nc ",i);
		  int *lits=pcls+1-len;
		  for (; lits<pcls; lits++){
		        vi=*lits;
       	                int xi= vi < 0 ? -vi : vi; 
                        printf("%d[%d] ",vi,sol[xi]);
		  }
		  exit(0);
  	 }
   }
   printf("c verified \n");
}

void free_mem(int * & ptr)
{
	if(ptr) free(ptr);
	ptr=0;
}
void release_pps (PPS * pps)
{
	if(pps==0) return;
	if(pps->clause) {
		delete pps->clause;
		pps->clause=0;
	}
    release_occCls(pps);
	if(pps->clausePos){
		delete pps->clausePos;
		pps->clausePos=0;
	}
	free_mem(pps->unit);
	free_mem(pps->seen);
    free_mem(pps->outEquAtom);
    if(pps->n_inative) {
		free(pps->inaLit[0]);
		free(pps->inaLit);
		pps->n_inative=0;
    }
	if(pps->numXOR){
		pps->numVar=0;
		free(pps->Leq[0]);
		free(pps->Leq);
	}
    if(pps->inactiveVar){
		delete pps->inactiveVar;
		pps->inactiveVar=0;
	}
}

void release_free_pps (PPS * & pps)
{
	if(pps==0) return;
    release_pps (pps);
    free(pps);
	pps=0;
}

void release_occCls(PPS *pps) 
{
	if(pps->occCls){
		for(int i = 1; i <= pps->numVar; i++) {
	       pps->occCls[i].release();
	       pps->occCls[-i].release();
		}
	    pps->occCls-=pps->numVar;
	    free(pps->occCls);
        pps->occCls = 0;
	}
	if(pps->occBoth){
        for(int i = 1; i <= pps->numVar; i++) pps->occBoth[i].release();
	    free(pps->occBoth); 
        pps->occBoth=0;
	}
}
