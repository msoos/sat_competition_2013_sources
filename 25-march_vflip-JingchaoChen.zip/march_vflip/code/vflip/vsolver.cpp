/*
 vflipnum --- Copyright (c) 2013, Jingchao Chen and Yuyang Huang, Donghua University, China   

vflipnum is a SLS SAT Solver obtained by modifying Sparrow . Permissions and copyrights of
vflipnum are exactly the same as Sparrow.

*/

#include "s_ubcsat.h"

extern int eCutoff;

#ifdef __cplusplus 
namespace ubcsat {
#endif

PROBABILITY iPs;
UINT32 *aPenClauseListPos;
UINT32 *aPenClauseList;
UINT32 iNumPenClauseList;
UINT32 iTabuTenure;
bool   isBigInstance=false;
UINT32 Valg_theta=5;

/* 
    Note: For consistency, we use the same weighted promising variable scheme as in gNovelty+, which has some quirks,
    espeically during smoothing & scaling updates.
*/

void PickVFN();
void ScaleSparrow();
void SmoothSparrow();
void FlipSparrow();
void InitSparrow();
void VFNSat2013Settings();

void CreateSparrowPromVars();
void InitSparrowPromVars();
UINT32 *aSparrowPromVars;
BOOL *aVarIsGNovCandVar;
UINT32 iNumSparrowPromVars;

void CreateSparrowScore();
void InitSparrowScore();
SINT32 *aSparrowScore;

void CreateSparrowWeights();
FLOAT *aSparrowWeights;

FLOAT fSparrowC1;
UINT32 iSparrowC2;
FLOAT fSparrowC3;
FLOAT fInvSparrowC3;

FLOAT aSparrowPreCalc[11];

// The new solver uses the following variables 
BOOL *aVarsConfChange; //
UINT32 *ClauseAge;
UINT32 *aVarsFlipNum;
UINT32 FlipSum=0;

//void AddSparrow() {

void Addvflipnum() {

  ALGORITHM *pCurAlg;

  pCurAlg = CreateAlgorithm("vflipnum","",0,
    "Vflipnum",
    "Chen, Huang [SAT 13]",
    "PickVFN",
    "DefaultProcedures,FlipSparrow,SparrowPromVars,FalseClauseList,VarLastChange,PenClauseList,VarsShareClauses,CreateSparrowWeights,InitSparrow",
    "default","default");
  
  AddParmProbability(&pCurAlg->parmList,"-ps","smooth probabilty [default %s]","after a scaling step, ~smooth penalties with probability PR","",&iPs,0.347);
  
  AddParmFloat(&pCurAlg->parmList,"-c1","sparrow score adjustment parameter [default %s]","adjusts the importance of the score","",&fSparrowC1,2.0);
  AddParmUInt(&pCurAlg->parmList,"-c2","sparrow age polynomial parameter [default %s]","adjusts the influence of the age","",&iSparrowC2,4);
  AddParmFloat(&pCurAlg->parmList,"-c3","sparrow age threshold parameter [default %s]","threshold for age calculation","",&fSparrowC3,100000.0);

  CreateTrigger("InitSparrow",PostRead,InitSparrow,"","");

  CreateTrigger("PickVFN",ChooseCandidate,PickVFN,"","");
  CreateTrigger("FlipSparrow",FlipCandidate,FlipSparrow,"SparrowPromVars,FalseClauseList","DefaultFlip,UpdateFalseClauseList");  
  CreateTrigger("CreateSparrowWeights",CreateStateInfo,CreateSparrowWeights,"","");

  CreateTrigger("CreateSparrowPromVars",CreateStateInfo,CreateSparrowPromVars,"CreateSparrowScore","");
  CreateTrigger("InitSparrowPromVars",InitStateInfo,InitSparrowPromVars,"InitSparrowScore","");
  CreateContainerTrigger("SparrowPromVars","CreateSparrowPromVars,InitSparrowPromVars");

  CreateTrigger("CreateSparrowScore",CreateStateInfo,CreateSparrowScore,"CreateClausePenaltyINT","");
  CreateTrigger("InitSparrowScore",InitStateInfo,InitSparrowScore,"InitClausePenaltyINT","");
  CreateContainerTrigger("SparrowScore","CreateSparrowScore,InitSparrowScore");


  pCurAlg = CreateAlgorithm("vflipnum","sat13",0,
    "vflipnum [SAT 13 Competition]",
    "Chen, Huang[SAT 13]",
    "PickVFN,VFNSat2013Settings",
    "DefaultProcedures,FlipSparrow,SparrowPromVars,FalseClauseList,VarLastChange,PenClauseList,VarsShareClauses,CreateSparrowWeights",
    "default","default");

  CreateTrigger("VFNSat2013Settings",PostRead,VFNSat2013Settings,"","");
}

void VFNSat2013Settings() {
  // These settings modified by Chen and Huang for the SAT 2013 competition
  // printf("c VFNSat2013Settings \n");
    if(iNumVars > 1300 && iSeed ==123) eCutoff=3*eCutoff;
    if(iNumVars<4000)  {
  // iNumVars<3000
          isBigInstance=false;
          Valg_theta=5;
   }
   else {
         isBigInstance=true;
         if(iNumVars > 16000) Valg_theta=9;
         else{
               if(iNumVars > 11000) Valg_theta=7;//8
               else Valg_theta=6;
         }
   }
	
  if (iMaxClauseLen < 4) {
    fSparrowC1 = 2.15;
   // fSparrowC1 = 2.0;
    iSparrowC2 = 4;
    fSparrowC3 = 100000.0;
    if(isBigInstance) iPs = FloatToProb(0.347);
    else iPs = FloatToProb(0.400);
  } else {
      if(iNumVars>1300) {
               Valg_theta=0;
               if(iSeed>=123) iSeed=187+(iSeed-123); // notice !!! new idea
      }
      if (iMaxClauseLen < 6) {
         iSparrowC2 = 4;
         if(iNumVars > 200){     
            fSparrowC1 = 2.85;//old
            fSparrowC3 = 75000.0;
            iPs = FloatToProb(1.0);
        }
        else{
          fSparrowC1 = 3.0;
          fSparrowC3 = 105000.0;
          iPs = FloatToProb(0.90);
        }
     } else {
       fSparrowC1 = 6.5;
       iSparrowC2 = 4;
      if(iNumClauses>10000){//old
          fSparrowC3 = 100000.0;
          iPs = FloatToProb(0.83);
      }
      else{
        if(iNumVars < 90) fSparrowC1 = 5.5;
        fSparrowC3 = 110000.0;
        iPs = FloatToProb(0.835);
      }
    }
  }
  
//  printf(" iPs=%u ", iPs);

  InitSparrow();
}

void InitSparrow() {
  SINT32 j;
  for (j=0;j <= 10; j++) {
    aSparrowPreCalc[j] = pow(fSparrowC1,-j);
  }
  fInvSparrowC3 = 1.0f / fSparrowC3;
}

void PickVFN() {

  UINT32 iClause;
  UINT32 iClauseLen;
  UINT32 iVar;
  SINT32 iScoreAdjust;
  LITTYPE *pLit;
  UINT32 j;
  UINT32 k;

  FLOAT fScoreProb;
  FLOAT fAgeProb;
  FLOAT fBaseAgeProb;
  FLOAT fScoreSum;
  FLOAT fScorePos;
  
  if (iNumFalse==0) return;
 
  iFlipCandidate = 0;

  if (iNumSparrowPromVars > 0 ) { 
    iBestScore = 0;
    j=0;
    k=0;
    while (j < iNumSparrowPromVars) {
      iVar = aSparrowPromVars[k];
      if (aSparrowScore[iVar] >= 0) {
        iNumSparrowPromVars--;
        aVarIsGNovCandVar[iVar] = 0;
      } else {
       //6  or 9 4??
		 if (iNumFalse > Valg_theta || aVarsConfChange[iVar] == 1 || aSparrowScore[iVar] < -1){//-1 //CCA sat  -iAverageWeight
	//	 if (iNumFalse>2 || aVarsConfChange[iVar] == 1 || aSparrowScore[iVar] < -1){
			 if (aSparrowScore[iVar] < iBestScore) {
                iFlipCandidate = iVar;
                iBestScore = aSparrowScore[iVar];
			//	if(iBestScore<-7) return;
			} 
			else {
              if (aSparrowScore[iVar] == iBestScore) {
                 if (aVarLastChange[iVar] < aVarLastChange[iFlipCandidate]) iFlipCandidate = iVar;
			  }
			}
		 }
         aSparrowPromVars[j++]=aSparrowPromVars[k];
      }
      k++;
    }
  }
  if (iFlipCandidate != 0) return;
 
// vfilpnum new idea -----------------------------------
   if (iNumSparrowPromVars > 0) {
          k=0;
          for(j=1; j < iNumSparrowPromVars; j++) 
	      if(aSparrowScore[aSparrowPromVars[j]] < aSparrowScore[aSparrowPromVars[k]]) k=j;
    
          iFlipCandidate = aSparrowPromVars[k];
          iBestScore = aSparrowScore[aSparrowPromVars[k]]; 
          UINT32 sum=0;
          UINT32 maxflip=0;
          UINT32 minflip=aVarsFlipNum[iFlipCandidate];
          UINT32 minFlipVar=0;
          UINT32 maxAge=(UINT32)aVarLastChange[iFlipCandidate];
          int  cnt=0;
          for(j=0; j < iNumSparrowPromVars; j++){
	     iVar = aSparrowPromVars[j];
	     if (aSparrowScore[iVar] == iBestScore) {
		   sum+=aVarsFlipNum[iVar];
		   if(maxflip<aVarsFlipNum[iVar]) maxflip=aVarsFlipNum[iVar];
		   else if(minflip > aVarsFlipNum[iVar]) {
		       minflip = aVarsFlipNum[iVar];
                       minFlipVar=iVar;
                   }
		   cnt++;
		   if (aVarLastChange[iVar] < aVarLastChange[iFlipCandidate]) iFlipCandidate = iVar;
		   else{
                       if(maxAge < (UINT32)aVarLastChange[iVar]) maxAge = (UINT32)aVarLastChange[iVar]; 
		   }
	      }
	  }
	  if(isBigInstance){ if(cnt<=1) return;}
          else if(cnt<=2) return;
	  
	  if(maxflip - minflip < iNumVars || iNumFalse < 3) {//3 4 /10000 
		 // if(maxflip - minflip >5000 && minFlipVar) iFlipCandidate = minFlipVar;
	      return;
	  }
	  if(maxflip/2 > minflip && minFlipVar) {
		  iFlipCandidate = minFlipVar;
		  return;
	  }
	// if(maxAge - aVarLastChange[iFlipCandidate]>100) return;
	  if(cnt>1){
		  int max=maxflip-(sum+cnt-1)/cnt;
                  if(max<cnt) return;
                  UINT32 pivot=RandomInt(max);
                  sum=0;
		   for(j=0; j < iNumSparrowPromVars; j++){
		         iVar = aSparrowPromVars[j];
	 	         if (aSparrowScore[iVar] == iBestScore) {
                              int delt = ((maxflip-aVarsFlipNum[iVar])/cnt);
			      if(delt<=0) sum++;
			      else sum+=delt;
                              if(pivot <sum ){
				      iFlipCandidate = iVar;
				      return;
                              }
                          }
		   }
		   return;
	   }
   }

//-----------------------------

  fScoreSum = 0.0;
//new idea
   iClause = aFalseList[RandomInt(iNumFalse)];
   if(!isBigInstance && (iMaxClauseLen < 4 || iNumClauses < 3500)){
  // if(!isBigInstance){
     if(iNumFalse>2) iClause = aFalseList[RandomInt(iNumFalse)];
     else{
       //     iClause = aFalseList[RandomInt(iNumFalse)];
  	  if(ClauseAge[iClause] > (UINT32)(iStep-iStep/8)) iClause = aFalseList[RandomInt(iNumFalse)];
          else{
            if(iNumFalse == 2){ 
             int delta=ClauseAge[aFalseList[0]] - ClauseAge[aFalseList[1]];
             if( delta<0) delta=-delta;
             if(delta > 3000){// iClause = aFalseList[RandomInt(iNumFalse)];
             //else{
                UINT32 k=0;
	        for(unsigned int i=1; i<iNumFalse;i++){
                   if(ClauseAge[aFalseList[1]]<ClauseAge[aFalseList[k]]) k=i;
	        }
	        iClause = aFalseList[k];
             }
           }
         }
      }     
     ClauseAge[iClause]=(UINT32)iStep;	 
 }
 iClauseLen = aClauseLen[iClause];
//isBigInstance  
  if(iNumVars > 8000) if(iNumVars >= iClause)  aVarsFlipNum[iClause]=(UINT32)iStep/2;
 
 UINT32 maxflip,sum,maxdis,minflip;
 BOOL  usefreq;
//choose the oldest 
 UINT32 iBestAge= (UINT32)iStep;
 if(iNumFalse <= 2){// && (iMaxClauseLen <5 || iNumVars<=1300)){
	  pLit = pClauseLits[iClause];
          for(j = 0; j < iClauseLen; j++){
               iVar = GetVarFromLit(*pLit);
	       if( (UINT32)aVarLastChange[iVar] < iBestAge){
     	            iFlipCandidate = iVar;
	            iBestAge = (UINT32)aVarLastChange[iVar];
		}
                pLit++;
	  }
         if(iFlipCandidate) goto end;
	}
//refind:
//iMaxClauseLen < 4
 if(iNumFalse <30 && iNumClauses > 5000 && iMaxClauseLen>=4 && iNumVars<=1000){// ((iMaxClauseLen==3 && iNumVars<=7000) || && (iNumClauses > 5000 || iNumClauses > 10*iNumVars)){//30
        sum=maxflip=0;
        minflip=0x7fffffff;
        pLit = pClauseLits[iClause];
        for(j = 0; j < iClauseLen; j++){
           iVar = GetVarFromLit(*pLit);
	   sum+=aVarsFlipNum[iVar];
	   if(maxflip<aVarsFlipNum[iVar]) maxflip=aVarsFlipNum[iVar];
	   if(minflip > aVarsFlipNum[iVar]) minflip=aVarsFlipNum[iVar];
           pLit++;
        }
        maxflip++;		           
        maxdis=maxflip-(sum+iClauseLen-1)/iClauseLen;
        if(maxdis>10 && (maxflip-minflip > 400 || maxflip-minflip >2*iNumVars )) usefreq=true; 
        else usefreq=false;
   }
   else usefreq=false;
// 
  pLit = pClauseLits[iClause];
  for (j=0;j<iClauseLen;j++) {
    iVar = GetVarFromLit(*pLit);
    // note :: unlike in sparrow paper, negative score is "good"

    iScoreAdjust = aSparrowScore[iVar];
    
    if (iScoreAdjust > 10) iScoreAdjust = 10;
    else if (iScoreAdjust < 0) iScoreAdjust = 0;
   
    fScoreProb = aSparrowPreCalc[iScoreAdjust];
    FLOAT frqweight=1.0;
    if(usefreq) {
        frqweight = (FLOAT(maxflip-aVarsFlipNum[iVar])/FLOAT(maxdis)); 
  //      if(frqweight==0) printf("fScoreProb=%f frqweight=%f maxdis=%d max-min=%d \n",fScoreProb,frqweight,maxdis,maxflip-minflip);
    }
//    fBaseAgeProb = (iStep - aVarLastChange[iVar]) * fInvSparrowC3;
    fBaseAgeProb = (unsigned int)(iStep - aVarLastChange[iVar]) * fInvSparrowC3;
    fAgeProb = 1.0;
    for (k=0; k < iSparrowC2; k++) {
      fAgeProb *= fBaseAgeProb;
    }
    fAgeProb += 1.0;

    aSparrowWeights[j] = fScoreProb * fAgeProb *frqweight;
    fScoreSum += aSparrowWeights[j];

    pLit++;
  }

  fScorePos = RandomFloat()*fScoreSum;
  fScoreSum = 0.0;

  for (j=0;j<iClauseLen;j++) {
    fScoreSum += aSparrowWeights[j];
    if (fScorePos <= fScoreSum) {
      iFlipCandidate = GetVar(iClause,j);
      break;
    }
  }
//new idea
/*
  if(iNumFalse < 3 ){  
      UINT32 Ave=(FlipSum+iNumVars-1)/iNumVars;
      if(aVarsFlipNum[iFlipCandidate] > Ave*3){
         //    FlipSum -= (aVarsFlipNum[iFlipCandidate]-Ave);
             FlipSum -= Ave;
             aVarsFlipNum[iFlipCandidate] -= Ave;
             iClause = aFalseList[RandomInt(iNumFalse)];
             goto refind;
       }
   }
*/
end:
  
    if (RandomProb(iPs)) {
      SmoothSparrow();
	} else {
      ScaleSparrow();
	}
}

void SmoothSparrow() {
  
  UINT32 j;
  UINT32 iVar;
  UINT32 iClause;
  UINT32 iLoopMax;

  iLoopMax = iNumPenClauseList;

  for (j=0;j<iLoopMax;j++) {
    iClause = aPenClauseList[j];
    if (aNumTrueLit[iClause] > 0) {
      aClausePenaltyINT[iClause]--;
      iTotalPenaltyINT--;
      if (aClausePenaltyINT[iClause]==1) {
        aPenClauseList[aPenClauseListPos[iClause]] = aPenClauseList[--iNumPenClauseList];
        aPenClauseListPos[aPenClauseList[iNumPenClauseList]] = aPenClauseListPos[iClause];
      }
      if (aNumTrueLit[iClause]==1) {
        iVar = aCritSat[iClause];
        aSparrowScore[iVar]--;
		if ((!aVarIsGNovCandVar[iVar]) && (aSparrowScore[iVar] < 0 ) && (aVarLastChange[iVar] < iStep - 1)) {
				  aSparrowPromVars[iNumSparrowPromVars++] = iVar;
				  aVarIsGNovCandVar[iVar] = 1;
		 } 
      }
    }
  }
}

void ScaleSparrow() {
  UINT32 j;
  UINT32 k;
  UINT32 iVar;
  UINT32 iClause;
  LITTYPE *pLit;

  iTotalPenaltyINT += iNumFalse;

  for(j=0;j<iNumFalse;j++) {
       iClause = aFalseList[j];
       aClausePenaltyINT[iClause]++;
       if (aClausePenaltyINT[iClause]==2) {
         aPenClauseList[iNumPenClauseList] = iClause;
         aPenClauseListPos[iClause] = iNumPenClauseList++;
	   }
       pLit = pClauseLits[iClause];
       for (k=0;k<aClauseLen[iClause];k++) {
          iVar = GetVarFromLit(*pLit);
          aSparrowScore[iVar]--;
		  if ((!aVarIsGNovCandVar[iVar]) && (aSparrowScore[iVar] < 0 ) && (aVarLastChange[iVar] < iStep - 1)) {
				aSparrowPromVars[iNumSparrowPromVars++] = iVar;
				aVarIsGNovCandVar[iVar] = 1;
		  } 
          pLit++;
    }
  }
}

void FlipSparrow() {

  UINT32 j;
  UINT32 k;
  UINT32 *pClause;
  UINT32 iVar;
  LITTYPE litWasTrue;
  LITTYPE litWasFalse;
  LITTYPE *pLit;

  SINT32 iPenalty;

  UINT32 *pShareVar;

  if (iFlipCandidate == 0) return;
 
  //update configuration check
  aVarsConfChange[iFlipCandidate] = 0; //CCA sat
  aVarsFlipNum[iFlipCandidate]++;//new idea
  FlipSum++;

  pShareVar = pVarsShareClause[iFlipCandidate];
  for (j=0; j < aNumVarsShareClause[iFlipCandidate]; j++) {
    if (aSparrowScore[*pShareVar] < 0) {
      aVarIsGNovCandVar[*pShareVar] = 1;
    } else {
      aVarIsGNovCandVar[*pShareVar] = 0;
    }
    pShareVar++;
  }

  litWasTrue = GetTrueLit(iFlipCandidate);
  litWasFalse = GetFalseLit(iFlipCandidate);

  aVarValue[iFlipCandidate] = !aVarValue[iFlipCandidate];

  pClause = pLitClause[litWasTrue];
  for (j=0;j<aNumLitOcc[litWasTrue];j++) {
    iPenalty = aClausePenaltyINT[*pClause];
	
	aNumTrueLit[*pClause]--;
    if (aNumTrueLit[*pClause]==0) { 
      
      aFalseList[iNumFalse] = *pClause;
      aFalseListPos[*pClause] = iNumFalse++;

      aSparrowScore[iFlipCandidate] -= iPenalty;
      
      pLit = pClauseLits[*pClause];
      for (k=0;k<aClauseLen[*pClause];k++) {
        iVar = GetVarFromLit(*pLit);
        aSparrowScore[iVar] -= iPenalty;

        pLit++;

      }
    }
    if (aNumTrueLit[*pClause]==1) {
      pLit = pClauseLits[*pClause];
      for (k=0;k<aClauseLen[*pClause];k++) {
        if (IsLitTrue(*pLit)) {
          iVar = GetVarFromLit(*pLit);
          aSparrowScore[iVar] += iPenalty;
          aCritSat[*pClause] = iVar;
          break;
        }
        pLit++;
      }
    }
    pClause++;
  }

  pClause = pLitClause[litWasFalse];
  for (j=0;j<aNumLitOcc[litWasFalse];j++) {
    iPenalty = aClausePenaltyINT[*pClause];
    aNumTrueLit[*pClause]++;
    if (aNumTrueLit[*pClause]==1) {

      aFalseList[aFalseListPos[*pClause]] = aFalseList[--iNumFalse];
      aFalseListPos[aFalseList[iNumFalse]] = aFalseListPos[*pClause];

      pLit = pClauseLits[*pClause];
      for (k=0;k<aClauseLen[*pClause];k++) {
        iVar = GetVarFromLit(*pLit);
        aSparrowScore[iVar] += iPenalty;

        pLit++;

      }
      aSparrowScore[iFlipCandidate] += iPenalty;
      aCritSat[*pClause] = iFlipCandidate;
    }
    if (aNumTrueLit[*pClause]==2) {
      aSparrowScore[aCritSat[*pClause]] -= iPenalty;
    }
    pClause++;
  }

  pShareVar = pVarsShareClause[iFlipCandidate];
  for (j=0; j < aNumVarsShareClause[iFlipCandidate]; j++) {
    if (aSparrowScore[*pShareVar] < 0) {
      if (!aVarIsGNovCandVar[*pShareVar]) {
        aSparrowPromVars[iNumSparrowPromVars++] = *pShareVar;
        aVarIsGNovCandVar[*pShareVar] = 1;
      }
    }
   
	//update CCA sat
    aVarsConfChange[*pShareVar] = 1;

	pShareVar++;
  }
}

void CreateSparrowPromVars() {
  aSparrowPromVars = (UINT32 *) AllocateRAM((iNumVars+1) * sizeof(UINT32));
  aVarIsGNovCandVar = (BOOL *) AllocateRAM((iNumVars+1) * sizeof(BOOL));

  //CCA sat init
  int csize=(iNumVars+1) * sizeof(BOOL);
  aVarsConfChange =  (BOOL *) AllocateRAM( csize );
  UINT32 i;
  for(i=0; i<=iNumVars; i++) aVarsConfChange[i]=1;

  aVarsFlipNum =  (UINT32 *) AllocateRAM((iNumVars+1) * sizeof(UINT32));
  for(i=0; i<=iNumVars; i++) aVarsFlipNum[i]=0;

//    memset(aVarsConfChange,1, csize);
  ClauseAge = (UINT32 *) AllocateRAM((iNumClauses+1) * sizeof(UINT32));
  for(i=0; i<=iNumClauses; i++) ClauseAge[i]=0;
  FlipSum=0;
}

void InitSparrowPromVars() {

  UINT32 j;

  iNumSparrowPromVars = 0;

  for (j=1;j<=iNumVars;j++) {
    if (aSparrowScore[j] < 0) {
      aSparrowPromVars[iNumSparrowPromVars++] = j;
      aVarIsGNovCandVar[j] = 1;
    } else {
      aVarIsGNovCandVar[j] = 0;
    }
  }
}

void CreateSparrowWeights() {
  aSparrowWeights = (FLOAT *) AllocateRAM((iMaxClauseLen+1)*sizeof(FLOAT));
}

void CreateSparrowScore() {
  aSparrowScore = (SINT32 *) AllocateRAM((iNumVars+1)*sizeof(UINT32));
  aCritSat = (UINT32 *) AllocateRAM(iNumClauses*sizeof(UINT32));
}

void InitSparrowScore() {

  UINT32 j;
  UINT32 k;
  UINT32 iVar;
  LITTYPE *pLit;

  for (j=1;j<=iNumVars;j++) {
    aSparrowScore[j] = 0;
  }

  for (j=0;j<iNumClauses;j++) {
    if (aNumTrueLit[j]==0) {
      for (k=0;k<aClauseLen[j];k++) {
        aSparrowScore[GetVar(j,k)] -= aClausePenaltyINT[j];
      }
    } else if (aNumTrueLit[j]==1) {
      pLit = pClauseLits[j];
      for (k=0;k<aClauseLen[j];k++) {
        if IsLitTrue(*pLit) {
          iVar = GetVarFromLit(*pLit);
          aSparrowScore[iVar] += aClausePenaltyINT[j];
          aCritSat[j] = iVar;
          break;
        }
        pLit++;
      }
    }
  }
}

//------------------------------------PAW 
UINT32 iPAWSMaxInc;
PROBABILITY iPAWSFlatMove;

UINT32 iPawsSmoothCounter;

void PickPAWS() {
  
  UINT32 j;
  UINT32 iVar;
  SINT32 iScore;
  SINT32 iBestScore;
  UINT32 iLoopEnd;

  iNumCandidates = 0;
  iBestScore = SINT32MAX;

  /* look at all variables that appear in false clauses */

  for (j=0;j<iNumVarsInFalseList;j++) {
    iVar = aVarInFalseList[j];

    /* use cached value of breakcount - makecount */

    iScore = (SINT32) aBreakPenaltyINT[iVar] - (SINT32) aMakePenaltyINT[iVar];

    /* build candidate list of best vars */

    if (iScore <= iBestScore) {
      if (iScore < iBestScore) {
        iNumCandidates = 0;
        iBestScore = iScore;
      }

      /* using the "Monte Carlo" method, each variable appears
         'Make Count' times in the candidate list */

      iLoopEnd = iNumCandidates + aMakeCount[iVar];
      
      if (iLoopEnd >= iMaxCandidates) {
        ReportPrint1(pRepErr,"Unexpected Error: increase iMaxCandidates [%"P32"]\n",iMaxCandidates);
        AbnormalExit();
        exit(1);
      }

      while (iNumCandidates < iLoopEnd) {
        aCandidateList[iNumCandidates++] = iVar;
      }
    }
  }

  iFlipCandidate = 0;

  if (iBestScore < 0) {

    /* if improving step can be made, select flip candidate uniformly from candidate list */
    
    if (iNumCandidates > 1) {
      iFlipCandidate = aCandidateList[RandomInt(iNumCandidates)];
    } else {
      iFlipCandidate = *aCandidateList;
    }
  } else {
    
    if (iBestScore == 0) {

      /* if a flat / sideways step can be made, with probability (iPAWSFlatMove) 
         flip candidate from candidate list, otherwise it's a null flip */
    
      if (RandomProb(iPAWSFlatMove)) {
        if (iNumCandidates > 1) {
          iFlipCandidate = aCandidateList[RandomInt(iNumCandidates)];
        } else {
          iFlipCandidate = *aCandidateList;
        }
      }
    }
  }
}

void PostFlipPAWS() {

  if (iFlipCandidate) {
    return;
  }

  /* if a 'null flip' */

  /* Scale penalties */

//  ScalePAWS();

  /* smooth every iPAWSMaxInc Null Flips */

  iPawsSmoothCounter++;
  if (iPawsSmoothCounter > iPAWSMaxInc) {
   // SmoothPAWS();
    iPawsSmoothCounter = 0;
  }

}


/***** Trigger PenClauseList *****/

void CreatePenClauseList();
void InitPenClauseList() {
  iNumPenClauseList = 0;
  iPawsSmoothCounter = 0;
}

void CreatePenClauseList() {
  aPenClauseList = (UINT32 *) AllocateRAM(iNumClauses*sizeof(UINT32));
  aPenClauseListPos = (UINT32 *) AllocateRAM(iNumClauses*sizeof(UINT32));
}

void AddPAWS() {

  ALGORITHM *pCurAlg;

  pCurAlg = CreateAlgorithm("paws","",0,
    "PAWS: Pure Additive Weighting Scheme",
    "Thornton, Pham, Bain, Ferreira [AAAI 04]",
    "PickPAWS,PostFlipPAWS",
    "DefaultProcedures,Flip+MBPINT+FCL+VIF,PenClauseList",
    "default","default");
  
  AddParmUInt(&pCurAlg->parmList,"-maxinc","frequency of penalty reductions [default %s]","reduce (smooth) all clause penalties by 1~after every INT increases","",&iPAWSMaxInc,10);
  AddParmProbability(&pCurAlg->parmList,"-pflat","flat move probabilty [default %s]","when a local minimum is encountered,~take a 'flat' (sideways) step with probability PR","",&iPAWSFlatMove,0.15);

  CreateTrigger("PickPAWS",ChooseCandidate,PickPAWS,"","");
  CreateTrigger("PostFlipPAWS",PostFlip,PostFlipPAWS,"","");

  CreateTrigger("CreatePenClauseList",CreateStateInfo,CreatePenClauseList,"","");
  CreateTrigger("InitPenClauseList",InitStateInfo,InitPenClauseList,"","");
  CreateContainerTrigger("PenClauseList","CreatePenClauseList,InitPenClauseList");

}

#ifdef __cplusplus
}
#endif
