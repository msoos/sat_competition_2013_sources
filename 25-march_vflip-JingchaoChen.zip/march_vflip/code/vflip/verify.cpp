/*
 verify.cpp Copyright (c) 2013, Jingchao Chen, Donghua University,China.
*/

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include "verify.h"

#define CNF_CLS    0
#define XOR_CLS    1
#define DELETED    2
#define FROZE      3
#define FLAGBIT    3
#define MARKBIT    7

#define ABS(x) ((x)>0?(x):(-x))

void release_pps (PPS *pps);
void release_free_pps (PPS * & pps);
void release_occCls(PPS *pps);
void free_mem(int * & ptr);
void extend_solution(PPS *pps);

void verify_output(int *solution);
void init_weight();
void check(int sol[],Stack<int> *clause);
void readSATProblem(char *CNFfile, PPS * & pps);

/* 
 * Prints the current solution 
 */
void print_solution(int sol[],int numVar)
{   
    printf("v ");
    for(int i=1; i<=numVar; i++) if(sol[i]) printf("%d ", sol[i]);
    printf("\nv 0\n");
//    printf("c \nc Running time=%f \n", nowtime()-starttime);
}

extern char *filename;

void verify_output(int *solution)
{    PPS *s_pps;
     readSATProblem(filename,s_pps);
     for(int i=1; i<=s_pps->numVar; i++){ 
	    if(solution[i]==0) solution[i]=i;
     }
     check(solution,s_pps->clause);
     printf("c \ns SATISFIABLE\n");
	// getchar();
     print_solution(solution,s_pps->numVar);
     release_pps (s_pps);
}

void readSATProblem(char *CNFfile, PPS * & pps)
{
    int i,lastc,nextc,lit;
 
	FILE *fp=fopen(CNFfile,"r");
    if(fp==NULL) {
	   printf("c Cann't open file %s \n", CNFfile);
	   exit(1);
    }
    while ((lastc = fgetc(fp)) == 'c'){
	    while ((nextc = fgetc(fp)) != EOF && nextc != '\n');
    }
    ungetc(lastc,fp);
	int numatom,numClauses;
    if (fscanf(fp,"p cnf %i %i",&numatom,&numClauses) != 2) {
	     printf("c Bad input file \n");
	     exit(1);
    }

    pps=(struct PPS *) calloc (1, sizeof (PPS));
    pps->numClause=numClauses;
    pps->numVar=numatom;
    
    pps->clause=new Stack<int>; 
    Stack<int> * clsSAT=pps->clause;
    for(i = 0; i < numClauses; i++){
	     int clsbegin=clsSAT->nowpos();
	     clsSAT->push(0);
         do {
		    if (fscanf(fp,"%i ",&lit) != 1) {
		        printf("c wrong CNF proposition \n");
		        exit(0);
			}
	        if(lit != 0) {
         		clsSAT->push(lit);
				if(ABS(lit)>numatom){
                      printf("c ERROR - incorrect problem format or extraneous characters\n");
	                  exit(0);
				}
			}
		 } while(lit != 0);
 		 int len =clsSAT->nowpos()-clsbegin;
         (*clsSAT)[clsbegin]=(len<<FLAGBIT) | CNF_CLS;
	}
    fclose(fp);
}	

void check(int sol[],Stack<int> *clause)
{
     int len,sum,i,vi;

	 int *pcls=clause->begin();
	 int *pend=clause->end();
	 i=0;
  
	 while(pcls < pend){
                 len=*pcls;
		// int mark=len & MARKBIT;
		 len=len>>FLAGBIT;
		 int *lits=pcls+1;
    	         pcls+=len;
                 sum=0; i++;
                 for (; lits<pcls; lits++){
		     vi=*lits;
       	             int xi= vi < 0 ? -vi : vi; 
                     if(sol) {
			   if(sol[xi]==vi) sum+=1;
		      }
		 }
//		 printf (" s=%d ",sum);
		 if(sum==0 && sol) {
        	      printf ("c result something wrong at i=%d !!!!! \n",i);
		      exit(0);
                      int *lits=pcls+1-len;
		      for (; lits<pcls; lits++){
		           vi=*lits;
       	                   int xi= vi < 0 ? -vi : vi; 
                           printf("%d[%d] ",vi,sol[xi]);
		       }
		       exit(0);
  	          }
   }
   printf("c verified \n");
  // getchar();
}

void free_mem(int * & ptr)
{
	if(ptr) free(ptr);
	ptr=0;
}
void release_pps (PPS * pps)
{
	if(pps==0) return;
	if(pps->clause) {
		delete pps->clause;
		pps->clause=0;
	}
    release_occCls(pps);
	if(pps->clausePos){
		delete pps->clausePos;
		pps->clausePos=0;
	}
	free_mem(pps->unit);
	free_mem(pps->seen);
    free_mem(pps->outEquAtom);
    if(pps->n_inative) {
		free(pps->inaLit[0]);
		free(pps->inaLit);
		pps->n_inative=0;
    }
	if(pps->numXOR){
		pps->numVar=0;
		free(pps->Leq[0]);
		free(pps->Leq);
	}
    if(pps->inactiveVar){
		delete pps->inactiveVar;
		pps->inactiveVar=0;
	}
}

void release_free_pps (PPS * & pps)
{
	if(pps==0) return;
    release_pps (pps);
    free(pps);
	pps=0;
}

void release_occCls(PPS *pps) 
{
	if(pps->occCls){
		for(int i = 1; i <= pps->numVar; i++) {
	       pps->occCls[i].release();
	       pps->occCls[-i].release();
		}
	    pps->occCls-=pps->numVar;
	    free(pps->occCls);
        pps->occCls = 0;
	}
	if(pps->occBoth){
        for(int i = 1; i <= pps->numVar; i++) pps->occBoth[i].release();
	    free(pps->occBoth); 
        pps->occBoth=0;
	}
}
