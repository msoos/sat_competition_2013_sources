  ======================================================
  march_vflip is a hybird Solver based on March and vflipnum
        Developed by Jingchao Chen
  ------------------------------------------------------
  .....e-mail chen-jc [@] dhu.edu.cn
  ------------------------------------------------------

For compiling march_vflip: 
   ./build.sh

===================
USAGE:

binary/march_vflip BENCHNAME




